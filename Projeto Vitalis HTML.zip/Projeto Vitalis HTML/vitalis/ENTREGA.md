# Vitalis — Complementação e finalização (relatório de entrega)

O site existente foi mantido (mesmas cores, fontes Poppins/Rowdies, botões, cartões, sombras, gradiente, cabeçalho e rodapé). Tudo o que foi criado reaproveita os componentes e tokens que já existiam. Os fluxos antigos do paciente continuam funcionando e passam nos mesmos testes.

Contas de demonstração (senha `Vitalis@123`, botões **Preencher** na tela de login): paciente `demo@vitalis.com`, profissional `profissional@vitalis.com`, administrador `admin@vitalis.com`.

---

## 1. Páginas adicionadas

**Área do profissional** (`/profissional/*`, somente papel “profissional”)

| Rota | Página |
| --- | --- |
| `/profissional` | Visão geral: saudação, resumo do dia, indicadores, agenda de hoje, próximos atendimentos, gráfico dos próximos 7 dias, ocupação, notificações e atalhos |
| `/profissional/onboarding` | Cadastro em etapas: Cadastro → Dados profissionais → Especialidade → Serviços → Disponibilidade → Perfil → Revisão → Publicação |
| `/profissional/agenda` | Agenda em visão Dia, Semana, Mês e Lista (hoje, próximos, anteriores), com legenda de situações |
| `/profissional/horarios` | Horário semanal, intervalo, bloqueios, horários especiais e prévia de 7 dias |
| `/profissional/servicos` | Meus serviços |
| `/profissional/clientes` | Clientes e histórico com o profissional |
| `/profissional/financeiro` | Financeiro (valores simulados) |
| `/profissional/notificacoes` | Central de notificações |
| `/profissional/perfil` | Perfil profissional com prévia ao vivo |
| `/profissional/configuracoes` | Conta, visibilidade, agenda, privacidade, notificações, segurança e sessão |

**Administração** (`/admin/*`, somente papel “admin”): Visão geral · Profissionais (moderação) · Usuários · Serviços · Agendamentos · Pagamentos · Solicitações · Notificações · Configurações.

**Paciente e público:** `/profissionais` (busca avançada) · `/profissionais/:id` (perfil público) · `/favoritos` · `/notificacoes` · `/acesso-negado` (403).

## 2. Funcionalidades adicionadas

- **Papéis e autorização real:** paciente, profissional e administrador. Cada operação da camada de serviços confere quem chama e o papel registrado (`FORBIDDEN`/`UNAUTHENTICATED`); a interface mostra a página 403. Profissional só altera o próprio perfil; ninguém agenda com o próprio perfil; administração não agenda.
- **Agenda do profissional:** situações Confirmado, Aguardando confirmação, Concluído, Cancelado e Indisponível (bloqueios/intervalo); detalhes do atendimento, cancelamento com motivo obrigatório (cliente avisado e reembolsado no modo simulado), registro de presença/falta, arquivo .ics. O contato do cliente só aparece enquanto houver agendamento ativo.
- **Gestão de horários:** dias e expediente, intervalo, intervalo entre inícios (30/60 min), copiar horário para os dias ativos, bloqueios (dia inteiro ou parcial) e horários especiais. O sistema impede conflitos: um horário só fica livre se o atendimento inteiro couber sem sobrepor consulta, bloqueio ou intervalo; bloqueios sobre consultas marcadas são recusados; mudanças que deixariam consultas fora do expediente pedem confirmação.
- **Meus serviços:** adicionar, editar, ativar/desativar, visualizar como o cliente vê e excluir; nome (sem duplicados), categoria do catálogo, descrição, duração e preço com validação. Serviço com histórico não pode ser excluído.
- **Clientes:** busca, filtros por situação, histórico com o profissional. Sem prontuário e sem dados clínicos.
- **Financeiro simulado:** filtros Hoje / Semana / Mês / Personalizado, recebido, a receber, aguardando pagamento, reembolsado, saldo estimado, divisão Pix/cartão, taxas, gráfico mensal e exportação CSV — sempre identificado como demonstração.
- **Notificações dentro do Vitalis:** sino com contador e central com filtros (todas, não lidas, importantes), marcar como lida/não lida, destacar e excluir. São geradas por eventos reais do sistema (novo agendamento pago, cancelamento, remarcação, verificação de perfil, suspensão, solicitação resolvida) e por lembretes 24h antes.
- **Perfil profissional:** foto, tratamento, nome, profissão, registro no conselho, especialidade, área do catálogo, modalidade, endereço/região, apresentação, formação, experiência e contato público opcional, com prévia ao vivo. Não há sistema de avaliações: perfis novos aparecem como “Novo no Vitalis”.
- **Onboarding** com indicador de progresso, validação por etapa, retomada de onde parou e envio para verificação.
- **Administração:** indicadores, verificação de profissionais (aprovar, pedir ajustes com justificativa, suspender, reativar), usuários (suspender/reativar, conta própria protegida), catálogo (ativar/desativar serviços), agendamentos com filtros e histórico, pagamentos simulados, solicitações de suporte (situação e nota interna), aviso global no topo do site e restauração dos dados de demonstração.
- **Para o paciente:** busca avançada (serviço, cidade, modalidade, preço, dia da semana, ordenação), perfil público com serviços e próximas datas livres, favoritos, escolha do serviço específico do profissional (preço e duração próprios) e sugestões explicáveis no dashboard.
- **Estados de interface:** carregamento (skeletons), vazio, erro com “tentar novamente”, sucesso (toasts), botões desabilitados durante o envio e aviso de modo offline.

## 3. Funcionalidades modificadas

- **Login:** três contas de demonstração; o botão “Sou administrador” explica o acesso e preenche a conta de exemplo.
- **Cadastro de profissional:** agora leva ao onboarding (o aviso “em desenvolvimento” foi removido do cadastro e da Central de Ajuda).
- **Agendamento:** horários seguem a disponibilidade configurada pelo profissional e a duração do serviço escolhido, com antecedência mínima de 1 hora; cidades vêm dos profissionais publicados; serviços desativados pela administração somem do catálogo.
- **Revisão, pagamento e detalhes da consulta:** mostram o serviço escolhido, a duração e o intervalo de horário; a consulta informa quando foi cancelada pelo profissional ou liberada por falta de pagamento.
- **Remarcação** respeita a duração da consulta.
- **Pagamento pendente** cujo horário chegou é liberado automaticamente.
- **Dashboard do paciente:** atalhos “Encontrar profissional” e “Favoritos” e a seção “Sugestões para você”.
- **Perfil do paciente:** opção “Lembretes no Vitalis” e aviso de que e-mail, SMS e WhatsApp ficam salvos só como preferência (não há envio).
- **Cabeçalho:** menu e menu da conta por papel, sino de notificações; avatares com foto, iniciais ou o emoji dos perfis fictícios.
- **Textos da landing** ajustados para não prometer além do que existe (LGPD e recomendações).
- `/painel`, `/perfil` e `/notificacoes` levam profissional e administrador à seção equivalente da sua área.

## 4. Backend

Continua **sem servidor**. A camada `src/services` faz o papel de backend da demonstração, com funções assíncronas, erros padronizados (`ApiError` com `code` e `field`) e latência simulada:

- novos serviços: `session` (autorização), `professionalService`, `adminService`, `notificationService`, `favoriteService`, `proModel` (regras de agenda e serviços) e `seed` (dados iniciais e migração);
- serviços existentes ampliados: `authService`, `catalogService`, `appointmentService`, `paymentService`, `supportService`.

As páginas falam apenas com essas funções; o README lista os endpoints sugeridos para trocar o corpo delas por chamadas HTTP. A verificação de papéis organiza as regras, mas, por rodar no navegador, **não substitui um servidor**: em produção, a mesma lógica precisa estar na API.

## 5. Banco de dados

Banco local (`localStorage`, chave `vitalis:db:v1`) com esquema versão 2 e **migração não destrutiva** da versão anterior (testada: usuários, consultas, pagamentos e solicitações são preservados).

- **Novas coleções:** `professionals` (perfil, serviços oferecidos, disponibilidade, situação de verificação), `notifications`, `favorites`, `settings` (aviso global, serviços desativados).
- **Campos novos:** usuários (`status`, `professionalId`, `photo`, `lastLoginAt`, preferência de lembretes); consultas (`offeringId`, `offeringName`, `duration`, `clientName`, `canceledBy`, `cancelReason`, `attendance`, `reminderSent`); pagamentos (`professionalId`); solicitações (`status`, `adminNote`).
- Nenhum dado clínico é armazenado. Senhas continuam com hash PBKDF2 e sal; dados de cartão não são guardados (só bandeira e 4 últimos dígitos).

## 6. Novas ideias

**Implementadas (propostas minhas, além do pedido):** prévia “como o cliente vê” no perfil e nos serviços; sugestões explicáveis com o motivo (“Porque você agendou…”); exportação CSV do financeiro; aviso global da administração; restauração dos dados de demonstração; contato público opcional; registro de presença/falta.

**Sugeridas para uma próxima versão:** avaliações verificadas (só após consulta concluída); lista de espera para horários lotados; lembretes por e-mail/WhatsApp pelo servidor; confirmação de presença pelo paciente; sincronização com Google Agenda; videochamada integrada para atendimentos online; repasse automático ao profissional com split de pagamento; relatórios mensais em PDF.

## 7. Pendências

- Backend e banco reais (API com autenticação, mesmas regras de permissão no servidor, dados compartilhados entre dispositivos).
- Pagamentos reais (gateway, Pix, split e repasse ao profissional); hoje tudo é simulado e marcado como tal.
- Envio de e-mail, SMS e WhatsApp.
- Verificação automática do registro no conselho profissional (hoje a aprovação é manual).
- Revisão jurídica/LGPD (termos para profissionais, política de privacidade, consentimentos).
- Fotos ficam no `localStorage` (limite de alguns MB por site).
- Testes em Safari/iOS e com leitores de tela reais (os testes automatizados usam Chromium).
- O pacote JavaScript tem cerca de 730 kB; dividir o código por área (carregamento sob demanda) melhoraria o primeiro acesso.

---

## Verificação

- `tests/e2e_fluxos.py` (fluxos originais do paciente) e `tests/e2e_perfis.py` (profissional, administração, permissões, teclado, celular 390 px, tablet 820 px e migração): todos passaram, **0 erros no console**.
- Build de produção e `docs/index.html` (arquivo único) gerados sem erros; código formatado com Prettier.
