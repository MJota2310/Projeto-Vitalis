# Vitalis — aplicação web

Plataforma de agendamento de serviços de saúde e bem-estar, construída a partir das telas do Figma (exportação HTML/CSS) e do vídeo do protótipo.

> Relatório da complementação (páginas, funcionalidades, backend, banco, ideias e pendências): **[ENTREGA.md](ENTREGA.md)**.

Três perfis de acesso: **paciente** (agenda e paga consultas), **profissional** (agenda, horários, serviços, clientes, financeiro, perfil público) e **administrador** (moderação, usuários, catálogo, agendamentos, pagamentos, suporte e configurações).

- **Stack:** React 18 · Vite 5 · React Router 6 (HashRouter) · CSS puro com design tokens
- **Dados:** camada de serviços simulada com `localStorage` (modo demonstração), pronta para ser trocada por uma API real
- **Fontes e ícones:** Rowdies, Poppins, Montserrat, Inter, Crimson Text e Open Sans (via `@fontsource`, servidas localmente) + Material Symbols (os mesmos ícones das telas originais)

---

## Para ver o site (sem instalar nada)

Abra o arquivo **`docs/index.html`** com dois cliques. Ele contém o site inteiro (código, fontes e imagens) e funciona até sem internet.

> O `index.html` que fica na raiz do projeto é o **código-fonte**: aberto com dois cliques ele não carrega (o navegador bloqueia os arquivos de código). Por isso existe a pasta `docs`.

## Publicar no GitHub Pages (passo a passo)

1. Em [github.com](https://github.com), clique em **+ → New repository**, dê o nome `vitalis`, marque **Public** e clique em **Create repository**.
2. Na página do repositório vazio, clique no link **uploading an existing file**.
3. Abra a pasta `vitalis` no seu computador e arraste **a pasta `docs`** para a página. Clique em **Commit changes**.
4. Clique em **Add file → Upload files** e arraste **todo o resto** do conteúdo da pasta `vitalis` (pastas `src`, `public`, `scripts`, `tests` e os arquivos soltos). Clique em **Commit changes**.
   - Arraste o **conteúdo** da pasta, não a pasta `vitalis` em si.
   - O GitHub aceita até 100 arquivos por envio; por isso são dois envios.
5. Vá em **Settings → Pages**. Em **Source**, escolha **Deploy from a branch**; em **Branch**, escolha `main` e a pasta **`/docs`**. Clique em **Save**.
6. Espere 1 a 2 minutos e recarregue a página. O endereço aparece no topo: `https://SEU-USUARIO.github.io/vitalis/`.

## Para programar (opcional)

Precisa do [Node.js](https://nodejs.org) instalado. No terminal, dentro da pasta do projeto:

```bash
npm install          # instala as dependências (só na primeira vez)
npm run dev          # abre o site em modo de desenvolvimento: http://localhost:5173
npm run build:single # gera de novo o docs/index.html depois de mudar o código
npm run build        # build em vários arquivos (dist/), precisa de servidor
npm run preview      # pré-visualiza o build de dist/
npm run format       # formata o código com Prettier
```

Depois de alterar o código, rode `npm run build:single` e envie o novo `docs/index.html` para o GitHub (**Add file → Upload files**, substituindo o antigo).

O roteamento usa `HashRouter` (`/#/servicos`), então o site funciona em qualquer hospedagem estática (GitHub Pages, Netlify, Vercel) sem configurar reescrita de URLs.

## Roteiro para apresentar (≈ 5 minutos)

1. **Início:** mostre o header fixo, clique em "Como funciona" e "Serviços" (rolagem suave) e passe o mouse nos botões e cards.
2. **Serviços:** clique em "Ver todos os serviços" e troque os filtros (Medicina 8 · Terapias 3 · Bem-estar 5). Busque "carlos".
3. **Agendamento:** em Cardiologia, clique em "Agendar" com o Dr. Carlos Silva, escolha data e horário e clique em "Confirmar Agendamento". O site pede login.
4. **Login:** clique em "Preencher" e em "Entrar". A seleção do agendamento continua lá. Revise e vá para o pagamento.
5. **Pagamento:** use o cartão de teste **recusado** (tela de erro), clique em "Tentar novamente" e pague com **PIX** (tela de aprovado).
6. **Área do usuário:** mostre o Dashboard, a lista de Consultas com filtros e os detalhes (remarcar/cancelar). Termine no Perfil e na Central de Ajuda (chat).
7. **Profissional:** saia, entre com a conta **Profissional** (botão "Preencher" correspondente) e mostre a Visão geral, a Agenda (dia/semana/mês/lista), Horários (crie um bloqueio), Meus serviços e o Financeiro (marcado como simulado).
8. **Administração:** entre com a conta **Administrador**, aprove o cadastro pendente em Profissionais e publique um aviso em Configurações (ele aparece no topo do site).

Dicas: abra o site uma vez antes da aula; para começar do zero, use uma **janela anônima**; leve o `docs/index.html` num pendrive como plano B (funciona sem internet).

---

## Dados de demonstração

| O quê | Valor |
| --- | --- |
| Paciente | `demo@vitalis.com` · `Vitalis@123` |
| Profissional | `profissional@vitalis.com` · `Vitalis@123` (Dr. Roberto Alves, perfil publicado) |
| Administrador | `admin@vitalis.com` · `Vitalis@123` |
| Atalho | botões **Preencher** de cada conta na tela de login |
| Cartão aprovado | `4242 4242 4242 4242` |
| Cartão recusado | `4000 0000 0000 0002` |
| PIX | “Já fiz o pagamento” aprova; “Simular pagamento não identificado” recusa |

- Tudo fica salvo **somente no navegador** (`localStorage`). Para zerar, use **Administração → Configurações → Restaurar dados iniciais** ou limpe os dados do site no navegador.
- Os clientes que aparecem na agenda do profissional (`@exemplo.com`) são fictícios e **não conseguem entrar**. Há também um cadastro profissional pendente de verificação (Dra. Lívia Andrade) para testar a moderação.
- Bancos salvos pela versão anterior são **migrados sem perder dados** (usuários, consultas, pagamentos e solicitações são mantidos).
- Senhas são guardadas apenas como **hash PBKDF2-SHA256 com sal** — nunca em texto puro.
- **Nenhum dado de cartão é armazenado**: o pagamento guarda só bandeira, 4 últimos dígitos, valor e status.
- As telas de pagamento exibem claramente que se trata de um **ambiente de demonstração** (nenhuma cobrança real).
- Adicione `?fast` antes do `#` na URL (ex.: `http://localhost:5173/?fast#/`) para desativar a latência simulada da API (útil em testes automatizados).

---

## Mapa de navegação

```
/                         Landing (Início · Como funciona · Serviços · Para profissionais · Diferenciais · Depoimentos · CTA)
├─ /servicos              Todos os serviços — filtros Todas(12) / Bem-estar(5) / Terapias(3) / Medicina(8) + busca
│  └─ /servicos/:slug     Detalhe do serviço → profissionais → "Agendar"
├─ /agendar               Etapas 1–3: serviço → profissional → data e horário
│  └─ /agendar/revisao    Etapa 4: revisão  (exige login — a seleção é preservada)
├─ /pagamento/:id         Etapa 5: cartão ou PIX
│  ├─ /pagamento/:id/aprovado
│  └─ /pagamento/:id/recusado  → "Tentar novamente" volta para /pagamento/:id
├─ /entrar · /cadastro    Login / criação de conta (usuário ou profissional)
├─ /painel                Dashboard (próxima consulta, estatísticas, histórico, pagamentos)
├─ /consultas             Minhas consultas (“Users Page” do Figma) — filtros, busca, cancelar
│  └─ /consultas/:id      Detalhes, histórico, pagamento, remarcar, cancelar, comprovante, .ics
├─ /perfil                Dados pessoais (editar) · ?aba=configuracoes (senha, 2 etapas, notificações)
├─ /ajuda                 Central de ajuda: FAQ com busca, chat, tutoriais, formulário de contato
├─ /termos · /privacidade Documentos legais
├─ /profissionais         Busca avançada (serviço, cidade, modalidade, preço, dia, ordenação)
│  └─ /profissionais/:id  Perfil público (serviços e valores, próximas datas livres, favoritar, agendar)
├─ /favoritos             Profissionais salvos
├─ /notificacoes          Central de notificações (paciente)
├─ /profissional          Área do profissional (somente papel "profissional")
│  ├─ /onboarding         Cadastro em etapas → envio para verificação
│  ├─ /agenda             Dia · Semana · Mês · Lista (?visao=&data=)
│  ├─ /horarios           Horário semanal, intervalos, bloqueios e horários especiais, prévia
│  ├─ /servicos           Meus serviços (nome, categoria, duração, preço, ativo)
│  ├─ /clientes           Clientes e histórico (?cliente=)
│  ├─ /financeiro         Valores simulados por período + exportação CSV
│  ├─ /notificacoes · /perfil · /configuracoes
├─ /admin                 Administração (somente papel "admin")
│  ├─ /profissionais      Moderação (aprovar, pedir ajustes, suspender, reativar)
│  ├─ /usuarios · /servicos · /agendamentos · /pagamentos
│  ├─ /solicitacoes · /notificacoes · /configuracoes
├─ /acesso-negado         Página 403
└─ atalhos: /como-funciona · /para-profissionais · /contato · /faq
```

Rotas privadas redirecionam para o login e **voltam ao destino** após entrar. Quem entra com um papel sem permissão vê a página **403 — Acesso negado** (e não apenas um menu escondido). `/painel`, `/perfil` e `/notificacoes` levam profissionais e administradores para a seção equivalente da sua área.

### Perfis e permissões

| Recurso | Paciente | Profissional | Admin |
| --- | :-: | :-: | :-: |
| Agendar, pagar, consultas, favoritos | ✓ | ✓ (como cliente, nunca com o próprio perfil) | — |
| Área do profissional (`/profissional/*`) | — | ✓ (somente o próprio perfil) | — |
| Administração (`/admin/*`) | — | — | ✓ |

A regra fica na **camada de serviços** (`src/services/session.js`): cada função descobre quem chama pela sessão e confere o papel no cadastro (`requireUser`, `assertSelf`, `requireProfessional`). Chamar uma função de administrador com outro papel gera `FORBIDDEN`, mesmo sem passar pela tela.

### Menus

- **Visitante:** INÍCIO · COMO FUNCIONA · SERVIÇOS · PARA PROFISSIONAIS · CONTATO (rolagem suave até as seções, como no protótipo) + ENTRAR / Criar conta.
- **Paciente:** Início · Agende · Dashboard · Consultas · Suporte (menu das telas internas do Figma) + sino de notificações + menu do avatar (favoritos, notificações, perfil, configurações, sair).
- **Profissional:** Início · Painel · Agenda · Clientes · Suporte + menu lateral da área (vira faixa rolável no celular).
- **Administrador:** Início · Painel · Profissionais · Agendamentos · Solicitações + menu lateral da administração.
- **Celular (≤ 1100 px):** menu lateral (drawer) com foco preso e fechamento por Esc.

---

## Telas do Figma → implementação

| Arquivo original | Implementação |
| --- | --- |
| `projetoVitalis Landing.html` | `pages/Home/HomePage.jsx` |
| `todos_os_serviços.html` + `frame_tudo` / `opções_*` | `pages/Services/ServicesPage.jsx` (filtros dinâmicos) |
| `agendar.html` + `confirmaragendamento.html` | `pages/Booking/BookingPage.jsx` (painel lateral de data/horário) |
| `pagamento.html` + `pix.html` | `pages/Payment/PaymentPage.jsx` |
| `aprovação_de_pagamento.html` / `reprovação_de_pagamento.html` | `pages/Payment/PaymentResultPage.jsx` |
| `frame_entrar_usuario.html` / `frame_criar_conta.html` | `pages/Auth/LoginPage.jsx` / `RegisterPage.jsx` |
| `PaginadoUsuario.html` (“Users Page”) | `pages/Account/AppointmentsPage.jsx` |
| `perfilusuario.html` + `frame_segurança.html` | `pages/Account/ProfilePage.jsx` (abas) |
| `frame_central_de_ajuda.html` | `pages/Help/HelpPage.jsx` |
| — (novas, exigidas pelos fluxos) | Dashboard, detalhe do serviço, revisão, detalhe da consulta, termos, privacidade, 404 |
| — (complementação) | `pages/Pro/*` (área do profissional), `pages/Admin/*` (administração), `pages/Professionals/*` (busca, perfil público, favoritos), `pages/Notifications/*`, `pages/AccessDeniedPage.jsx` |

---

## Arquitetura

```
src/
├─ assets/          imagens originais do Figma (logo, redes sociais, fundos, badges) + icons.js
├─ components/
│  ├─ layout/       Header, Footer, Layout, RequireAuth/GuestOnly, navegação
│  ├─ ui/           Button, Icon, Field, Modal, Accordion, Feedback (empty/erro/skeleton/badges)
│  ├─ services/     ServiceCard
│  ├─ booking/      ProfessionalCard, FavoriteButton, DatePicker, TimeSlots, Stepper, OrderSummary
│  ├─ account/      AppointmentCard, modais de cancelar/remarcar, AccountSettings (blocos de conta)
│  └─ panel/        PanelLayout (menu lateral), KPIs, gráficos leves (colunas, barras, medidor), tabelas
├─ context/         AuthContext, BookingContext (rascunho no sessionStorage), ToastContext
├─ data/            catálogo (serviços, profissionais), conteúdo, FAQ, textos legais
├─ hooks/           useReveal, useAsync, useForm, useFocusTrap, useScrollSpy, useSectionNav…
├─ pages/           uma pasta por área, cada uma com seu CSS
├─ services/        API simulada: session (autorização), auth, catálogo, consultas, pagamentos, suporte,
│                   professional (área do profissional), admin, notification, favorite, proModel
│                   (regras de agenda/serviços), seed + migração do banco, storage, db
├─ styles/          tokens.css, base.css, animations.css, ui.css, cards.css
└─ utils/           formatação pt-BR, validações, máscaras, hash de senha, downloads (.ics/.txt)

scripts/gen-icons.py   regenera src/assets/icons.js a partir de @material-symbols/svg-400
tests/e2e_fluxos.py    testes ponta a ponta do paciente (Playwright)
tests/e2e_perfis.py    profissional, administração, permissões, celular/tablet, teclado e migração
```

### Integração com um backend real

Todas as páginas falam **apenas** com `src/services/*`. Cada função já é assíncrona e lança `ApiError` com `code`/`field`, então basta trocar o corpo por chamadas HTTP:

| Serviço | Funções | Endpoint sugerido |
| --- | --- | --- |
| `authService` | `login`, `register`, `logout`, `updateProfile`, `changePassword`, `requestPasswordReset` | `/auth/*`, `/me` |
| `catalogService` | `listServices`, `listProfessionals`, `fetchSlots` | `/services`, `/professionals`, `/professionals/:id/slots` |
| `appointmentService` | `listAppointments`, `getAppointment`, `createAppointment`, `cancelAppointment`, `rescheduleAppointment` | `/appointments` |
| `paymentService` | `payWithCard`, `createPixCharge`, `confirmPix`, `listPayments` | provedor de pagamento (Stripe, Mercado Pago, Pagar.me…) via backend |
| `supportService` | `createTicket`, `askAssistant` | `/support/tickets` |
| `professionalService` | perfil, serviços, disponibilidade, agenda, clientes, financeiro, visão geral | `/pro/me`, `/pro/offerings`, `/pro/availability`, `/pro/appointments`… |
| `adminService` | indicadores, usuários, moderação, catálogo, agendamentos, pagamentos, solicitações, aviso | `/admin/*` |
| `notificationService` / `favoriteService` | notificações, favoritos, sugestões | `/me/notifications`, `/me/favorites` |

No servidor, `session.js` vira um middleware de autenticação/autorização: as mesmas verificações de papel e de dono do registro precisam rodar na API.

---

## Regras de negócio aplicadas (vindas do material)

- **Taxa de serviço:** R$ 10,00 por consulta (tela de pagamento).
- **Horários:** cada profissional define dias, expediente, intervalo, bloqueios e horários especiais. Um horário só fica livre se o atendimento inteiro (duração do serviço escolhido) couber sem sobrepor outra consulta, bloqueio ou intervalo. Antecedência mínima de 1 hora e janela de 45 dias.
- **Serviços do profissional:** nome, categoria do catálogo, duração (30–120 min) e preço (R$ 20–5.000). Serviços com histórico não podem ser excluídos, só desativados.
- **Pagamento pendente:** se o horário chegar sem pagamento, a reserva é liberada automaticamente.
- **Cancelamento pelo profissional:** exige motivo; o cliente recebe reembolso integral (simulado) e uma notificação.
- **Moderação:** um profissional só aparece nas buscas depois de aprovado pela administração; pedir ajustes exige justificativa.
- **Garantia de reembolso:** cancelamento com 24h de antecedência → reembolso total (tela de pagamento). Com menos de 24h o cancelamento é permitido, mas sem reembolso, e o usuário é avisado antes.
- **Remarcação:** permitida até 24h antes (mesma regra de antecedência).
- **Confirmação:** a consulta só é confirmada após o pagamento aprovado; antes disso fica como “Pagamento pendente”.
- **Status:** Pagamento pendente · Aguardando (confirmada) · Concluída · Cancelada. Consultas confirmadas cujo horário já passou viram “Concluída”.

---

## Animações e microinterações

Reproduzidas do vídeo do protótipo (transições de ~300 ms, ease-out):

- Header fixo com rolagem suave até as seções e destaque da seção ativa.
- Botão contorno → preenche com o gradiente; botão cheio → vira contorno; CTA branco → fundo verde-claro com a seta deslizando.
- Cards de serviço, profissionais e depoimentos sobem com sombra; blocos de “Nossos diferenciais” ganham cor.
- Links do menu e do rodapé ficam verdes; ícones sociais crescem.
- Entrada das seções ao rolar, linhas do card do hero em sequência, blobs decorativos flutuando.
- Skeletons, spinners em botões, modal de processamento, check desenhado no pagamento aprovado e “shake” no recusado.
- Tudo respeita `prefers-reduced-motion`.

---

## Acessibilidade e responsividade

- HTML semântico, link “Pular para o conteúdo”, foco visível, rótulos em todos os campos, mensagens de erro com `role="alert"`, modais com foco preso e Esc.
- Auditoria automática (axe-core) sem violações nas páginas principais.
- **Contraste:** textos pequenos usam tons derivados da paleta (`--green-text`, `--teal-text`, `--cyan-text`) e os botões com texto branco usam uma versão mais profunda do gradiente (`--grad-action`) para atingir 4.5:1. O gradiente original do Figma (`--grad-brand`) continua em ilustrações, ícones e elementos decorativos. Para usar o gradiente original também nos botões, basta trocar `--grad-action` em `src/styles/tokens.css`.
- Layouts com Grid/Flexbox, testados em 390 px, 820 px e 1366 px, sem rolagem horizontal. No celular, o menu lateral dos painéis vira uma faixa rolável, as tabelas viram cartões e os filtros da busca abrem como painel inferior.

---

## Testes realizados

Testes ponta a ponta automatizados (Playwright) cobrindo:

1. Início → Serviços (filtros e busca) → Serviço → Agendamento → login exigido → cadastro → revisão com seleção preservada.
2. Criar conta (validações, e-mail duplicado) → Dashboard → Perfil (editar dados, trocar senha, notificações) → sair → rota protegida.
3. Pagamento: validação do cartão (Luhn), recusa → tentar novamente → PIX (copiar código) → aprovado → detalhes.
4. Dashboard → Consultas (filtros) → Detalhes → Remarcar → Cancelar com reembolso.
5. Rodapé, Central de ajuda (busca no FAQ, chat, formulário de contato), termos, privacidade, FAQ e 404.

6. **Perfis e permissões** (`tests/e2e_perfis.py`): visitante/paciente bloqueados em `/profissional` e `/admin` (403) e nos serviços (`FORBIDDEN`); busca avançada, perfil público, favoritos e agendamento de um serviço específico; profissional (visão geral, agenda nas 4 visões, bloqueio, validação de horários, CRUD de serviços, clientes, financeiro, perfil, pausar/reativar); cadastro de profissional pelo onboarding até o envio; administração (aprovar, pedir ajustes, suspender conta, desativar serviço, aviso global, solicitações); teclado; páginas em 390 px e 820 px sem rolagem horizontal; migração de um banco da versão anterior.

Resultado: todos os fluxos passaram, sem erros ou avisos no console. Instruções no topo de cada arquivo.

---

## Limitações conhecidas

- Não há backend: contas, consultas e pagamentos existem apenas no navegador de quem usa.
- E-mails (confirmação, recuperação de senha) e SMS/WhatsApp **não são enviados**; as telas deixam isso explícito.
- Login com Google/Facebook não faz parte do material; os botões informam que estão indisponíveis na demonstração.
- As permissões são verificadas na camada de serviços, mas como tudo roda no navegador, uma pessoa técnica pode alterar o `localStorage`. Em produção a mesma lógica precisa ficar em uma API.
- Não há verificação automática do registro no conselho profissional; a aprovação é manual (administração).
- Fotos enviadas são reduzidas para 256 px e guardadas no `localStorage` (limite de alguns MB por site).
- Avaliações de clientes não existem nesta versão: as notas exibidas são dos perfis fictícios do catálogo; perfis novos aparecem como “Novo no Vitalis”.
- O Vitalis não guarda prontuários nem dados clínicos.
- “Baixar Receita” gera um documento de exemplo, sem validade médica.
- O código PIX é o fictício do protótipo e o QR Code é marcado como demonstração.
