import { HashRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { BookingProvider } from './context/BookingContext';
import Layout, { GuestOnly, RequireAuth, RoleHome } from './components/layout/Layout';

import HomePage from './pages/Home/HomePage';
import ServicesPage from './pages/Services/ServicesPage';
import ServiceDetailPage from './pages/Services/ServiceDetailPage';
import LoginPage from './pages/Auth/LoginPage';
import RegisterPage from './pages/Auth/RegisterPage';
import BookingPage from './pages/Booking/BookingPage';
import BookingReviewPage from './pages/Booking/BookingReviewPage';
import PaymentPage from './pages/Payment/PaymentPage';
import PaymentResultPage from './pages/Payment/PaymentResultPage';
import DashboardPage from './pages/Account/DashboardPage';
import AppointmentsPage from './pages/Account/AppointmentsPage';
import AppointmentDetailPage from './pages/Account/AppointmentDetailPage';
import ProfilePage from './pages/Account/ProfilePage';
import HelpPage from './pages/Help/HelpPage';
import LegalPage from './pages/Legal/LegalPage';
import NotFoundPage from './pages/NotFoundPage';
import AccessDeniedPage from './pages/AccessDeniedPage';
import NotificationsPage, { EmbeddedNotificationsPage } from './pages/Notifications/NotificationsPage';
import ProfessionalsPage from './pages/Professionals/ProfessionalsPage';
import ProfessionalProfilePage from './pages/Professionals/ProfessionalProfilePage';
import FavoritesPage from './pages/Professionals/FavoritesPage';

import ProLayout from './pages/Pro/ProLayout';
import ProOverviewPage from './pages/Pro/ProOverviewPage';
import ProAgendaPage from './pages/Pro/ProAgendaPage';
import ProSchedulePage from './pages/Pro/ProSchedulePage';
import ProServicesPage from './pages/Pro/ProServicesPage';
import ProClientsPage from './pages/Pro/ProClientsPage';
import ProFinancePage from './pages/Pro/ProFinancePage';
import ProProfilePage from './pages/Pro/ProProfilePage';
import ProSettingsPage from './pages/Pro/ProSettingsPage';
import ProOnboardingPage from './pages/Pro/ProOnboardingPage';

import AdminLayout from './pages/Admin/AdminLayout';
import AdminOverviewPage from './pages/Admin/AdminOverviewPage';
import AdminProfessionalsPage from './pages/Admin/AdminProfessionalsPage';
import AdminUsersPage from './pages/Admin/AdminUsersPage';
import { AdminAppointmentsPage, AdminPaymentsPage, AdminServicesPage } from './pages/Admin/AdminCatalogPages';
import { AdminSettingsPage, AdminTicketsPage } from './pages/Admin/AdminSupportPages';

/*
 * Mapa de rotas
 * ─────────────────────────────────────────────────────────────────────────
 *  Públicas     /  ·  /servicos  ·  /servicos/:slug  ·  /profissionais
 *               /profissionais/:id  ·  /agendar  ·  /ajuda  ·  /termos  ·  /privacidade
 *  Visitante    /entrar  ·  /cadastro
 *  Paciente     /painel  ·  /perfil  ·  /notificacoes (outros papéis são levados
 *               à seção equivalente da sua área)
 *  Paciente e profissional (como cliente)
 *               /agendar/revisao  ·  /pagamento/:id[/aprovado|/recusado]
 *               /consultas  ·  /consultas/:id  ·  /favoritos
 *  Profissional /profissional/* (visão geral, onboarding, agenda, horários,
 *               serviços, clientes, financeiro, notificações, perfil, configurações)
 *  Admin        /admin/* (visão geral, profissionais, usuários, serviços,
 *               agendamentos, pagamentos, solicitações, notificações, configurações)
 *  Outros       /acesso-negado (403)
 *  Atalhos      /como-funciona  ·  /para-profissionais  ·  /contato  ·  /faq
 *
 * HashRouter: funciona em qualquer hospedagem estática (GitHub Pages, Netlify,
 * abrir o build localmente) sem configuração de reescrita de URLs.
 */
export default function App() {
  return (
    <HashRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      <ToastProvider>
        <AuthProvider>
          <BookingProvider>
            <Routes>
              <Route element={<Layout />}>
                <Route index element={<HomePage />} />
                <Route path="como-funciona" element={<Navigate to="/?secao=como-funciona" replace />} />
                <Route path="para-profissionais" element={<Navigate to="/?secao=profissionais" replace />} />
                <Route path="contato" element={<Navigate to="/ajuda?secao=contato" replace />} />
                <Route path="faq" element={<Navigate to="/ajuda?secao=faq" replace />} />

                <Route path="servicos" element={<ServicesPage />} />
                <Route path="servicos/:slug" element={<ServiceDetailPage />} />
                <Route path="profissionais" element={<ProfessionalsPage />} />
                <Route path="profissionais/:id" element={<ProfessionalProfilePage />} />

                <Route
                  path="entrar"
                  element={
                    <GuestOnly>
                      <LoginPage />
                    </GuestOnly>
                  }
                />
                <Route
                  path="cadastro"
                  element={
                    <GuestOnly>
                      <RegisterPage />
                    </GuestOnly>
                  }
                />

                <Route path="agendar" element={<BookingPage />} />
                <Route
                  path="agendar/revisao"
                  element={
                    <RequireAuth roles={['usuario', 'profissional']}>
                      <BookingReviewPage />
                    </RequireAuth>
                  }
                />

                <Route
                  path="pagamento/:id"
                  element={
                    <RequireAuth roles={['usuario', 'profissional']}>
                      <PaymentPage />
                    </RequireAuth>
                  }
                />
                <Route
                  path="pagamento/:id/aprovado"
                  element={
                    <RequireAuth roles={['usuario', 'profissional']}>
                      <PaymentResultPage result="aprovado" />
                    </RequireAuth>
                  }
                />
                <Route
                  path="pagamento/:id/recusado"
                  element={
                    <RequireAuth roles={['usuario', 'profissional']}>
                      <PaymentResultPage result="recusado" />
                    </RequireAuth>
                  }
                />

                <Route
                  path="painel"
                  element={
                    <RequireAuth>
                      <RoleHome role="usuario">
                        <DashboardPage />
                      </RoleHome>
                    </RequireAuth>
                  }
                />
                <Route
                  path="consultas"
                  element={
                    <RequireAuth roles={['usuario', 'profissional']}>
                      <AppointmentsPage />
                    </RequireAuth>
                  }
                />
                <Route
                  path="consultas/:id"
                  element={
                    <RequireAuth roles={['usuario', 'profissional']}>
                      <AppointmentDetailPage />
                    </RequireAuth>
                  }
                />
                <Route
                  path="perfil"
                  element={
                    <RequireAuth>
                      <RoleHome role="usuario" to="configuracoes">
                        <ProfilePage />
                      </RoleHome>
                    </RequireAuth>
                  }
                />

                {/* ─────────────── Área do profissional (somente papel "profissional") */}
                <Route
                  path="profissional"
                  element={
                    <RequireAuth roles={['profissional']}>
                      <ProLayout />
                    </RequireAuth>
                  }
                >
                  <Route index element={<ProOverviewPage />} />
                  <Route path="onboarding" element={<ProOnboardingPage />} />
                  <Route path="agenda" element={<ProAgendaPage />} />
                  <Route path="horarios" element={<ProSchedulePage />} />
                  <Route path="servicos" element={<ProServicesPage />} />
                  <Route path="clientes" element={<ProClientsPage />} />
                  <Route path="financeiro" element={<ProFinancePage />} />
                  <Route path="notificacoes" element={<EmbeddedNotificationsPage />} />
                  <Route path="perfil" element={<ProProfilePage />} />
                  <Route path="configuracoes" element={<ProSettingsPage />} />
                  <Route path="*" element={<Navigate to="/profissional" replace />} />
                </Route>

                {/* ─────────────── Administração (somente papel "admin") */}
                <Route
                  path="admin"
                  element={
                    <RequireAuth roles={['admin']}>
                      <AdminLayout />
                    </RequireAuth>
                  }
                >
                  <Route index element={<AdminOverviewPage />} />
                  <Route path="profissionais" element={<AdminProfessionalsPage />} />
                  <Route path="usuarios" element={<AdminUsersPage />} />
                  <Route path="servicos" element={<AdminServicesPage />} />
                  <Route path="agendamentos" element={<AdminAppointmentsPage />} />
                  <Route path="pagamentos" element={<AdminPaymentsPage />} />
                  <Route path="solicitacoes" element={<AdminTicketsPage />} />
                  <Route path="notificacoes" element={<EmbeddedNotificationsPage />} />
                  <Route path="configuracoes" element={<AdminSettingsPage />} />
                  <Route path="*" element={<Navigate to="/admin" replace />} />
                </Route>

                <Route
                  path="notificacoes"
                  element={
                    <RequireAuth>
                      <RoleHome role="usuario" to="notificacoes">
                        <NotificationsPage />
                      </RoleHome>
                    </RequireAuth>
                  }
                />
                <Route
                  path="favoritos"
                  element={
                    <RequireAuth roles={['usuario', 'profissional']}>
                      <FavoritesPage />
                    </RequireAuth>
                  }
                />
                <Route path="acesso-negado" element={<AccessDeniedPage />} />

                <Route path="ajuda" element={<HelpPage />} />
                <Route path="termos" element={<LegalPage doc="termos" />} />
                <Route path="privacidade" element={<LegalPage doc="privacidade" />} />

                <Route path="*" element={<NotFoundPage />} />
              </Route>
            </Routes>
          </BookingProvider>
        </AuthProvider>
      </ToastProvider>
    </HashRouter>
  );
}
