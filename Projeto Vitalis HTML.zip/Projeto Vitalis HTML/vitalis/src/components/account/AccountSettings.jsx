import { useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../ui/Icon';
import Button from '../ui/Button';
import { PasswordField, TextField, Toggle } from '../ui/Field';
import { UserAvatar } from '../ui/Avatar';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useForm } from '../../hooks';
import { getSessionInfo } from '../../services/authService';
import { validateConfirm, validateEmail, validateName, validatePassword, validatePhone } from '../../utils/validation';
import { maskPhone } from '../../utils/masks';
import { resizeImage } from '../../utils/avatar';
import { formatDateTimeBR } from '../../utils/format';

/*
 * Blocos de configurações da conta reaproveitados pelas áreas do profissional
 * e da administração (o paciente continua usando a página "Meu perfil").
 */

/** Nome, e-mail, telefone e foto da conta. */
export function AccountInfoCard({ photoHint }) {
  const { user, updateProfile } = useAuth();
  const toast = useToast();
  const fileRef = useRef(null);
  const [saving, setSaving] = useState(false);
  const initial = useMemo(() => ({ name: user.name || '', email: user.email || '', phone: user.phone || '' }), [user]);
  const validators = useMemo(() => ({ name: validateName, email: validateEmail, phone: validatePhone }), []);
  const { values, errors, setField, onBlur, validateAll, reset, setErrors } = useForm(initial, validators);
  const dirty = JSON.stringify(values) !== JSON.stringify(initial);

  const save = async (e) => {
    e.preventDefault();
    const errs = validateAll();
    if (Object.keys(errs).length) {
      document.querySelector(`[name="acc-${Object.keys(errs)[0]}"]`)?.focus();
      return;
    }
    setSaving(true);
    try {
      await updateProfile(values);
      toast.success('Conta atualizada', 'Seus dados foram salvos.');
    } catch (err) {
      if (err.field) setErrors((x) => ({ ...x, [err.field]: err.message }));
      else toast.error('Não foi possível salvar', err.message);
    } finally {
      setSaving(false);
    }
  };

  const pickPhoto = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const photo = await resizeImage(file, 256);
      await updateProfile({ ...initial, photo });
      toast.success('Foto atualizada');
    } catch (err) {
      toast.error('Não foi possível usar a imagem', err.message);
    }
  };

  const removePhoto = async () => {
    try {
      await updateProfile({ ...initial, photo: null });
      toast.success('Foto removida');
    } catch (err) {
      toast.error('Não foi possível remover', err.message);
    }
  };

  return (
    <section className="panel-card" aria-labelledby="acc-title">
      <h2 id="acc-title" className="panel-card__title">
        <Icon name="account_circle" size={22} /> Dados da conta
      </h2>
      <form className="stack section-gap" onSubmit={save} noValidate>
        <div className="photo-field">
          <UserAvatar user={user} size={72} />
          <div>
            <p className="field__label">Foto</p>
            <p className="field__hint">{photoHint || 'PNG, JPG ou WEBP de até 5 MB.'}</p>
            <div className="photo-field__btns">
              <Button variant="soft-green" size="sm" icon="photo_camera" iconSize={18} onClick={() => fileRef.current?.click()}>
                {user.photo ? 'Trocar foto' : 'Enviar foto'}
              </Button>
              {user.photo && (
                <Button variant="ghost" size="sm" icon="delete" iconSize={18} onClick={removePhoto}>
                  Remover
                </Button>
              )}
            </div>
            <input
              ref={fileRef}
              type="file"
              accept="image/png,image/jpeg,image/webp"
              className="sr-only"
              tabIndex={-1}
              aria-hidden="true"
              onChange={pickPhoto}
            />
          </div>
        </div>
        <div className="form-grid">
          <TextField
            className="form-grid__full"
            label="Nome completo"
            name="acc-name"
            icon="person"
            value={values.name}
            onChange={(e) => setField('name', e.target.value)}
            onBlur={() => onBlur('name')}
            error={errors.name}
            autoComplete="name"
          />
          <TextField
            label="E-mail de acesso"
            name="acc-email"
            type="email"
            icon="mail"
            value={values.email}
            onChange={(e) => setField('email', e.target.value)}
            onBlur={() => onBlur('email')}
            error={errors.email}
            autoComplete="email"
          />
          <TextField
            label="Telefone"
            name="acc-phone"
            type="tel"
            icon="call"
            value={values.phone}
            onChange={(e) => setField('phone', maskPhone(e.target.value))}
            onBlur={() => onBlur('phone')}
            error={errors.phone}
            autoComplete="tel"
          />
        </div>
        <div className="form-actions">
          {dirty && (
            <Button variant="ghost" onClick={() => reset(initial)} disabled={saving}>
              Desfazer
            </Button>
          )}
          <Button type="submit" variant="primary" icon="save" loading={saving} loadingText="Salvando…" disabled={!dirty}>
            Salvar dados
          </Button>
        </div>
      </form>
    </section>
  );
}

/** Alteração de senha. */
export function PasswordCard() {
  const { changePassword } = useAuth();
  const toast = useToast();
  const [saving, setSaving] = useState(false);
  const validators = useMemo(
    () => ({
      current: (v) => (v ? '' : 'Informe sua senha atual.'),
      next: validatePassword,
      confirm: (v, vals) => validateConfirm(vals.next)(v),
    }),
    [],
  );
  const { values, errors, setField, onBlur, validateAll, reset, setErrors } = useForm(
    { current: '', next: '', confirm: '' },
    validators,
  );

  const submit = async (e) => {
    e.preventDefault();
    if (Object.keys(validateAll()).length) return;
    setSaving(true);
    try {
      await changePassword(values.current, values.next);
      toast.success('Senha alterada', 'Use a nova senha no próximo login.');
      reset({ current: '', next: '', confirm: '' });
    } catch (err) {
      if (err.field) setErrors((x) => ({ ...x, [err.field]: err.message }));
      else toast.error('Não foi possível alterar', err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="panel-card" aria-labelledby="pwd-title">
      <h2 id="pwd-title" className="panel-card__title">
        <Icon name="lock" size={22} /> Segurança
      </h2>
      <form onSubmit={submit} noValidate className="section-gap">
        <div className="form-grid">
          <PasswordField
            className="form-grid__full"
            label="Senha atual"
            name="current"
            autoComplete="current-password"
            value={values.current}
            onChange={(e) => setField('current', e.target.value)}
            onBlur={() => onBlur('current')}
            error={errors.current}
          />
          <PasswordField
            label="Nova senha"
            name="next"
            autoComplete="new-password"
            value={values.next}
            onChange={(e) => setField('next', e.target.value)}
            onBlur={() => onBlur('next')}
            error={errors.next}
            hint="Mínimo de 8 caracteres, com letras e números."
          />
          <PasswordField
            label="Confirmar nova senha"
            name="confirm"
            autoComplete="new-password"
            value={values.confirm}
            onChange={(e) => setField('confirm', e.target.value)}
            onBlur={() => onBlur('confirm')}
            error={errors.confirm}
          />
        </div>
        <div className="form-actions">
          <Button type="submit" variant="primary" icon="key" loading={saving} loadingText="Alterando…">
            Alterar senha
          </Button>
        </div>
      </form>
    </section>
  );
}

/** Preferências de notificação: o que funciona agora e o que depende de servidor. */
export function NotificationPrefsCard({ reminderText = 'Aviso dentro do Vitalis 24 horas antes de cada atendimento.' }) {
  const { user, updatePreferences } = useAuth();
  const toast = useToast();
  const [busy, setBusy] = useState('');
  const prefs = user.prefs || {};
  const toggle = async (key, value, label) => {
    setBusy(key);
    try {
      await updatePreferences({ [key]: value });
      toast.success(`${label} ${value ? 'ativado' : 'desativado'}`);
    } catch (err) {
      toast.error('Não foi possível salvar', err.message);
    } finally {
      setBusy('');
    }
  };
  const EXTERNAL = [
    { key: 'notifyEmail', title: 'E-mail' },
    { key: 'notifySms', title: 'SMS' },
    { key: 'notifyWhatsapp', title: 'WhatsApp' },
  ];
  return (
    <section className="panel-card" aria-labelledby="ntfp-title">
      <h2 id="ntfp-title" className="panel-card__title">
        <Icon name="notifications" size={22} /> Notificações
      </h2>
      <div className="stack section-gap" style={{ '--stack-gap': '12px' }}>
        <div className="setting-row setting-row--bordered">
          <div>
            <p className="setting-row__title">Lembretes no Vitalis</p>
            <p className="setting-row__text">{reminderText}</p>
          </div>
          <Toggle
            checked={prefs.reminders !== false}
            label="Lembretes no Vitalis"
            disabled={busy === 'reminders'}
            onChange={(v) => toggle('reminders', v, 'Lembretes')}
          />
        </div>
        <p className="settings-label">Canais externos (preferência salva para quando houver envio)</p>
        {EXTERNAL.map((n) => (
          <div key={n.key} className="setting-row setting-row--bordered">
            <div>
              <p className="setting-row__title">{n.title}</p>
              <p className="setting-row__text">Envio ainda não disponível nesta versão.</p>
            </div>
            <Toggle
              checked={!!prefs[n.key]}
              label={`Preferência de ${n.title}`}
              disabled={busy === n.key}
              onChange={(v) => toggle(n.key, v, `Preferência de ${n.title}`)}
            />
          </div>
        ))}
      </div>
    </section>
  );
}

/** Informações da sessão e saída. */
export function SessionCard() {
  const { user, logout } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const info = getSessionInfo();
  return (
    <section className="panel-card" aria-labelledby="sess-title">
      <h2 id="sess-title" className="panel-card__title">
        <Icon name="devices" size={22} /> Sessão
      </h2>
      <dl className="pf-facts">
        <div>
          <dt>Entrou em</dt>
          <dd>{info?.createdAt ? formatDateTimeBR(info.createdAt) : '—'}</dd>
        </div>
        <div>
          <dt>Manter conectado</dt>
          <dd>{info?.remember ? 'Sim, neste navegador' : 'Não (encerra ao fechar)'}</dd>
        </div>
        <div>
          <dt>Senha alterada em</dt>
          <dd>{user.passwordChangedAt ? formatDateTimeBR(user.passwordChangedAt) : 'Nunca'}</dd>
        </div>
        <div>
          <dt>Conta criada em</dt>
          <dd>{user.createdAt ? formatDateTimeBR(user.createdAt) : '—'}</dd>
        </div>
      </dl>
      <div className="setting-row section-gap">
        <div>
          <p className="setting-row__title">Sair desta conta</p>
          <p className="setting-row__text">Os dados de demonstração continuam salvos neste navegador.</p>
        </div>
        <Button
          variant="danger"
          size="sm"
          icon="logout"
          onClick={async () => {
            await logout();
            toast.info('Você saiu da sua conta');
            navigate('/');
          }}
        >
          Sair
        </Button>
      </div>
    </section>
  );
}
