import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Icon from '../ui/Icon';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { isFavorite, toggleFavorite } from '../../services/favoriteService';

/** Coração para salvar um profissional nos favoritos (pede login quando necessário). */
export default function FavoriteButton({ proId, name, className = '', withLabel = false }) {
  const { user, role } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [on, setOn] = useState(() => isFavorite(proId));
  const [busy, setBusy] = useState(false);
  const [pop, setPop] = useState(false);

  useEffect(() => {
    setOn(isFavorite(proId));
  }, [proId, user]);

  if (role === 'admin') return null;

  const click = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      toast.info('Entre para salvar favoritos', 'Depois do login você volta para esta página.');
      navigate(`/entrar?redirect=${encodeURIComponent(location.pathname + location.search)}`);
      return;
    }
    setBusy(true);
    try {
      const next = await toggleFavorite(proId);
      setOn(next);
      setPop(next);
      toast.success(next ? 'Adicionado aos favoritos' : 'Removido dos favoritos', name);
    } catch (err) {
      toast.error('Não foi possível atualizar', err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <button
      type="button"
      className={`fav-btn${on ? ' is-on' : ''}${pop ? ' is-pop' : ''}${withLabel ? ' fav-btn--label' : ''} ${className}`}
      aria-pressed={on}
      aria-label={on ? `Remover ${name} dos favoritos` : `Salvar ${name} nos favoritos`}
      title={on ? 'Remover dos favoritos' : 'Salvar nos favoritos'}
      disabled={busy}
      onClick={click}
      onAnimationEnd={() => setPop(false)}
    >
      <Icon name="favorite" fill={on} size={22} />
      {withLabel && <span>{on ? 'Salvo nos favoritos' : 'Salvar nos favoritos'}</span>}
    </button>
  );
}
