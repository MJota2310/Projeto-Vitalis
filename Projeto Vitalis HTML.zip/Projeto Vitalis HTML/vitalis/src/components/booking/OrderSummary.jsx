import { professionalById } from '../../data/catalog';
import { ProAvatar } from '../ui/Avatar';
import { formatCurrency, formatDateBR, formatTimeRange } from '../../utils/format';

/** "Resumo do pedido" (tela de pagamento do Figma). */
export default function OrderSummary({ appointment, children }) {
  const pro = professionalById(appointment.professionalId);
  return (
    <aside className="order-summary" aria-labelledby="order-title">
      <h2 id="order-title" className="order-summary__title">
        Resumo do pedido
      </h2>
      <div className="order-summary__pro">
        <ProAvatar pro={pro || { name: appointment.professionalName, simulated: true }} size={60} />
        <div>
          <p className="order-summary__name">{appointment.professionalName}</p>
          <p className="order-summary__spec">{pro?.title || appointment.specialty}</p>
          <p className="order-summary__date">
            {formatDateBR(appointment.date)} · {formatTimeRange(appointment.time, appointment.duration)}
          </p>
        </div>
      </div>
      <p className="order-summary__protocol">
        Protocolo <strong>{appointment.protocol}</strong>
      </p>
      <div className="summary-rows order-summary__rows">
        <div className="summary-row">
          <span>{appointment.offeringName || 'Consulta'}</span>
          <strong>{formatCurrency(appointment.price)}</strong>
        </div>
        <div className="summary-row">
          <span>Taxa de serviço</span>
          <strong>{formatCurrency(appointment.fee)}</strong>
        </div>
        <div className="summary-row summary-row--total">
          <span>Total</span>
          <strong>{formatCurrency(appointment.total)}</strong>
        </div>
      </div>
      <div className="guarantee">
        <p className="guarantee__title">Garantia de reembolso:</p>
        <p>Se você não puder comparecer, cancele até 24h antes e receba reembolso total.</p>
      </div>
      {children}
    </aside>
  );
}
