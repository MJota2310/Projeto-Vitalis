import { Link } from 'react-router-dom';
import Icon from '../ui/Icon';
import Button from '../ui/Button';
import { Stars } from '../ui/Feedback';
import { ProAvatar } from '../ui/Avatar';
import { serviceBySlug } from '../../data/catalog';
import { WEEKDAYS_SHORT, formatPriceShort } from '../../utils/format';
import FavoriteButton from './FavoriteButton';

/**
 * Card de profissional (tela "Agendar" do Figma).
 * - modo seleção: `selectable` + `selected` + `onSelect` (radio acessível)
 * - modo ação: `actionTo` (ex.: agendar com este profissional)
 * - `profileLink`: o nome vira link para o perfil público
 * - `favorite`: mostra o botão de favoritar (somente para quem está logado)
 * - `preview`: prévia estática (área do profissional), sem links nem ações
 */
export default function ProfessionalCard({
  pro,
  selectable,
  selected,
  onSelect,
  actionTo,
  actionLabel = 'Agendar',
  showService,
  profileLink,
  favorite,
  preview,
}) {
  const service = serviceBySlug(pro.service);
  const NameTag = selectable ? 'p' : 'h3';
  // `priceFrom` (verdadeiro quando há serviços com preços diferentes) → "a partir de"
  const multiple = pro.priceFrom === true;
  const content = (
    <>
      <ProAvatar pro={pro} size={null} />
      <div className="pro-item__body">
        <div className="pro-item__head">
          <div className="pro-item__id">
            <NameTag className="pro-item__name">
              {profileLink && !selectable && !preview ? (
                <Link to={`/profissionais/${pro.id}`} className="pro-item__link">
                  {pro.name}
                </Link>
              ) : (
                pro.name
              )}
            </NameTag>
            <p className="pro-item__spec">
              {pro.specialty}
              {showService && service && service.name !== pro.specialty ? ` · ${service.name}` : ''}
            </p>
          </div>
          <div className="pro-item__price">
            {multiple && <span>a partir de</span>}
            <strong>{pro.price ? formatPriceShort(pro.price) : '—'}</strong>
            <span>por consulta</span>
          </div>
        </div>
        <div className="pro-item__meta">
          {pro.rating ? (
            <Stars rating={pro.rating} reviews={pro.reviews} size={15} />
          ) : (
            <span className="badge badge--blue pro-item__new">
              <Icon name="fiber_new" size={15} /> Novo no Vitalis
            </span>
          )}
          {pro.city && (
            <span className="pro-item__city">
              <Icon name="distance" size={17} /> {pro.city}
            </span>
          )}
          {pro.modality && pro.modality !== 'presencial' && (
            <span className="pro-item__city">
              <Icon name="videocam" size={17} /> {pro.modality === 'online' ? 'Online' : 'Presencial e online'}
            </span>
          )}
        </div>
        <div className="pro-item__days">
          <span className="pro-item__days-label">Disponível:</span>
          {(pro.days || []).length ? (
            pro.days.map((d) => (
              <span key={d} className="day-chip">
                {WEEKDAYS_SHORT[d]}
              </span>
            ))
          ) : (
            <span className="muted">sem dias configurados</span>
          )}
        </div>
      </div>
      {selectable && (
        <span className="pro-item__radio" aria-hidden="true">
          <Icon name="check" size={18} />
        </span>
      )}
    </>
  );

  if (selectable) {
    return (
      <div
        role="radio"
        tabIndex={0}
        aria-checked={!!selected}
        aria-label={`${pro.name}, ${pro.specialty}, ${multiple ? 'a partir de ' : ''}${formatPriceShort(pro.price)} por consulta`}
        className={`pro-item pro-item--selectable${selected ? ' is-selected' : ''}`}
        onClick={() => onSelect(pro.id)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onSelect(pro.id);
          }
        }}
      >
        {content}
      </div>
    );
  }

  return (
    <article className={`pro-item${preview ? ' pro-item--preview' : ''}`}>
      {content}
      {favorite && !preview && <FavoriteButton proId={pro.id} name={pro.name} className="pro-item__fav" />}
      {(actionTo || (profileLink && !preview)) && (
        <div className="pro-item__action">
          {profileLink && !preview && (
            <Button variant="ghost" size="sm" to={`/profissionais/${pro.id}`} icon="person" iconSize={18}>
              Ver perfil
            </Button>
          )}
          {actionTo && (
            <Button
              variant="primary"
              size="sm"
              to={preview ? undefined : actionTo}
              disabled={preview}
              icon="calendar_today"
              iconSize={18}
            >
              {actionLabel}
            </Button>
          )}
        </div>
      )}
    </article>
  );
}

export function ProfessionalCardSkeleton() {
  return (
    <div className="pro-item" aria-hidden="true">
      <span className="skeleton" style={{ width: 64, height: 64, borderRadius: 12 }} />
      <div className="pro-item__body">
        <span className="skeleton" style={{ width: '40%', height: 18 }} />
        <span className="skeleton" style={{ width: '25%', height: 12, marginTop: 10 }} />
        <span className="skeleton" style={{ width: '60%', height: 12, marginTop: 14 }} />
        <span className="skeleton" style={{ width: '35%', height: 20, marginTop: 14 }} />
      </div>
    </div>
  );
}
