import { useEffect, useMemo, useRef, useState } from 'react';
import Icon from '../ui/Icon';
import { fetchSlots, isBookableDate, BOOKING_WINDOW_DAYS } from '../../services/catalogService';
import { MONTHS, WEEKDAYS_LONG, WEEKDAYS_SHORT, addDays, parseISODate, toISODate } from '../../utils/format';

/** Calendário mensal: só habilita os dias em que o profissional atende. */
export function DatePicker({ pro, value, onChange, label = 'Data' }) {
  const today = useMemo(() => parseISODate(toISODate(new Date())), []);
  const limit = useMemo(() => addDays(today, BOOKING_WINDOW_DAYS), [today]);
  // abre no mês do valor escolhido ou no mês do primeiro dia disponível
  const firstBookable = useMemo(() => {
    for (let i = 0; i <= BOOKING_WINDOW_DAYS; i += 1) {
      const d = addDays(today, i);
      if (isBookableDate(pro, toISODate(d))) return d;
    }
    return today;
  }, [pro, today]);
  const initial = value ? parseISODate(value) : firstBookable;
  const [view, setView] = useState(new Date(initial.getFullYear(), initial.getMonth(), 1));
  const gridRef = useRef(null);

  useEffect(() => {
    if (value) {
      const d = parseISODate(value);
      setView(new Date(d.getFullYear(), d.getMonth(), 1));
    }
  }, [value]);

  const canPrev = view > new Date(today.getFullYear(), today.getMonth(), 1);
  const canNext = new Date(view.getFullYear(), view.getMonth() + 1, 1) <= limit;

  const cells = useMemo(() => {
    const first = new Date(view.getFullYear(), view.getMonth(), 1);
    const daysInMonth = new Date(view.getFullYear(), view.getMonth() + 1, 0).getDate();
    const out = Array.from({ length: first.getDay() }, () => null);
    for (let d = 1; d <= daysInMonth; d += 1) {
      const date = new Date(view.getFullYear(), view.getMonth(), d);
      const iso = toISODate(date);
      out.push({ d, iso, date, enabled: isBookableDate(pro, iso), isToday: iso === toISODate(today) });
    }
    return out;
  }, [view, pro, today]);

  const firstEnabled = cells.find((c) => c && c.enabled);

  // navegação por setas entre os dias habilitados
  const onKeyDown = (e) => {
    const keys = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 };
    if (!(e.key in keys)) return;
    const current = document.activeElement?.dataset?.iso;
    if (!current) return;
    e.preventDefault();
    let d = parseISODate(current);
    for (let i = 0; i < 60; i += 1) {
      d = addDays(d, keys[e.key] > 0 ? 1 : -1);
      if (Math.abs(keys[e.key]) === 7 && i < 6) continue;
      if (d < today || d > limit) return;
      const iso = toISODate(d);
      if (isBookableDate(pro, iso)) {
        if (d.getMonth() !== view.getMonth()) setView(new Date(d.getFullYear(), d.getMonth(), 1));
        requestAnimationFrame(() => gridRef.current?.querySelector(`[data-iso="${iso}"]`)?.focus());
        return;
      }
    }
  };

  return (
    <div className="datepicker">
      <div className="datepicker__head">
        <p className="datepicker__label">
          <Icon name="calendar_today" size={20} /> {label}
        </p>
        <div className="datepicker__nav">
          <button
            type="button"
            className="icon-btn"
            onClick={() => setView(new Date(view.getFullYear(), view.getMonth() - 1, 1))}
            disabled={!canPrev}
            aria-label="Mês anterior"
          >
            <Icon name="chevron_left" />
          </button>
          <span className="datepicker__month" aria-live="polite">
            {MONTHS[view.getMonth()]} {view.getFullYear()}
          </span>
          <button
            type="button"
            className="icon-btn"
            onClick={() => setView(new Date(view.getFullYear(), view.getMonth() + 1, 1))}
            disabled={!canNext}
            aria-label="Próximo mês"
          >
            <Icon name="chevron_right" />
          </button>
        </div>
      </div>
      <div
        className="datepicker__grid"
        role="group"
        aria-label={`Calendário de ${MONTHS[view.getMonth()]} — use as setas para navegar`}
        ref={gridRef}
        onKeyDown={onKeyDown}
      >
        {WEEKDAYS_SHORT.map((w) => (
          <span key={w} className="datepicker__dow" aria-hidden="true">
            {w.charAt(0)}
          </span>
        ))}
        {cells.map((c, i) =>
          c ? (
            <button
              key={c.iso}
              type="button"
              data-iso={c.iso}
              className={`day${c.enabled ? ' is-available' : ''}${value === c.iso ? ' is-selected' : ''}${c.isToday ? ' is-today' : ''}`}
              disabled={!c.enabled}
              aria-pressed={value === c.iso}
              aria-label={`${WEEKDAYS_LONG[c.date.getDay()]}, ${c.d} de ${MONTHS[c.date.getMonth()]}${c.enabled ? '' : ' — indisponível'}`}
              tabIndex={value ? (value === c.iso ? 0 : -1) : c === firstEnabled ? 0 : -1}
              onClick={() => onChange(c.iso)}
            >
              {c.d}
            </button>
          ) : (
            <span key={`e${i}`} aria-hidden="true" />
          ),
        )}
      </div>
      <p className="datepicker__legend">
        <span className="legend-dot legend-dot--on" /> dias de atendimento
        <span className="legend-dot" /> indisponível
      </p>
    </div>
  );
}

/**
 * Grade de horários do dia. Segue a disponibilidade do profissional e a
 * duração do serviço escolhido (`duration`, em minutos).
 */
export function TimeSlots({ proId, date, value, onChange, ignoreAppointmentId, duration }) {
  const [slots, setSlots] = useState(null);

  useEffect(() => {
    let alive = true;
    setSlots(null);
    if (!proId || !date) return undefined;
    fetchSlots(proId, date, { ignoreAppointmentId, duration }).then((s) => alive && setSlots(s));
    return () => {
      alive = false;
    };
  }, [proId, date, ignoreAppointmentId, duration]);

  if (!date) {
    return (
      <p className="slots__hint">
        <Icon name="schedule" size={18} /> Escolha uma data para ver os horários.
      </p>
    );
  }

  const free = slots?.filter((s) => s.status === 'livre').length ?? 0;

  return (
    <div className="slots">
      <p className="slots__label">
        <Icon name="nest_clock_farsight_analog" size={20} /> Horário{duration ? ` · ${duration} min` : ''}
        {slots && <span className="slots__count">{free > 0 ? `${free} livres` : 'sem horários livres'}</span>}
      </p>
      <div className="slots__grid" role="radiogroup" aria-label="Horários disponíveis">
        {!slots
          ? Array.from({ length: 8 }, (_, i) => <span key={i} className="skeleton" style={{ height: 44, borderRadius: 8 }} />)
          : slots.map((s) => (
              <button
                key={s.time}
                type="button"
                role="radio"
                aria-checked={value === s.time}
                className={`slot slot--${s.status}${value === s.time ? ' is-selected' : ''}`}
                disabled={s.status !== 'livre'}
                onClick={() => onChange(s.time)}
                title={s.status === 'ocupado' ? 'Horário ocupado' : s.status === 'passado' ? 'Horário indisponível' : undefined}
                aria-label={`${s.time}${s.status === 'ocupado' ? ' — ocupado' : s.status === 'passado' ? ' — indisponível' : ''}`}
              >
                {s.time}
              </button>
            ))}
      </div>
      {slots && slots.length === 0 && (
        <p className="slots__hint">Nenhum horário comporta este atendimento neste dia. Escolha outra data.</p>
      )}
      {slots && slots.length > 0 && free === 0 && (
        <p className="slots__hint">Todos os horários deste dia estão ocupados. Escolha outra data.</p>
      )}
    </div>
  );
}

const STEPS = ['Serviço', 'Profissional', 'Data e horário', 'Revisão', 'Pagamento'];

export function Stepper({ current }) {
  return (
    <ol className="stepper" aria-label="Etapas do agendamento">
      {STEPS.map((label, i) => {
        const n = i + 1;
        const state = n < current ? 'is-done' : n === current ? 'is-current' : '';
        return (
          <li key={label} className="stepper__item" style={{ display: 'contents' }}>
            {i > 0 && <span className={`step__line${n <= current ? ' is-done' : ''}`} aria-hidden="true" />}
            <span className={`step ${state}`} aria-current={n === current ? 'step' : undefined}>
              <span className="step__dot">{n < current ? <Icon name="check" size={16} /> : n}</span>
              <span className="step__label">{label}</span>
            </span>
          </li>
        );
      })}
    </ol>
  );
}
