import { Link } from 'react-router-dom';
import iconX from '../../assets/images/social-x.png';
import iconFacebook from '../../assets/images/social-facebook.png';
import iconInstagram from '../../assets/images/social-instagram.png';
import Icon from '../ui/Icon';
import { CONTACT, SOCIAL } from '../../data/content';
import { FOOTER_LINKS } from './navigation';
import { useSectionNav } from '../../hooks/useSectionNav';

const SOCIAL_ICONS = { facebook: iconFacebook, x: iconX, instagram: iconInstagram };

export default function Footer() {
  const goToSection = useSectionNav();

  return (
    <footer className="site-footer" id="contato" aria-labelledby="footer-title">
      <div className="container site-footer__grid">
        <div className="site-footer__brand">
          <h2 id="footer-title" className="site-footer__logo">
            Vitalis
          </h2>
          <p className="site-footer__tagline">Transformando a forma como você cuida da sua saúde e bem-estar.</p>
          <ul className="social" aria-label="Redes sociais">
            {SOCIAL.map((s) => (
              <li key={s.id}>
                <a
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="social__link"
                  aria-label={`${s.label} (abre em nova aba)`}
                >
                  <img src={SOCIAL_ICONS[s.id]} alt="" width="46" height="46" />
                </a>
              </li>
            ))}
          </ul>
        </div>

        <nav className="site-footer__col" aria-labelledby="footer-links">
          <h3 id="footer-links" className="site-footer__heading">
            Links úteis
          </h3>
          <ul>
            {FOOTER_LINKS.uteis.map((l) => (
              <li key={l.label}>
                {l.to ? (
                  <Link to={l.to} className="footer-link">
                    {l.label}
                  </Link>
                ) : (
                  <a
                    href={`#/${l.section === 'inicio' ? '' : `?secao=${l.section}`}`}
                    className="footer-link"
                    onClick={(e) => {
                      e.preventDefault();
                      goToSection(l.section);
                    }}
                  >
                    {l.label}
                  </a>
                )}
              </li>
            ))}
          </ul>
        </nav>

        <nav className="site-footer__col" aria-labelledby="footer-support">
          <h3 id="footer-support" className="site-footer__heading">
            Suporte
          </h3>
          <ul>
            {FOOTER_LINKS.suporte.map((l) => (
              <li key={l.label}>
                <Link to={l.to} className="footer-link">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="site-footer__col site-footer__contact">
          <h3 className="site-footer__heading">Contato</h3>
          <ul>
            <li>
              <a href={`mailto:${CONTACT.email}`} className="contact-link">
                <Icon name="mail" size={28} className="contact-link__icon contact-link__icon--green" />
                <span>{CONTACT.email}</span>
              </a>
            </li>
            <li>
              <a href={CONTACT.phoneHref} className="contact-link">
                <Icon name="call" size={28} className="contact-link__icon contact-link__icon--cyan" />
                <span>{CONTACT.phone}</span>
              </a>
            </li>
            <li>
              <a href={CONTACT.mapsHref} target="_blank" rel="noopener noreferrer" className="contact-link">
                <Icon name="add_location_alt" size={28} className="contact-link__icon contact-link__icon--yellow" />
                <span>{CONTACT.location}</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="site-footer__bottom">
        <div className="container site-footer__bottom-inner">
          <p>© 2026 Vitalis. Todos os direitos reservados.</p>
          <p className="site-footer__demo">
            <Icon name="info" size={16} /> Versão de demonstração — dados salvos apenas neste navegador.
          </p>
        </div>
      </div>
    </footer>
  );
}
