import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import logo from '../../assets/images/logo-vitalis.png';
import Icon from '../ui/Icon';
import Button from '../ui/Button';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { UserAvatar } from '../ui/Avatar';
import NotificationBell from './NotificationBell';
import { useClickOutside, useFocusTrap, useLockBody, useMediaQuery, useScrollSpy } from '../../hooks';
import { useSectionNav } from '../../hooks/useSectionNav';
import { ACCOUNT_MENU, LANDING_SECTIONS, LINKS_BY_ROLE, NOTIFICATIONS_PATH } from './navigation';
import { firstName } from '../../utils/format';

const SECTION_IDS = LANDING_SECTIONS.map((s) => s.id);

function UserMenu({ user, roleLabel, onLogout }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const close = useCallback(() => setOpen(false), []);
  useClickOutside(ref, close, open);

  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);

  const items = ACCOUNT_MENU[user.role] || ACCOUNT_MENU.usuario;

  return (
    <div className="user-menu" ref={ref}>
      <button
        type="button"
        className="user-menu__trigger"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={`Menu da conta de ${user.name}`}
        onClick={() => setOpen((v) => !v)}
      >
        <UserAvatar user={user} size={44} />
        <span className="user-menu__name">{firstName(user.name)}</span>
        <Icon name="keyboard_arrow_down" size={20} className={`user-menu__chev${open ? ' is-open' : ''}`} />
      </button>
      {open && (
        <div className="dropdown" role="menu" aria-label="Menu da conta">
          <div className="dropdown__head">
            <p className="dropdown__name">{user.name}</p>
            <p className="dropdown__email">{user.email}</p>
            {user.role !== 'usuario' && <span className={`role-chip role-chip--${user.role}`}>{roleLabel}</span>}
          </div>
          {items.map((i) => (
            <Link key={i.to} role="menuitem" to={i.to} className="dropdown__item" onClick={close}>
              <Icon name={i.icon} size={20} /> {i.label}
            </Link>
          ))}
          <button
            role="menuitem"
            type="button"
            className="dropdown__item dropdown__item--danger"
            onClick={() => {
              close();
              onLogout();
            }}
          >
            <Icon name="logout" size={20} /> Sair
          </button>
        </div>
      )}
    </div>
  );
}

export default function Header() {
  const { user, logout, roleLabel } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const goToSection = useSectionNav();
  const isDesktop = useMediaQuery('(min-width: 1101px)');
  const [scrolled, setScrolled] = useState(false);
  const [drawer, setDrawer] = useState(false);
  const drawerRef = useRef(null);
  const onHome = location.pathname === '/';
  const active = useScrollSpy(SECTION_IDS, onHome && !user);

  useLockBody(drawer);
  useFocusTrap(drawer, drawerRef, () => setDrawer(false));

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => setDrawer(false), [location.pathname, location.search]);
  useEffect(() => {
    if (isDesktop) setDrawer(false);
  }, [isDesktop]);

  const handleLogout = async () => {
    await logout();
    toast.info('Você saiu da sua conta', 'Até logo! Seus dados continuam salvos neste navegador.');
    navigate('/');
  };

  const handleSection = (e, id) => {
    e.preventDefault();
    setDrawer(false);
    goToSection(id);
  };

  const guestLinks = LANDING_SECTIONS.map((s) => (
    <li key={s.id}>
      <a
        href={`#/${s.id === 'inicio' ? '' : `?secao=${s.id}`}`}
        className={`nav-link${onHome && active === s.id ? ' is-active' : ''}`}
        aria-current={onHome && active === s.id ? 'true' : undefined}
        onClick={(e) => handleSection(e, s.id)}
      >
        {s.label}
      </a>
    </li>
  ));

  const roleLinks = LINKS_BY_ROLE[user?.role] || LINKS_BY_ROLE.usuario;
  const appLinks = roleLinks.map((l) => (
    <li key={l.to}>
      <NavLink to={l.to} end={l.end} className={({ isActive }) => `nav-link nav-link--app${isActive ? ' is-active' : ''}`}>
        <Icon name={l.icon} size={20} className="nav-link__icon" />
        {l.label}
      </NavLink>
    </li>
  ));

  return (
    <header className={`site-header${scrolled ? ' is-scrolled' : ''}`}>
      <div className="container site-header__inner">
        <Link
          to="/"
          className="brand"
          aria-label="Vitalis — página inicial"
          onClick={(e) => {
            if (onHome) {
              e.preventDefault();
              goToSection('inicio');
            }
          }}
        >
          <img src={logo} alt="" width="62" height="52" className="brand__logo" />
        </Link>

        <nav className="main-nav" aria-label="Navegação principal">
          <ul className={`main-nav__list${user ? ' main-nav__list--app' : ''}`}>{user ? appLinks : guestLinks}</ul>
        </nav>

        <div className="site-header__actions">
          {user ? (
            <>
              <NotificationBell path={NOTIFICATIONS_PATH[user.role] || '/notificacoes'} />
              <UserMenu user={user} roleLabel={roleLabel} onLogout={handleLogout} />
            </>
          ) : (
            <>
              <Button variant="nav" to="/entrar" className="hide-sm">
                ENTRAR
              </Button>
              <Button variant="nav" to="/cadastro" className="hide-sm">
                Criar conta
              </Button>
            </>
          )}
          <button
            type="button"
            className="icon-btn menu-toggle"
            aria-label="Abrir menu"
            aria-expanded={drawer}
            aria-controls="mobile-drawer"
            onClick={() => setDrawer(true)}
          >
            <Icon name="menu" size={28} />
          </button>
        </div>
      </div>

      {drawer &&
        createPortal(
          <div className="drawer-root">
            <div className="drawer-backdrop" onClick={() => setDrawer(false)} aria-hidden="true" />
            <div className="drawer" id="mobile-drawer" ref={drawerRef} role="dialog" aria-modal="true" aria-label="Menu">
              <div className="drawer__head">
                <img src={logo} alt="Vitalis" width="54" height="46" />
                <button type="button" className="icon-btn" aria-label="Fechar menu" onClick={() => setDrawer(false)}>
                  <Icon name="close" size={28} />
                </button>
              </div>
              {user && (
                <div className="drawer__user">
                  <UserAvatar user={user} size={44} />
                  <div>
                    <p className="drawer__user-name">{user.name}</p>
                    <p className="drawer__user-email">{user.email}</p>
                    {user.role !== 'usuario' && <span className={`role-chip role-chip--${user.role}`}>{roleLabel}</span>}
                  </div>
                </div>
              )}
              <nav aria-label="Navegação principal (menu móvel)">
                <ul className="drawer__nav">{user ? appLinks : guestLinks}</ul>
                {!user && (
                  <ul className="drawer__nav drawer__nav--secondary">
                    <li>
                      <NavLink to="/servicos" className="nav-link">
                        Todos os serviços
                      </NavLink>
                    </li>
                    <li>
                      <NavLink to="/agendar" className="nav-link">
                        Agendar consulta
                      </NavLink>
                    </li>
                    <li>
                      <NavLink to="/ajuda" className="nav-link">
                        Central de ajuda
                      </NavLink>
                    </li>
                  </ul>
                )}
                {user && (
                  <ul className="drawer__nav drawer__nav--secondary">
                    {(ACCOUNT_MENU[user.role] || ACCOUNT_MENU.usuario)
                      .filter((i) => !roleLinks.some((l) => l.to === i.to))
                      .map((i) => (
                        <li key={i.to}>
                          <NavLink to={i.to} end className="nav-link">
                            <Icon name={i.icon} size={20} className="nav-link__icon" />
                            {i.label}
                          </NavLink>
                        </li>
                      ))}
                  </ul>
                )}
              </nav>
              <div className="drawer__actions">
                {user ? (
                  <Button variant="danger" block icon="logout" onClick={handleLogout}>
                    Sair da conta
                  </Button>
                ) : (
                  <>
                    <Button variant="primary" block to="/cadastro">
                      Criar conta
                    </Button>
                    <Button variant="outline" block to="/entrar">
                      Entrar
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>,
          document.body,
        )}
    </header>
  );
}
