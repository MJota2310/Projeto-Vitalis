import { useEffect, useState } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import Icon from '../ui/Icon';
import { useAuth } from '../../context/AuthContext';
import AccessDeniedPage from '../../pages/AccessDeniedPage';
import { getAnnouncement } from '../../services/adminService';

/** Volta ao topo a cada troca de página (exceto quando há uma seção alvo). */
function ScrollManager() {
  const location = useLocation();
  useEffect(() => {
    if (location.state?.scrollTo || location.state?.keepScroll) return;
    if (location.pathname === '/' && new URLSearchParams(location.search).get('secao')) return;
    window.scrollTo({ top: 0, behavior: 'auto' });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);
  return null;
}

/** Aviso global definido pela administração (Configurações da plataforma). */
function AnnouncementBar() {
  const [notice, setNotice] = useState(() => getAnnouncement());
  const [hidden, setHidden] = useState('');
  useEffect(() => {
    const update = () => setNotice(getAnnouncement());
    window.addEventListener('vitalis:db', update);
    return () => window.removeEventListener('vitalis:db', update);
  }, []);
  if (!notice || hidden === notice.text) return null;
  return (
    <div className={`announce announce--${notice.tone}`} role="status">
      <div className="container announce__inner">
        <Icon name="campaign" size={20} />
        <p>{notice.text}</p>
        <button
          type="button"
          className="icon-btn announce__close"
          aria-label="Fechar aviso"
          onClick={() => setHidden(notice.text)}
        >
          <Icon name="close" size={18} />
        </button>
      </div>
    </div>
  );
}

/** Aviso de conexão perdida (os dados continuam salvos neste navegador). */
function OfflineBanner() {
  const [offline, setOffline] = useState(typeof navigator !== 'undefined' && navigator.onLine === false);
  useEffect(() => {
    const on = () => setOffline(false);
    const off = () => setOffline(true);
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);
  if (!offline) return null;
  return (
    <div className="offline-banner" role="alert">
      <Icon name="wifi_off" size={18} /> Você está sem conexão. Nesta demonstração os dados ficam salvos neste navegador e
      continuam disponíveis.
    </div>
  );
}

export default function Layout() {
  const location = useLocation();
  // As áreas com menu lateral mantêm a moldura fixa e animam só o conteúdo interno
  const area = location.pathname.match(/^\/(profissional|admin)(\/|$)/)?.[1];
  return (
    <>
      <a
        href="#conteudo"
        className="skip-link"
        onClick={(e) => {
          e.preventDefault();
          document.getElementById('conteudo')?.focus();
        }}
      >
        Pular para o conteúdo
      </a>
      <ScrollManager />
      <Header />
      <AnnouncementBar />
      <OfflineBanner />
      <main id="conteudo" tabIndex={-1} className="site-main">
        <div key={area || location.pathname} className="page-transition">
          <Outlet />
        </div>
      </main>
      <Footer />
    </>
  );
}

/**
 * Protege rotas privadas.
 * - sem sessão → login, voltando depois ao destino;
 * - com sessão, mas papel diferente de `roles` → página de acesso negado (403).
 * A interface só reflete a regra: as operações de dados também verificam o
 * papel na camada de serviços (services/session.js).
 */
export function RequireAuth({ children, roles }) {
  const { isAuthenticated, signedOut, user } = useAuth();
  const location = useLocation();
  if (!isAuthenticated) {
    if (signedOut) return <Navigate to="/" replace />;
    const redirect = encodeURIComponent(location.pathname + location.search);
    return <Navigate to={`/entrar?redirect=${redirect}`} replace state={{ reason: 'auth' }} />;
  }
  if (roles && !roles.includes(user.role)) return <AccessDeniedPage required={roles} />;
  return children;
}

/** Páginas de login/cadastro: se já estiver logado, vai para a página inicial do seu perfil. */
export function GuestOnly({ children }) {
  const { isAuthenticated, landing } = useAuth();
  const location = useLocation();
  if (isAuthenticated) {
    const redirect = new URLSearchParams(location.search).get('redirect');
    return <Navigate to={redirect && redirect.startsWith('/') ? redirect : landing} replace />;
  }
  return children;
}

/**
 * Leva cada perfil ao seu painel (ex.: profissional que abre /painel).
 * `to` (opcional) aponta para a seção equivalente na área do papel:
 * <RoleHome role="usuario" to="notificacoes"> → /profissional/notificacoes.
 */
export function RoleHome({ children, role, to }) {
  const { user, home } = useAuth();
  if (user && user.role !== role) return <Navigate to={to ? `${home}/${to}` : home} replace />;
  return children;
}
