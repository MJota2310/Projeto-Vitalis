import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Icon from '../ui/Icon';
import { useClickOutside } from '../../hooks';
import { listNotifications, markAllRead, markRead, unreadCount, NOTIFICATION_TYPES } from '../../services/notificationService';
import { relativeTime } from '../../utils/format';

/** Sino com contador de não lidas e prévia das últimas notificações. */
export default function NotificationBell({ path }) {
  const [count, setCount] = useState(() => unreadCount());
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState(null);
  const [bump, setBump] = useState(false);
  const ref = useRef(null);
  const navigate = useNavigate();
  const close = useCallback(() => setOpen(false), []);
  useClickOutside(ref, close, open);

  useEffect(() => {
    const update = () =>
      setCount((prev) => {
        const next = unreadCount();
        if (next > prev) setBump(true);
        return next;
      });
    window.addEventListener('vitalis:db', update);
    return () => window.removeEventListener('vitalis:db', update);
  }, []);

  useEffect(() => {
    if (!open) return undefined;
    let alive = true;
    setItems(null);
    listNotifications().then((list) => alive && setItems(list.slice(0, 5)));
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('keydown', onKey);
    return () => {
      alive = false;
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const openItem = async (n) => {
    setOpen(false);
    if (!n.read) await markRead(n.id).catch(() => {});
    if (n.link) navigate(n.link);
  };

  return (
    <div className="bell" ref={ref}>
      <button
        type="button"
        className={`icon-btn bell__btn${bump ? ' is-bumping' : ''}`}
        aria-label={count ? `Notificações: ${count} não lida(s)` : 'Notificações'}
        aria-haspopup="dialog"
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
        onAnimationEnd={() => setBump(false)}
      >
        <Icon name={count ? 'notifications_active' : 'notifications'} size={24} />
        {count > 0 && (
          <span className="bell__count" aria-hidden="true">
            {count > 9 ? '9+' : count}
          </span>
        )}
      </button>
      {open && (
        <div className="bell__panel dropdown" role="dialog" aria-label="Notificações recentes">
          <div className="bell__head">
            <p className="bell__title">Notificações</p>
            {count > 0 && (
              <button
                type="button"
                className="text-link bell__all"
                onClick={async () => {
                  await markAllRead();
                  setItems((list) => list?.map((n) => ({ ...n, read: true })));
                }}
              >
                Marcar todas como lidas
              </button>
            )}
          </div>
          {!items ? (
            <div className="bell__loading">
              <span className="skeleton" style={{ height: 52 }} />
              <span className="skeleton" style={{ height: 52 }} />
            </div>
          ) : items.length === 0 ? (
            <p className="bell__empty">
              <Icon name="notifications_off" size={22} /> Nenhuma notificação por aqui.
            </p>
          ) : (
            <ul className="bell__list">
              {items.map((n) => {
                const t = NOTIFICATION_TYPES[n.type] || NOTIFICATION_TYPES.sistema;
                return (
                  <li key={n.id}>
                    <button type="button" className={`bell__item${n.read ? '' : ' is-unread'}`} onClick={() => openItem(n)}>
                      <span className={`ntf-icon ntf-icon--${t.tone}`}>
                        <Icon name={t.icon} size={18} />
                      </span>
                      <span className="bell__body">
                        <strong>{n.title}</strong>
                        <small>{n.text}</small>
                        <time dateTime={n.createdAt}>{relativeTime(n.createdAt)}</time>
                      </span>
                      {n.important && <Icon name="label_important" size={18} className="bell__flag" label="Importante" />}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
          <Link to={path} className="bell__footer" onClick={close}>
            Ver todas as notificações <Icon name="arrow_forward" size={18} />
          </Link>
        </div>
      )}
    </div>
  );
}
