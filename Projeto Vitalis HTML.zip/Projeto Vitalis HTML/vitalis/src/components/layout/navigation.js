// Mapa de navegação do cabeçalho e rodapé.

// Seções da landing page (menu do visitante, como no Figma)
export const LANDING_SECTIONS = [
  { id: 'inicio', label: 'Início' },
  { id: 'como-funciona', label: 'Como funciona' },
  { id: 'servicos', label: 'Serviços' },
  { id: 'profissionais', label: 'Para profissionais' },
  { id: 'contato', label: 'Contato' },
];

// Menu da área logada (telas internas do Figma: Início, Agende, Dashboard, Consultas, Suporte)
export const APP_LINKS = [
  { to: '/', label: 'Início', end: true, icon: 'home' },
  { to: '/agendar', label: 'Agende', icon: 'calendar_today' },
  { to: '/painel', label: 'Dashboard', icon: 'dashboard' },
  { to: '/consultas', label: 'Consultas', icon: 'event_note' },
  { to: '/ajuda', label: 'Suporte', icon: 'support_agent' },
];

// Menu do profissional
export const PRO_LINKS = [
  { to: '/', label: 'Início', end: true, icon: 'home' },
  { to: '/profissional', label: 'Painel', end: true, icon: 'dashboard' },
  { to: '/profissional/agenda', label: 'Agenda', icon: 'calendar_month' },
  { to: '/profissional/clientes', label: 'Clientes', icon: 'group' },
  { to: '/ajuda', label: 'Suporte', icon: 'support_agent' },
];

// Menu da administração
export const ADMIN_LINKS = [
  { to: '/', label: 'Início', end: true, icon: 'home' },
  { to: '/admin', label: 'Painel', end: true, icon: 'dashboard' },
  { to: '/admin/profissionais', label: 'Profissionais', icon: 'badge' },
  { to: '/admin/agendamentos', label: 'Agendamentos', icon: 'event_note' },
  { to: '/admin/solicitacoes', label: 'Solicitações', icon: 'inbox' },
];

export const LINKS_BY_ROLE = { usuario: APP_LINKS, profissional: PRO_LINKS, admin: ADMIN_LINKS };

// Itens do menu da conta (avatar) por perfil
export const ACCOUNT_MENU = {
  usuario: [
    { to: '/painel', icon: 'dashboard', label: 'Dashboard' },
    { to: '/consultas', icon: 'event_note', label: 'Minhas consultas' },
    { to: '/favoritos', icon: 'favorite', label: 'Favoritos' },
    { to: '/notificacoes', icon: 'notifications', label: 'Notificações' },
    { to: '/perfil', icon: 'account_circle', label: 'Meu perfil' },
    { to: '/perfil?aba=configuracoes', icon: 'settings', label: 'Configurações' },
  ],
  profissional: [
    { to: '/profissional', icon: 'dashboard', label: 'Painel profissional' },
    { to: '/profissional/agenda', icon: 'calendar_month', label: 'Agenda' },
    { to: '/profissional/perfil', icon: 'badge', label: 'Perfil profissional' },
    { to: '/profissional/notificacoes', icon: 'notifications', label: 'Notificações' },
    { to: '/profissional/configuracoes', icon: 'settings', label: 'Configurações' },
    { to: '/consultas', icon: 'event_note', label: 'Minhas consultas (paciente)' },
  ],
  admin: [
    { to: '/admin', icon: 'dashboard', label: 'Painel administrativo' },
    { to: '/admin/usuarios', icon: 'group', label: 'Usuários' },
    { to: '/admin/notificacoes', icon: 'notifications', label: 'Notificações' },
    { to: '/admin/configuracoes', icon: 'settings', label: 'Configurações da plataforma' },
  ],
};

export const NOTIFICATIONS_PATH = {
  usuario: '/notificacoes',
  profissional: '/profissional/notificacoes',
  admin: '/admin/notificacoes',
};

export const FOOTER_LINKS = {
  uteis: [
    { label: 'Início', section: 'inicio' },
    { label: 'Como Funciona', section: 'como-funciona' },
    { label: 'Serviços', to: '/servicos' },
    { label: 'Profissionais', to: '/profissionais' },
    { label: 'Para Profissionais', section: 'profissionais' },
  ],
  suporte: [
    { label: 'Central de ajuda', to: '/ajuda' },
    { label: 'FAQ', to: '/faq' },
    { label: 'Termos de uso', to: '/termos' },
    { label: 'Política de privacidade', to: '/privacidade' },
  ],
};
