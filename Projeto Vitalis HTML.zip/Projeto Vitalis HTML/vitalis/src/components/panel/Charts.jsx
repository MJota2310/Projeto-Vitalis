import { useId, useState } from 'react';

/*
 * Gráficos leves (SVG/HTML, sem bibliotecas) na cor da marca.
 * Série única → sem legenda (o título nomeia o que é mostrado). Barras finas
 * (≤ 24px) com ponta arredondada, linhas de grade discretas, rótulo apenas no
 * destaque, dica (tooltip) no foco e no hover e tabela acessível equivalente.
 */

/** Colunas verticais (ex.: agendamentos por dia, receita por mês). */
export function ColumnChart({ data, format = (v) => v, height = 160, highlight, label, emptyText = 'Sem dados no período.' }) {
  const [active, setActive] = useState(null);
  const id = useId();
  const max = Math.max(...data.map((d) => d.value), 0);
  if (!data.length) return <p className="chart-empty">{emptyText}</p>;
  const top = max > 0 ? niceMax(max) : 1;
  const ticks = [0, top / 2, top];
  const shown = active ?? highlight;
  return (
    <figure className="chart" aria-labelledby={`${id}-cap`}>
      <figcaption id={`${id}-cap`} className="sr-only">
        {label}
      </figcaption>
      <div className="chart__plot" style={{ height }}>
        <div className="chart__grid" aria-hidden="true">
          {ticks
            .slice()
            .reverse()
            .map((t) => (
              <span key={t}>
                <em>{format(t)}</em>
              </span>
            ))}
        </div>
        <div className="chart__cols" role="list">
          {data.map((d, i) => {
            const h = top ? (d.value / top) * 100 : 0;
            const isOn = shown === i;
            const tip = active === i; // dica completa só no hover/foco; o destaque mostra apenas o valor
            return (
              <div
                key={d.key || d.label}
                role="listitem"
                tabIndex={0}
                className={`chart__col${isOn ? ' is-active' : ''}${d.muted ? ' is-muted' : ''}`}
                aria-label={`${d.full || d.label}: ${format(d.value)}`}
                onPointerEnter={() => setActive(i)}
                onPointerLeave={() => setActive(null)}
                onFocus={() => setActive(i)}
                onBlur={() => setActive(null)}
              >
                <span className="chart__bar" style={{ '--h': `${h}%`, animationDelay: `${i * 50}ms` }}>
                  {isOn && !tip && <span className="chart__val">{format(d.value)}</span>}
                  {tip && (
                    <span className="chart__tip" role="tooltip">
                      <strong>{format(d.value)}</strong>
                      <span>{d.full || d.label}</span>
                    </span>
                  )}
                </span>
                <span className="chart__x">{d.label}</span>
              </div>
            );
          })}
        </div>
      </div>
      <table className="sr-only">
        <caption>{label}</caption>
        <tbody>
          {data.map((d) => (
            <tr key={d.key || d.label}>
              <th scope="row">{d.full || d.label}</th>
              <td>{format(d.value)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </figure>
  );
}

/** Barras horizontais com valor na ponta (ex.: serviços mais agendados). */
export function BarList({ data, format = (v) => v, label }) {
  const max = Math.max(...data.map((d) => d.value), 0) || 1;
  return (
    <figure className="barlist">
      <figcaption className="sr-only">{label}</figcaption>
      <ul>
        {data.map((d, i) => (
          <li key={d.key || d.label} className="barlist__row">
            <span className="barlist__label" title={typeof d.label === 'string' ? d.label : undefined}>
              {d.badge}
              <span>{d.label}</span>
            </span>
            <span className="barlist__track" aria-hidden="true">
              <span className="barlist__bar" style={{ '--w': `${(d.value / max) * 100}%`, animationDelay: `${i * 60}ms` }} />
            </span>
            <span className="barlist__value">{format(d.value)}</span>
          </li>
        ))}
      </ul>
    </figure>
  );
}

/** Medidor de proporção (ex.: ocupação da agenda). */
export function Meter({ value, label, hint }) {
  const v = Math.max(0, Math.min(100, Math.round(value)));
  const tone = v >= 85 ? 'high' : v >= 50 ? 'mid' : 'low';
  return (
    <div className={`meter meter--${tone}`}>
      <div className="meter__top">
        <span className="meter__label">{label}</span>
        <strong className="meter__value">{v}%</strong>
      </div>
      <div className="meter__track" role="meter" aria-valuemin={0} aria-valuemax={100} aria-valuenow={v} aria-label={label}>
        <span className="meter__fill" style={{ '--w': `${v}%` }} />
      </div>
      {hint && <p className="meter__hint">{hint}</p>}
    </div>
  );
}

function niceMax(v) {
  const p = 10 ** Math.floor(Math.log10(v));
  const n = v / p;
  const step = n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10;
  return step * p;
}
