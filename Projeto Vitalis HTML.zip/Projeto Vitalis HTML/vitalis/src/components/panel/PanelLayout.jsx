import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, Outlet, useLocation } from 'react-router-dom';
import Icon from '../ui/Icon';
import './panel.css';
import { scrollBehavior } from '../../utils/motion';

/**
 * Moldura das áreas de gestão (profissional e administração): menu lateral no
 * computador e faixa de navegação rolável no celular, mantendo o cabeçalho e o
 * rodapé do site. O conteúdo de cada página entra no <Outlet />.
 */
export default function PanelLayout({ identity, items, footer, label, context }) {
  const { pathname } = useLocation();
  const listRef = useRef(null);

  // no celular o menu vira uma faixa rolável: mantém o item ativo visível
  useEffect(() => {
    const ul = listRef.current;
    const active = ul?.querySelector('.is-active');
    if (!ul || !active || ul.scrollWidth <= ul.clientWidth) return;
    ul.scrollTo({ left: active.offsetLeft - ul.clientWidth / 2 + active.clientWidth / 2, behavior: scrollBehavior() });
  }, [pathname]);

  return (
    <div className="panel-page">
      <div className="container panel">
        <aside className="panel-side">
          {identity && <div className="panel-side__id">{identity}</div>}
          <nav className="panel-nav" aria-label={label}>
            <ul ref={listRef}>
              {items.map((it) => (
                <li key={it.to}>
                  <NavLink to={it.to} end={it.end} className={({ isActive }) => `panel-nav__link${isActive ? ' is-active' : ''}`}>
                    <Icon name={it.icon} size={21} />
                    <span>{it.label}</span>
                    {it.badge ? (
                      <span className="panel-nav__badge" aria-label={`${it.badge} pendente(s)`}>
                        {it.badge > 9 ? '9+' : it.badge}
                      </span>
                    ) : null}
                  </NavLink>
                </li>
              ))}
            </ul>
          </nav>
          {footer && <div className="panel-side__foot">{footer}</div>}
        </aside>
        <div className="panel-main" key={pathname}>
          <Outlet context={context} />
        </div>
      </div>
    </div>
  );
}

/** Cabeçalho padrão das páginas internas dos painéis. */
export function PanelHeader({ eyebrow, title, subtitle, actions, children }) {
  return (
    <header className="panel-header">
      <div className="panel-header__copy">
        {eyebrow && <p className="panel-header__eyebrow">{eyebrow}</p>}
        <h1 className="panel-header__title">{title}</h1>
        {subtitle && <p className="panel-header__subtitle">{subtitle}</p>}
        {children}
      </div>
      {actions && <div className="panel-header__actions">{actions}</div>}
    </header>
  );
}

/** Cartão de indicador (mesma linguagem dos cartões de estatística do site). */
export function KpiCard({ icon, label, value, hint, tone = 'green', to, delay = 0, children }) {
  const Tag = to ? Link : 'div';
  return (
    <Tag to={to} className={`kpi kpi--${tone}${to ? ' kpi--link' : ''}`} style={{ animationDelay: `${delay}ms` }}>
      <span className="kpi__icon">
        <Icon name={icon} size={22} />
      </span>
      <span className="kpi__body">
        <span className="kpi__label">{label}</span>
        <strong className={`kpi__value${String(value).length > 9 ? ' kpi__value--long' : ''}`}>{value}</strong>
        {hint && <span className="kpi__hint">{hint}</span>}
        {children}
      </span>
      {to && <Icon name="chevron_right" size={20} className="kpi__chev" />}
    </Tag>
  );
}

/** Selo com tom (usa as classes .badge do site). */
export function ToneBadge({ tone = 'gray', icon, children, className = '' }) {
  return (
    <span className={`badge badge--${tone} ${className}`}>
      {icon && <Icon name={icon} size={15} />}
      {children}
    </span>
  );
}

/** Campo de busca usado nas barras de filtro dos painéis. */
export function SearchBox({ id, label, placeholder, value, onChange }) {
  return (
    <div className="field field--icon toolbar__search">
      <label htmlFor={id} className="sr-only">
        {label}
      </label>
      <div className="field__control">
        <Icon name="search" size={20} className="field__icon" />
        <input
          id={id}
          className="input"
          type="search"
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />
      </div>
    </div>
  );
}

/** Valor com atraso (debounce) para buscas digitadas. */
export function useDebounced(value, ms = 250) {
  const [v, setV] = useState(value);
  useEffect(() => {
    const t = setTimeout(() => setV(value), ms);
    return () => clearTimeout(t);
  }, [value, ms]);
  return v;
}
