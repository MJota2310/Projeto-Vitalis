import { Link } from 'react-router-dom';
import Icon from '../ui/Icon';
import Button from '../ui/Button';
import { professionalCount } from '../../services/catalogService';
import { pluralize } from '../../utils/format';

/** Card de serviço (grades "Todos os serviços" / Medicina / Terapias / Bem-estar). */
export default function ServiceCard({ service, style }) {
  const count = professionalCount(service.slug);
  return (
    <article className="service-card" style={style}>
      <Link
        to={`/servicos/${service.slug}`}
        className="service-card__main"
        aria-label={`${service.name}: ver detalhes e profissionais`}
      >
        <div className="service-card__top">
          <span className={`icon-tile icon-tile--${service.tile}`}>
            <Icon name={service.icon} size={30} />
          </span>
          <span className="service-card__count">{pluralize(count, 'profissional', 'profissionais')}</span>
        </div>
        <h3 className="service-card__title">{service.name}</h3>
        <p className="service-card__desc">{service.description}</p>
        <span className="service-card__more">
          Ver detalhes <Icon name="arrow_forward" size={16} />
        </span>
      </Link>
      <Button variant="soft-green" block to={`/agendar?servico=${service.slug}`} className="service-card__cta">
        Agendar agora
      </Button>
    </article>
  );
}

export function ServiceCardSkeleton() {
  return (
    <div className="service-card service-card--skeleton" aria-hidden="true">
      <div className="service-card__top">
        <span className="skeleton" style={{ width: 52, height: 52, borderRadius: 10 }} />
        <span className="skeleton" style={{ width: 100, height: 14 }} />
      </div>
      <span className="skeleton" style={{ width: '55%', height: 20, marginTop: 22 }} />
      <span className="skeleton" style={{ width: '90%', height: 12, marginTop: 12 }} />
      <span className="skeleton" style={{ width: '70%', height: 12, marginTop: 8 }} />
      <span className="skeleton" style={{ width: '100%', height: 44, marginTop: 22, borderRadius: 8 }} />
    </div>
  );
}
