import { useId, useState } from 'react';
import Icon from './Icon';

/** Acordeão acessível (botão com aria-expanded + região controlada). */
export function AccordionItem({ title, children, open, onToggle, id }) {
  const autoId = useId();
  const baseId = id || autoId;
  return (
    <div className={`acc-item${open ? ' is-open' : ''}`}>
      <h3 style={{ margin: 0 }}>
        <button
          type="button"
          className="acc-trigger"
          aria-expanded={open}
          aria-controls={`${baseId}-panel`}
          id={`${baseId}-trigger`}
          onClick={onToggle}
        >
          <span>{title}</span>
          <Icon name="keyboard_arrow_down" size={26} />
        </button>
      </h3>
      <div className="acc-panel" id={`${baseId}-panel`} role="region" aria-labelledby={`${baseId}-trigger`} hidden={false}>
        <div>
          <div className="acc-content" inert={!open ? '' : undefined}>
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Accordion({ items, defaultOpen = null, allowMultiple = false }) {
  const [open, setOpen] = useState(() => (defaultOpen == null ? [] : [defaultOpen]));
  const toggle = (key) =>
    setOpen((cur) => {
      if (cur.includes(key)) return cur.filter((k) => k !== key);
      return allowMultiple ? [...cur, key] : [key];
    });
  return (
    <div className="accordion">
      {items.map((item) => (
        <AccordionItem key={item.key} title={item.title} open={open.includes(item.key)} onToggle={() => toggle(item.key)}>
          {item.content}
        </AccordionItem>
      ))}
    </div>
  );
}
