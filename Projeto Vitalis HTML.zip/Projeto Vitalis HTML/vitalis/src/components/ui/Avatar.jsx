import { initials, proEmoji } from '../../utils/avatar';

/** Avatar da conta: foto (se houver) ou iniciais sobre o gradiente da marca. */
export function UserAvatar({ user, size = 44, className = '' }) {
  if (user?.photo) {
    return (
      <img
        src={user.photo}
        alt=""
        className={`avatar avatar--photo ${className}`}
        style={{ '--avatar': `${size}px` }}
        width={size}
        height={size}
      />
    );
  }
  return (
    <span className={`avatar ${className}`} style={{ '--avatar': `${size}px` }} aria-hidden="true">
      {initials(user?.name || '')}
    </span>
  );
}

/**
 * Avatar de profissional: foto enviada pelo profissional; nos perfis fictícios
 * do catálogo, o emoji usado desde o protótipo; nos demais, as iniciais.
 */
export function ProAvatar({ pro, size = 64, className = '' }) {
  const style = size ? { '--pro-avatar': `${size}px` } : undefined;
  if (pro?.photo) {
    return (
      <img
        src={pro.photo}
        alt=""
        className={`pro-avatar pro-avatar--photo ${className}`}
        style={style}
        width={size || undefined}
        height={size || undefined}
      />
    );
  }
  if (pro?.simulated || pro?.gender) {
    return (
      <span className={`pro-avatar ${className}`} style={style} aria-hidden="true">
        {proEmoji(pro)}
      </span>
    );
  }
  return (
    <span className={`pro-avatar pro-avatar--initials ${className}`} style={style} aria-hidden="true">
      {initials(String(pro?.name || '').replace(/^(Dr\.|Dra\.|Prof\.|Profª\.)\s+/, ''))}
    </span>
  );
}
