import { forwardRef } from 'react';
import { Link } from 'react-router-dom';
import Icon from './Icon';

/**
 * Botão padrão da Vitalis.
 * - `to` → renderiza <Link> (navegação interna)
 * - `href` → renderiza <a> (links externos, mailto:, tel:)
 * - `loading` → mostra spinner e bloqueia cliques repetidos
 */
const Button = forwardRef(function Button(
  {
    variant = 'primary',
    size,
    block,
    wrap,
    icon,
    iconRight,
    iconSize = 22,
    loading = false,
    loadingText,
    disabled,
    to,
    href,
    className = '',
    children,
    type = 'button',
    ...rest
  },
  ref,
) {
  const classes = [
    'btn',
    `btn--${variant}`,
    size && `btn--${size}`,
    block && 'btn--block',
    wrap && 'btn--wrap',
    loading && 'is-loading',
    className,
  ]
    .filter(Boolean)
    .join(' ');

  const content = (
    <>
      {loading ? <span className="spinner" aria-hidden="true" /> : icon && <Icon name={icon} size={iconSize} />}
      <span>{loading && loadingText ? loadingText : children}</span>
      {!loading && iconRight && <Icon name={iconRight} size={iconSize} />}
    </>
  );

  if (to && !disabled) {
    return (
      <Link ref={ref} to={to} className={classes} {...rest}>
        {content}
      </Link>
    );
  }

  if (href && !disabled) {
    const external = /^https?:/.test(href);
    return (
      <a
        ref={ref}
        href={href}
        className={classes}
        {...(external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
        {...rest}
      >
        {content}
      </a>
    );
  }

  return (
    <button ref={ref} type={type} className={classes} disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
      {content}
    </button>
  );
});

export default Button;
