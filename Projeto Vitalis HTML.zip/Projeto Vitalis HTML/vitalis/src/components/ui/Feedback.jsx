import Icon from './Icon';
import Button from './Button';
import { STATUS } from '../../services/appointmentService';

export function Spinner({ size = 'lg', label = 'Carregando…' }) {
  return (
    <div className="loader" role="status" aria-live="polite">
      <span className={`spinner spinner--${size}`} aria-hidden="true" />
      <span className="sr-only">{label}</span>
    </div>
  );
}

export function Skeleton({ width = '100%', height = 16, radius, style, className = '' }) {
  return (
    <span className={`skeleton ${className}`} style={{ width, height, borderRadius: radius, ...style }} aria-hidden="true" />
  );
}

export function EmptyState({ icon = 'search', title, text, actions }) {
  return (
    <div className="empty">
      <div className="empty__icon">
        <Icon name={icon} size={38} />
      </div>
      <h3 className="empty__title">{title}</h3>
      {text && <p className="empty__text">{text}</p>}
      {actions && <div className="empty__actions">{actions}</div>}
    </div>
  );
}

export function ErrorState({ error, onRetry }) {
  return (
    <EmptyState
      icon="error"
      title="Não foi possível carregar"
      text={error?.message || 'Ocorreu um erro inesperado. Tente novamente.'}
      actions={
        onRetry && (
          <Button variant="outline" size="sm" icon="refresh" onClick={onRetry}>
            Tentar novamente
          </Button>
        )
      }
    />
  );
}

export function Notice({ tone = 'info', icon, title, children, className = '' }) {
  const icons = { info: 'info', success: 'check_circle', warning: 'warning', error: 'error', demo: 'info' };
  return (
    <div className={`notice notice--${tone} ${className}`} role={tone === 'error' ? 'alert' : undefined}>
      <Icon name={icon || icons[tone]} size={20} />
      <div>
        {title && <strong>{title} </strong>}
        {children}
      </div>
    </div>
  );
}

export function StatusBadge({ status }) {
  const s = STATUS[status] || { label: status, tone: 'gray', icon: 'info' };
  return (
    <span className={`badge badge--${s.tone}`}>
      <Icon name={s.icon} size={15} />
      {s.label}
    </span>
  );
}

export function Stars({ rating = 5, reviews, size = 16 }) {
  const full = Math.round(rating);
  return (
    <span className="rating">
      <span className="rating__stars" aria-label={`Nota ${rating.toFixed(1)} de 5`} role="img">
        {Array.from({ length: 5 }, (_, i) => (
          <Icon key={i} name="star" fill={i < full} size={size} />
        ))}
      </span>
      <span>
        {rating.toFixed(1)}
        {reviews != null && ` (${reviews} avaliações)`}
      </span>
    </span>
  );
}

export function DemoBadge({ children = 'Modo demonstração' }) {
  return (
    <span className="badge badge--demo">
      <Icon name="info" size={14} />
      {children}
    </span>
  );
}
