import { useId, useState } from 'react';
import Icon from './Icon';

/** Campo de texto com rótulo, ícone, dica e mensagem de erro acessível. */
export function TextField({
  label,
  name,
  icon,
  error,
  hint,
  required,
  className = '',
  action,
  as = 'input',
  children,
  valid,
  ...inputProps
}) {
  const autoId = useId();
  const id = inputProps.id || `${name || 'f'}-${autoId}`;
  const errId = `${id}-err`;
  const hintId = `${id}-hint`;
  const describedBy = [error ? errId : null, hint ? hintId : null].filter(Boolean).join(' ') || undefined;
  const Tag = as;
  const controlClass = as === 'textarea' ? 'textarea' : as === 'select' ? 'select' : 'input';

  return (
    <div
      className={[
        'field',
        icon && 'field--icon',
        action && 'field--action',
        error && 'has-error',
        valid && !error && 'is-valid',
        className,
      ]
        .filter(Boolean)
        .join(' ')}
    >
      {label && (
        <label className="field__label" htmlFor={id}>
          {label}
          {required && (
            <span className="req" aria-hidden="true">
              *
            </span>
          )}
        </label>
      )}
      <div className="field__control">
        {icon && <Icon name={icon} size={20} className="field__icon" />}
        <Tag
          id={id}
          name={name}
          className={controlClass}
          aria-invalid={error ? 'true' : undefined}
          aria-describedby={describedBy}
          aria-required={required || undefined}
          {...inputProps}
        >
          {children}
        </Tag>
        {action}
      </div>
      {hint && !error && (
        <p className="field__hint" id={hintId}>
          {hint}
        </p>
      )}
      {error && (
        <p className="field__error" id={errId} role="alert">
          <Icon name="error" size={16} />
          {error}
        </p>
      )}
    </div>
  );
}

/** Campo de senha com botão para mostrar/ocultar. */
export function PasswordField(props) {
  const [visible, setVisible] = useState(false);
  return (
    <TextField
      {...props}
      type={visible ? 'text' : 'password'}
      icon={props.icon ?? 'lock'}
      action={
        <button
          type="button"
          className="field__action"
          onClick={() => setVisible((v) => !v)}
          aria-label={visible ? 'Ocultar senha' : 'Mostrar senha'}
          aria-pressed={visible}
        >
          <Icon name={visible ? 'visibility_off' : 'visibility'} size={20} />
        </button>
      }
    />
  );
}

/** Caixa de seleção estilizada. */
export function Checkbox({ label, error, className = '', ...props }) {
  const id = useId();
  return (
    <div>
      <label className={`check ${error ? 'has-error' : ''} ${className}`} htmlFor={id}>
        <input
          id={id}
          type="checkbox"
          aria-invalid={error ? 'true' : undefined}
          aria-describedby={error ? `${id}-err` : undefined}
          {...props}
        />
        <span>{label}</span>
      </label>
      {error && (
        <p className="field__error" id={`${id}-err`} role="alert" style={{ marginTop: 6 }}>
          <Icon name="error" size={16} />
          {error}
        </p>
      )}
    </div>
  );
}

/** Interruptor liga/desliga acessível (role="switch"). */
export function Toggle({ checked, onChange, label, disabled, id }) {
  return (
    <button
      id={id}
      type="button"
      role="switch"
      className="switch"
      aria-checked={checked}
      aria-label={label}
      disabled={disabled}
      onClick={() => onChange(!checked)}
    />
  );
}
