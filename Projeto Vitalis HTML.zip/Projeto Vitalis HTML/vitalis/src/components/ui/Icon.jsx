import icons from '../../assets/icons';

/**
 * Ícone Material Symbols (mesma família usada nas telas do Figma).
 * Decorativo por padrão (aria-hidden). Informe `label` quando o ícone
 * transmitir significado sozinho.
 */
export default function Icon({ name, size = 24, className = '', label, fill, style }) {
  const key = fill ? `${name}Fill` : name;
  const d = icons[key] || icons[name];
  if (!d) {
    if (import.meta.env.DEV) console.warn(`[Icon] ícone não encontrado: ${name}`);
    return null;
  }
  const paths = Array.isArray(d) ? d : [d];
  return (
    <svg
      className={`icon ${className}`}
      width={size}
      height={size}
      viewBox="0 -960 960 960"
      fill="currentColor"
      style={style}
      role={label ? 'img' : undefined}
      aria-label={label}
      aria-hidden={label ? undefined : true}
      focusable="false"
    >
      {paths.map((p, i) => (
        <path key={i} d={p} />
      ))}
    </svg>
  );
}
