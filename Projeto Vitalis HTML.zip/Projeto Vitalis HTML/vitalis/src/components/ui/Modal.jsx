import { useId, useRef } from 'react';
import { createPortal } from 'react-dom';
import Icon from './Icon';
import { useFocusTrap, useLockBody } from '../../hooks';

/** Modal acessível: foco preso, Esc fecha, clique no fundo fecha. */
export default function Modal({ open, onClose, title, children, footer, width, dismissible = true, labelledBy }) {
  const ref = useRef(null);
  const titleId = useId();
  useLockBody(open);
  useFocusTrap(open, ref, dismissible ? onClose : undefined);

  if (!open) return null;

  return createPortal(
    <div className="modal-root">
      <div className="modal-backdrop" onClick={dismissible ? onClose : undefined} aria-hidden="true" />
      <div
        ref={ref}
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby={labelledBy || titleId}
        style={width ? { '--modal-w': `${width}px` } : undefined}
        tabIndex={-1}
      >
        {title && (
          <div className="modal__header">
            <h2 className="modal__title" id={titleId}>
              {title}
            </h2>
            {dismissible && (
              <button type="button" className="icon-btn" onClick={onClose} aria-label="Fechar">
                <Icon name="close" />
              </button>
            )}
          </div>
        )}
        <div className="modal__body">{children}</div>
        {footer && <div className="modal__footer">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}
