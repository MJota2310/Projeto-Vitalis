import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import * as authService from '../services/authService';
import { homeFor, ROLES } from '../services/session';
import { professionalById } from '../data/catalog';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => authService.getSessionUser());
  // true após um "Sair" voluntário: rotas privadas mandam para o início, não para o login
  const [signedOut, setSignedOut] = useState(false);
  const { pathname } = useLocation();

  // Depois de chegar ao início, rotas privadas voltam a pedir login normalmente
  useEffect(() => {
    if (signedOut && pathname === '/') setSignedOut(false);
  }, [signedOut, pathname]);

  // Mantém o usuário em sincronia com o banco (foto, nome, suspensão, outra aba)
  const refreshUser = useCallback(() => {
    const fresh = authService.getSessionUser();
    setUser((prev) => {
      if (!fresh && !prev) return prev;
      if (fresh && prev && JSON.stringify(fresh) === JSON.stringify(prev)) return prev;
      return fresh;
    });
  }, []);
  useEffect(() => {
    window.addEventListener('vitalis:db', refreshUser);
    return () => window.removeEventListener('vitalis:db', refreshUser);
  }, [refreshUser]);

  const login = useCallback(async (credentials) => {
    const u = await authService.login(credentials);
    setSignedOut(false);
    setUser(u);
    return u;
  }, []);

  const register = useCallback(async (data) => {
    const u = await authService.register(data);
    setSignedOut(false);
    setUser(u);
    return u;
  }, []);

  const logout = useCallback(async () => {
    await authService.logout();
    setSignedOut(true);
    setUser(null);
  }, []);

  const updateProfile = useCallback(
    async (data) => {
      const u = await authService.updateProfile(user.id, data);
      setUser(u);
      return u;
    },
    [user],
  );

  const updatePreferences = useCallback(
    async (prefs) => {
      const u = await authService.updatePreferences(user.id, prefs);
      setUser(u);
      return u;
    },
    [user],
  );

  const changePassword = useCallback((current, next) => authService.changePassword(user.id, current, next), [user]);

  const value = useMemo(
    () => ({
      user,
      role: user?.role || null,
      roleLabel: ROLES[user?.role]?.label || '',
      home: homeFor(user),
      // profissional com cadastro ainda em configuração começa pelo onboarding
      landing:
        user?.role === 'profissional' && (!user.professionalId || professionalById(user.professionalId)?.status === 'rascunho')
          ? '/profissional/onboarding'
          : homeFor(user),
      isAuthenticated: !!user,
      refreshUser,
      signedOut,
      login,
      register,
      logout,
      updateProfile,
      updatePreferences,
      changePassword,
    }),
    [user, signedOut, login, register, logout, updateProfile, updatePreferences, changePassword, refreshUser],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth deve ser usado dentro de <AuthProvider>');
  return ctx;
}
