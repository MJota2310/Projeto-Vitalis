// Rascunho do agendamento — preservado entre as etapas (e após um refresh ou
// login) no sessionStorage.

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { session, KEYS } from '../services/storage';
import { professionalById, serviceBySlug, SERVICE_FEE } from '../data/catalog';
import { activeOfferings, resolveOffering } from '../services/proModel';

const BookingContext = createContext(null);

const EMPTY = { serviceSlug: '', professionalId: '', offeringId: '', date: '', time: '' };

/** O profissional oferece (com serviço ativo) a categoria do catálogo? */
const offers = (pro, slug) =>
  !!pro && (!slug || activeOfferings(pro, slug).length > 0 || (!pro.offerings && pro.service === slug));

export function BookingProvider({ children }) {
  const [draft, setDraft] = useState(() => ({ ...EMPTY, ...(session.get(KEYS.bookingDraft) || {}) }));

  useEffect(() => {
    session.set(KEYS.bookingDraft, draft);
  }, [draft]);

  const setService = useCallback((serviceSlug) => {
    setDraft((d) => {
      if (d.serviceSlug === serviceSlug) return d;
      const pro = professionalById(d.professionalId);
      if (!offers(pro, serviceSlug)) return { ...EMPTY, serviceSlug };
      // mantém o profissional; troca o serviço escolhido se ele for de outra categoria
      const off = (pro.offerings || []).find((o) => o.id === d.offeringId);
      const keepOffering = off && (!serviceSlug || off.serviceSlug === serviceSlug);
      return { ...d, serviceSlug, ...(keepOffering ? {} : { offeringId: '', time: '' }) };
    });
  }, []);

  const setProfessional = useCallback((professionalId) => {
    const pro = professionalById(professionalId);
    setDraft((d) => {
      if (d.professionalId === professionalId) return d;
      const serviceSlug = d.serviceSlug && offers(pro, d.serviceSlug) ? d.serviceSlug : pro?.service || d.serviceSlug;
      return { serviceSlug, professionalId, offeringId: '', date: '', time: '' };
    });
  }, []);

  /** Serviço específico do profissional (duração e preço próprios). */
  const setOffering = useCallback((offeringId) => {
    setDraft((d) => {
      if (d.offeringId === offeringId) return d;
      const pro = professionalById(d.professionalId);
      const off = (pro?.offerings || []).find((o) => o.id === offeringId);
      // outra duração pode mudar os horários livres: o horário é escolhido de novo
      return { ...d, offeringId, serviceSlug: off?.serviceSlug || d.serviceSlug, time: '' };
    });
  }, []);

  const setDate = useCallback((date) => setDraft((d) => (d.date === date ? d : { ...d, date, time: '' })), []);
  const setTime = useCallback((time) => setDraft((d) => ({ ...d, time })), []);
  const reset = useCallback(() => setDraft(EMPTY), []);
  const hydrate = useCallback((partial) => setDraft((d) => ({ ...d, ...partial })), []);

  const value = useMemo(() => {
    const professional = professionalById(draft.professionalId);
    const offering = professional ? resolveOffering(professional, draft.serviceSlug, draft.offeringId) : null;
    const service = serviceBySlug(offering?.serviceSlug || draft.serviceSlug);
    // serviços do profissional na categoria escolhida (ou todos, se nenhuma)
    const offerings = professional
      ? activeOfferings(
          professional,
          draft.serviceSlug && offers(professional, draft.serviceSlug) ? draft.serviceSlug : undefined,
        )
      : [];
    const price = offering?.price || professional?.price || 0;
    const duration = Number(offering?.duration) || 60;
    const step = !professional ? (service ? 2 : 1) : !draft.date || !draft.time ? 3 : 4;
    return {
      draft,
      service,
      professional,
      offering,
      offerings,
      duration,
      price,
      fee: SERVICE_FEE,
      total: price ? price + SERVICE_FEE : 0,
      isComplete: !!(professional && draft.date && draft.time),
      step,
      setService,
      setProfessional,
      setOffering,
      setDate,
      setTime,
      reset,
      hydrate,
    };
  }, [draft, setService, setProfessional, setOffering, setDate, setTime, reset, hydrate]);

  return <BookingContext.Provider value={value}>{children}</BookingContext.Provider>;
}

export function useBooking() {
  const ctx = useContext(BookingContext);
  if (!ctx) throw new Error('useBooking deve ser usado dentro de <BookingProvider>');
  return ctx;
}
