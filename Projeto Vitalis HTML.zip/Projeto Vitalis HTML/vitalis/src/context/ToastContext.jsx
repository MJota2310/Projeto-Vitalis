import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import Icon from '../components/ui/Icon';

const ToastContext = createContext(null);

const ICONS = { success: 'check_circle', error: 'error', info: 'info', warning: 'warning' };

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);
  const timers = useRef(new Map());

  const dismiss = useCallback((id) => {
    setToasts((list) => list.map((t) => (t.id === id ? { ...t, leaving: true } : t)));
    setTimeout(() => setToasts((list) => list.filter((t) => t.id !== id)), 200);
    clearTimeout(timers.current.get(id));
    timers.current.delete(id);
  }, []);

  const show = useCallback(
    (type, title, text, { duration = 4200 } = {}) => {
      const id = `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
      setToasts((list) => [...list.slice(-3), { id, type, title, text }]);
      timers.current.set(
        id,
        setTimeout(() => dismiss(id), duration),
      );
      return id;
    },
    [dismiss],
  );

  const api = useMemo(
    () => ({
      success: (title, text, opts) => show('success', title, text, opts),
      error: (title, text, opts) => show('error', title, text, opts),
      info: (title, text, opts) => show('info', title, text, opts),
      warning: (title, text, opts) => show('warning', title, text, opts),
      dismiss,
    }),
    [show, dismiss],
  );

  // Avisos disparados fora do React (ex.: utils/download.js)
  useEffect(() => {
    const onNotice = (e) => show(e.detail?.type || 'info', e.detail?.title || '', e.detail?.text);
    window.addEventListener('vitalis:notice', onNotice);
    return () => window.removeEventListener('vitalis:notice', onNotice);
  }, [show]);

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="toast-region" role="status" aria-live="polite" aria-atomic="false">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast--${t.type}${t.leaving ? ' is-leaving' : ''}`}>
            <Icon name={ICONS[t.type]} size={22} className="toast__icon" />
            <div className="toast__body">
              <p className="toast__title">{t.title}</p>
              {t.text && <p className="toast__text">{t.text}</p>}
            </div>
            <button type="button" className="icon-btn toast__close" onClick={() => dismiss(t.id)} aria-label="Fechar aviso">
              <Icon name="close" size={18} />
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast deve ser usado dentro de <ToastProvider>');
  return ctx;
}
