// Catálogo de serviços e profissionais.
// Serviços, descrições, ícones e categorias vêm das telas do Figma
// (frame_tudo / opções_medicina / opções_terapia / opções_bem_estar).
// Os profissionais Dr. Carlos Silva, Dra. Ana Marques e Dr. Douglas Alves
// vêm da tela "Agendar"; os demais são fictícios, criados para que todos os
// serviços possam ser agendados na demonstração.

export const SERVICE_FEE = 10; // "Taxa de serviço R$10,00" (tela de pagamento)

export const TIME_SLOTS = ['08:00', '09:00', '10:00', '11:00', '14:00', '15:00', '16:00', '17:00'];

export const CATEGORIES = [
  { id: 'todas', label: 'Todas' },
  { id: 'bem-estar', label: 'Bem-estar' },
  { id: 'terapias', label: 'Terapias' },
  { id: 'medicina', label: 'Medicina' },
];

export const SERVICES = [
  {
    slug: 'consultas-medicas',
    name: 'Consultas médicas',
    short: 'Diversas especialidades médicas disponíveis',
    description: 'Diversas especialidades médicas disponíveis para atender suas necessidades',
    icon: 'medical_information',
    landingIcon: 'stethoscope',
    tile: 'aqua',
    categories: ['medicina'],
  },
  {
    slug: 'psicologia',
    name: 'Psicologia',
    short: 'Atendimento psicológico e terapias',
    description: 'Atendimento psicológico, terapias e acompanhamento emocional',
    icon: 'neurology',
    landingIcon: 'neurology',
    tile: 'mint',
    categories: ['terapias', 'bem-estar'],
  },
  {
    slug: 'fisioterapia',
    name: 'Fisioterapia',
    short: 'Reabilitação e tratamentos especializados',
    description: 'Reabilitação, tratamentos especializados e prevenção de lesões',
    icon: 'cardiology',
    landingIcon: 'vital_signs',
    tile: 'lemon',
    categories: ['medicina', 'bem-estar'],
  },
  {
    slug: 'atividades-fisicas',
    name: 'Atividades físicas',
    short: 'Personal trainers e aulas especializadas',
    description: 'Personal trainers, aulas especializadas e programas personalizados',
    icon: 'exercise',
    landingIcon: 'fitness_center',
    tile: 'aqua',
    categories: ['bem-estar'],
  },
  {
    slug: 'estetica',
    name: 'Estética',
    short: 'Tratamentos estéticos e bem-estar',
    description: 'Tratamentos estéticos faciais e corporais, bem-estar e beleza',
    icon: 'spa',
    landingIcon: 'ar_on_you',
    tile: 'mint',
    categories: ['terapias', 'bem-estar'],
  },
  {
    slug: 'cardiologia',
    name: 'Cardiologia',
    short: 'Saúde cardiovascular',
    description: 'Especialistas em saúde cardiovascular e prevenção de doenças do coração',
    icon: 'ecg',
    tile: 'lemon',
    categories: ['medicina'],
  },
  {
    slug: 'pediatria',
    name: 'Pediatria',
    short: 'Saúde infantil',
    description: 'Cuidados especializados para saúde infantil e desenvolvimento',
    icon: 'child_care',
    tile: 'aqua',
    categories: ['medicina'],
  },
  {
    slug: 'oftalmologia',
    name: 'Oftalmologia',
    short: 'Saúde dos olhos',
    description: 'Cuidados com a saúde dos olhos e correção visual',
    icon: 'symptoms',
    tile: 'mint',
    categories: ['medicina'],
  },
  {
    slug: 'ortopedia',
    name: 'Ortopedia',
    short: 'Ossos, articulações e músculos',
    description: 'Tratamento de lesões ósseas, articulares e musculares',
    icon: 'humerus',
    tile: 'lemon',
    categories: ['medicina'],
  },
  {
    slug: 'nutricao',
    name: 'Nutrição',
    short: 'Planejamento alimentar',
    description: 'Planejamento alimentar e acompanhamento nutricional personalizado',
    icon: 'pill',
    tile: 'aqua',
    categories: ['medicina', 'bem-estar'],
  },
  {
    slug: 'neurologia',
    name: 'Neurologia',
    short: 'Sistema nervoso',
    description: 'Diagnóstico e tratamento de doenças do sistema nervoso',
    icon: 'network_intelligence',
    tile: 'mint',
    categories: ['medicina'],
  },
  {
    slug: 'terapia-de-casal',
    name: 'Terapia de casal',
    short: 'Relacionamentos',
    description: 'Aconselhamento e terapia para relacionamentos',
    icon: 'person_heart',
    tile: 'lemon',
    categories: ['terapias'],
  },
];

// Dias: 0=dom … 6=sáb. Horários seguem a grade do Figma (08h–11h e 14h–17h).
const MWF = [1, 3, 5];
const TT = [2, 4];
const WEEK = [1, 2, 3, 4, 5];
const TTS = [2, 4, 6];

export const PROFESSIONALS = [
  // --- Tela "Agendar" (Figma) ---
  {
    id: 'carlos-silva',
    name: 'Dr. Carlos Silva',
    gender: 'm',
    service: 'cardiologia',
    specialty: 'Cardiologia',
    title: 'Cardiologista',
    price: 250,
    rating: 4.9,
    reviews: 156,
    city: 'São Paulo, SP',
    days: MWF,
  },
  {
    id: 'ana-marques',
    name: 'Dra. Ana Marques',
    gender: 'f',
    service: 'psicologia',
    specialty: 'Psicologia',
    title: 'Psicóloga',
    price: 180,
    rating: 4.9,
    reviews: 203,
    city: 'São Paulo, SP',
    days: MWF,
  },
  {
    id: 'douglas-alves',
    name: 'Dr. Douglas Alves',
    gender: 'm',
    service: 'fisioterapia',
    specialty: 'Fisioterapia',
    title: 'Fisioterapeuta',
    price: 150,
    rating: 4.7,
    reviews: 98,
    city: 'São Paulo, SP',
    days: MWF,
  },
  // --- Histórico da "Users Page" (Figma) ---
  {
    id: 'ana-costa',
    name: 'Dra. Ana Costa',
    gender: 'f',
    service: 'psicologia',
    specialty: 'Psicologia',
    title: 'Psicóloga',
    price: 180,
    rating: 4.8,
    reviews: 121,
    city: 'Santo André, SP',
    days: TT,
  },
  {
    id: 'roberto-alves',
    name: 'Dr. Roberto Alves',
    gender: 'm',
    service: 'fisioterapia',
    specialty: 'Fisioterapia',
    title: 'Fisioterapeuta',
    price: 150,
    rating: 4.6,
    reviews: 74,
    city: 'Guarulhos, SP',
    days: WEEK,
  },
  {
    id: 'carla-mendes',
    name: 'Dra. Carla Mendes',
    gender: 'f',
    service: 'consultas-medicas',
    specialty: 'Dermatologia',
    title: 'Dermatologista',
    price: 200,
    rating: 4.8,
    reviews: 142,
    city: 'São Paulo, SP',
    days: TT,
  },
  {
    id: 'joao-santos',
    name: 'Dr. João Santos',
    gender: 'm',
    service: 'consultas-medicas',
    specialty: 'Dermatologia',
    title: 'Dermatologista',
    price: 280,
    rating: 4.9,
    reviews: 188,
    city: 'Campinas, SP',
    days: MWF,
  },
  {
    id: 'patricia-lima',
    name: 'Dra. Patricia Lima',
    gender: 'f',
    service: 'consultas-medicas',
    specialty: 'Clínica geral',
    title: 'Clínica geral',
    price: 160,
    rating: 4.7,
    reviews: 96,
    city: 'São Paulo, SP',
    days: WEEK,
  },
  // --- Demais profissionais fictícios ---
  {
    id: 'helena-duarte',
    name: 'Dra. Helena Duarte',
    gender: 'f',
    service: 'cardiologia',
    specialty: 'Cardiologia',
    title: 'Cardiologista',
    price: 260,
    rating: 4.8,
    reviews: 87,
    city: 'Campinas, SP',
    days: TT,
  },
  {
    id: 'bruno-teixeira',
    name: 'Prof. Bruno Teixeira',
    gender: 'm',
    service: 'atividades-fisicas',
    specialty: 'Personal trainer',
    title: 'Personal trainer',
    price: 120,
    rating: 4.8,
    reviews: 134,
    city: 'São Paulo, SP',
    days: TTS,
  },
  {
    id: 'camila-rocha',
    name: 'Profª. Camila Rocha',
    gender: 'f',
    service: 'atividades-fisicas',
    specialty: 'Pilates',
    title: 'Instrutora de pilates',
    price: 110,
    rating: 4.9,
    reviews: 176,
    city: 'Santo André, SP',
    days: MWF,
  },
  {
    id: 'juliana-prado',
    name: 'Dra. Juliana Prado',
    gender: 'f',
    service: 'estetica',
    specialty: 'Estética facial',
    title: 'Esteticista',
    price: 190,
    rating: 4.7,
    reviews: 112,
    city: 'São Paulo, SP',
    days: WEEK,
  },
  {
    id: 'fernanda-lopes',
    name: 'Dra. Fernanda Lopes',
    gender: 'f',
    service: 'estetica',
    specialty: 'Estética corporal',
    title: 'Esteticista',
    price: 170,
    rating: 4.6,
    reviews: 65,
    city: 'Guarulhos, SP',
    days: TTS,
  },
  {
    id: 'mariana-couto',
    name: 'Dra. Mariana Couto',
    gender: 'f',
    service: 'pediatria',
    specialty: 'Pediatria',
    title: 'Pediatra',
    price: 220,
    rating: 4.9,
    reviews: 201,
    city: 'São Paulo, SP',
    days: MWF,
  },
  {
    id: 'paulo-henrique',
    name: 'Dr. Paulo Henrique',
    gender: 'm',
    service: 'pediatria',
    specialty: 'Pediatria',
    title: 'Pediatra',
    price: 230,
    rating: 4.7,
    reviews: 90,
    city: 'Campinas, SP',
    days: TT,
  },
  {
    id: 'eduardo-nunes',
    name: 'Dr. Eduardo Nunes',
    gender: 'm',
    service: 'oftalmologia',
    specialty: 'Oftalmologia',
    title: 'Oftalmologista',
    price: 240,
    rating: 4.8,
    reviews: 118,
    city: 'São Paulo, SP',
    days: WEEK,
  },
  {
    id: 'renata-farias',
    name: 'Dra. Renata Farias',
    gender: 'f',
    service: 'oftalmologia',
    specialty: 'Oftalmologia',
    title: 'Oftalmologista',
    price: 230,
    rating: 4.6,
    reviews: 58,
    city: 'Santo André, SP',
    days: MWF,
  },
  {
    id: 'marcelo-tavares',
    name: 'Dr. Marcelo Tavares',
    gender: 'm',
    service: 'ortopedia',
    specialty: 'Ortopedia',
    title: 'Ortopedista',
    price: 260,
    rating: 4.8,
    reviews: 143,
    city: 'São Paulo, SP',
    days: TT,
  },
  {
    id: 'luana-freitas',
    name: 'Dra. Luana Freitas',
    gender: 'f',
    service: 'ortopedia',
    specialty: 'Ortopedia',
    title: 'Ortopedista',
    price: 250,
    rating: 4.7,
    reviews: 77,
    city: 'Guarulhos, SP',
    days: MWF,
  },
  {
    id: 'beatriz-moura',
    name: 'Dra. Beatriz Moura',
    gender: 'f',
    service: 'nutricao',
    specialty: 'Nutrição',
    title: 'Nutricionista',
    price: 160,
    rating: 4.9,
    reviews: 165,
    city: 'São Paulo, SP',
    days: WEEK,
  },
  {
    id: 'thiago-ramos',
    name: 'Dr. Thiago Ramos',
    gender: 'm',
    service: 'nutricao',
    specialty: 'Nutrição esportiva',
    title: 'Nutricionista',
    price: 150,
    rating: 4.7,
    reviews: 82,
    city: 'Campinas, SP',
    days: TTS,
  },
  {
    id: 'andre-campos',
    name: 'Dr. André Campos',
    gender: 'm',
    service: 'neurologia',
    specialty: 'Neurologia',
    title: 'Neurologista',
    price: 300,
    rating: 4.8,
    reviews: 109,
    city: 'São Paulo, SP',
    days: MWF,
  },
  {
    id: 'sofia-almeida',
    name: 'Dra. Sofia Almeida',
    gender: 'f',
    service: 'neurologia',
    specialty: 'Neurologia',
    title: 'Neurologista',
    price: 290,
    rating: 4.9,
    reviews: 95,
    city: 'Santo André, SP',
    days: TT,
  },
  {
    id: 'leticia-barros',
    name: 'Dra. Letícia Barros',
    gender: 'f',
    service: 'terapia-de-casal',
    specialty: 'Terapia de casal',
    title: 'Terapeuta de casal',
    price: 220,
    rating: 4.8,
    reviews: 71,
    city: 'São Paulo, SP',
    days: TTS,
  },
  {
    id: 'rafael-moreira',
    name: 'Dr. Rafael Moreira',
    gender: 'm',
    service: 'terapia-de-casal',
    specialty: 'Terapia de casal',
    title: 'Terapeuta de casal',
    price: 210,
    rating: 4.7,
    reviews: 49,
    city: 'Campinas, SP',
    days: MWF,
  },
];

// A lista acima é a BASE INICIAL do catálogo. Em execução, os perfis ficam no
// banco local (services/db.js → db.professionals), onde podem ser editados pelos
// próprios profissionais e moderados pela administração. O banco registra aqui
// uma função de consulta, para que os componentes continuem usando
// professionalById() sem conhecer a origem dos dados.
let directory = null;
export function registerDirectory(fn) {
  directory = typeof fn === 'function' ? fn : null;
}

export const CITIES = [...new Set(PROFESSIONALS.map((p) => p.city))].sort();

export const proEmoji = (p) => (p?.gender === 'f' ? '👩‍⚕️' : '👨‍⚕️');

export function serviceBySlug(slug) {
  return SERVICES.find((s) => s.slug === slug) || null;
}

export function professionalById(id) {
  if (!id) return null;
  return (directory && directory(id)) || PROFESSIONALS.find((p) => p.id === id) || null;
}

export function professionalsForService(slug) {
  return PROFESSIONALS.filter((p) => p.service === slug);
}

export function servicesInCategory(category) {
  if (!category || category === 'todas') return SERVICES;
  return SERVICES.filter((s) => s.categories.includes(category));
}

export function categoryCount(category) {
  return servicesInCategory(category).length;
}
