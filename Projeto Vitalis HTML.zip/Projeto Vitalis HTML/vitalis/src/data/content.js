// Conteúdo institucional — textos extraídos das telas do Figma (landing page,
// central de ajuda). Pequenos erros de digitação do protótipo foram corrigidos.

export const HERO_FEATURES = [
  { title: 'Agendamento Rápido', text: 'em poucos cliques', tone: 'mint' },
  { title: 'Profissionais Qualificados', text: 'Verificados e Avaliados', tone: 'aqua' },
  { title: 'Histórico Completo', text: 'Tudo em um só lugar', tone: 'lemon' },
];

export const HOW_IT_WORKS = [
  {
    n: 1,
    title: 'Busque serviços',
    text: 'Encontre o serviço que você precisa por especialidade ou localização',
    icon: 'search',
    badge: 'step-1',
  },
  {
    n: 2,
    title: 'Escolha seu profissional',
    text: 'Compare avaliações, valores e dias de atendimento para escolher o melhor para você',
    icon: 'account_circle',
    badge: 'step-2',
  },
  {
    n: 3,
    title: 'Agende facilmente',
    text: 'Marque sua consulta com poucos cliques e receba confirmação instantânea',
    icon: 'calendar_today',
    badge: 'step-3',
  },
  {
    n: 4,
    title: 'Gerencie tudo',
    text: 'Acompanhe seus agendamentos, histórico e lembretes em um só lugar',
    icon: 'dashboard',
    badge: 'step-4',
  },
];

export const USER_BENEFITS = [
  { icon: 'alarm', title: 'Agendamento rápido', text: 'Marque consultas em segundos' },
  { icon: 'notifications', title: 'Lembretes automáticos', text: 'Nunca mais perca uma consulta' },
  { icon: 'article', title: 'Histórico de atendimentos', text: 'Acesse todo seu histórico médico' },
];

export const PRO_BENEFITS = [
  { icon: 'assignment_turned_in', title: 'Gestão de agenda', text: 'Controle total sobre seus horários' },
  { icon: 'moving', title: 'Mais visibilidade', text: 'Alcance mais pacientes' },
  { icon: 'group', title: 'Organização de atendimentos', text: 'Gerencie seus pacientes facilmente' },
];

export const PRO_CHECKLIST = [
  { text: 'Controle de agenda, pacientes e atendimentos em um só lugar', tone: 'green' },
  { text: 'Seja encontrado por novos pacientes na sua região', tone: 'cyan' },
  { text: 'Plataforma intuitiva e suporte dedicado', tone: 'yellow' },
];

export const PRO_CARDS = [
  {
    icon: 'card_travel',
    tone: 'mint',
    title: 'Gestão profissional',
    text: 'Ferramentas completas para organizar sua prática e otimizar seu tempo',
  },
  {
    icon: 'moving',
    tone: 'aqua',
    title: 'Crescimento constante',
    text: 'Aumente sua base de pacientes e construa sua reputação online',
  },
  {
    icon: 'add_moderator',
    tone: 'lemon',
    title: 'Segurança garantida',
    text: 'Proteção total dos dados em conformidade com a LGPD',
  },
];

export const DIFFERENTIALS = [
  {
    n: 1,
    icon: 'bookmark_stacks',
    tone: 'mint',
    title: 'Plataforma integrada',
    text: 'Tudo que você precisa em um único lugar, sem complicação',
  },
  {
    n: 2,
    icon: 'electric_bolt',
    tone: 'aqua',
    title: 'Interface intuitiva',
    text: 'Design pensado para facilitar sua experiência',
  },
  {
    n: 3,
    icon: 'lock',
    tone: 'lemon',
    title: 'Segurança de dados',
    text: 'Proteção de informações com base nos princípios da LGPD',
  },
  {
    n: 4,
    icon: 'kid_star',
    tone: 'green',
    title: 'Recomendações personalizadas',
    text: 'Sugestões baseadas no seu histórico de agendamentos',
  },
];

export const TESTIMONIALS = [
  {
    emoji: '👩🏻‍🦳',
    name: 'Dra. Maria Silva',
    role: 'Usuária',
    text: 'A Vitalis transformou a forma como cuido da minha saúde. Consigo agendar consultas facilmente e tenho todo meu histórico organizado.',
  },
  {
    emoji: '🧑🏻‍⚕️',
    name: 'Dr. João Santos',
    role: 'Psicólogo',
    text: 'Como profissional, a plataforma me ajudou a organizar minha agenda e alcançar mais pacientes. Excelente ferramenta!',
  },
  {
    emoji: '🧔🏻',
    name: 'Dr. Levi Bisneto',
    role: 'Usuário',
    text: 'Praticidade e segurança em um só lugar. Os lembretes automáticos são perfeitos, nunca mais perdi uma consulta.',
  },
  {
    emoji: '👩🏻‍⚕️',
    name: 'Dra. Carla Menezes',
    role: 'Fisioterapeuta',
    text: 'A Vitalis me deu mais visibilidade e facilitou a gestão dos meus atendimentos. Recomendo a todos os profissionais!',
  },
];

export const CONTACT = {
  email: 'vitalis.contato01@gmail.com',
  phone: '(11) 9999-9999',
  phoneHref: 'tel:+551199999999',
  location: 'São Paulo, SP - Brasil',
  mapsHref: 'https://www.google.com/maps/search/?api=1&query=S%C3%A3o+Paulo%2C+SP%2C+Brasil',
  hours: [
    { label: 'Segunda - Sexta', value: '8h - 18h' },
    { label: 'Sábado', value: '9h - 13h' },
    { label: 'Domingo', value: 'Fechado' },
  ],
};

export const SOCIAL = [
  { id: 'facebook', label: 'Facebook', href: 'https://www.facebook.com/' },
  { id: 'x', label: 'X (antigo Twitter)', href: 'https://x.com/' },
  { id: 'instagram', label: 'Instagram', href: 'https://www.instagram.com/' },
];
