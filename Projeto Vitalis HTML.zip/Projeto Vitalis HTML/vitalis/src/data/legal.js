// Termos de Uso e Política de Privacidade.
// ATENÇÃO: textos-modelo criados para o projeto acadêmico Vitalis. Antes de
// qualquer uso real, devem ser revisados por um profissional jurídico.

export const LEGAL_UPDATED_AT = '2026-09-27';

export const TERMS = [
  {
    id: 'aceitacao',
    title: '1. Aceitação dos termos',
    body: [
      'Ao criar uma conta ou utilizar a plataforma Vitalis, você declara que leu e concorda com estes Termos de Uso e com a Política de Privacidade.',
      'Se não concordar com algum ponto, não utilize a plataforma.',
    ],
  },
  {
    id: 'servico',
    title: '2. O que é a Vitalis',
    body: [
      'A Vitalis é uma plataforma que conecta pessoas a profissionais de saúde e bem-estar, permitindo buscar serviços, agendar atendimentos, realizar pagamentos e acompanhar o histórico de consultas.',
      'A Vitalis não presta serviços médicos. O atendimento é de responsabilidade exclusiva do profissional escolhido.',
    ],
  },
  {
    id: 'conta',
    title: '3. Cadastro e conta',
    body: [
      'Você é responsável pela veracidade dos dados informados e pela confidencialidade da sua senha.',
      'Contas podem ser de Usuário (quem busca serviços) ou de Profissional (quem oferece serviços).',
    ],
  },
  {
    id: 'agendamentos',
    title: '4. Agendamentos, cancelamentos e reembolsos',
    body: [
      'O agendamento é confirmado após a aprovação do pagamento.',
      'Garantia de reembolso: se você não puder comparecer, cancele até 24h antes do horário marcado e receba o reembolso total.',
      'A remarcação pode ser feita pela própria plataforma até 24h antes do horário marcado, conforme a disponibilidade do profissional.',
    ],
  },
  {
    id: 'pagamentos',
    title: '5. Pagamentos',
    body: [
      'São aceitos cartão (débito ou crédito) e PIX. O valor total inclui o preço da consulta definido pelo profissional e a taxa de serviço exibida antes da confirmação.',
      'Os dados de cartão são processados por parceiros de pagamento e não são armazenados pela Vitalis.',
    ],
  },
  {
    id: 'conduta',
    title: '6. Uso adequado',
    body: [
      'É proibido utilizar a plataforma para fins ilícitos, enviar informações falsas ou tentar acessar dados de outros usuários.',
    ],
  },
  {
    id: 'alteracoes',
    title: '7. Alterações destes termos',
    body: ['Estes termos podem ser atualizados. A data da última atualização estará sempre indicada nesta página.'],
  },
  {
    id: 'contato',
    title: '8. Contato',
    body: ['Dúvidas sobre estes termos podem ser enviadas para vitalis.contato01@gmail.com.'],
  },
];

export const PRIVACY = [
  {
    id: 'dados-coletados',
    title: '1. Dados que coletamos',
    body: [
      'Dados de cadastro: nome, e-mail, telefone, data de nascimento e endereço.',
      'Dados de uso: agendamentos realizados, profissionais consultados e preferências de notificação.',
      'Dados de pagamento: apenas a identificação da transação, o método e os 4 últimos dígitos do cartão — nunca o número completo ou o código de segurança.',
    ],
  },
  {
    id: 'finalidade',
    title: '2. Para que usamos seus dados',
    body: [
      'Para criar e manter sua conta, viabilizar agendamentos e pagamentos, enviar lembretes (quando autorizados) e melhorar a plataforma.',
    ],
  },
  {
    id: 'compartilhamento',
    title: '3. Compartilhamento',
    body: [
      'Compartilhamos com o profissional escolhido apenas os dados necessários para o atendimento. Não vendemos dados pessoais.',
    ],
  },
  {
    id: 'lgpd',
    title: '4. Seus direitos (LGPD)',
    body: [
      'Em conformidade com a Lei Geral de Proteção de Dados (Lei nº 13.709/2018), você pode solicitar acesso, correção, portabilidade ou exclusão dos seus dados, além de revogar consentimentos.',
    ],
  },
  {
    id: 'seguranca',
    title: '5. Segurança',
    body: [
      'Adotamos medidas técnicas para proteger seus dados, como criptografia de senhas e controle de acesso às áreas privadas.',
    ],
  },
  {
    id: 'demo',
    title: '6. Versão de demonstração',
    body: [
      'Nesta versão de demonstração, todas as informações ficam salvas somente no seu navegador (armazenamento local). Nenhum dado é enviado a servidores, e as senhas são guardadas apenas na forma de hash.',
    ],
  },
  {
    id: 'contato-dpo',
    title: '7. Contato',
    body: ['Solicitações relacionadas à privacidade podem ser enviadas para vitalis.contato01@gmail.com.'],
  },
];
