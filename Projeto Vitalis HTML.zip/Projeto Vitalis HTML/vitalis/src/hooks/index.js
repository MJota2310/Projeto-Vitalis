import { useCallback, useEffect, useRef, useState } from 'react';

/** Define o título da aba do navegador. */
export function useDocumentTitle(title) {
  useEffect(() => {
    document.title = title ? `${title} | Vitalis` : 'Vitalis — Cuide da sua saúde com mais praticidade';
  }, [title]);
}

/**
 * Revela elementos com a classe `.reveal` quando entram na tela.
 * Uso: const ref = useReveal(); <section ref={ref}> … <div className="reveal"> …
 */
export function useReveal(deps = []) {
  const ref = useRef(null);
  useEffect(() => {
    const root = ref.current;
    if (!root) return undefined;
    const items = root.classList.contains('reveal') ? [root] : [...root.querySelectorAll('.reveal:not(.is-visible)')];
    if (!('IntersectionObserver' in window)) {
      items.forEach((el) => el.classList.add('is-visible'));
      return undefined;
    }
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('is-visible');
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -40px 0px' },
    );
    items.forEach((el) => io.observe(el));
    return () => io.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return ref;
}

/** Busca assíncrona com estados de carregamento, erro e recarga. */
export function useAsync(fn, deps = []) {
  const [state, setState] = useState({ data: null, error: null, loading: true });
  const alive = useRef(true);
  const run = useCallback(async () => {
    setState((s) => ({ ...s, loading: true, error: null }));
    try {
      const data = await fn();
      if (alive.current) setState({ data, error: null, loading: false });
      return data;
    } catch (error) {
      if (alive.current) setState({ data: null, error, loading: false });
      return null;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  useEffect(() => {
    alive.current = true;
    run();
    return () => {
      alive.current = false;
    };
  }, [run]);

  return { ...state, reload: run, setData: (data) => setState((s) => ({ ...s, data })) };
}

/** Trava a rolagem do body (menus e modais). */
export function useLockBody(locked) {
  useEffect(() => {
    if (!locked) return undefined;
    document.body.classList.add('is-locked');
    return () => document.body.classList.remove('is-locked');
  }, [locked]);
}

export function useMediaQuery(query) {
  const get = () => (typeof window !== 'undefined' ? window.matchMedia(query).matches : false);
  const [matches, setMatches] = useState(get);
  useEffect(() => {
    const mql = window.matchMedia(query);
    const onChange = () => setMatches(mql.matches);
    onChange();
    mql.addEventListener('change', onChange);
    return () => mql.removeEventListener('change', onChange);
  }, [query]);
  return matches;
}

/** Destaca no menu a seção visível da landing page. */
export function useScrollSpy(ids, enabled = true) {
  const [active, setActive] = useState('');
  useEffect(() => {
    if (!enabled) {
      setActive('');
      return undefined;
    }
    const onScroll = () => {
      const offset = window.innerHeight * 0.35;
      let current = '';
      ids.forEach((id) => {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top - offset <= 0) current = id;
      });
      if (window.innerHeight + window.scrollY >= document.body.scrollHeight - 4) current = ids[ids.length - 1];
      setActive(current);
    };
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, ids.join('|')]);
  return active;
}

/** Mantém o foco dentro de um container (modais) e devolve ao sair. */
export function useFocusTrap(active, ref, onEscape) {
  useEffect(() => {
    if (!active || !ref.current) return undefined;
    const node = ref.current;
    const previous = document.activeElement;
    const selector =
      'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';
    const focusables = () => [...node.querySelectorAll(selector)].filter((el) => el.offsetParent !== null);
    const first = node.querySelector('[data-autofocus]') || focusables()[0] || node;
    requestAnimationFrame(() => first.focus());

    const onKey = (e) => {
      if (e.key === 'Escape' && onEscape) {
        e.stopPropagation();
        onEscape();
        return;
      }
      if (e.key !== 'Tab') return;
      const list = focusables();
      if (!list.length) return;
      const firstEl = list[0];
      const lastEl = list[list.length - 1];
      if (e.shiftKey && document.activeElement === firstEl) {
        e.preventDefault();
        lastEl.focus();
      } else if (!e.shiftKey && document.activeElement === lastEl) {
        e.preventDefault();
        firstEl.focus();
      }
    };
    node.addEventListener('keydown', onKey);
    return () => {
      node.removeEventListener('keydown', onKey);
      if (previous && previous.focus) previous.focus();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);
}

/** Fecha algo ao clicar fora do elemento. */
export function useClickOutside(ref, handler, active = true) {
  useEffect(() => {
    if (!active) return undefined;
    const onDown = (e) => {
      if (ref.current && !ref.current.contains(e.target)) handler(e);
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('touchstart', onDown);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('touchstart', onDown);
    };
  }, [ref, handler, active]);
}

/** Estado de formulário simples com validação por campo. */
export function useForm(initial, validators = {}) {
  const [values, setValues] = useState(initial);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});

  const validateField = useCallback(
    (name, vals) => {
      const fn = validators[name];
      return fn ? fn(vals[name], vals) : '';
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [validators],
  );

  const setField = useCallback(
    (name, value) => {
      setValues((prev) => {
        const next = { ...prev, [name]: value };
        setErrors((errs) => {
          if (!touched[name] && !errs[name]) return errs;
          const msg = validateField(name, next);
          return { ...errs, [name]: msg };
        });
        return next;
      });
    },
    [touched, validateField],
  );

  const onBlur = useCallback(
    (name) => {
      setTouched((t) => ({ ...t, [name]: true }));
      setErrors((errs) => ({ ...errs, [name]: validateField(name, values) }));
    },
    [validateField, values],
  );

  const validateAll = useCallback(() => {
    const next = {};
    Object.keys(validators).forEach((name) => {
      const msg = validateField(name, values);
      if (msg) next[name] = msg;
    });
    setErrors(next);
    setTouched(Object.fromEntries(Object.keys(validators).map((k) => [k, true])));
    return next;
  }, [validators, validateField, values]);

  const reset = useCallback((vals = initial) => {
    setValues(vals);
    setErrors({});
    setTouched({});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return { values, errors, touched, setField, setValues, setErrors, onBlur, validateAll, reset };
}
