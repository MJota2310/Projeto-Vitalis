import { useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

/** Rola suavemente até uma seção pelo id, compensando o cabeçalho fixo. */
export function scrollToSection(id, { smooth = true } = {}) {
  if (id === 'inicio' || id === 'top') {
    window.scrollTo({ top: 0, behavior: smooth ? 'smooth' : 'auto' });
    return true;
  }
  const el = document.getElementById(id);
  if (!el) return false;
  const header = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--header-h'), 10) || 80;
  const top = el.getBoundingClientRect().top + window.scrollY - header - 8;
  window.scrollTo({ top: Math.max(0, top), behavior: smooth ? 'smooth' : 'auto' });
  return true;
}

/**
 * Navega para uma seção da landing page. Se já estiver na página inicial,
 * apenas rola; caso contrário, navega para "/" e rola ao carregar.
 * A seção "contato" é o rodapé, presente em todas as páginas.
 */
export function useSectionNav() {
  const location = useLocation();
  const navigate = useNavigate();
  return useCallback(
    (id) => {
      if (id === 'contato') {
        scrollToSection('contato');
        return;
      }
      if (location.pathname === '/') {
        scrollToSection(id);
        if (location.search) navigate('/', { replace: true, state: { keepScroll: true } });
      } else {
        navigate('/', { state: { scrollTo: id } });
      }
    },
    [location.pathname, location.search, navigate],
  );
}
