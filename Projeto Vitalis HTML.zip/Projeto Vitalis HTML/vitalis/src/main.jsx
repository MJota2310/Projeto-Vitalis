import React from 'react';
import ReactDOM from 'react-dom/client';

// Fontes do projeto (mesmas famílias do Figma), servidas localmente.
import '@fontsource/rowdies/latin-300.css';
import '@fontsource/rowdies/latin-400.css';
import '@fontsource/rowdies/latin-700.css';
import '@fontsource/poppins/latin-300.css';
import '@fontsource/poppins/latin-400.css';
import '@fontsource/poppins/latin-500.css';
import '@fontsource/poppins/latin-600.css';
import '@fontsource/poppins/latin-700.css';
import '@fontsource/montserrat/latin-400.css';
import '@fontsource/montserrat/latin-500.css';
import '@fontsource/montserrat/latin-600.css';
import '@fontsource/inter/latin-400.css';
import '@fontsource/inter/latin-500.css';
import '@fontsource/inter/latin-600.css';
import '@fontsource/inter/latin-700.css';
import '@fontsource/crimson-text/latin-400.css';
import '@fontsource/open-sans/latin-400.css';

import './styles/tokens.css';
import './styles/base.css';
import './styles/animations.css';
import './styles/ui.css';
import './styles/cards.css';
import './components/layout/layout.css';

import App from './App';
import { initDb } from './services/db';

const root = ReactDOM.createRoot(document.getElementById('root'));

initDb()
  .catch((err) => {
    // Mesmo sem armazenamento disponível a aplicação segue funcionando em memória.
    console.warn('[Vitalis] Falha ao inicializar dados locais:', err);
  })
  .finally(() => {
    root.render(
      <React.StrictMode>
        <App />
      </React.StrictMode>,
    );
  });
