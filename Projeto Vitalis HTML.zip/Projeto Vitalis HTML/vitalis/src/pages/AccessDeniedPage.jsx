import Button from '../components/ui/Button';
import Icon from '../components/ui/Icon';
import { useAuth } from '../context/AuthContext';
import { useDocumentTitle } from '../hooks';
import { ROLES } from '../services/session';

/** 403 — a conta atual não tem permissão para a área solicitada. */
export default function AccessDeniedPage({ required = [] }) {
  useDocumentTitle('Acesso negado');
  const { user, roleLabel, home } = useAuth();
  const needed = required.map((r) => ROLES[r]?.label).filter(Boolean);
  return (
    <div className="container page denied">
      <div className="denied__card">
        <span className="denied__icon" aria-hidden="true">
          <Icon name="lock_person" size={44} />
        </span>
        <p className="denied__code">Erro 403</p>
        <h1 className="page-title">Acesso negado</h1>
        <p className="page-subtitle">
          Esta área é exclusiva para {needed.length ? needed.join(' ou ').toLowerCase() : 'outro tipo de conta'}. Você entrou como{' '}
          <strong>{roleLabel.toLowerCase() || 'visitante'}</strong>
          {user?.name ? ` (${user.name})` : ''}.
        </p>
        {required.includes('usuario') && user?.role === 'admin' && (
          <p className="muted">
            Contas administrativas não fazem agendamentos. Use uma conta de paciente para testar esse fluxo.
          </p>
        )}
        <div className="denied__actions">
          <Button variant="primary" to={home} icon="dashboard">
            Ir para o meu painel
          </Button>
          <Button variant="outline" to="/ajuda?secao=contato" icon="support_agent">
            Falar com o suporte
          </Button>
        </div>
      </div>
    </div>
  );
}
