import { useState } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState, Notice, Spinner, Stars, StatusBadge } from '../../components/ui/Feedback';
import { CancelModal, RescheduleModal } from '../../components/account/AppointmentModals';
import { useAuth } from '../../context/AuthContext';
import { getAppointment, cancellationPolicy, CANCEL_REFUND_HOURS } from '../../services/appointmentService';
import { professionalById } from '../../data/catalog';
import { ProAvatar } from '../../components/ui/Avatar';
import { useAsync, useDocumentTitle } from '../../hooks';
import { downloadCalendarEvent, downloadPrescriptionDemo, downloadReceipt } from '../../utils/download';
import { formatCurrency, formatDateLong, formatDateTimeBR, formatTimeRange, relativeDay } from '../../utils/format';
import './account.css';

const PAYMENT_STATUS = {
  aprovado: { label: 'Aprovado', tone: 'green' },
  recusado: { label: 'Recusado', tone: 'red' },
  reembolsado: { label: 'Reembolsado', tone: 'blue' },
};

export default function AppointmentDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const location = useLocation();
  const { data: appt, loading, error, reload, setData } = useAsync(() => getAppointment(user.id, id), [id]);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [rescheduleOpen, setRescheduleOpen] = useState(false);
  useDocumentTitle(appt ? `Consulta ${appt.protocol}` : 'Detalhes da consulta');

  if (loading) return <Spinner label="Carregando consulta…" />;
  if (error) {
    return (
      <div className="container page">
        {error.code === 'NOT_FOUND' ? (
          <EmptyState
            icon="event_busy"
            title="Consulta não encontrada"
            text="Ela pode ter sido removida ou pertence a outra conta."
            actions={
              <Button variant="primary" to="/consultas">
                Ver minhas consultas
              </Button>
            }
          />
        ) : (
          <ErrorState error={error} onRetry={reload} />
        )}
      </div>
    );
  }

  const pro = professionalById(appt.professionalId);
  const policy = cancellationPolicy(appt);
  const payment = appt.payment;
  const isUpcoming = appt.status === 'agendada' || appt.status === 'pendente_pagamento';

  return (
    <div className="account-page">
      <div className="container page appt-detail">
        <nav className="breadcrumb" aria-label="Você está em">
          <ol>
            <li>
              <Link to="/painel">Dashboard</Link>
            </li>
            <li>
              <Link to="/consultas">Consultas</Link>
            </li>
            <li aria-current="page">{appt.protocol}</li>
          </ol>
        </nav>

        {location.state?.paid && (
          <Notice tone="info" className="appt-detail__notice">
            Esta consulta já está paga — não é necessário pagar novamente.
          </Notice>
        )}

        <header className="appt-detail__header">
          <div>
            <p className="appt-detail__eyebrow">Protocolo {appt.protocol}</p>
            <h1 className="page-title">
              {appt.offeringName && appt.offeringName !== appt.serviceName ? appt.offeringName : appt.serviceName}
            </h1>
            <p className="page-subtitle">
              {formatDateLong(appt.date, true)} às {appt.time}
              {isUpcoming && <span className="appt-detail__rel"> · {relativeDay(appt.date)}</span>}
            </p>
          </div>
          <StatusBadge status={appt.status} />
        </header>

        {appt.status === 'cancelada' && appt.canceledBy && appt.canceledBy !== 'cliente' && (
          <Notice
            tone="info"
            className="appt-detail__notice"
            title={appt.canceledBy === 'profissional' ? 'Cancelada pelo profissional.' : 'Cancelada automaticamente.'}
          >
            {appt.canceledBy === 'profissional'
              ? `${appt.cancelReason ? `Motivo: ${appt.cancelReason}. ` : ''}${appt.refund?.status === 'reembolsado' ? 'O valor pago foi reembolsado integralmente (demonstração).' : ''}`
              : 'O pagamento não foi concluído antes do horário marcado, e a reserva foi liberada.'}
          </Notice>
        )}

        {appt.status === 'pendente_pagamento' && (
          <Notice tone="warning" className="appt-detail__notice">
            <strong>Pagamento pendente.</strong> Conclua o pagamento para confirmar este horário.
          </Notice>
        )}

        <div className="appt-detail__grid">
          <div className="stack" style={{ '--stack-gap': '20px' }}>
            <section className="card card--pad" aria-labelledby="pro-h">
              <h2 id="pro-h" className="detail-title">
                Profissional
              </h2>
              <div className="detail-pro">
                <ProAvatar pro={pro || { name: appt.professionalName, simulated: true }} size={null} />
                <div>
                  <p className="detail-pro__name">{appt.professionalName}</p>
                  <p className="muted">{pro?.title || appt.specialty}</p>
                  {pro?.rating ? <Stars rating={pro.rating} reviews={pro.reviews} size={15} /> : null}
                </div>
                <Button
                  variant="soft-green"
                  size="sm"
                  to={pro?.status === 'publicado' ? `/profissionais/${pro.id}` : `/servicos/${appt.serviceSlug}`}
                >
                  {pro?.status === 'publicado' ? 'Ver perfil' : 'Ver serviço'}
                </Button>
              </div>
              <ul className="detail-facts">
                <li>
                  <Icon name="calendar_today" size={20} />
                  <span>
                    <small>Data</small>
                    {formatDateLong(appt.date, true)}
                  </span>
                </li>
                <li>
                  <Icon name="schedule" size={20} />
                  <span>
                    <small>Horário</small>
                    {formatTimeRange(appt.time, appt.duration)} ({appt.duration || 60} min)
                  </span>
                </li>
                <li>
                  <Icon name="distance" size={20} />
                  <span>
                    <small>Local</small>
                    {appt.location}
                  </span>
                </li>
                <li>
                  <Icon name="archive" size={20} />
                  <span>
                    <small>Protocolo</small>
                    {appt.protocol}
                  </span>
                </li>
              </ul>
            </section>

            <section className="card card--pad" aria-labelledby="timeline-h">
              <h2 id="timeline-h" className="detail-title">
                Histórico
              </h2>
              <ol className="timeline">
                {[...appt.history].reverse().map((h, i) => (
                  <li key={`${h.at}-${i}`} className={i === 0 ? 'is-latest' : ''}>
                    <span className="timeline__dot" aria-hidden="true" />
                    <div>
                      <p>{h.label}</p>
                      <time dateTime={h.at}>{formatDateTimeBR(h.at)}</time>
                    </div>
                  </li>
                ))}
              </ol>
            </section>
          </div>

          <aside className="stack" style={{ '--stack-gap': '20px' }}>
            <section className="card card--pad" aria-labelledby="pay-h">
              <h2 id="pay-h" className="detail-title">
                Pagamento
              </h2>
              <div className="summary-rows">
                <div className="summary-row">
                  <span>{appt.offeringName || 'Consulta'}</span>
                  <strong>{formatCurrency(appt.price)}</strong>
                </div>
                <div className="summary-row">
                  <span>Taxa de serviço</span>
                  <strong>{formatCurrency(appt.fee)}</strong>
                </div>
                <div className="summary-row summary-row--total">
                  <span>Total</span>
                  <strong>{formatCurrency(appt.total)}</strong>
                </div>
              </div>
              {payment ? (
                <dl className="pay-facts">
                  <div>
                    <dt>Status</dt>
                    <dd>
                      <span className={`badge badge--${PAYMENT_STATUS[payment.status]?.tone || 'gray'}`}>
                        {PAYMENT_STATUS[payment.status]?.label || payment.status}
                      </span>
                    </dd>
                  </div>
                  <div>
                    <dt>Método</dt>
                    <dd>{payment.method === 'pix' ? 'PIX' : `${payment.brand} •••• ${payment.last4}`}</dd>
                  </div>
                  <div>
                    <dt>Pago em</dt>
                    <dd>{formatDateTimeBR(payment.paidAt || payment.createdAt)}</dd>
                  </div>
                  {appt.refund && (
                    <div>
                      <dt>Reembolso</dt>
                      <dd>
                        {appt.refund.status === 'reembolsado'
                          ? `${formatCurrency(appt.refund.amount)} (total)`
                          : 'Fora do prazo de 24h'}
                      </dd>
                    </div>
                  )}
                </dl>
              ) : (
                <p className="muted pay-none">
                  {appt.attempts.length ? `${appt.attempts.length} tentativa(s) recusada(s).` : 'Nenhum pagamento realizado.'}
                </p>
              )}
              {payment?.demo && <p className="pay-demo-note">Transação de demonstração — nenhuma cobrança real.</p>}
            </section>

            <section className="card card--pad" aria-labelledby="actions-h">
              <h2 id="actions-h" className="detail-title">
                Ações
              </h2>
              <div className="detail-actions">
                {appt.status === 'pendente_pagamento' && (
                  <Button variant="primary" block to={`/pagamento/${appt.id}`} icon="payments">
                    Pagar agora
                  </Button>
                )}
                {appt.status === 'agendada' && (
                  <Button variant="soft-green" block icon="event" onClick={() => downloadCalendarEvent(appt)}>
                    Adicionar à agenda (.ics)
                  </Button>
                )}
                {payment && payment.status !== 'recusado' && (
                  <Button variant="soft" block icon="receipt_long" onClick={() => downloadReceipt(appt, payment)}>
                    Baixar comprovante
                  </Button>
                )}
                {appt.status === 'concluida' && (
                  <Button variant="soft-green" block icon="download" onClick={() => downloadPrescriptionDemo(appt, user)}>
                    Baixar Receita (exemplo)
                  </Button>
                )}
                {policy.canCancel && (
                  <Button
                    variant="soft"
                    block
                    icon="event_repeat"
                    onClick={() => setRescheduleOpen(true)}
                    disabled={!policy.canReschedule}
                  >
                    Remarcar
                  </Button>
                )}
                {policy.canCancel && !policy.canReschedule && (
                  <p className="detail-actions__hint">
                    A remarcação fica disponível até {CANCEL_REFUND_HOURS}h antes do horário.
                  </p>
                )}
                {policy.canCancel && (
                  <Button variant="danger" block icon="event_busy" onClick={() => setCancelOpen(true)}>
                    Cancelar consulta
                  </Button>
                )}
                {(appt.status === 'concluida' || appt.status === 'cancelada') && (
                  <Button variant="primary" block icon="calendar_today" to={`/agendar?profissional=${appt.professionalId}`}>
                    Agendar novamente
                  </Button>
                )}
                <Button variant="ghost" block icon="arrow_back" to="/consultas">
                  Voltar para consultas
                </Button>
              </div>
            </section>
          </aside>
        </div>
      </div>

      <CancelModal appt={cancelOpen ? appt : null} onClose={() => setCancelOpen(false)} onDone={setData} />
      <RescheduleModal appt={rescheduleOpen ? appt : null} onClose={() => setRescheduleOpen(false)} onDone={setData} />
    </div>
  );
}
