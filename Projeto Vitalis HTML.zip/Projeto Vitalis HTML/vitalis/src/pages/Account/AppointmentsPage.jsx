import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState } from '../../components/ui/Feedback';
import AppointmentCard, { AppointmentCardSkeleton } from '../../components/account/AppointmentCard';
import { CancelModal } from '../../components/account/AppointmentModals';
import { useAuth } from '../../context/AuthContext';
import { useDocumentTitle } from '../../hooks';
import { useAppointments } from './useAppointments';
import { downloadPrescriptionDemo } from '../../utils/download';
import { normalize } from '../../utils/format';
import './account.css';

const FILTERS = [
  { id: 'todas', label: 'Todas' },
  { id: 'concluida', label: 'Concluídas' },
  { id: 'agendada', label: 'Agendadas' },
  { id: 'pendente_pagamento', label: 'Pendentes' },
  { id: 'cancelada', label: 'Canceladas' },
];

export function StatCards({ stats, active, onSelect }) {
  const cards = [
    { id: 'todas', label: 'Total de consultas', value: stats.total, tone: 'green', icon: null },
    { id: 'concluida', label: 'Concluídas', value: stats.concluidas, tone: 'green', icon: 'check_circle' },
    { id: 'agendada', label: 'Agendadas', value: stats.agendadas, tone: 'blue', icon: 'alarm' },
    { id: 'cancelada', label: 'Canceladas', value: stats.canceladas, tone: 'red', icon: 'cancel' },
  ];
  return (
    <div className="stat-grid">
      {cards.map((c, i) => {
        const Tag = onSelect ? 'button' : 'div';
        return (
          <Tag
            key={c.id}
            type={onSelect ? 'button' : undefined}
            className={`stat-card stat-card--${c.tone}${active === c.id ? ' is-active' : ''}`}
            onClick={onSelect ? () => onSelect(c.id) : undefined}
            aria-pressed={onSelect ? active === c.id : undefined}
            style={{ animationDelay: `${i * 60}ms` }}
          >
            <span className="stat-card__top">
              {c.icon ? <Icon name={c.icon} size={30} className="stat-card__icon" /> : <span />}
              <span className="stat-card__value">{c.value}</span>
            </span>
            <span className="stat-card__label">{c.label}</span>
          </Tag>
        );
      })}
    </div>
  );
}

export default function AppointmentsPage() {
  useDocumentTitle('Minhas consultas');
  const { user } = useAuth();
  const { list, stats, loading, error, reload, replace } = useAppointments();
  const [params, setParams] = useSearchParams();
  const filter = FILTERS.some((f) => f.id === params.get('status')) ? params.get('status') : 'todas';
  const [query, setQuery] = useState('');
  const [cancelTarget, setCancelTarget] = useState(null);

  const setFilter = (id) => setParams(id === 'todas' ? {} : { status: id }, { replace: true });

  const filtered = useMemo(() => {
    const q = normalize(query.trim());
    return list.filter((a) => {
      if (filter !== 'todas' && a.status !== filter) return false;
      if (!q) return true;
      return normalize(`${a.professionalName} ${a.specialty} ${a.serviceName} ${a.protocol}`).includes(q);
    });
  }, [list, filter, query]);

  const visibleFilters = FILTERS.filter((f) => f.id !== 'pendente_pagamento' || stats.pendentes > 0);

  return (
    <div className="account-page">
      <div className="container page">
        <header className="page-header">
          <h1 className="page-title page-title--strong">Minhas consultas</h1>
          <p className="page-subtitle">Visualize e gerencie todo o seu histórico de consultas</p>
        </header>

        {loading ? (
          <div className="stat-grid">
            {Array.from({ length: 4 }, (_, i) => (
              <span key={i} className="skeleton" style={{ height: 118, borderRadius: 16 }} />
            ))}
          </div>
        ) : (
          !error && <StatCards stats={stats} active={filter} onSelect={setFilter} />
        )}

        <section className="history-panel" aria-labelledby="history-title">
          <h2 id="history-title" className="sr-only">
            Histórico de consultas
          </h2>
          <div className="history-panel__toolbar">
            <div className="field field--icon field--action history-panel__search">
              <label htmlFor="appt-search" className="sr-only">
                Buscar consultas
              </label>
              <div className="field__control">
                <Icon name="data_loss_prevention" size={22} className="field__icon" />
                <input
                  id="appt-search"
                  className="input"
                  type="search"
                  placeholder="Buscar por profissional, especialidade ou protocolo..."
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                />
                {query && (
                  <button type="button" className="field__action" onClick={() => setQuery('')} aria-label="Limpar busca">
                    <Icon name="close" size={18} />
                  </button>
                )}
              </div>
            </div>
            <div className="tabs" role="tablist" aria-label="Filtrar por status">
              {visibleFilters.map((f) => (
                <button
                  key={f.id}
                  type="button"
                  role="tab"
                  className="tab"
                  aria-selected={filter === f.id}
                  onClick={() => setFilter(f.id)}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div role="tabpanel" aria-live="polite">
            {error ? (
              <ErrorState error={error} onRetry={reload} />
            ) : loading ? (
              <div className="appt-list">
                <AppointmentCardSkeleton />
                <AppointmentCardSkeleton />
                <AppointmentCardSkeleton />
              </div>
            ) : list.length === 0 ? (
              <EmptyState
                icon="event_note"
                title="Você ainda não tem consultas"
                text="Quando você agendar um atendimento, ele aparecerá aqui com status, protocolo e comprovantes."
                actions={
                  <Button variant="primary" to="/agendar" icon="calendar_today">
                    Agendar minha primeira consulta
                  </Button>
                }
              />
            ) : filtered.length === 0 ? (
              <EmptyState
                icon="search"
                title="Nenhuma consulta encontrada"
                text="Nenhuma consulta corresponde ao filtro ou à busca atual."
                actions={
                  <Button
                    variant="outline"
                    size="sm"
                    icon="refresh"
                    onClick={() => {
                      setQuery('');
                      setFilter('todas');
                    }}
                  >
                    Limpar filtros
                  </Button>
                }
              />
            ) : (
              <div className="appt-list" key={filter}>
                {filtered.map((a, i) => (
                  <AppointmentCard
                    key={a.id}
                    appt={a}
                    style={{ animationDelay: `${i * 50}ms` }}
                    onCancel={setCancelTarget}
                    onDownload={(appt) => downloadPrescriptionDemo(appt, user)}
                  />
                ))}
              </div>
            )}
          </div>
        </section>
      </div>
      <CancelModal appt={cancelTarget} onClose={() => setCancelTarget(null)} onDone={replace} />
    </div>
  );
}
