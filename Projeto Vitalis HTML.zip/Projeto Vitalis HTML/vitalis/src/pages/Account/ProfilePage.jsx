import { useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { Notice } from '../../components/ui/Feedback';
import { PasswordField, TextField, Toggle } from '../../components/ui/Field';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useDocumentTitle, useForm } from '../../hooks';
import { useAppointments } from './useAppointments';
import {
  validateBirthDate,
  validateConfirm,
  validateEmail,
  validateName,
  validatePassword,
  validatePhone,
} from '../../utils/validation';
import { maskPhone } from '../../utils/masks';
import { formatDateBR, initials } from '../../utils/format';
import './account.css';

function PersonalInfo({ user }) {
  const { updateProfile } = useAuth();
  const toast = useToast();
  const { stats, loading: statsLoading } = useAppointments();
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const initial = useMemo(
    () => ({
      name: user.name || '',
      birthDate: user.birthDate || '',
      email: user.email || '',
      phone: user.phone || '',
      address: user.address || '',
    }),
    [user],
  );
  const validators = useMemo(
    () => ({
      name: validateName,
      birthDate: (v) => (v ? validateBirthDate(v) : ''),
      email: validateEmail,
      phone: validatePhone,
      address: (v) =>
        v && v.trim().length < 8
          ? 'Endereço muito curto — inclua rua, número e cidade.'
          : v.length > 140
            ? 'Endereço muito longo.'
            : '',
    }),
    [],
  );
  const { values, errors, setField, onBlur, validateAll, reset, setErrors } = useForm(initial, validators);

  const cancel = () => {
    reset(initial);
    setEditing(false);
  };

  const save = async (e) => {
    e.preventDefault();
    const errs = validateAll();
    if (Object.keys(errs).length) {
      document.querySelector(`[name="p-${Object.keys(errs)[0]}"]`)?.focus();
      return;
    }
    setSaving(true);
    try {
      await updateProfile(values);
      toast.success('Perfil atualizado', 'Suas informações foram salvas.');
      setEditing(false);
    } catch (err) {
      if (err.field) setErrors((x) => ({ ...x, [err.field]: err.message }));
      else toast.error('Não foi possível salvar', err.message);
    } finally {
      setSaving(false);
    }
  };

  const ro = !editing;

  return (
    <section className="profile-card" aria-labelledby="personal-title">
      <form onSubmit={save} noValidate>
        <div className="profile-card__head">
          <h2 id="personal-title" className="profile-card__title">
            Informações pessoais
          </h2>
          {!editing ? (
            <button type="button" className="edit-btn" onClick={() => setEditing(true)}>
              <Icon name="edit_square" size={26} /> Editar
            </button>
          ) : (
            <span className="badge badge--green">Editando</span>
          )}
        </div>

        {!user.birthDate && !user.address && !editing && (
          <Notice tone="info" className="profile-card__notice">
            Complete seu cadastro com data de nascimento e endereço clicando em <strong>Editar</strong>.
          </Notice>
        )}

        <div className="form-grid profile-grid">
          <TextField
            label="Nome completo"
            name="p-name"
            icon="person"
            value={values.name}
            readOnly={ro}
            onChange={(e) => setField('name', e.target.value)}
            onBlur={() => onBlur('name')}
            error={errors.name}
            autoComplete="name"
          />
          <TextField
            label="Data de Nascimento"
            name="p-birthDate"
            icon="calendar_month"
            type={ro ? 'text' : 'date'}
            value={ro ? (values.birthDate ? formatDateBR(values.birthDate) : 'Não informado') : values.birthDate}
            readOnly={ro}
            max={new Date().toISOString().slice(0, 10)}
            onChange={(e) => setField('birthDate', e.target.value)}
            onBlur={() => onBlur('birthDate')}
            error={errors.birthDate}
            autoComplete="bday"
          />
          <TextField
            label="Email"
            name="p-email"
            type="email"
            icon="mail"
            value={values.email}
            readOnly={ro}
            onChange={(e) => setField('email', e.target.value)}
            onBlur={() => onBlur('email')}
            error={errors.email}
            autoComplete="email"
          />
          <TextField
            label="Telefone"
            name="p-phone"
            type="tel"
            icon="call"
            value={values.phone}
            readOnly={ro}
            onChange={(e) => setField('phone', maskPhone(e.target.value))}
            onBlur={() => onBlur('phone')}
            error={errors.phone}
            autoComplete="tel"
          />
          <TextField
            className="form-grid__full"
            label="Endereço"
            name="p-address"
            icon="add_location_alt"
            value={ro && !values.address ? 'Não informado' : values.address}
            readOnly={ro}
            placeholder="Rua, número - Cidade, UF"
            onChange={(e) => setField('address', e.target.value)}
            onBlur={() => onBlur('address')}
            error={errors.address}
            autoComplete="street-address"
          />
        </div>

        {editing && (
          <div className="profile-card__actions">
            <Button variant="ghost" onClick={cancel} disabled={saving}>
              Cancelar
            </Button>
            <Button type="submit" variant="primary" icon="save" loading={saving} loadingText="Salvando…">
              Salvar alterações
            </Button>
          </div>
        )}
      </form>

      <hr className="divider" />

      <h2 className="profile-card__title profile-card__title--sm">Estatísticas da conta</h2>
      <div className="account-stats">
        <div className="account-stat account-stat--green">
          <span>Consultas realizadas</span>
          <strong>{statsLoading ? '…' : stats.concluidas}</strong>
        </div>
        <div className="account-stat account-stat--cyan">
          <span>Consultas agendadas</span>
          <strong>{statsLoading ? '…' : stats.agendadas}</strong>
        </div>
        <div className="account-stat account-stat--yellow">
          <span>Membro desde</span>
          <strong>{new Date(user.createdAt).getFullYear()}</strong>
        </div>
      </div>
    </section>
  );
}

function Settings({ user }) {
  const { changePassword, updatePreferences, logout } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [saving, setSaving] = useState(false);
  const [prefSaving, setPrefSaving] = useState('');
  const validators = useMemo(
    () => ({
      current: (v) => (v ? '' : 'Informe sua senha atual.'),
      next: validatePassword,
      confirm: (v, vals) => validateConfirm(vals.next)(v),
    }),
    [],
  );
  const { values, errors, setField, onBlur, validateAll, reset, setErrors } = useForm(
    { current: '', next: '', confirm: '' },
    validators,
  );

  const submit = async (e) => {
    e.preventDefault();
    const errs = validateAll();
    if (Object.keys(errs).length) return;
    setSaving(true);
    try {
      await changePassword(values.current, values.next);
      toast.success('Senha alterada', 'Use a nova senha no próximo login.');
      reset({ current: '', next: '', confirm: '' });
    } catch (err) {
      if (err.field) setErrors((x) => ({ ...x, [err.field]: err.message }));
      else toast.error('Não foi possível alterar', err.message);
    } finally {
      setSaving(false);
    }
  };

  const togglePref = async (key, value, label) => {
    setPrefSaving(key);
    try {
      await updatePreferences({ [key]: value });
      toast.success(`${label} ${value ? 'ativado' : 'desativado'}`);
    } catch (err) {
      toast.error('Não foi possível salvar', err.message);
    } finally {
      setPrefSaving('');
    }
  };

  const prefs = user.prefs || {};
  const NOTIFS = [
    { key: 'notifyEmail', title: 'E-mail', text: 'Receber e-mails sobre consultas' },
    { key: 'notifySms', title: 'SMS', text: 'Lembrete por mensagem' },
    { key: 'notifyWhatsapp', title: 'WhatsApp', text: 'Notificações via WhatsApp' },
  ];

  return (
    <div className="stack" style={{ '--stack-gap': '24px' }}>
      <section className="profile-card" aria-labelledby="security-title">
        <h2 id="security-title" className="profile-card__title profile-card__title--display">
          Segurança
        </h2>
        <form onSubmit={submit} noValidate className="password-form">
          <h3 className="settings-sub">Alterar senha</h3>
          <div className="form-grid">
            <PasswordField
              className="form-grid__full"
              label="Senha atual"
              name="current"
              autoComplete="current-password"
              value={values.current}
              onChange={(e) => setField('current', e.target.value)}
              onBlur={() => onBlur('current')}
              error={errors.current}
            />
            <PasswordField
              label="Nova senha"
              name="next"
              autoComplete="new-password"
              value={values.next}
              onChange={(e) => setField('next', e.target.value)}
              onBlur={() => onBlur('next')}
              error={errors.next}
              hint="Mínimo de 8 caracteres, com letras e números."
            />
            <PasswordField
              label="Confirmar nova senha"
              name="confirm"
              autoComplete="new-password"
              value={values.confirm}
              onChange={(e) => setField('confirm', e.target.value)}
              onBlur={() => onBlur('confirm')}
              error={errors.confirm}
            />
          </div>
          <div className="password-form__actions">
            <Button type="submit" variant="primary" size="sm" loading={saving} loadingText="Alterando…">
              ALTERAR
            </Button>
          </div>
        </form>

        <hr className="divider" />

        <h3 className="settings-sub">Autenticação em duas etapas</h3>
        <div className="setting-row">
          <div>
            <p className="setting-row__title">Proteção adicional</p>
            <p className="setting-row__text">Ative para maior segurança</p>
          </div>
          <Toggle
            checked={!!prefs.twoFactor}
            label="Autenticação em duas etapas"
            disabled={prefSaving === 'twoFactor'}
            onChange={(v) => togglePref('twoFactor', v, 'Autenticação em duas etapas')}
          />
        </div>
        {prefs.twoFactor && (
          <p className="setting-demo">
            <Icon name="info" size={16} /> Preferência salva. O envio dos códigos de verificação depende de um servidor e não é
            executado na demonstração.
          </p>
        )}
      </section>

      <section className="profile-card" aria-labelledby="notif-title">
        <h2 id="notif-title" className="profile-card__title profile-card__title--display">
          Notificações
        </h2>
        <div className="stack" style={{ '--stack-gap': '12px' }}>
          <div className="setting-row setting-row--bordered">
            <div>
              <p className="setting-row__title">Lembretes no Vitalis</p>
              <p className="setting-row__text">Aviso no sino de notificações 24h antes de cada consulta</p>
            </div>
            <Toggle
              checked={prefs.reminders !== false}
              label="Lembretes no Vitalis"
              disabled={prefSaving === 'reminders'}
              onChange={(v) => togglePref('reminders', v, 'Lembretes')}
            />
          </div>
          {NOTIFS.map((n) => (
            <div key={n.key} className="setting-row setting-row--bordered">
              <div>
                <p className="setting-row__title">{n.title}</p>
                <p className="setting-row__text">{n.text}</p>
              </div>
              <Toggle
                checked={!!prefs[n.key]}
                label={n.text}
                disabled={prefSaving === n.key}
                onChange={(v) => togglePref(n.key, v, n.title)}
              />
            </div>
          ))}
          <p className="setting-demo">
            <Icon name="info" size={16} /> E-mail, SMS e WhatsApp ficam salvos como preferência, mas o envio depende de um
            servidor e não acontece nesta versão — os avisos aparecem nas notificações do Vitalis.
          </p>
        </div>
      </section>

      <section className="profile-card" aria-labelledby="session-title">
        <h2 id="session-title" className="profile-card__title profile-card__title--display">
          Sessão
        </h2>
        <div className="setting-row">
          <div>
            <p className="setting-row__title">Sair desta conta</p>
            <p className="setting-row__text">Seus dados continuam salvos neste navegador.</p>
          </div>
          <Button
            variant="danger"
            size="sm"
            icon="logout"
            onClick={async () => {
              await logout();
              toast.info('Você saiu da sua conta');
              navigate('/');
            }}
          >
            Sair
          </Button>
        </div>
      </section>
    </div>
  );
}

export default function ProfilePage() {
  useDocumentTitle('Meu perfil');
  const { user } = useAuth();
  const [params, setParams] = useSearchParams();
  const tab = params.get('aba') === 'configuracoes' ? 'configuracoes' : 'dados';

  return (
    <div className="profile-page">
      <div className="container page">
        <header className="page-header">
          <h1 className="page-title">Meu Perfil</h1>
          <p className="page-subtitle">Gerencie suas informações pessoais e preferências</p>
        </header>

        <div className="profile-layout">
          <aside className="profile-side" aria-label="Perfil">
            <span className="avatar profile-side__avatar" aria-hidden="true">
              {initials(user.name)}
            </span>
            <p className="profile-side__name">{user.name.split(' ').slice(0, 2).join(' ')}</p>
            <p className="profile-side__email">{user.email}</p>
            <span className="profile-side__badge">{user.role === 'profissional' ? 'Profissional' : 'Conta ativa'} ✓</span>
            <nav className="profile-tabs" role="tablist" aria-label="Seções do perfil">
              <button
                type="button"
                role="tab"
                aria-selected={tab === 'dados'}
                className="profile-tab"
                onClick={() => setParams({}, { replace: true })}
              >
                <Icon name="account_circle" size={20} /> Dados Pessoais
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={tab === 'configuracoes'}
                className="profile-tab"
                onClick={() => setParams({ aba: 'configuracoes' }, { replace: true })}
              >
                <Icon name="admin_panel_settings" size={20} /> Configurações
              </button>
            </nav>
          </aside>

          <div role="tabpanel" className="profile-main" key={tab}>
            {tab === 'dados' ? <PersonalInfo user={user} /> : <Settings user={user} />}
          </div>
        </div>
      </div>
    </div>
  );
}
