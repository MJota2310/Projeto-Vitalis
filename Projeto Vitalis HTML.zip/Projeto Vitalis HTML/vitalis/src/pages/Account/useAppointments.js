import { useCallback, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useAsync } from '../../hooks';
import { computeStats, listAppointments } from '../../services/appointmentService';

/** Lista de consultas do usuário logado + estatísticas. */
export function useAppointments() {
  const { user } = useAuth();
  const state = useAsync(() => listAppointments(user.id), [user.id]);
  const stats = useMemo(() => computeStats(state.data || []), [state.data]);
  const replace = useCallback(
    (updated) => state.setData((state.data || []).map((a) => (a.id === updated.id ? updated : a))),
    [state],
  );
  return { ...state, list: state.data || [], stats, replace };
}
