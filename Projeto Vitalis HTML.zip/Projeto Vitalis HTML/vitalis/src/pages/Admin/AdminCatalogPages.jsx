import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Modal from '../../components/ui/Modal';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState, Notice } from '../../components/ui/Feedback';
import { Toggle } from '../../components/ui/Field';
import { KpiCard, PanelHeader, SearchBox, ToneBadge, useDebounced } from '../../components/panel/PanelLayout';
import { useToast } from '../../context/ToastContext';
import { useAsync, useDocumentTitle } from '../../hooks';
import { listAllAppointments, listAllPayments, listCatalogAdmin, setServiceEnabled } from '../../services/adminService';
import { PRO_APPT_STATUS } from '../../services/proModel';

// na administração, as situações seguem os nomes usados pelos profissionais
const STATUS = Object.fromEntries(Object.entries(PRO_APPT_STATUS).filter(([id]) => id !== 'indisponivel'));
import { formatCurrency, formatDateBR, formatDateTimeBR, pluralize } from '../../utils/format';

/* ========================================================================
   Serviços do catálogo
   ======================================================================== */
export function AdminServicesPage() {
  useDocumentTitle('Serviços · Administração');
  const toast = useToast();
  const { data, loading, error, reload, setData } = useAsync(() => listCatalogAdmin(), []);
  const [busy, setBusy] = useState('');
  const [confirm, setConfirm] = useState(null);

  const apply = async (s, enabled) => {
    setBusy(s.slug);
    try {
      await setServiceEnabled(s.slug, enabled);
      setData(data.map((x) => (x.slug === s.slug ? { ...x, enabled } : x)));
      toast.success(enabled ? 'Serviço ativado' : 'Serviço desativado', s.name);
      setConfirm(null);
    } catch (err) {
      toast.error('Não foi possível alterar', err.message);
    } finally {
      setBusy('');
    }
  };

  const toggle = (s, enabled) => {
    if (!enabled && s.professionals > 0) setConfirm(s);
    else apply(s, enabled);
  };

  return (
    <div className="admin-services">
      <PanelHeader
        eyebrow="Catálogo"
        title="Serviços"
        subtitle="Ative ou desative categorias do catálogo. Um serviço desativado some da busca e do agendamento; os profissionais continuam com seus cadastros."
      />
      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data ? (
        <span className="skeleton" style={{ height: 320, display: 'block', borderRadius: 16 }} />
      ) : (
        <section className="panel-card panel-card--flush" aria-label="Serviços do catálogo">
          <div className="data-table-wrap">
            <table className="data-table data-table--cards">
              <thead>
                <tr>
                  <th scope="col">Serviço</th>
                  <th scope="col">Profissionais</th>
                  <th scope="col">Faixa de preço</th>
                  <th scope="col" className="num">
                    Agendamentos
                  </th>
                  <th scope="col">Disponível</th>
                </tr>
              </thead>
              <tbody>
                {data.map((s) => (
                  <tr key={s.slug} className={s.enabled ? '' : 'is-off'}>
                    <td className="cell-first">
                      <span className="adm-person">
                        <span className={`icon-tile icon-tile--${s.tile || 'mint'}`} style={{ '--tile': '40px' }}>
                          <Icon name={s.icon || 'medical_services'} size={22} />
                        </span>
                        <span className="cell-main">
                          <strong>{s.name}</strong>
                          <small>
                            <Link to={`/servicos/${s.slug}`} className="text-link">
                              Ver página
                            </Link>
                          </small>
                        </span>
                      </span>
                    </td>
                    <td data-label="Profissionais">
                      {s.professionals} publicado(s) · {s.offerings} oferta(s)
                    </td>
                    <td data-label="Faixa de preço">
                      {s.priceRange ? `${formatCurrency(s.priceRange[0])} – ${formatCurrency(s.priceRange[1])}` : '—'}
                    </td>
                    <td data-label="Agendamentos" className="num">
                      {s.appointments}
                    </td>
                    <td data-label="Disponível">
                      <span className="adm-toggle">
                        <Toggle
                          checked={s.enabled}
                          disabled={busy === s.slug}
                          label={`${s.enabled ? 'Desativar' : 'Ativar'} ${s.name}`}
                          onChange={(v) => toggle(s, v)}
                        />
                        <small>{s.enabled ? 'Ativo' : 'Desativado'}</small>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}
      <Modal
        open={!!confirm}
        onClose={() => setConfirm(null)}
        title="Desativar serviço?"
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirm(null)}>
              Manter ativo
            </Button>
            <Button variant="danger-solid" onClick={() => apply(confirm, false)} loading={busy === confirm?.slug}>
              Desativar
            </Button>
          </>
        }
      >
        {confirm && (
          <Notice tone="warning">
            {confirm.name} tem {pluralize(confirm.professionals, 'profissional publicado', 'profissionais publicados')}. O serviço
            deixa de aparecer na busca e não aceita novos agendamentos. Agendamentos já marcados continuam válidos.
          </Notice>
        )}
      </Modal>
    </div>
  );
}

/* ========================================================================
   Agendamentos (todos)
   ======================================================================== */
const PAY_LABEL = {
  aprovado: { label: 'Aprovado', tone: 'green' },
  recusado: { label: 'Recusado', tone: 'red' },
  reembolsado: { label: 'Reembolsado', tone: 'gray' },
};

export function AdminAppointmentsPage() {
  useDocumentTitle('Agendamentos · Administração');
  const [query, setQuery] = useState('');
  const debounced = useDebounced(query);
  const [status, setStatus] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [open, setOpen] = useState(null);
  const { data, loading, error, reload } = useAsync(
    () => listAllAppointments({ query: debounced, status, from, to }),
    [debounced, status, from, to],
  );
  const list = data || [];
  const shown = list.slice(0, 200);

  return (
    <div className="admin-appts">
      <PanelHeader
        eyebrow="Operação"
        title="Agendamentos"
        subtitle="Todos os agendamentos da plataforma, com filtros por situação, período e busca por protocolo, cliente ou profissional."
      />
      <div className="toolbar">
        <SearchBox
          id="adm-appt-q"
          label="Buscar agendamento"
          placeholder="Protocolo, cliente, profissional ou serviço"
          value={query}
          onChange={setQuery}
        />
        <label htmlFor="adm-appt-status" className="sr-only">
          Situação
        </label>
        <select id="adm-appt-status" className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">Todas as situações</option>
          {Object.entries(STATUS).map(([id, s]) => (
            <option key={id} value={id}>
              {s.label}
            </option>
          ))}
        </select>
        <label className="adm-date">
          <span>De</span>
          <input type="date" className="input" value={from} onChange={(e) => setFrom(e.target.value)} />
        </label>
        <label className="adm-date">
          <span>Até</span>
          <input type="date" className="input" value={to} min={from || undefined} onChange={(e) => setTo(e.target.value)} />
        </label>
        {(status || from || to || query) && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setQuery('');
              setStatus('');
              setFrom('');
              setTo('');
            }}
          >
            Limpar
          </Button>
        )}
      </div>

      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data ? (
        <span className="skeleton" style={{ height: 320, display: 'block', borderRadius: 16 }} />
      ) : list.length === 0 ? (
        <div className="panel-card">
          <EmptyState icon="event_busy" title="Nenhum agendamento encontrado" text="Ajuste a busca ou os filtros." />
        </div>
      ) : (
        <section className="panel-card panel-card--flush" aria-label="Lista de agendamentos">
          <p className="adm-count">
            {pluralize(list.length, 'agendamento', 'agendamentos')}
            {list.length > shown.length && ` · mostrando os ${shown.length} mais recentes`}
          </p>
          <div className={`data-table-wrap${loading ? ' is-refreshing' : ''}`}>
            <table className="data-table data-table--cards">
              <thead>
                <tr>
                  <th scope="col">Protocolo</th>
                  <th scope="col">Data</th>
                  <th scope="col">Cliente</th>
                  <th scope="col">Profissional</th>
                  <th scope="col">Situação</th>
                  <th scope="col" className="num">
                    Total
                  </th>
                </tr>
              </thead>
              <tbody>
                {shown.map((a) => {
                  const st = STATUS[a.status] || { label: a.status, tone: 'gray' };
                  return (
                    <tr key={a.id}>
                      <td className="cell-first">
                        <button type="button" className="text-link adm-link" onClick={() => setOpen(a)}>
                          {a.protocol}
                        </button>
                      </td>
                      <td data-label="Data">
                        {formatDateBR(a.date)} · {a.time}
                      </td>
                      <td data-label="Cliente">{a.clientName || '—'}</td>
                      <td data-label="Profissional">
                        <span className="cell-main">
                          <span>{a.professionalName}</span>
                          <small>{a.offeringName || a.serviceName}</small>
                        </span>
                      </td>
                      <td data-label="Situação">
                        <ToneBadge tone={st.tone} icon={st.icon}>
                          {st.label}
                        </ToneBadge>
                      </td>
                      <td data-label="Total" className="num">
                        {formatCurrency(a.total)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}

      <Modal open={!!open} onClose={() => setOpen(null)} title={open ? `Agendamento ${open.protocol}` : ''} width={540}>
        {open && (
          <div className="stack">
            <dl className="pf-facts">
              <div>
                <dt>Cliente</dt>
                <dd>{open.clientName}</dd>
              </div>
              <div>
                <dt>Profissional</dt>
                <dd>{open.professionalName}</dd>
              </div>
              <div>
                <dt>Serviço</dt>
                <dd>
                  {open.offeringName || open.serviceName} · {open.duration || 60} min
                </dd>
              </div>
              <div>
                <dt>Data</dt>
                <dd>
                  {formatDateBR(open.date)} às {open.time}
                </dd>
              </div>
              <div>
                <dt>Consulta + taxa</dt>
                <dd>
                  {formatCurrency(open.price)} + {formatCurrency(open.fee || 0)}
                </dd>
              </div>
              <div>
                <dt>Pagamento (simulado)</dt>
                <dd>
                  {open.payment
                    ? `${PAY_LABEL[open.payment.status]?.label || open.payment.status} · ${open.payment.method === 'pix' ? 'Pix' : 'Cartão'}`
                    : 'Sem pagamento'}
                </dd>
              </div>
            </dl>
            {open.cancelReason && (
              <Notice
                tone="info"
                title={`Cancelado por ${open.canceledBy === 'profissional' ? 'profissional' : open.canceledBy === 'sistema' ? 'sistema (prazo de pagamento)' : 'cliente'}:`}
              >
                {open.cancelReason}
              </Notice>
            )}
            {(open.history || []).length > 0 && (
              <div>
                <h3 className="detail-title">Histórico</h3>
                <ul className="adm-history">
                  {open.history.map((h, i) => (
                    <li key={i}>
                      <time>{formatDateTimeBR(h.at)}</time> {h.label}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ========================================================================
   Pagamentos (simulados)
   ======================================================================== */
export function AdminPaymentsPage() {
  useDocumentTitle('Pagamentos · Administração');
  const [status, setStatus] = useState('');
  const [method, setMethod] = useState('');
  const { data, loading, error, reload } = useAsync(() => listAllPayments({ status, method }), [status, method]);
  const list = data || [];
  const totals = useMemo(() => {
    const sum = (st) => list.filter((p) => p.status === st).reduce((s, p) => s + p.amount, 0);
    return {
      approved: sum('aprovado'),
      refunded: sum('reembolsado'),
      declined: list.filter((p) => p.status === 'recusado').length,
      fees: list.filter((p) => p.status === 'aprovado').reduce((s, p) => s + (p.appointment?.fee || 0), 0),
    };
  }, [list]);

  return (
    <div className="admin-payments">
      <PanelHeader
        eyebrow="Financeiro"
        title="Pagamentos"
        subtitle="Registros das tentativas de pagamento feitas no fluxo de agendamento."
      />
      <Notice tone="demo" title="Pagamentos simulados.">
        Nenhum valor desta lista foi cobrado de verdade: não há integração com operadora de cartão nem com Pix nesta versão.
        Números de cartão não são armazenados — apenas bandeira e 4 últimos dígitos.
      </Notice>
      <div className="kpi-grid section-gap">
        {!data ? (
          Array.from({ length: 4 }, (_, i) => <span key={i} className="skeleton" style={{ height: 96, borderRadius: 16 }} />)
        ) : (
          <>
            <KpiCard icon="payments" label="Aprovado (simulado)" value={formatCurrency(totals.approved)} />
            <KpiCard icon="receipt_long" label="Taxas de serviço" value={formatCurrency(totals.fees)} tone="blue" delay={60} />
            <KpiCard icon="undo" label="Reembolsado" value={formatCurrency(totals.refunded)} tone="yellow" delay={120} />
            <KpiCard icon="credit_card" label="Tentativas recusadas" value={totals.declined} tone="red" delay={180} />
          </>
        )}
      </div>
      <div className="toolbar section-gap">
        <label htmlFor="adm-pay-status" className="sr-only">
          Situação
        </label>
        <select id="adm-pay-status" className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">Todas as situações</option>
          {Object.entries(PAY_LABEL).map(([id, s]) => (
            <option key={id} value={id}>
              {s.label}
            </option>
          ))}
        </select>
        <label htmlFor="adm-pay-method" className="sr-only">
          Forma de pagamento
        </label>
        <select id="adm-pay-method" className="select" value={method} onChange={(e) => setMethod(e.target.value)}>
          <option value="">Todas as formas</option>
          <option value="pix">Pix</option>
          <option value="card">Cartão</option>
        </select>
      </div>
      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data ? (
        <span className="skeleton" style={{ height: 320, display: 'block', borderRadius: 16 }} />
      ) : list.length === 0 ? (
        <div className="panel-card">
          <EmptyState icon="payments" title="Nenhum pagamento encontrado" text="Ajuste os filtros." />
        </div>
      ) : (
        <section className="panel-card panel-card--flush" aria-label="Lista de pagamentos">
          <div className={`data-table-wrap${loading ? ' is-refreshing' : ''}`}>
            <table className="data-table data-table--cards">
              <thead>
                <tr>
                  <th scope="col">Agendamento</th>
                  <th scope="col">Data</th>
                  <th scope="col">Forma</th>
                  <th scope="col">Situação</th>
                  <th scope="col" className="num">
                    Valor
                  </th>
                </tr>
              </thead>
              <tbody>
                {list.map((p) => {
                  const st = PAY_LABEL[p.status] || { label: p.status, tone: 'gray' };
                  return (
                    <tr key={p.id}>
                      <td className="cell-first">
                        <span className="cell-main">
                          <strong>{p.appointment?.protocol || '—'}</strong>
                          <small>
                            {p.appointment
                              ? `${p.appointment.clientName} → ${p.appointment.professionalName}`
                              : 'agendamento removido'}
                          </small>
                        </span>
                      </td>
                      <td data-label="Data">{formatDateTimeBR(p.createdAt)}</td>
                      <td data-label="Forma">{p.method === 'pix' ? 'Pix' : `${p.brand || 'Cartão'} •••• ${p.last4 || '—'}`}</td>
                      <td data-label="Situação">
                        <ToneBadge tone={st.tone}>{st.label}</ToneBadge>
                        {p.failureReason && <small className="adm-note">{p.failureReason}</small>}
                      </td>
                      <td data-label="Valor" className="num">
                        {formatCurrency(p.amount)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}
    </div>
  );
}
