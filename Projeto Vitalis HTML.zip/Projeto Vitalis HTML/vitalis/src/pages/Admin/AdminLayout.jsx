import { useEffect, useState } from 'react';
import PanelLayout from '../../components/panel/PanelLayout';
import { UserAvatar } from '../../components/ui/Avatar';
import Icon from '../../components/ui/Icon';
import { useAuth } from '../../context/AuthContext';
import { adminBadges } from '../../services/adminService';
import './admin.css';

/** Moldura da área administrativa (papel "admin"). */
export default function AdminLayout() {
  const { user } = useAuth();
  const [badges, setBadges] = useState(() => adminBadges());

  useEffect(() => {
    const update = () => setBadges(adminBadges());
    window.addEventListener('vitalis:db', update);
    return () => window.removeEventListener('vitalis:db', update);
  }, []);

  const items = [
    { to: '/admin', end: true, icon: 'dashboard', label: 'Visão geral' },
    { to: '/admin/profissionais', icon: 'badge', label: 'Profissionais', badge: badges.pendingPros },
    { to: '/admin/usuarios', icon: 'group', label: 'Usuários' },
    { to: '/admin/servicos', icon: 'medical_services', label: 'Serviços' },
    { to: '/admin/agendamentos', icon: 'event_note', label: 'Agendamentos' },
    { to: '/admin/pagamentos', icon: 'payments', label: 'Pagamentos' },
    { to: '/admin/solicitacoes', icon: 'inbox', label: 'Solicitações', badge: badges.openTickets },
    { to: '/admin/notificacoes', icon: 'notifications', label: 'Notificações', badge: badges.unread },
    { to: '/admin/configuracoes', icon: 'settings', label: 'Configurações' },
  ];

  const identity = (
    <>
      <UserAvatar user={user} size={64} />
      <p className="panel-side__name">{user.name}</p>
      <p className="panel-side__meta">Administração</p>
      <span className="badge badge--blue">
        <Icon name="admin_panel_settings" size={15} /> Acesso administrativo
      </span>
    </>
  );

  const footer = (
    <p className="pro-side-note">
      <Icon name="info" size={16} /> Os dados desta área são de demonstração e ficam salvos apenas neste navegador.
    </p>
  );

  return <PanelLayout label="Administração" identity={identity} items={items} footer={footer} />;
}
