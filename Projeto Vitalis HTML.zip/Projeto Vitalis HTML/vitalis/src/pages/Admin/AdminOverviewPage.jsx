import { Link } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState, Notice } from '../../components/ui/Feedback';
import { KpiCard, PanelHeader } from '../../components/panel/PanelLayout';
import { BarList, ColumnChart } from '../../components/panel/Charts';
import { useAuth } from '../../context/AuthContext';
import { useAsync, useDocumentTitle } from '../../hooks';
import { getAdminOverview } from '../../services/adminService';
import { STATUS } from '../../services/appointmentService';
import { MONTHS_SHORT, firstName, formatCurrency, formatCurrencyCompact, monthLabel, relativeTime } from '../../utils/format';

const ADMIN_STATUS = {
  agendada: 'Confirmados',
  pendente_pagamento: 'Pagamento pendente',
  concluida: 'Concluídos',
  cancelada: 'Cancelados',
};

export default function AdminOverviewPage() {
  useDocumentTitle('Administração');
  const { user } = useAuth();
  const { data, loading, error, reload } = useAsync(() => getAdminOverview(), []);

  if (error) return <ErrorState error={error} onRetry={reload} />;

  const chart = (data?.revenue.months || []).map((m) => ({
    key: m.key,
    label: MONTHS_SHORT[m.month],
    full: `${monthLabel(m.month, m.year)} · ${m.count} agendamento(s)`,
    value: m.value,
  }));

  return (
    <div className="admin-overview">
      <PanelHeader
        eyebrow="Administração"
        title={`Olá, ${firstName(user.name)}`}
        subtitle="Visão geral da plataforma: cadastros, agendamentos, moderação e suporte."
        actions={
          <Button variant="outline" size="sm" icon="refresh" iconSize={18} onClick={reload} loading={loading && !!data}>
            Atualizar
          </Button>
        }
      />
      <Notice tone="demo" title="Dados de demonstração.">
        Todos os números vêm do banco local deste navegador. Pagamentos são simulados e não representam receita real.
      </Notice>

      <div className="kpi-grid section-gap">
        {!data ? (
          Array.from({ length: 4 }, (_, i) => <span key={i} className="skeleton" style={{ height: 96, borderRadius: 16 }} />)
        ) : (
          <>
            <KpiCard
              icon="group"
              label="Usuários"
              value={data.users.total}
              hint={`${data.users.patients} pacientes · ${data.users.professionals} profissionais`}
              to="/admin/usuarios"
              tone="blue"
            />
            <KpiCard
              icon="verified"
              label="Profissionais publicados"
              value={data.professionals.published}
              hint={data.professionals.pending ? `${data.professionals.pending} aguardando verificação` : 'nenhum pendente'}
              to="/admin/profissionais"
              delay={60}
            />
            <KpiCard
              icon="event_note"
              label="Agendamentos no mês"
              value={data.appointments.month}
              hint={`${data.appointments.upcoming} confirmados a seguir`}
              to="/admin/agendamentos"
              tone="yellow"
              delay={120}
            />
            <KpiCard
              icon="receipt_long"
              label="Taxas de serviço (simulado)"
              value={formatCurrency(data.revenue.fees)}
              hint={`volume pago: ${formatCurrency(data.revenue.volume)}`}
              to="/admin/pagamentos"
              delay={180}
            />
          </>
        )}
      </div>

      <div className="panel-grid panel-grid--main section-gap">
        <div className="panel-stack">
          <section className="panel-card" aria-labelledby="adm-pend">
            <div className="panel-card__head">
              <h2 id="adm-pend" className="panel-card__title">
                <Icon name="pending_actions" size={22} /> Verificações pendentes
              </h2>
              <Link to="/admin/profissionais?status=em_analise" className="text-link">
                Ver todas
              </Link>
            </div>
            {!data ? (
              <span className="skeleton" style={{ height: 120, display: 'block' }} />
            ) : data.pendingPros.length === 0 ? (
              <EmptyState
                icon="task_alt"
                title="Nada para verificar"
                text="Novos profissionais aparecem aqui quando enviam o perfil."
              />
            ) : (
              <ul className="adm-list">
                {data.pendingPros.map((p) => (
                  <li key={p.id}>
                    <span className="adm-list__body">
                      <strong>{p.name}</strong>
                      <small>
                        {p.title || 'Profissional'} · enviado {p.submittedAt ? relativeTime(p.submittedAt) : 'recentemente'}
                      </small>
                    </span>
                    <Button
                      variant="primary"
                      size="sm"
                      to={`/admin/profissionais?status=em_analise&id=${p.id}`}
                      iconRight="arrow_forward"
                      iconSize={18}
                    >
                      Revisar
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="panel-card" aria-labelledby="adm-rev">
            <div className="panel-card__head">
              <div>
                <h2 id="adm-rev" className="panel-card__title">
                  <Icon name="bar_chart" size={22} /> Taxas de serviço por mês
                </h2>
                <p className="panel-card__sub">Últimos 6 meses · agendamentos pagos e não cancelados (simulado)</p>
              </div>
            </div>
            {!data ? (
              <span className="skeleton" style={{ height: 200, display: 'block' }} />
            ) : (
              <ColumnChart
                data={chart}
                format={formatCurrencyCompact}
                highlight={chart.length - 1}
                height={200}
                label="Taxas de serviço por mês, últimos 6 meses"
              />
            )}
          </section>
        </div>

        <div className="panel-stack">
          <section className="panel-card" aria-labelledby="adm-status">
            <h2 id="adm-status" className="panel-card__title">
              <Icon name="event_note" size={22} /> Agendamentos por situação
            </h2>
            {!data ? (
              <span className="skeleton" style={{ height: 150, display: 'block' }} />
            ) : (
              <div className="section-gap">
                <BarList
                  label="Agendamentos por situação"
                  data={data.appointments.byStatus.map((s) => ({
                    key: s.status,
                    label: ADMIN_STATUS[s.status] || STATUS[s.status]?.label || s.status,
                    value: s.count,
                  }))}
                />
              </div>
            )}
          </section>

          <section className="panel-card" aria-labelledby="adm-svc">
            <h2 id="adm-svc" className="panel-card__title">
              <Icon name="medical_services" size={22} /> Serviços mais agendados
            </h2>
            {!data ? (
              <span className="skeleton" style={{ height: 150, display: 'block' }} />
            ) : data.appointments.byService.length === 0 ? (
              <EmptyState icon="medical_services" title="Sem agendamentos" />
            ) : (
              <div className="section-gap">
                <BarList
                  label="Serviços mais agendados"
                  data={data.appointments.byService.map((s) => ({ key: s.slug, label: s.name, value: s.count }))}
                />
              </div>
            )}
          </section>

          <section className="panel-card" aria-labelledby="adm-quick">
            <h2 id="adm-quick" className="panel-card__title">
              <Icon name="electric_bolt" size={22} /> Atenção
            </h2>
            {!data ? (
              <span className="skeleton" style={{ height: 120, display: 'block' }} />
            ) : (
              <ul className="adm-alerts">
                <li>
                  <Link to="/admin/solicitacoes">
                    <Icon name="inbox" size={20} />
                    <span>
                      <strong>{data.tickets.open}</strong> solicitação(ões) de suporte em aberto
                    </span>
                    <Icon name="chevron_right" size={18} />
                  </Link>
                </li>
                <li>
                  <Link to="/admin/servicos">
                    <Icon name="toggle_on" size={20} />
                    <span>
                      <strong>{data.services.enabled}</strong> de {data.services.total} serviços ativos no catálogo
                    </span>
                    <Icon name="chevron_right" size={18} />
                  </Link>
                </li>
                <li>
                  <Link to="/admin/usuarios?status=suspenso">
                    <Icon name="block" size={20} />
                    <span>
                      <strong>{data.users.suspended}</strong> conta(s) suspensa(s)
                    </span>
                    <Icon name="chevron_right" size={18} />
                  </Link>
                </li>
                <li>
                  <Link to="/admin/profissionais?status=rascunho">
                    <Icon name="edit_note" size={20} />
                    <span>
                      <strong>{data.professionals.draft}</strong> cadastro(s) profissional(is) em configuração
                    </span>
                    <Icon name="chevron_right" size={18} />
                  </Link>
                </li>
              </ul>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
