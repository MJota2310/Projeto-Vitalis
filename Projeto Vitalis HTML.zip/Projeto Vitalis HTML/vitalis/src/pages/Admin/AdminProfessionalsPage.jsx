import { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import { EmptyState, ErrorState, Notice } from '../../components/ui/Feedback';
import { TextField } from '../../components/ui/Field';
import { ProAvatar } from '../../components/ui/Avatar';
import { PanelHeader, SearchBox, ToneBadge, useDebounced } from '../../components/panel/PanelLayout';
import { useToast } from '../../context/ToastContext';
import { useAsync, useDocumentTitle } from '../../hooks';
import { listProfessionalsAdmin, reviewProfessional } from '../../services/adminService';
import { MODALITIES, PRO_STATUS, serviceName } from '../../services/proModel';
import { WEEKDAYS_SHORT, formatCurrency, formatDateTimeBR, pluralize } from '../../utils/format';

const FILTERS = [
  { id: '', label: 'Todos' },
  { id: 'em_analise', label: 'Em análise' },
  { id: 'publicado', label: 'Publicados' },
  { id: 'recusado', label: 'Ajustes pedidos' },
  { id: 'rascunho', label: 'Em configuração' },
  { id: 'pausado', label: 'Pausados' },
  { id: 'suspenso', label: 'Suspensos' },
];

const ACTIONS = {
  aprovar: {
    label: 'Aprovar e publicar',
    variant: 'primary',
    icon: 'verified',
    from: ['em_analise', 'recusado'],
    note: 'Mensagem ao profissional (opcional)',
  },
  ajustes: {
    label: 'Pedir ajustes',
    variant: 'outline',
    icon: 'edit_note',
    from: ['em_analise'],
    note: 'O que precisa ser ajustado? (obrigatório)',
  },
  suspender: {
    label: 'Suspender',
    variant: 'danger',
    icon: 'block',
    from: ['publicado', 'pausado', 'em_analise'],
    note: 'Motivo (enviado ao profissional)',
  },
  reativar: { label: 'Reativar', variant: 'primary', icon: 'play_circle', from: ['suspenso'], note: null },
};

function ReviewModal({ pro, onClose, onDone }) {
  const toast = useToast();
  const [action, setAction] = useState(null);
  const [note, setNote] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  if (!pro) return null;
  const status = PRO_STATUS[pro.status] || PRO_STATUS.rascunho;
  const available = Object.entries(ACTIONS).filter(([, a]) => a.from.includes(pro.status));
  const days = (pro.availability?.weekly || []).filter((d) => d.enabled);
  const modality = MODALITIES.find((m) => m.id === pro.modality);

  const run = async () => {
    setBusy(true);
    setError('');
    try {
      await reviewProfessional(pro.id, action, note);
      toast.success(`${ACTIONS[action].label}: concluído`, `${pro.name} foi avisado por notificação.`);
      onDone();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const footer = action ? (
    <>
      <Button variant="ghost" onClick={() => setAction(null)} disabled={busy}>
        Voltar
      </Button>
      <Button variant={action === 'suspender' ? 'danger-solid' : 'primary'} onClick={run} loading={busy} loadingText="Salvando…">
        Confirmar: {ACTIONS[action].label.toLowerCase()}
      </Button>
    </>
  ) : (
    <>
      <Button variant="ghost" onClick={onClose}>
        Fechar
      </Button>
      {available.map(([id, a]) => (
        <Button
          key={id}
          variant={a.variant}
          icon={a.icon}
          iconSize={18}
          onClick={() => {
            setAction(id);
            setNote('');
            setError('');
          }}
        >
          {a.label}
        </Button>
      ))}
    </>
  );

  return (
    <Modal open onClose={busy ? () => {} : onClose} title="Perfil profissional" width={640} footer={footer}>
      <div className="adm-review">
        <div className="adm-review__head">
          <ProAvatar pro={pro} size={64} />
          <div>
            <p className="adm-review__name">{pro.name}</p>
            <p className="muted">
              {pro.title || 'Profissão não informada'} · {pro.specialty || 'especialidade não informada'}
            </p>
            <ToneBadge tone={status.tone} icon={status.icon}>
              {status.label}
            </ToneBadge>
          </div>
        </div>

        {action ? (
          <div className="stack">
            <Notice tone={action === 'suspender' ? 'warning' : 'info'}>
              {action === 'aprovar' && 'O perfil passa a aparecer nas buscas e a receber agendamentos.'}
              {action === 'ajustes' && 'O perfil volta para o profissional, que verá sua mensagem e poderá reenviar.'}
              {action === 'suspender' &&
                'O perfil sai das buscas e não recebe novos agendamentos. Agendamentos já marcados não são cancelados automaticamente.'}
              {action === 'reativar' && 'O perfil volta a aparecer nas buscas.'}
            </Notice>
            {ACTIONS[action].note && (
              <TextField
                as="textarea"
                rows={3}
                label={ACTIONS[action].note}
                name="note"
                maxLength={400}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                error={error && action === 'ajustes' ? error : undefined}
                required={action === 'ajustes'}
              />
            )}
            {error && action !== 'ajustes' && <Notice tone="error">{error}</Notice>}
          </div>
        ) : (
          <>
            <dl className="pf-facts">
              <div>
                <dt>Registro</dt>
                <dd>
                  {pro.registry?.council ? `${pro.registry.council} ${pro.registry.number}/${pro.registry.uf}` : 'Não informado'}
                </dd>
              </div>
              <div>
                <dt>Conta</dt>
                <dd>{pro.owner ? pro.owner.email : pro.simulated ? 'Perfil fictício do catálogo' : '—'}</dd>
              </div>
              <div>
                <dt>Área / cidade</dt>
                <dd>
                  {serviceName(pro.service) || '—'} · {pro.city || '—'}
                </dd>
              </div>
              <div>
                <dt>Modalidade</dt>
                <dd>{modality?.label || '—'}</dd>
              </div>
              <div>
                <dt>Atendimento</dt>
                <dd>{days.length ? days.map((d) => WEEKDAYS_SHORT[d.day]).join(', ') : 'Sem dias'}</dd>
              </div>
              <div>
                <dt>Cadastro</dt>
                <dd>
                  {pro.progress.done}/{pro.progress.total} etapas · {pluralize(pro.appointments, 'agendamento', 'agendamentos')}
                </dd>
              </div>
            </dl>
            <ul className="adm-check">
              {pro.progress.list.map((i) => (
                <li key={i.id} className={i.done ? 'is-done' : ''}>
                  <Icon name={i.done ? 'check_circle' : 'radio_button_unchecked'} size={18} /> {i.label}
                </li>
              ))}
            </ul>
            <div>
              <h3 className="detail-title">Serviços</h3>
              {(pro.offerings || []).length === 0 ? (
                <p className="muted">Nenhum serviço cadastrado.</p>
              ) : (
                <ul className="adm-offers">
                  {pro.offerings.map((o) => (
                    <li key={o.id} className={o.active ? '' : 'is-inactive'}>
                      <span>{o.name}</span>
                      <small>
                        {o.duration} min · {formatCurrency(o.price)}
                        {!o.active && ' · inativo'}
                      </small>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            {pro.bio && (
              <div>
                <h3 className="detail-title">Apresentação</h3>
                <p className="adm-review__bio">{pro.bio}</p>
              </div>
            )}
            {pro.reviewNote && (
              <Notice tone="info" title="Última observação da verificação:">
                {pro.reviewNote}
              </Notice>
            )}
            <p className="pf-updated">
              {pro.submittedAt && `Enviado em ${formatDateTimeBR(pro.submittedAt)} · `}
              {pro.reviewedAt ? `Última decisão em ${formatDateTimeBR(pro.reviewedAt)}` : 'Ainda não revisado'}
              {pro.status === 'publicado' && (
                <>
                  {' · '}
                  <Link to={`/profissionais/${pro.id}`} className="text-link">
                    Ver perfil público
                  </Link>
                </>
              )}
            </p>
            {available.length === 0 && (
              <Notice tone="info">Nenhuma ação de moderação se aplica a esta situação ({status.label.toLowerCase()}).</Notice>
            )}
          </>
        )}
      </div>
    </Modal>
  );
}

export default function AdminProfessionalsPage() {
  useDocumentTitle('Profissionais · Administração');
  const [params, setParams] = useSearchParams();
  const status = params.get('status') || '';
  const openId = params.get('id');
  const [query, setQuery] = useState('');
  const debounced = useDebounced(query);
  const { data, loading, error, reload } = useAsync(
    () => listProfessionalsAdmin({ query: debounced, status }),
    [debounced, status],
  );
  const list = data || [];
  const open = useMemo(() => list.find((p) => p.id === openId) || null, [list, openId]);

  const setParam = (patch) => {
    const next = { status, ...(openId ? { id: openId } : {}), ...patch };
    Object.keys(next).forEach((k) => !next[k] && delete next[k]);
    setParams(next, { replace: true });
  };

  return (
    <div className="admin-pros">
      <PanelHeader
        eyebrow="Moderação"
        title="Profissionais"
        subtitle="Verifique novos cadastros, peça ajustes, suspenda ou reative perfis. Cada decisão gera uma notificação para o profissional."
      />
      <div className="toolbar">
        <SearchBox
          id="adm-pro-q"
          label="Buscar profissional"
          placeholder="Buscar por nome, profissão ou cidade"
          value={query}
          onChange={setQuery}
        />
      </div>
      <div className="chip-row adm-chips" role="group" aria-label="Filtrar por situação">
        {FILTERS.map((f) => (
          <button
            key={f.id || 'all'}
            type="button"
            className="chip chip--sm"
            aria-pressed={status === f.id}
            onClick={() => setParam({ status: f.id, id: '' })}
          >
            {f.label}
          </button>
        ))}
      </div>

      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data ? (
        <span className="skeleton" style={{ height: 320, display: 'block', borderRadius: 16 }} />
      ) : list.length === 0 ? (
        <div className="panel-card">
          <EmptyState
            icon="person_search"
            title="Nenhum profissional encontrado"
            text="Ajuste a busca ou o filtro de situação."
          />
        </div>
      ) : (
        <section className="panel-card panel-card--flush" aria-label="Lista de profissionais">
          <div className={`data-table-wrap${loading ? ' is-refreshing' : ''}`}>
            <table className="data-table data-table--cards">
              <thead>
                <tr>
                  <th scope="col">Profissional</th>
                  <th scope="col">Situação</th>
                  <th scope="col">Cadastro</th>
                  <th scope="col">Serviços</th>
                  <th scope="col" className="num">
                    Agendamentos
                  </th>
                  <th scope="col">
                    <span className="sr-only">Ações</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {list.map((p) => {
                  const st = PRO_STATUS[p.status] || PRO_STATUS.rascunho;
                  return (
                    <tr key={p.id}>
                      <td className="cell-first">
                        <span className="adm-person">
                          <ProAvatar pro={p} size={40} />
                          <span className="cell-main">
                            <strong>{p.name}</strong>
                            <small>
                              {p.title || 'Profissão não informada'}
                              {p.city && ` · ${p.city}`}
                              {p.simulated && ' · fictício'}
                            </small>
                          </span>
                        </span>
                      </td>
                      <td data-label="Situação">
                        <ToneBadge tone={st.tone} icon={st.icon}>
                          {st.label}
                        </ToneBadge>
                      </td>
                      <td data-label="Cadastro">
                        {p.progress.done}/{p.progress.total}
                      </td>
                      <td data-label="Serviços">{p.activeOfferings} ativo(s)</td>
                      <td data-label="Agendamentos" className="num">
                        {p.appointments}
                      </td>
                      <td className="cell-actions">
                        <Button
                          variant={p.status === 'em_analise' ? 'primary' : 'outline'}
                          size="sm"
                          onClick={() => setParam({ id: p.id })}
                        >
                          {p.status === 'em_analise' ? 'Revisar' : 'Detalhes'}
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {open && (
        <ReviewModal
          key={open.id}
          pro={open}
          onClose={() => setParam({ id: '' })}
          onDone={() => {
            setParam({ id: '' });
            reload();
          }}
        />
      )}
    </div>
  );
}
