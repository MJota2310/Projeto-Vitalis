import { useEffect, useState } from 'react';
import Icon from '../../components/ui/Icon';
import Modal from '../../components/ui/Modal';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState, Notice } from '../../components/ui/Feedback';
import { TextField, Toggle } from '../../components/ui/Field';
import { PanelHeader, ToneBadge } from '../../components/panel/PanelLayout';
import { AccountInfoCard, PasswordCard, SessionCard } from '../../components/account/AccountSettings';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useAsync, useDocumentTitle } from '../../hooks';
import {
  TICKET_STATUS,
  getPlatformSettings,
  listTickets,
  resetDemoData,
  updateAnnouncement,
  updateTicket,
} from '../../services/adminService';
import { formatDateTimeBR, relativeTime } from '../../utils/format';

/* ========================================================================
   Solicitações de suporte
   ======================================================================== */
function TicketModal({ ticket, onClose, onSaved }) {
  const toast = useToast();
  const [status, setStatus] = useState(ticket.status);
  const [note, setNote] = useState(ticket.adminNote || '');
  const [busy, setBusy] = useState(false);
  const dirty = status !== ticket.status || note !== (ticket.adminNote || '');

  const save = async () => {
    setBusy(true);
    try {
      await updateTicket(ticket.id, { status, adminNote: note });
      toast.success('Solicitação atualizada', ticket.protocol);
      onSaved();
    } catch (err) {
      toast.error('Não foi possível salvar', err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      open
      onClose={busy ? () => {} : onClose}
      title={`Solicitação ${ticket.protocol}`}
      width={580}
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={busy}>
            Fechar
          </Button>
          <Button variant="primary" icon="save" onClick={save} loading={busy} disabled={!dirty}>
            Salvar
          </Button>
        </>
      }
    >
      <div className="stack">
        <dl className="pf-facts">
          <div>
            <dt>De</dt>
            <dd>{ticket.name}</dd>
          </div>
          <div>
            <dt>E-mail</dt>
            <dd>{ticket.email}</dd>
          </div>
          <div>
            <dt>Assunto</dt>
            <dd>{ticket.subject}</dd>
          </div>
          <div>
            <dt>Recebida</dt>
            <dd>{formatDateTimeBR(ticket.createdAt)}</dd>
          </div>
        </dl>
        <blockquote className="adm-message">{ticket.message}</blockquote>
        <fieldset className="seg seg--3" aria-label="Situação">
          <legend className="field__label">Situação</legend>
          {Object.entries(TICKET_STATUS).map(([id, s]) => (
            <label key={id} className={`seg__opt${status === id ? ' is-on' : ''}`}>
              <input
                type="radio"
                name="ticket-status"
                className="sr-only"
                checked={status === id}
                onChange={() => setStatus(id)}
              />
              {s.label}
            </label>
          ))}
        </fieldset>
        <TextField
          as="textarea"
          rows={3}
          label="Nota interna (só a administração vê)"
          name="adminNote"
          maxLength={500}
          value={note}
          onChange={(e) => setNote(e.target.value)}
          hint={`${note.length}/500`}
        />
        <p className="field__hint">
          <Icon name="info" size={14} /> Não há envio de e-mail nesta versão. Ao marcar como resolvida, a pessoa recebe uma
          notificação no Vitalis se a solicitação foi enviada com a conta logada; caso contrário, responda pelo e-mail informado.
        </p>
      </div>
    </Modal>
  );
}

export function AdminTicketsPage() {
  useDocumentTitle('Solicitações · Administração');
  const [status, setStatus] = useState('');
  const [open, setOpen] = useState(null);
  const { data, loading, error, reload } = useAsync(() => listTickets({ status }), [status]);
  const list = data || [];

  return (
    <div className="admin-tickets">
      <PanelHeader
        eyebrow="Suporte"
        title="Solicitações"
        subtitle="Mensagens enviadas pelo formulário de contato da Central de Ajuda."
      />
      <div className="toolbar">
        <div className="tabs" role="tablist" aria-label="Situação">
          {[['', 'Todas'], ...Object.entries(TICKET_STATUS).map(([id, s]) => [id, s.label])].map(([id, label]) => (
            <button
              key={id || 'all'}
              type="button"
              role="tab"
              className="tab"
              aria-selected={status === id}
              onClick={() => setStatus(id)}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data ? (
        <span className="skeleton" style={{ height: 240, display: 'block', borderRadius: 16 }} />
      ) : list.length === 0 ? (
        <div className="panel-card">
          <EmptyState
            icon="inbox"
            title="Nenhuma solicitação"
            text={status ? 'Nenhuma solicitação nesta situação.' : 'As mensagens do formulário de contato aparecem aqui.'}
          />
        </div>
      ) : (
        <ul className="adm-tickets">
          {list.map((t, i) => {
            const st = TICKET_STATUS[t.status] || TICKET_STATUS.aberto;
            return (
              <li key={t.id} style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}>
                <button type="button" className="adm-ticket" onClick={() => setOpen(t)}>
                  <span className="adm-ticket__top">
                    <strong>{t.subject}</strong>
                    <ToneBadge tone={st.tone}>{st.label}</ToneBadge>
                  </span>
                  <span className="adm-ticket__msg">{t.message}</span>
                  <span className="adm-ticket__meta">
                    {t.protocol} · {t.name} · {relativeTime(t.createdAt)}
                    {t.adminNote && (
                      <>
                        {' · '}
                        <Icon name="edit_note" size={16} /> com nota
                      </>
                    )}
                  </span>
                </button>
              </li>
            );
          })}
        </ul>
      )}
      {open && (
        <TicketModal
          key={open.id}
          ticket={open}
          onClose={() => setOpen(null)}
          onSaved={() => {
            setOpen(null);
            reload();
          }}
        />
      )}
    </div>
  );
}

/* ========================================================================
   Configurações da plataforma
   ======================================================================== */
const TONES = [
  { id: 'info', label: 'Informativo' },
  { id: 'warning', label: 'Atenção' },
  { id: 'success', label: 'Novidade' },
];

function AnnouncementCard() {
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => getPlatformSettings(), []);
  const [form, setForm] = useState(null);
  const [fieldError, setFieldError] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (data)
      setForm({
        active: !!data.announcement?.active,
        text: data.announcement?.text || '',
        tone: data.announcement?.tone || 'info',
      });
  }, [data]);

  const save = async (e) => {
    e.preventDefault();
    setBusy(true);
    setFieldError('');
    try {
      await updateAnnouncement(form);
      toast.success(
        form.active ? 'Aviso publicado' : 'Aviso desativado',
        form.active ? 'Ele aparece no topo de todas as páginas.' : undefined,
      );
      reload();
    } catch (err) {
      if (err.field === 'text') setFieldError(err.message);
      else toast.error('Não foi possível salvar', err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="panel-card" aria-labelledby="ann-title">
      <h2 id="ann-title" className="panel-card__title">
        <Icon name="campaign" size={22} /> Aviso no topo do site
      </h2>
      <p className="panel-card__sub">Mensagem curta exibida para todos os visitantes (ex.: manutenção programada, novidades).</p>
      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : loading || !form ? (
        <span className="skeleton" style={{ height: 180, display: 'block', marginTop: 16 }} />
      ) : (
        <form className="stack section-gap" onSubmit={save} noValidate>
          <div className="setting-row setting-row--bordered">
            <div>
              <p className="setting-row__title">Exibir aviso</p>
              <p className="setting-row__text">{form.active ? 'Visível para todos' : 'Oculto'}</p>
            </div>
            <Toggle
              checked={form.active}
              label="Exibir aviso no topo do site"
              onChange={(v) => setForm((f) => ({ ...f, active: v }))}
            />
          </div>
          <TextField
            as="textarea"
            rows={2}
            label="Texto do aviso"
            name="ann-text"
            maxLength={180}
            value={form.text}
            onChange={(e) => setForm((f) => ({ ...f, text: e.target.value }))}
            error={fieldError}
            hint={`${form.text.length}/180 · mínimo de 10 caracteres`}
          />
          <fieldset className="seg seg--3" aria-label="Tom do aviso">
            <legend className="field__label">Tom</legend>
            {TONES.map((t) => (
              <label key={t.id} className={`seg__opt${form.tone === t.id ? ' is-on' : ''}`}>
                <input
                  type="radio"
                  name="ann-tone"
                  className="sr-only"
                  checked={form.tone === t.id}
                  onChange={() => setForm((f) => ({ ...f, tone: t.id }))}
                />
                {t.label}
              </label>
            ))}
          </fieldset>
          {form.text.trim() && (
            <div className={`announce announce--${form.tone} announce--preview`} aria-hidden="true">
              <Icon name="campaign" size={18} /> <span>{form.text}</span>
            </div>
          )}
          <div className="form-actions">
            <Button type="submit" variant="primary" icon="save" loading={busy} loadingText="Salvando…">
              Salvar aviso
            </Button>
          </div>
        </form>
      )}
    </section>
  );
}

function ResetCard() {
  const toast = useToast();
  const { logout } = useAuth();
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const reset = async () => {
    setBusy(true);
    try {
      await resetDemoData();
      toast.success('Dados restaurados', 'A demonstração voltou ao estado inicial.');
      setConfirm(false);
      // a sessão continua válida (os ids das contas de demonstração são fixos); recarrega a tela
      setTimeout(() => window.location.reload(), 600);
    } catch (err) {
      toast.error('Não foi possível restaurar', err.message);
      if (err.code === 'UNAUTHENTICATED') await logout();
    } finally {
      setBusy(false);
    }
  };
  return (
    <section className="panel-card" aria-labelledby="reset-title">
      <h2 id="reset-title" className="panel-card__title">
        <Icon name="restart_alt" size={22} /> Dados de demonstração
      </h2>
      <p className="panel-card__sub">
        Apaga todas as alterações feitas neste navegador (contas criadas, agendamentos, perfis) e recria os dados iniciais.
      </p>
      <div className="form-actions">
        <Button variant="danger" icon="restart_alt" onClick={() => setConfirm(true)}>
          Restaurar dados iniciais
        </Button>
      </div>
      <Modal
        open={confirm}
        onClose={() => setConfirm(false)}
        title="Restaurar dados de demonstração?"
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirm(false)} disabled={busy}>
              Cancelar
            </Button>
            <Button variant="danger-solid" onClick={reset} loading={busy} loadingText="Restaurando…">
              Restaurar
            </Button>
          </>
        }
      >
        <Notice tone="warning">Esta ação não pode ser desfeita. Ela afeta apenas os dados salvos neste navegador.</Notice>
      </Modal>
    </section>
  );
}

export function AdminSettingsPage() {
  useDocumentTitle('Configurações · Administração');
  return (
    <div className="admin-settings">
      <PanelHeader
        eyebrow="Plataforma"
        title="Configurações"
        subtitle="Aviso global, dados de demonstração e a sua conta de administrador."
      />
      <div className="panel-grid panel-grid--2">
        <div className="panel-stack">
          <AnnouncementCard />
          <ResetCard />
          <section className="panel-card" aria-labelledby="lim-title">
            <h2 id="lim-title" className="panel-card__title">
              <Icon name="info" size={22} /> Limites desta versão
            </h2>
            <ul className="hint-list section-gap">
              <li>
                <Icon name="database" size={16} /> Os dados ficam no armazenamento local do navegador; não há servidor nem banco
                compartilhado.
              </li>
              <li>
                <Icon name="payments" size={16} /> Pagamentos são simulados (sem operadora de cartão ou Pix).
              </li>
              <li>
                <Icon name="mail" size={16} /> Não há envio de e-mail, SMS ou WhatsApp — só notificações dentro do Vitalis.
              </li>
              <li>
                <Icon name="shield" size={16} /> As permissões são verificadas na camada de serviços, mas em produção precisam
                ficar em uma API no servidor.
              </li>
            </ul>
          </section>
        </div>
        <div className="panel-stack">
          <AccountInfoCard />
          <PasswordCard />
          <SessionCard />
        </div>
      </div>
    </div>
  );
}
