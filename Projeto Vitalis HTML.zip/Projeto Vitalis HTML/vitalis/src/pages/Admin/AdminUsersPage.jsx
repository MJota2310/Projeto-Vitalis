import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import { EmptyState, ErrorState, Notice } from '../../components/ui/Feedback';
import { UserAvatar } from '../../components/ui/Avatar';
import { PanelHeader, SearchBox, ToneBadge, useDebounced } from '../../components/panel/PanelLayout';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useAsync, useDocumentTitle } from '../../hooks';
import { listUsers, setUserStatus } from '../../services/adminService';
import { ROLES } from '../../services/session';
import { formatDateBR, pluralize, relativeTime } from '../../utils/format';

const ROLE_TONE = { usuario: 'green', profissional: 'blue', admin: 'yellow' };

export default function AdminUsersPage() {
  useDocumentTitle('Usuários · Administração');
  const { user: me } = useAuth();
  const toast = useToast();
  const [params, setParams] = useSearchParams();
  const role = params.get('papel') || '';
  const status = params.get('status') || '';
  const [query, setQuery] = useState('');
  const debounced = useDebounced(query);
  const [target, setTarget] = useState(null);
  const [busy, setBusy] = useState(false);
  const { data, loading, error, reload } = useAsync(
    () => listUsers({ query: debounced, role, status }),
    [debounced, role, status],
  );
  const list = data || [];

  const setParam = (patch) => {
    const next = { papel: role, status, ...patch };
    Object.keys(next).forEach((k) => !next[k] && delete next[k]);
    setParams(next, { replace: true });
  };

  const apply = async () => {
    const next = target.status === 'suspenso' ? 'ativo' : 'suspenso';
    setBusy(true);
    try {
      await setUserStatus(target.id, next);
      toast.success(next === 'suspenso' ? 'Conta suspensa' : 'Conta reativada', target.name);
      setTarget(null);
      reload();
    } catch (err) {
      toast.error('Não foi possível alterar', err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="admin-users">
      <PanelHeader
        eyebrow="Contas"
        title="Usuários"
        subtitle="Pacientes, profissionais e administradores cadastrados. Senhas nunca são exibidas."
      />
      <div className="toolbar">
        <SearchBox
          id="adm-user-q"
          label="Buscar usuário"
          placeholder="Buscar por nome ou e-mail"
          value={query}
          onChange={setQuery}
        />
        <label htmlFor="adm-role" className="sr-only">
          Perfil
        </label>
        <select id="adm-role" className="select" value={role} onChange={(e) => setParam({ papel: e.target.value })}>
          <option value="">Todos os perfis</option>
          {Object.entries(ROLES).map(([id, r]) => (
            <option key={id} value={id}>
              {r.label}
            </option>
          ))}
        </select>
        <label htmlFor="adm-status" className="sr-only">
          Situação
        </label>
        <select id="adm-status" className="select" value={status} onChange={(e) => setParam({ status: e.target.value })}>
          <option value="">Todas as situações</option>
          <option value="ativo">Ativas</option>
          <option value="suspenso">Suspensas</option>
        </select>
      </div>

      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data ? (
        <span className="skeleton" style={{ height: 320, display: 'block', borderRadius: 16 }} />
      ) : list.length === 0 ? (
        <div className="panel-card">
          <EmptyState icon="person_search" title="Nenhum usuário encontrado" text="Ajuste a busca ou os filtros." />
        </div>
      ) : (
        <section className="panel-card panel-card--flush" aria-label="Lista de usuários">
          <p className="adm-count">{pluralize(list.length, 'conta', 'contas')}</p>
          <div className={`data-table-wrap${loading ? ' is-refreshing' : ''}`}>
            <table className="data-table data-table--cards">
              <thead>
                <tr>
                  <th scope="col">Conta</th>
                  <th scope="col">Perfil</th>
                  <th scope="col">Situação</th>
                  <th scope="col">Criada em</th>
                  <th scope="col">Último acesso</th>
                  <th scope="col" className="num">
                    Consultas
                  </th>
                  <th scope="col">
                    <span className="sr-only">Ações</span>
                  </th>
                </tr>
              </thead>
              <tbody>
                {list.map((u) => {
                  const self = u.id === me.id;
                  const canToggle = !self && u.role !== 'admin';
                  return (
                    <tr key={u.id}>
                      <td className="cell-first">
                        <span className="adm-person">
                          <UserAvatar user={u} size={40} />
                          <span className="cell-main">
                            <strong>
                              {u.name}
                              {self && ' (você)'}
                            </strong>
                            <small>{u.email}</small>
                          </span>
                        </span>
                      </td>
                      <td data-label="Perfil">
                        <ToneBadge tone={ROLE_TONE[u.role] || 'gray'}>{ROLES[u.role]?.label || u.role}</ToneBadge>
                      </td>
                      <td data-label="Situação">
                        <ToneBadge
                          tone={u.status === 'suspenso' ? 'red' : 'green'}
                          icon={u.status === 'suspenso' ? 'block' : 'check_circle'}
                        >
                          {u.status === 'suspenso' ? 'Suspensa' : 'Ativa'}
                        </ToneBadge>
                        {!u.canLogin && <small className="adm-note">fictícia, sem login</small>}
                      </td>
                      <td data-label="Criada em">{u.createdAt ? formatDateBR(u.createdAt.slice(0, 10)) : '—'}</td>
                      <td data-label="Último acesso">{u.lastLoginAt ? relativeTime(u.lastLoginAt) : '—'}</td>
                      <td data-label="Consultas" className="num">
                        {u.appointments}
                      </td>
                      <td className="cell-actions">
                        {canToggle ? (
                          <Button
                            variant={u.status === 'suspenso' ? 'soft-green' : 'danger'}
                            size="sm"
                            onClick={() => setTarget(u)}
                          >
                            {u.status === 'suspenso' ? 'Reativar' : 'Suspender'}
                          </Button>
                        ) : (
                          <span className="adm-note">{self ? 'sua conta' : 'administrador'}</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}

      <Modal
        open={!!target}
        onClose={() => setTarget(null)}
        title={target?.status === 'suspenso' ? 'Reativar conta?' : 'Suspender conta?'}
        footer={
          <>
            <Button variant="ghost" onClick={() => setTarget(null)} disabled={busy}>
              Cancelar
            </Button>
            <Button variant={target?.status === 'suspenso' ? 'primary' : 'danger-solid'} onClick={apply} loading={busy}>
              {target?.status === 'suspenso' ? 'Reativar' : 'Suspender'}
            </Button>
          </>
        }
      >
        {target && (
          <Notice tone={target.status === 'suspenso' ? 'info' : 'warning'}>
            {target.status === 'suspenso'
              ? `${target.name} volta a conseguir entrar no Vitalis e recebe um aviso.`
              : `${target.name} perde o acesso imediatamente (não consegue mais entrar). ${target.role === 'profissional' ? 'O perfil profissional deixa de aparecer nas buscas. ' : ''}Agendamentos existentes não são cancelados automaticamente.`}
          </Notice>
        )}
      </Modal>
    </div>
  );
}
