import { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { Checkbox, PasswordField, TextField } from '../../components/ui/Field';
import { Notice } from '../../components/ui/Feedback';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useDocumentTitle, useForm } from '../../hooks';
import {
  passwordChecks,
  passwordStrength,
  validateConfirm,
  validateEmail,
  validateName,
  validatePassword,
  validatePhone,
} from '../../utils/validation';
import { maskPhone } from '../../utils/masks';
import { firstName } from '../../utils/format';
import './auth.css';

const ROLES = [
  { id: 'usuario', title: 'Usuário', text: 'Busco serviços de saúde', icon: 'person' },
  { id: 'profissional', title: 'Profissional', text: 'Ofereço serviços de saúde', icon: 'stethoscope' },
];

const STRENGTH = ['', 'Fraca', 'Razoável', 'Boa', 'Forte'];

function PasswordMeter({ value }) {
  const score = passwordStrength(value);
  const c = passwordChecks(value);
  if (!value) return null;
  return (
    <div className="pw-meter" aria-live="polite">
      <div className="pw-meter__bar" data-score={score}>
        {[1, 2, 3, 4].map((i) => (
          <span key={i} className={i <= score ? 'is-on' : ''} />
        ))}
      </div>
      <p className="pw-meter__label">
        Força da senha: <strong>{STRENGTH[score]}</strong>
      </p>
      <ul className="pw-meter__rules">
        <li className={c.length ? 'is-ok' : ''}>
          <Icon name={c.length ? 'check_circle' : 'cancel'} size={15} /> 8+ caracteres
        </li>
        <li className={c.letter && c.number ? 'is-ok' : ''}>
          <Icon name={c.letter && c.number ? 'check_circle' : 'cancel'} size={15} /> letras e números
        </li>
        <li className={c.special ? 'is-ok' : ''}>
          <Icon name={c.special ? 'check_circle' : 'cancel'} size={15} /> símbolo (recomendado)
        </li>
      </ul>
    </div>
  );
}

export default function RegisterPage() {
  useDocumentTitle('Criar conta');
  const { register } = useAuth();
  const toast = useToast();
  const [params] = useSearchParams();
  const redirect = params.get('redirect') || '';
  const [loading, setLoading] = useState(false);
  const [formError, setFormError] = useState('');

  const validators = useMemo(
    () => ({
      name: validateName,
      phone: validatePhone,
      email: validateEmail,
      password: validatePassword,
      confirm: (v, vals) => validateConfirm(vals.password)(v),
      terms: (v) => (v ? '' : 'Você precisa aceitar os termos para continuar.'),
    }),
    [],
  );

  const form = useForm(
    {
      role: params.get('tipo') === 'profissional' ? 'profissional' : 'usuario',
      name: '',
      phone: '',
      email: '',
      password: '',
      confirm: '',
      terms: false,
    },
    validators,
  );
  const { values, errors, setField, onBlur, validateAll, setErrors } = form;

  const submit = async (e) => {
    e.preventDefault();
    setFormError('');
    const errs = validateAll();
    if (Object.keys(errs).length) {
      const first = Object.keys(errs)[0];
      document.querySelector(`[name="${first}"]`)?.focus();
      return;
    }
    setLoading(true);
    try {
      const user = await register({
        name: values.name,
        phone: values.phone,
        email: values.email,
        password: values.password,
        role: values.role,
      });
      toast.success(
        `Conta criada, ${firstName(user.name)}!`,
        user.role === 'profissional' ? 'Agora vamos configurar o seu perfil profissional.' : 'Bem-vindo(a) à Vitalis.',
      );
    } catch (err) {
      if (err.field) setErrors((x) => ({ ...x, [err.field]: err.message }));
      else setFormError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-page__bg" aria-hidden="true" />
      <div className="container auth-page__inner">
        <section className="auth-card auth-card--wide" aria-labelledby="register-title">
          <header className="auth-card__header">
            <h1 id="register-title" className="auth-card__title">
              Criar sua conta
            </h1>
            <p className="auth-card__subtitle">comece a cuidar da sua saúde hoje mesmo</p>
          </header>

          {formError && (
            <Notice tone="error" className="auth-card__notice">
              {formError}
            </Notice>
          )}

          <form onSubmit={submit} noValidate className="auth-form">
            <fieldset className="role-picker">
              <legend>Você é:</legend>
              <div className="role-picker__options" role="radiogroup">
                {ROLES.map((r) => (
                  <label key={r.id} className={`role-option${values.role === r.id ? ' is-selected' : ''}`}>
                    <input
                      type="radio"
                      name="role"
                      value={r.id}
                      checked={values.role === r.id}
                      onChange={() => setField('role', r.id)}
                      className="sr-only"
                    />
                    <span className={`role-option__icon role-option__icon--${r.id}`}>
                      <Icon name={r.icon} size={28} />
                    </span>
                    <span className="role-option__title">{r.title}</span>
                    <span className="role-option__text">{r.text}</span>
                    <span className="role-option__check" aria-hidden="true">
                      <Icon name="check" size={16} />
                    </span>
                  </label>
                ))}
              </div>
            </fieldset>

            {values.role === 'profissional' && (
              <Notice tone="info">
                Depois de criar a conta, você configura o perfil profissional em etapas: registro, especialidade, serviços,
                horários e apresentação. O perfil aparece nas buscas após a verificação da equipe Vitalis.
              </Notice>
            )}

            <div className="form-grid">
              <TextField
                label="Nome completo"
                name="name"
                icon="person"
                autoComplete="name"
                placeholder="Seu nome"
                value={values.name}
                onChange={(e) => setField('name', e.target.value)}
                onBlur={() => onBlur('name')}
                error={errors.name}
                required
              />
              <TextField
                label="Telefone"
                name="phone"
                type="tel"
                icon="call"
                autoComplete="tel"
                inputMode="tel"
                placeholder="(11) 99999-9999"
                value={values.phone}
                onChange={(e) => setField('phone', maskPhone(e.target.value))}
                onBlur={() => onBlur('phone')}
                error={errors.phone}
                required
              />
              <TextField
                className="form-grid__full"
                label="Email"
                name="email"
                type="email"
                icon="mail"
                autoComplete="email"
                inputMode="email"
                placeholder="seu@email.com"
                value={values.email}
                onChange={(e) => setField('email', e.target.value)}
                onBlur={() => onBlur('email')}
                error={errors.email}
                required
              />
              <div>
                <PasswordField
                  label="Senha"
                  name="password"
                  autoComplete="new-password"
                  placeholder="Crie uma senha"
                  value={values.password}
                  onChange={(e) => setField('password', e.target.value)}
                  onBlur={() => onBlur('password')}
                  error={errors.password}
                  required
                />
                <PasswordMeter value={values.password} />
              </div>
              <PasswordField
                label="Confirmar senha"
                name="confirm"
                icon="lock"
                autoComplete="new-password"
                placeholder="Repita a senha"
                value={values.confirm}
                onChange={(e) => setField('confirm', e.target.value)}
                onBlur={() => onBlur('confirm')}
                error={errors.confirm}
                valid={values.confirm && values.confirm === values.password}
                required
              />
            </div>

            <Checkbox
              name="terms"
              checked={values.terms}
              onChange={(e) => setField('terms', e.target.checked)}
              error={errors.terms}
              label={
                <>
                  Concordo com os{' '}
                  <Link to="/termos" target="_blank" className="text-link">
                    termos de uso
                  </Link>{' '}
                  e a{' '}
                  <Link to="/privacidade" target="_blank" className="text-link">
                    política de privacidade
                  </Link>
                </>
              }
            />

            <Button
              type="submit"
              variant="primary"
              size="lg"
              block
              iconRight="arrow_forward"
              loading={loading}
              loadingText="Criando conta…"
            >
              Criar conta
            </Button>
          </form>

          <p className="auth-card__switch">
            Já tem uma conta?{' '}
            <Link to={`/entrar${redirect ? `?redirect=${encodeURIComponent(redirect)}` : ''}`} className="text-link">
              Fazer login
            </Link>
          </p>
          <p className="auth-card__privacy">
            <Icon name="lock" size={16} /> Sua senha é armazenada apenas de forma criptografada (hash).
          </p>
        </section>
      </div>
    </div>
  );
}
