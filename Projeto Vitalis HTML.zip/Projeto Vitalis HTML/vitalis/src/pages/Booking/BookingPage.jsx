import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState, Notice } from '../../components/ui/Feedback';
import { ProAvatar } from '../../components/ui/Avatar';
import ProfessionalCard, { ProfessionalCardSkeleton } from '../../components/booking/ProfessionalCard';
import { DatePicker, Stepper, TimeSlots } from '../../components/booking/Schedule';
import { useBooking } from '../../context/BookingContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { professionalById, serviceBySlug } from '../../data/catalog';
import { enabledServices, listCities, listProfessionals } from '../../services/catalogService';
import { activeOfferings } from '../../services/proModel';
import { useAsync, useDocumentTitle, useMediaQuery } from '../../hooks';
import { formatCurrency, formatDateLong } from '../../utils/format';
import './booking.css';
import { scrollBehavior } from '../../utils/motion';

export default function BookingPage() {
  useDocumentTitle('Agendar serviço');
  const [params, setParams] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToast();
  const { isAuthenticated, user, role } = useAuth();
  const booking = useBooking();
  const {
    draft,
    service,
    professional,
    offering,
    offerings,
    duration,
    setService,
    setProfessional,
    setOffering,
    setDate,
    setTime,
    hydrate,
  } = booking;
  const [query, setQuery] = useState('');
  const [city, setCity] = useState('');
  const panelRef = useRef(null);
  const isMobile = useMediaQuery('(max-width: 960px)');

  // Parâmetros vindos de "Agendar agora" (serviço / profissional)
  useEffect(() => {
    const s = params.get('servico');
    const p = params.get('profissional');
    const o = params.get('oferta');
    const pro = professionalById(p);
    if (pro) {
      const off = activeOfferings(pro).find((x) => x.id === o);
      const slug = off?.serviceSlug || (serviceBySlug(s) && activeOfferings(pro, s).length ? s : pro.service);
      hydrate({
        serviceSlug: slug,
        professionalId: pro.id,
        offeringId: off?.id || (pro.id === draft.professionalId ? draft.offeringId : ''),
        ...(pro.id !== draft.professionalId || (off && off.id !== draft.offeringId) ? { date: '', time: '' } : {}),
      });
    } else if (serviceBySlug(s)) setService(s);
    if (s || p || o) setParams({}, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // "Alterar data/horário" na revisão → rola até o painel de agenda
  useEffect(() => {
    if (location.state?.focus !== 'horario') return undefined;
    const t = setTimeout(() => panelRef.current?.scrollIntoView({ behavior: scrollBehavior(), block: 'start' }), 150);
    return () => clearTimeout(t);
  }, [location.state]);

  const {
    data: pros,
    loading,
    error,
    reload,
  } = useAsync(() => listProfessionals({ service: draft.serviceSlug, query, city }), [draft.serviceSlug, query, city]);

  const step = booking.step;
  const ownProfile = !!(professional && user && professional.userId === user.id);
  const blocked = role === 'admin' || ownProfile;
  const canContinue = booking.isComplete && !blocked;
  const cities = useMemo(() => listCities(), []);

  const handleSelectPro = (id) => {
    setProfessional(id);
    if (isMobile) setTimeout(() => panelRef.current?.scrollIntoView({ behavior: scrollBehavior(), block: 'start' }), 120);
  };

  const handleContinue = () => {
    if (!canContinue) return;
    if (!isAuthenticated) {
      toast.info('Entre para concluir', 'Sua seleção foi salva — faça login ou crie uma conta.');
      navigate(`/entrar?redirect=${encodeURIComponent('/agendar/revisao')}`);
      return;
    }
    navigate('/agendar/revisao');
  };

  const chips = useMemo(() => [{ slug: '', name: 'Todas' }, ...enabledServices()], []);

  return (
    <div className="container page booking-page">
      <header className="page-header booking-page__header">
        <div>
          <h1 className="page-title">Agendar Serviço</h1>
          <p className="page-subtitle">Encontre o profissional ideal e agende seu atendimento</p>
        </div>
        <Stepper current={step} />
      </header>

      <div className="booking-layout">
        <div className="booking-main">
          <section className="search-panel" aria-labelledby="search-title">
            <div className="search-panel__head">
              <h2 id="search-title" className="search-panel__title">
                Busca profissional
              </h2>
              <Link to="/profissionais" className="text-link search-panel__adv">
                Busca avançada e perfis
              </Link>
            </div>
            <div className="search-panel__fields">
              <div className="field field--icon field--action search-panel__query">
                <label htmlFor="pro-search" className="sr-only">
                  Buscar por nome ou especialidade
                </label>
                <div className="field__control">
                  <Icon name="search" size={20} className="field__icon" />
                  <input
                    id="pro-search"
                    className="input"
                    type="search"
                    placeholder="Busca por especialidade ou nome"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    autoComplete="off"
                  />
                  {query && (
                    <button type="button" className="field__action" onClick={() => setQuery('')} aria-label="Limpar busca">
                      <Icon name="close" size={18} />
                    </button>
                  )}
                </div>
              </div>
              <div className="field field--icon search-panel__city">
                <label htmlFor="pro-city" className="sr-only">
                  Localização
                </label>
                <div className="field__control">
                  <Icon name="distance" size={20} className="field__icon" />
                  <select id="pro-city" className="select" value={city} onChange={(e) => setCity(e.target.value)}>
                    <option value="">Localização: todas</option>
                    {cities.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            <div className="search-panel__chips" role="group" aria-label="Especialidade">
              {chips.map((c) => (
                <button
                  key={c.slug || 'all'}
                  type="button"
                  className="chip chip--sm"
                  aria-pressed={draft.serviceSlug === c.slug}
                  onClick={() => setService(c.slug)}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </section>

          <section aria-labelledby="pros-list-title" className="booking-pros">
            <div className="booking-pros__head">
              <h2 id="pros-list-title" className="card-title">
                {service ? `Profissionais de ${service.name}` : 'Todos os profissionais'}
              </h2>
              {!loading && pros && <span className="muted">{pros.length} encontrados</span>}
            </div>
            {error ? (
              <ErrorState error={error} onRetry={reload} />
            ) : loading ? (
              <div className="pro-list">
                <ProfessionalCardSkeleton />
                <ProfessionalCardSkeleton />
                <ProfessionalCardSkeleton />
              </div>
            ) : pros.length === 0 ? (
              <EmptyState
                icon="person"
                title="Nenhum profissional encontrado"
                text="Ajuste a busca, a localização ou escolha outra especialidade."
                actions={
                  <Button
                    variant="outline"
                    size="sm"
                    icon="refresh"
                    onClick={() => {
                      setQuery('');
                      setCity('');
                      setService('');
                    }}
                  >
                    Limpar filtros
                  </Button>
                }
              />
            ) : (
              <div
                className="pro-list"
                role="radiogroup"
                aria-label="Escolha um profissional"
                key={`${draft.serviceSlug}-${city}-${query}`}
              >
                {pros.map((p, i) => (
                  <div key={p.id} style={{ animationDelay: `${i * 40}ms` }} className="pro-list__item">
                    <ProfessionalCard
                      pro={p}
                      selectable
                      selected={draft.professionalId === p.id}
                      onSelect={handleSelectPro}
                      showService={!service}
                    />
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>

        <aside className="booking-panel" ref={panelRef} aria-labelledby="panel-title" id="horario">
          <h2 id="panel-title" className="booking-panel__title">
            Confirmar agendamento
          </h2>

          {!professional ? (
            <div className="booking-panel__empty">
              <Icon name="calendar_today" size={40} />
              <p>Selecione um profissional para continuar</p>
            </div>
          ) : (
            <div className="booking-panel__body" key={professional.id}>
              <div className="panel-pro">
                <ProAvatar pro={professional} size={48} />
                <div>
                  <p className="panel-pro__name">{professional.name}</p>
                  <p className="panel-pro__spec">
                    {professional.specialty} · {professional.city} ·{' '}
                    <Link to={`/profissionais/${professional.id}`} className="text-link">
                      ver perfil
                    </Link>
                  </p>
                </div>
                <button type="button" className="icon-btn" onClick={() => setProfessional('')} aria-label="Trocar profissional">
                  <Icon name="close" size={20} />
                </button>
              </div>

              {offerings.length > 1 ? (
                <fieldset className="offer-pick">
                  <legend className="offer-pick__label">
                    <Icon name="medical_services" size={20} /> Serviço
                  </legend>
                  {offerings.map((o) => {
                    const on = offering?.id === o.id;
                    return (
                      <label key={o.id} className={`offer-pick__opt${on ? ' is-on' : ''}`}>
                        <input type="radio" name="offering" className="sr-only" checked={on} onChange={() => setOffering(o.id)} />
                        <span className="offer-pick__body">
                          <strong>{o.name}</strong>
                          <small>{o.duration} min</small>
                        </span>
                        <span className="offer-pick__price">{formatCurrency(o.price)}</span>
                      </label>
                    );
                  })}
                </fieldset>
              ) : (
                offering && (
                  <p className="offer-pick__single">
                    <Icon name="medical_services" size={18} /> {offering.name} · {offering.duration} min
                  </p>
                )
              )}

              <DatePicker pro={professional} value={draft.date} onChange={setDate} />
              <TimeSlots proId={professional.id} date={draft.date} value={draft.time} onChange={setTime} duration={duration} />

              <hr className="divider" />

              <div className="summary-rows">
                <div className="summary-row">
                  <span>{offering?.name || 'Consulta'}</span>
                  <strong>{formatCurrency(booking.price)}</strong>
                </div>
                <div className="summary-row">
                  <span>Taxa de Serviço</span>
                  <strong>{formatCurrency(booking.fee)}</strong>
                </div>
                <div className="summary-row summary-row--total">
                  <span>Total</span>
                  <strong>{formatCurrency(booking.total)}</strong>
                </div>
              </div>

              {draft.date && draft.time && (
                <p className="booking-panel__selection" aria-live="polite">
                  <Icon name="event_available" size={18} /> {formatDateLong(draft.date)} às {draft.time}
                </p>
              )}

              {blocked && (
                <Notice tone="info">
                  {role === 'admin'
                    ? 'Contas de administração não fazem agendamentos. Entre com uma conta de paciente para testar o fluxo.'
                    : 'Este é o seu próprio perfil profissional — não é possível agendar com você mesmo.'}
                </Notice>
              )}
              <Button
                variant="primary"
                block
                size="lg"
                iconRight="arrow_forward"
                disabled={!canContinue}
                onClick={handleContinue}
              >
                Confirmar Agendamento
              </Button>
              <p className="booking-panel__note">
                {blocked
                  ? 'Agendamento indisponível para esta conta.'
                  : canContinue
                    ? 'Você revisará os dados antes do pagamento.'
                    : !draft.date
                      ? 'Escolha uma data disponível.'
                      : 'Escolha um horário livre.'}
              </p>
            </div>
          )}
        </aside>
      </div>

      {/* Barra fixa no celular */}
      {isMobile && professional && (
        <div className={`booking-bar${canContinue ? ' is-ready' : ''}`}>
          <div>
            <p className="booking-bar__title">
              {canContinue ? `${formatDateLong(draft.date)} · ${draft.time}` : professional.name}
            </p>
            <p className="booking-bar__sub">
              {canContinue ? `Total ${formatCurrency(booking.total)}` : 'Escolha data e horário'}
            </p>
          </div>
          {canContinue ? (
            <Button variant="primary" size="sm" iconRight="arrow_forward" onClick={handleContinue}>
              Continuar
            </Button>
          ) : (
            <Button variant="outline" size="sm" onClick={() => panelRef.current?.scrollIntoView({ behavior: scrollBehavior() })}>
              Ver agenda
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
