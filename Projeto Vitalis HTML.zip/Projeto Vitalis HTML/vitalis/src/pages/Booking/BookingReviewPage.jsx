import { useEffect, useState } from 'react';
import { Link, Navigate, useNavigate } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { Notice, Stars } from '../../components/ui/Feedback';
import { ProAvatar } from '../../components/ui/Avatar';
import { Stepper } from '../../components/booking/Schedule';
import { useBooking } from '../../context/BookingContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { createAppointment } from '../../services/appointmentService';
import { isSlotAvailable } from '../../services/catalogService';
import { useDocumentTitle } from '../../hooks';
import { formatCurrency, formatDateLong, formatTimeRange, relativeDay } from '../../utils/format';
import './booking.css';

export default function BookingReviewPage() {
  useDocumentTitle('Revisar agendamento');
  const booking = useBooking();
  const { user } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const { draft, service, professional, offering, duration, isComplete } = booking;
  const [available, setAvailable] = useState(true);

  useEffect(() => {
    if (isComplete) setAvailable(isSlotAvailable(professional.id, draft.date, draft.time, { duration }));
  }, [isComplete, professional, draft.date, draft.time, duration]);

  if (!isComplete) {
    return <Navigate to="/agendar" replace />;
  }

  const confirm = async () => {
    setLoading(true);
    try {
      const appt = await createAppointment(user.id, {
        serviceSlug: offering?.serviceSlug || draft.serviceSlug,
        professionalId: draft.professionalId,
        offeringId: offering?.id || '',
        date: draft.date,
        time: draft.time,
      });
      toast.success('Agendamento criado', `Protocolo ${appt.protocol}. Conclua o pagamento para confirmar.`);
      // o rascunho é limpo pela página de pagamento (evita redirecionar esta página antes da navegação)
      navigate(`/pagamento/${appt.id}`, { replace: true, state: { fromBooking: true } });
    } catch (err) {
      setLoading(false);
      toast.error('Não foi possível agendar', err.message);
      if (err.code === 'SLOT_TAKEN') {
        booking.setTime('');
        navigate('/agendar');
      }
    }
  };

  return (
    <div className="container page booking-review">
      <header className="page-header booking-page__header">
        <div>
          <h1 className="page-title">Revise seu agendamento</h1>
          <p className="page-subtitle">Confira os dados antes de seguir para o pagamento</p>
        </div>
        <Stepper current={4} />
      </header>

      <div className="review-layout">
        <section className="card card--elevated review-card" aria-labelledby="review-title">
          <h2 id="review-title" className="sr-only">
            Dados do agendamento
          </h2>

          <div className="review-block">
            <div className="review-block__head">
              <h3>Profissional</h3>
              <Link to="/agendar" className="text-link">
                Alterar
              </Link>
            </div>
            <div className="review-pro">
              <ProAvatar pro={professional} size={null} />
              <div>
                <p className="review-pro__name">{professional.name}</p>
                <p className="muted">
                  {professional.title} · {service?.name}
                </p>
                {professional.rating ? (
                  <Stars rating={professional.rating} reviews={professional.reviews} size={15} />
                ) : (
                  <span className="badge badge--blue">
                    <Icon name="fiber_new" size={15} /> Novo no Vitalis
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="review-block">
            <div className="review-block__head">
              <h3>Data e horário</h3>
              <Link to="/agendar" state={{ focus: 'horario' }} className="text-link">
                Alterar
              </Link>
            </div>
            <ul className="review-facts">
              <li>
                <Icon name="calendar_today" size={22} />
                <span>
                  <strong>{formatDateLong(draft.date, true)}</strong>
                  <span className="muted"> ({relativeDay(draft.date)})</span>
                </span>
              </li>
              <li>
                <Icon name="schedule" size={22} />
                <span>
                  <strong>{formatTimeRange(draft.time, duration)}</strong>
                  <span className="muted"> ({duration} min)</span>
                </span>
              </li>
              {offering && (
                <li>
                  <Icon name="medical_services" size={22} />
                  <span>{offering.name}</span>
                </li>
              )}
              <li>
                <Icon name="distance" size={22} />
                <span>{professional.city}</span>
              </li>
            </ul>
            {!available && (
              <Notice tone="warning">
                Este horário não está mais disponível.{' '}
                <Link to="/agendar" className="text-link">
                  Escolha outro horário
                </Link>
                .
              </Notice>
            )}
          </div>

          <div className="review-block">
            <h3>Seus dados</h3>
            <ul className="review-facts">
              <li>
                <Icon name="person" size={22} /> {user.name}
              </li>
              <li>
                <Icon name="mail" size={22} /> {user.email}
              </li>
              {user.phone && (
                <li>
                  <Icon name="call" size={22} /> {user.phone}
                </li>
              )}
            </ul>
          </div>
        </section>

        <aside className="card card--elevated review-summary" aria-labelledby="summary-title">
          <h2 id="summary-title" className="card-title">
            Resumo do pedido
          </h2>
          <div className="summary-rows">
            <div className="summary-row">
              <span>{offering?.name || 'Consulta'}</span>
              <strong>{formatCurrency(booking.price)}</strong>
            </div>
            <div className="summary-row">
              <span>Taxa de serviço</span>
              <strong>{formatCurrency(booking.fee)}</strong>
            </div>
            <div className="summary-row summary-row--total">
              <span>Total</span>
              <strong>{formatCurrency(booking.total)}</strong>
            </div>
          </div>
          <div className="guarantee">
            <p className="guarantee__title">Garantia de reembolso:</p>
            <p>Se você não puder comparecer, cancele até 24h antes e receba reembolso total.</p>
          </div>
          <Button
            variant="primary"
            block
            size="lg"
            iconRight="arrow_forward"
            onClick={confirm}
            loading={loading}
            loadingText="Reservando horário…"
            disabled={!available}
          >
            Ir para o pagamento
          </Button>
          <Button variant="ghost" block to="/agendar" icon="arrow_back">
            Voltar e editar
          </Button>
        </aside>
      </div>
    </div>
  );
}
