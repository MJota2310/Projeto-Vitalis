import { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { AccordionItem } from '../../components/ui/Accordion';
import { TextField } from '../../components/ui/Field';
import { EmptyState, Notice } from '../../components/ui/Feedback';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useDocumentTitle, useForm } from '../../hooks';
import { scrollToSection } from '../../hooks/useSectionNav';
import { FAQ_GROUPS, SUPPORT_SUBJECTS, TUTORIALS } from '../../data/help';
import { CONTACT } from '../../data/content';
import { createTicket } from '../../services/supportService';
import { normalize } from '../../utils/format';
import { validateEmail } from '../../utils/validation';
import SupportChat from './SupportChat';
import './help.css';

function ContactForm() {
  const { user } = useAuth();
  const toast = useToast();
  const [loading, setLoading] = useState(false);
  const [ticket, setTicket] = useState(null);
  const validators = useMemo(
    () => ({
      name: (v) => (String(v).trim().length >= 3 ? '' : 'Informe seu nome.'),
      email: validateEmail,
      subject: (v) => (v ? '' : 'Escolha um assunto.'),
      message: (v) => {
        const t = String(v).trim();
        if (t.length < 15) return 'Descreva sua dúvida com pelo menos 15 caracteres.';
        if (t.length > 1000) return 'Limite de 1000 caracteres.';
        return '';
      },
    }),
    [],
  );
  const { values, errors, setField, onBlur, validateAll, reset } = useForm(
    { name: user?.name || '', email: user?.email || '', subject: '', message: '' },
    validators,
  );

  const submit = async (e) => {
    e.preventDefault();
    const errs = validateAll();
    if (Object.keys(errs).length) {
      document.querySelector(`[name="c-${Object.keys(errs)[0]}"]`)?.focus();
      return;
    }
    setLoading(true);
    try {
      const t = await createTicket({ ...values, userId: user?.id });
      setTicket(t);
      toast.success('Mensagem registrada', `Protocolo ${t.protocol}.`);
    } catch (err) {
      toast.error('Não foi possível enviar', err.message);
    } finally {
      setLoading(false);
    }
  };

  if (ticket) {
    const mailto = `mailto:${CONTACT.email}?subject=${encodeURIComponent(`[${ticket.protocol}] ${ticket.subject}`)}&body=${encodeURIComponent(ticket.message)}`;
    return (
      <div className="contact-success">
        <span className="contact-success__icon" aria-hidden="true">
          <Icon name="task_alt" size={40} />
        </span>
        <h3>Mensagem registrada!</h3>
        <p>
          Protocolo <strong>{ticket.protocol}</strong>. Guarde este número para acompanhar seu atendimento.
        </p>
        <Notice tone="demo" title="Modo demonstração:">
          a mensagem foi salva apenas neste navegador. Para falar de verdade com a equipe, envie também por e-mail.
        </Notice>
        <div className="row" style={{ justifyContent: 'center' }}>
          <Button variant="primary" href={mailto} icon="mail">
            Enviar por e-mail
          </Button>
          <Button
            variant="ghost"
            onClick={() => {
              setTicket(null);
              reset({ name: user?.name || '', email: user?.email || '', subject: '', message: '' });
            }}
          >
            Nova mensagem
          </Button>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} noValidate className="contact-form">
      <div className="form-grid">
        <TextField
          label="Nome"
          name="c-name"
          icon="person"
          value={values.name}
          onChange={(e) => setField('name', e.target.value)}
          onBlur={() => onBlur('name')}
          error={errors.name}
          autoComplete="name"
          required
        />
        <TextField
          label="E-mail"
          name="c-email"
          type="email"
          icon="mail"
          value={values.email}
          onChange={(e) => setField('email', e.target.value)}
          onBlur={() => onBlur('email')}
          error={errors.email}
          autoComplete="email"
          required
        />
        <TextField
          as="select"
          className="form-grid__full"
          label="Assunto"
          name="c-subject"
          value={values.subject}
          onChange={(e) => setField('subject', e.target.value)}
          onBlur={() => onBlur('subject')}
          error={errors.subject}
          required
        >
          <option value="">Selecione…</option>
          {SUPPORT_SUBJECTS.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </TextField>
        <TextField
          as="textarea"
          className="form-grid__full"
          label="Mensagem"
          name="c-message"
          rows={5}
          maxLength={1000}
          placeholder="Descreva sua dúvida ou problema"
          value={values.message}
          onChange={(e) => setField('message', e.target.value)}
          onBlur={() => onBlur('message')}
          error={errors.message}
          hint={`${values.message.length}/1000`}
          required
        />
      </div>
      <Button type="submit" variant="primary" icon="send" loading={loading} loadingText="Enviando…">
        Enviar mensagem
      </Button>
    </form>
  );
}

export default function HelpPage() {
  useDocumentTitle('Central de Ajuda');
  const location = useLocation();
  const [query, setQuery] = useState('');
  const [open, setOpen] = useState(null);
  const [chatOpen, setChatOpen] = useState(false);

  useEffect(() => {
    const target = new URLSearchParams(location.search).get('secao');
    if (!target) return undefined;
    // "contato" é o id do rodapé; na Central de Ajuda o formulário fica em #fale-conosco
    const id = target === 'contato' ? 'fale-conosco' : target;
    const t = setTimeout(() => scrollToSection(id), 120);
    return () => clearTimeout(t);
  }, [location.search, location.key]);

  const q = normalize(query.trim());
  const groups = useMemo(
    () =>
      FAQ_GROUPS.map((g) => ({
        ...g,
        items: g.items.filter((i) => !q || normalize(`${i.q} ${i.a.join(' ')} ${i.keywords.join(' ')}`).includes(q)),
      })).filter((g) => g.items.length),
    [q],
  );
  const total = groups.reduce((n, g) => n + g.items.length, 0);

  return (
    <div className="help-page">
      <header className="help-hero">
        <div className="container">
          <h1 className="help-hero__title">Central de Ajuda</h1>
          <p className="help-hero__text">Encontre respostas rápidas para suas dúvidas</p>
          <div className="help-search field field--icon field--action">
            <label htmlFor="help-search" className="sr-only">
              Buscar por dúvidas
            </label>
            <div className="field__control">
              <Icon name="data_loss_prevention" size={24} className="field__icon" />
              <input
                id="help-search"
                className="input"
                type="search"
                placeholder="Buscar por dúvidas..."
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setOpen(null);
                }}
              />
              {query && (
                <button type="button" className="field__action" onClick={() => setQuery('')} aria-label="Limpar busca">
                  <Icon name="close" size={18} />
                </button>
              )}
            </div>
          </div>
          {q && (
            <p className="help-hero__count" aria-live="polite">
              {total} {total === 1 ? 'resultado' : 'resultados'} para “{query.trim()}”
            </p>
          )}
        </div>
      </header>

      <div className="container help-layout">
        <section className="faq-card" id="faq" aria-labelledby="faq-title">
          <h2 id="faq-title" className="faq-card__title">
            Perguntas Frequentes
          </h2>
          {groups.length === 0 ? (
            <EmptyState
              icon="help"
              title="Nenhuma pergunta encontrada"
              text="Tente outras palavras ou fale com a nossa equipe."
              actions={
                <>
                  <Button variant="outline" size="sm" onClick={() => setQuery('')}>
                    Limpar busca
                  </Button>
                  <Button variant="primary" size="sm" icon="chat" onClick={() => setChatOpen(true)}>
                    Abrir chat
                  </Button>
                </>
              }
            />
          ) : (
            groups.map((g) => (
              <div key={g.id} className="faq-group">
                <h3 className="faq-group__title">
                  <span className="faq-group__dot" aria-hidden="true" />
                  {g.title}
                </h3>
                <div className="accordion">
                  {g.items.map((item) => {
                    const key = `${g.id}-${item.q}`;
                    return (
                      <AccordionItem
                        key={key}
                        title={item.q}
                        open={open === key || (!!q && total <= 2)}
                        onToggle={() => setOpen(open === key ? null : key)}
                      >
                        {item.a.map((p) => (
                          <p key={p}>{p}</p>
                        ))}
                      </AccordionItem>
                    );
                  })}
                </div>
              </div>
            ))
          )}
        </section>

        <aside className="help-side">
          <section className="help-box" aria-labelledby="more-help">
            <h2 id="more-help" className="help-box__title">
              Precisa de mais ajuda?
            </h2>
            <p className="help-box__text">Não encontrou o que procurava? Entre em contato conosco.</p>
            <div className="help-box__actions">
              <Button variant="primary" block icon="chat" onClick={() => setChatOpen(true)}>
                Abrir chat
              </Button>
              <Button variant="outline" block icon="mail" href={`mailto:${CONTACT.email}`}>
                Enviar email
              </Button>
              <Button variant="soft" block icon="call" href={CONTACT.phoneHref} className="help-box__call">
                Ligar Agora
              </Button>
            </div>
          </section>

          <section className="guides-box" aria-labelledby="guides-title">
            <h2 id="guides-title">📚 Guias e Tutoriais</h2>
            <p>Acesse nossa base de conhecimento completa com guias detalhados.</p>
            <Button variant="light" size="sm" onClick={() => scrollToSection('tutoriais')}>
              Ver Tutoriais
            </Button>
          </section>

          <section className="help-box" aria-labelledby="hours-title">
            <h2 id="hours-title" className="help-box__title">
              Horário de atendimento
            </h2>
            <dl className="hours">
              {CONTACT.hours.map((h) => (
                <div key={h.label}>
                  <dt>{h.label}</dt>
                  <dd>{h.value}</dd>
                </div>
              ))}
            </dl>
          </section>
        </aside>
      </div>

      <section className="container help-section" id="tutoriais" aria-labelledby="tutorials-title">
        <h2 id="tutorials-title" className="section-title">
          Guias e Tutoriais
        </h2>
        <p className="section-subtitle">Passo a passo das principais tarefas na Vitalis</p>
        <div className="tutorials">
          {TUTORIALS.map((t) => (
            <article key={t.id} className="tutorial">
              <span className="tutorial__icon" aria-hidden="true">
                <Icon name={t.icon} size={28} />
              </span>
              <h3>{t.title}</h3>
              <ol>
                {t.steps.map((s, i) => (
                  <li key={s}>
                    <span>{i + 1}</span>
                    {s}
                  </li>
                ))}
              </ol>
            </article>
          ))}
        </div>
      </section>

      <section className="container help-section" id="fale-conosco" aria-labelledby="contact-title">
        <div className="contact-card">
          <div className="contact-card__intro">
            <h2 id="contact-title">Fale com a nossa equipe</h2>
            <p>Envie sua mensagem e responderemos no horário de atendimento.</p>
            <ul>
              <li>
                <Icon name="mail" size={20} /> <a href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a>
              </li>
              <li>
                <Icon name="call" size={20} /> <a href={CONTACT.phoneHref}>{CONTACT.phone}</a>
              </li>
              <li>
                <Icon name="location_on" size={20} /> {CONTACT.location}
              </li>
            </ul>
          </div>
          <ContactForm />
        </div>
      </section>

      <SupportChat
        open={chatOpen}
        onClose={() => setChatOpen(false)}
        onContact={() => {
          setChatOpen(false);
          setTimeout(() => scrollToSection('fale-conosco'), 100);
        }}
      />
    </div>
  );
}
