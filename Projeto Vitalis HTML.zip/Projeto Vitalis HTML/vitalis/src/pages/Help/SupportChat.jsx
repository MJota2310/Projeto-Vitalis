import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import Icon from '../../components/ui/Icon';
import { askAssistant } from '../../services/supportService';
import { useFocusTrap } from '../../hooks';
import { scrollBehavior } from '../../utils/motion';

const SUGGESTIONS = ['Como agendar uma consulta?', 'Posso cancelar?', 'Formas de pagamento', 'Como funciona o reembolso?'];

/** Chat de suporte com assistente automático (respostas da Central de Ajuda). */
export default function SupportChat({ open, onClose, onContact }) {
  const [messages, setMessages] = useState([
    { from: 'bot', text: 'Olá! Sou o assistente virtual da Vitalis. Como posso ajudar?' },
  ]);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const listRef = useRef(null);
  const panelRef = useRef(null);
  useFocusTrap(open, panelRef, onClose);

  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: scrollBehavior() });
  }, [messages, typing]);

  const send = async (text) => {
    const msg = text.trim();
    if (!msg || typing) return;
    setMessages((m) => [...m, { from: 'user', text: msg }]);
    setInput('');
    setTyping(true);
    const reply = await askAssistant(msg);
    setTyping(false);
    setMessages((m) => [...m, { from: 'bot', text: reply.text, related: reply.related, fallback: !reply.related }]);
  };

  if (!open) return null;

  return createPortal(
    <div className="chat-root">
      <div className="chat-backdrop" onClick={onClose} aria-hidden="true" />
      <section ref={panelRef} className="chat" role="dialog" aria-modal="true" aria-labelledby="chat-title">
        <header className="chat__head">
          <span className="chat__avatar" aria-hidden="true">
            <Icon name="support_agent" size={24} />
          </span>
          <div>
            <h2 id="chat-title">Assistente Vitalis</h2>
            <p>Respostas automáticas da Central de Ajuda</p>
          </div>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Fechar chat">
            <Icon name="close" />
          </button>
        </header>

        <div className="chat__messages" ref={listRef} aria-live="polite">
          {messages.map((m, i) => (
            <div key={i} className={`bubble bubble--${m.from}`}>
              {m.related && <p className="bubble__related">Sobre: {m.related}</p>}
              <p>{m.text}</p>
              {m.fallback && (
                <button type="button" className="bubble__action" onClick={onContact}>
                  Enviar mensagem para a equipe
                </button>
              )}
            </div>
          ))}
          {typing && (
            <div className="bubble bubble--bot bubble--typing" aria-label="Assistente digitando">
              <span />
              <span />
              <span />
            </div>
          )}
        </div>

        <div className="chat__suggestions">
          {SUGGESTIONS.map((s) => (
            <button key={s} type="button" className="chip chip--sm" onClick={() => send(s)} disabled={typing}>
              {s}
            </button>
          ))}
        </div>

        <form
          className="chat__form"
          onSubmit={(e) => {
            e.preventDefault();
            send(input);
          }}
        >
          <label htmlFor="chat-input" className="sr-only">
            Digite sua dúvida
          </label>
          <input
            id="chat-input"
            className="input"
            placeholder="Digite sua dúvida…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            maxLength={300}
            autoComplete="off"
            data-autofocus
          />
          <button type="submit" className="chat__send" disabled={!input.trim() || typing} aria-label="Enviar">
            <Icon name="send" size={22} />
          </button>
        </form>
      </section>
    </div>,
    document.body,
  );
}
