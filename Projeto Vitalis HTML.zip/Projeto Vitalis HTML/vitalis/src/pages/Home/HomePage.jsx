import { useEffect } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { useAuth } from '../../context/AuthContext';
import { useDocumentTitle, useReveal } from '../../hooks';
import { scrollToSection } from '../../hooks/useSectionNav';
import {
  DIFFERENTIALS,
  HERO_FEATURES,
  HOW_IT_WORKS,
  PRO_BENEFITS,
  PRO_CARDS,
  PRO_CHECKLIST,
  TESTIMONIALS,
  USER_BENEFITS,
} from '../../data/content';
import { SERVICES } from '../../data/catalog';

import step1 from '../../assets/decor/step-1.svg';
import step2 from '../../assets/decor/step-2.svg';
import step3 from '../../assets/decor/step-3.svg';
import step4 from '../../assets/decor/step-4.svg';
import blobMint from '../../assets/decor/blob-mint.svg';
import blobYellow from '../../assets/decor/blob-yellow.svg';
import blobWave from '../../assets/decor/blob-wave.svg';
import quarterCyan from '../../assets/decor/quarter-cyan.png';
import quarterLight from '../../assets/decor/quarter-light.png';
import ctaBg from '../../assets/images/cta-background.png';
import './home.css';

const STEP_BADGES = { 'step-1': step1, 'step-2': step2, 'step-3': step3, 'step-4': step4 };

// Os 5 serviços em destaque na landing (+ "E muito mais"), como no Figma.
const FEATURED = ['consultas-medicas', 'psicologia', 'fisioterapia', 'atividades-fisicas', 'estetica'].map((slug) =>
  SERVICES.find((s) => s.slug === slug),
);
const FEATURED_TONES = ['green', 'cyan', 'yellow', 'green', 'cyan', 'yellow'];

/* ------------------------------------------------------------------------ */

function Hero({ isAuthenticated }) {
  return (
    <section className="hero" id="inicio" aria-labelledby="hero-title">
      <div className="container hero__inner">
        <div className="hero__copy">
          <h1 id="hero-title" className="hero__title">
            <span className="hero__line">Cuide da sua saúde</span>
            <span className="hero__line">com mais</span>
            <span className="hero__accent text-gradient">praticidade</span>
          </h1>
          <p className="hero__text">
            Conectamos você aos melhores profissionais de saúde e bem-estar.
            <br />
            Agende consultas, gerencie seu histórico e cuide da sua saúde em um só lugar.
          </p>
          <div className="hero__actions">
            <Button variant="primary" size="lg" icon="calendar_today" to="/agendar">
              Agendar Agora
            </Button>
            <Button
              variant="outline"
              size="lg"
              icon="search"
              href="#/?secao=servicos"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('servicos');
              }}
            >
              Explorar Serviços
            </Button>
          </div>
          {isAuthenticated && (
            <p className="hero__hint">
              <Icon name="dashboard" size={18} /> Acompanhe suas consultas no <Link to="/painel">Dashboard</Link>.
            </p>
          )}
        </div>

        <div className="hero-card" aria-label="Destaques da Vitalis">
          <div className="hero-card__frame">
            <ul className="hero-card__panel">
              {HERO_FEATURES.map((f, i) => (
                <li key={f.title} className={`hero-row hero-row--${f.tone}`} style={{ '--i': i }}>
                  <span className="hero-row__check" aria-hidden="true">
                    <Icon name="check" size={30} />
                  </span>
                  <span>
                    <strong className="hero-row__title">{f.title}</strong>
                    <span className="hero-row__text">{f.text}</span>
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}

function HowItWorks() {
  const ref = useReveal();
  return (
    <section className="section how" id="como-funciona" aria-labelledby="how-title" ref={ref}>
      <div className="container">
        <h2 id="how-title" className="section-title reveal">
          Como funciona
        </h2>
        <p className="section-subtitle reveal">
          Cuidar da sua saúde nunca foi tão simples. Veja como a Vitalis facilita seu dia a dia
        </p>
        <ol className="how__grid">
          {HOW_IT_WORKS.map((s, i) => (
            <li key={s.n} className="how-step reveal" style={{ '--reveal-delay': `${i * 90}ms` }}>
              <div className="how-step__badge">
                <img src={STEP_BADGES[s.badge]} alt="" width="119" height="140" />
                <span className="how-step__number" aria-hidden="true">
                  {s.n}
                </span>
                <Icon name={s.icon} size={40} className="how-step__icon" />
              </div>
              <h3 className="how-step__title">
                <span className="sr-only">Passo {s.n}: </span>
                {s.title}
              </h3>
              <p className="how-step__text">{s.text}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

function ServicesPreview() {
  const ref = useReveal();
  return (
    <section className="section services-preview" id="servicos" aria-labelledby="services-title" ref={ref}>
      <div className="container">
        <h2 id="services-title" className="section-title reveal">
          Serviços disponíveis
        </h2>
        <p className="section-subtitle reveal">Uma ampla variedade de serviços de saúde e bem-estar ao seu alcance</p>
        <ul className="services-preview__grid">
          {FEATURED.map((s, i) => (
            <li key={s.slug} className="reveal" style={{ '--reveal-delay': `${i * 70}ms` }}>
              <Link to={`/servicos/${s.slug}`} className={`sp-card sp-card--${FEATURED_TONES[i]}`}>
                <span className="sp-card__icon">
                  <Icon name={s.landingIcon} size={34} />
                </span>
                <span className="sp-card__title">{s.name}</span>
                <span className="sp-card__text">{s.short}</span>
                <Icon name="arrow_forward" size={22} className="sp-card__go" />
              </Link>
            </li>
          ))}
          <li className="reveal" style={{ '--reveal-delay': '350ms' }}>
            <Link to="/servicos" className="sp-card sp-card--yellow">
              <span className="sp-card__icon">
                <Icon name="arrow_right_alt" size={38} />
              </span>
              <span className="sp-card__title">E muito mais</span>
              <span className="sp-card__text">Explore todos os serviços disponíveis</span>
              <Icon name="arrow_forward" size={22} className="sp-card__go" />
            </Link>
          </li>
        </ul>
        <div className="services-preview__cta reveal">
          <Button variant="invert" to="/servicos" iconRight="arrow_right_alt" iconSize={28}>
            Ver todos os serviços
          </Button>
        </div>
      </div>
    </section>
  );
}

function Benefits() {
  const ref = useReveal();
  return (
    <section className="section benefits" aria-labelledby="benefits-title" ref={ref}>
      <img src={blobYellow} alt="" className="benefits__blob benefits__blob--yellow" aria-hidden="true" />
      <img src={blobMint} alt="" className="benefits__blob benefits__blob--mint" aria-hidden="true" />
      <img src={blobWave} alt="" className="benefits__blob benefits__blob--wave" aria-hidden="true" />
      <div className="container benefits__inner">
        <h2 id="benefits-title" className="section-title reveal">
          Benefícios para todos
        </h2>
        <p className="section-subtitle reveal">
          A Vitalis oferece vantagens tanto para usuários quanto para profissionais de saúde
        </p>
        <div className="benefits__grid">
          {[
            { label: 'Para Usuários', tone: 'users', items: USER_BENEFITS },
            { label: 'Para Profissionais', tone: 'pros', items: PRO_BENEFITS },
          ].map((col, c) => (
            <div key={col.label} className="benefits__col reveal" style={{ '--reveal-delay': `${c * 120}ms` }}>
              <span className={`pill pill--${col.tone}`}>{col.label}</span>
              <ul className="benefit-list">
                {col.items.map((b) => (
                  <li key={b.title} className="benefit">
                    <span className="benefit__icon">
                      <Icon name={b.icon} size={32} />
                    </span>
                    <span>
                      <strong className="benefit__title">{b.title}</strong>
                      <span className="benefit__text">{b.text}</span>
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ForProfessionals({ isAuthenticated }) {
  const ref = useReveal();
  return (
    <section className="section pros" id="profissionais" aria-labelledby="pros-title" ref={ref}>
      <div className="container pros__inner">
        <div className="pros__copy reveal">
          <span className="pill pill--yellow">Para Profissionais</span>
          <h2 id="pros-title" className="pros__title">
            Potencialize sua carreira na área da saúde
          </h2>
          <p className="pros__text">
            Junte-se a centenas de profissionais que já estão transformando a forma como atendem seus pacientes. Com a Vitalis,
            você tem todas as ferramentas necessárias para crescer e se destacar no mercado.
          </p>
          <ul className="pros__checks">
            {PRO_CHECKLIST.map((c) => (
              <li key={c.text}>
                <span className={`dot-check dot-check--${c.tone}`} aria-hidden="true">
                  <Icon name="check_small" size={24} />
                </span>
                {c.text}
              </li>
            ))}
          </ul>
          {isAuthenticated ? (
            <Button variant="primary" to="/ajuda?secao=contato" icon="support_agent">
              Fale com nossa equipe
            </Button>
          ) : (
            <Button variant="invert" to="/cadastro?tipo=profissional">
              Cadastre-se como um profissional
            </Button>
          )}
        </div>
        <ul className="pros__cards">
          {PRO_CARDS.map((c, i) => (
            <li key={c.title} className="pro-card reveal" style={{ '--reveal-delay': `${i * 100}ms` }}>
              <span className={`pro-card__icon pro-card__icon--${c.tone}`}>
                <Icon name={c.icon} size={34} />
              </span>
              <h3 className="pro-card__title">{c.title}</h3>
              <p className="pro-card__text">{c.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function Differentials() {
  const ref = useReveal();
  return (
    <section className="section diffs" aria-labelledby="diffs-title" ref={ref}>
      <div className="container">
        <h2 id="diffs-title" className="section-title reveal">
          Nossos diferenciais
        </h2>
        <p className="section-subtitle reveal">O que torna a Vitalis a melhor escolha para cuidar da sua saúde</p>
        <ul className="diffs__grid">
          {DIFFERENTIALS.map((d, i) => (
            <li key={d.n} className={`diff diff--${d.tone} reveal`} style={{ '--reveal-delay': `${i * 90}ms` }}>
              <div className="diff__tile">
                <Icon name={d.icon} size={64} />
                <span className="diff__num" aria-hidden="true">
                  {d.n}
                </span>
              </div>
              <h3 className="diff__title">{d.title}</h3>
              <p className="diff__text">{d.text}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function Testimonials() {
  const ref = useReveal();
  return (
    <section className="section testimonials" aria-labelledby="testimonials-title" ref={ref}>
      <div className="container">
        <h2 id="testimonials-title" className="section-title section-title--strong reveal">
          O que dizem sobre nós
        </h2>
        <p className="testimonials__subtitle reveal">Veja a experiência de quem já usa a Vitalis</p>
        <ul className="testimonials__grid">
          {TESTIMONIALS.map((t, i) => (
            <li key={t.name} className="quote-card reveal" style={{ '--reveal-delay': `${i * 90}ms` }}>
              <figure>
                <span className="quote-card__stars" role="img" aria-label="Avaliação 5 de 5 estrelas">
                  {Array.from({ length: 5 }, (_, k) => (
                    <Icon key={k} name="kid_star" fill size={20} />
                  ))}
                </span>
                <blockquote className="quote-card__text">“{t.text}”</blockquote>
                <figcaption className="quote-card__author">
                  <span className="quote-card__emoji" aria-hidden="true">
                    {t.emoji}
                  </span>
                  <span>
                    <span className="quote-card__name">{t.name}</span>
                    <span className="quote-card__role">{t.role}</span>
                  </span>
                </figcaption>
              </figure>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}

function CallToAction({ isAuthenticated }) {
  const ref = useReveal();
  return (
    <section className="cta" aria-labelledby="cta-title" ref={ref} style={{ '--cta-bg': `url(${ctaBg})` }}>
      <img src={quarterCyan} alt="" className="cta__decor cta__decor--left" aria-hidden="true" />
      <img src={quarterLight} alt="" className="cta__decor cta__decor--right" aria-hidden="true" />
      <div className="container cta__inner">
        <h2 id="cta-title" className="cta__title reveal">
          Comece a cuidar da sua saúde hoje
        </h2>
        <p className="cta__text reveal">Junte-se a milhares de pessoas que já estão transformando a forma como cuidam da saúde</p>
        <div className="reveal">
          {isAuthenticated ? (
            <Button variant="light" to="/agendar" iconRight="arrow_forward">
              agendar uma consulta
            </Button>
          ) : (
            <Button variant="light" to="/cadastro" iconRight="arrow_forward">
              criar conta gratuita
            </Button>
          )}
        </div>
        <p className="cta__small reveal">
          {isAuthenticated
            ? 'Escolha o profissional, a data e o horário em poucos cliques'
            : 'Sem cartão de crédito • Configure em 2 minutos'}
        </p>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------------ */

export default function HomePage() {
  useDocumentTitle('');
  const { isAuthenticated } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  // Rolagem para a seção pedida (menu em outra página ou link /?secao=…)
  useEffect(() => {
    const target = location.state?.scrollTo || new URLSearchParams(location.search).get('secao');
    if (!target) return undefined;
    const t = setTimeout(() => {
      scrollToSection(target);
      if (location.state?.scrollTo) navigate('/', { replace: true, state: { keepScroll: true } });
    }, 80);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.key]);

  return (
    <div className="home">
      <Hero isAuthenticated={isAuthenticated} />
      <HowItWorks />
      <ServicesPreview />
      <Benefits />
      <ForProfessionals isAuthenticated={isAuthenticated} />
      <Differentials />
      <Testimonials />
      <CallToAction isAuthenticated={isAuthenticated} />
    </div>
  );
}
