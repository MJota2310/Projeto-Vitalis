import { Link } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import { Notice } from '../../components/ui/Feedback';
import { useDocumentTitle } from '../../hooks';
import { scrollToSection } from '../../hooks/useSectionNav';
import { LEGAL_UPDATED_AT, PRIVACY, TERMS } from '../../data/legal';
import { formatDateBR } from '../../utils/format';
import './legal.css';

const DOCS = {
  termos: { title: 'Termos de Uso', sections: TERMS, other: { to: '/privacidade', label: 'Política de Privacidade' } },
  privacidade: { title: 'Política de Privacidade', sections: PRIVACY, other: { to: '/termos', label: 'Termos de Uso' } },
};

export default function LegalPage({ doc }) {
  const { title, sections, other } = DOCS[doc];
  useDocumentTitle(title);

  return (
    <div className="container page legal">
      <header className="page-header">
        <p className="legal__eyebrow">Documentos</p>
        <h1 className="page-title">{title}</h1>
        <p className="page-subtitle">Última atualização: {formatDateBR(LEGAL_UPDATED_AT)}</p>
      </header>

      <Notice tone="demo" className="legal__notice">
        Texto-modelo elaborado para o projeto Vitalis. Antes do uso em produção, deve ser revisado por um profissional jurídico.
      </Notice>

      <div className="legal__layout">
        <nav className="legal__toc" aria-label="Sumário">
          <p>Sumário</p>
          <ol>
            {sections.map((s) => (
              <li key={s.id}>
                <a
                  href={`#/${doc}`}
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection(s.id);
                  }}
                >
                  {s.title}
                </a>
              </li>
            ))}
          </ol>
          <Link to={other.to} className="legal__other">
            <Icon name="description" size={18} /> {other.label}
          </Link>
        </nav>

        <article className="legal__body">
          {sections.map((s) => (
            <section key={s.id} id={s.id} className="legal__section">
              <h2>{s.title}</h2>
              {s.body.map((p) => (
                <p key={p}>{p}</p>
              ))}
            </section>
          ))}
          <p className="legal__contact">
            Ficou com dúvidas? <Link to="/ajuda?secao=contato">Fale com a nossa equipe</Link>.
          </p>
        </article>
      </div>
    </div>
  );
}
