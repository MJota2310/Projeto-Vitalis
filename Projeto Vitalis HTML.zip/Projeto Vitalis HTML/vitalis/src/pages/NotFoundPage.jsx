import Button from '../components/ui/Button';
import { EmptyState } from '../components/ui/Feedback';
import { useDocumentTitle } from '../hooks';

export default function NotFoundPage() {
  useDocumentTitle('Página não encontrada');
  return (
    <div className="container page">
      <EmptyState
        icon="search"
        title="Página não encontrada"
        text="O endereço que você acessou não existe ou foi alterado."
        actions={
          <>
            <Button variant="primary" to="/" icon="home">
              Ir para o início
            </Button>
            <Button variant="outline" to="/servicos">
              Ver serviços
            </Button>
          </>
        }
      />
    </div>
  );
}
