import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState } from '../../components/ui/Feedback';
import { PanelHeader } from '../../components/panel/PanelLayout';
import { useToast } from '../../context/ToastContext';
import { useAsync, useDocumentTitle } from '../../hooks';
import {
  NOTIFICATION_TYPES,
  listNotifications,
  markAllRead,
  markRead,
  removeNotification,
  toggleImportant,
} from '../../services/notificationService';
import { formatDateTimeBR, relativeTime } from '../../utils/format';
import '../../components/panel/panel.css';
import './notifications.css';

const FILTERS = [
  { id: 'todas', label: 'Todas' },
  { id: 'nao_lidas', label: 'Não lidas' },
  { id: 'importantes', label: 'Importantes' },
];

/** Central de notificações (usada pelos três perfis). */
export function NotificationsView({ embedded = false }) {
  useDocumentTitle('Notificações');
  const toast = useToast();
  const navigate = useNavigate();
  const [filter, setFilter] = useState('todas');
  const [busy, setBusy] = useState('');
  const { data, loading, error, reload, setData } = useAsync(() => listNotifications({ filter }), [filter]);

  // mantém a lista atualizada quando algo muda em outra parte do app
  useEffect(() => {
    const onChange = () =>
      listNotifications({ filter })
        .then(setData)
        .catch(() => {});
    window.addEventListener('vitalis:db', onChange);
    return () => window.removeEventListener('vitalis:db', onChange);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filter]);

  const list = data || [];
  const unread = list.filter((n) => !n.read).length;

  const act = async (id, fn, okMsg) => {
    setBusy(id);
    try {
      await fn();
      if (okMsg) toast.success(okMsg);
    } catch (err) {
      toast.error('Não foi possível concluir', err.message);
    } finally {
      setBusy('');
    }
  };

  const open = async (n) => {
    if (!n.read) await markRead(n.id).catch(() => {});
    if (n.link) navigate(n.link);
  };

  const content = (
    <>
      <PanelHeader
        eyebrow="Central de avisos"
        title="Notificações"
        subtitle="Avisos sobre agendamentos, pagamentos e sua conta. Nesta versão, as notificações aparecem somente dentro do Vitalis (não há envio de e-mail ou SMS)."
        actions={
          unread > 0 && (
            <Button
              variant="outline"
              size="sm"
              icon="done_all"
              iconSize={18}
              loading={busy === 'all'}
              onClick={() => act('all', markAllRead, 'Todas marcadas como lidas')}
            >
              Marcar todas como lidas
            </Button>
          )
        }
      />
      <div className="toolbar">
        <div className="tabs" role="tablist" aria-label="Filtrar notificações">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              type="button"
              role="tab"
              className="tab"
              aria-selected={filter === f.id}
              onClick={() => setFilter(f.id)}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data ? (
        <div className="ntf-list">
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className="skeleton" style={{ height: 84, borderRadius: 14 }} />
          ))}
        </div>
      ) : list.length === 0 ? (
        <div className="panel-card">
          <EmptyState
            icon="notifications_off"
            title={
              filter === 'todas'
                ? 'Nenhuma notificação'
                : filter === 'nao_lidas'
                  ? 'Tudo lido por aqui'
                  : 'Nenhuma notificação importante'
            }
            text={
              filter === 'importantes'
                ? 'Use a estrela de uma notificação para destacá-la aqui.'
                : 'Quando algo acontecer na sua conta, você será avisado aqui.'
            }
          />
        </div>
      ) : (
        <ul className="ntf-list" aria-live="polite">
          {list.map((n, i) => {
            const t = NOTIFICATION_TYPES[n.type] || NOTIFICATION_TYPES.sistema;
            return (
              <li
                key={n.id}
                className={`ntf${n.read ? '' : ' is-unread'}${n.important ? ' is-important' : ''}`}
                style={{ animationDelay: `${Math.min(i, 8) * 40}ms` }}
              >
                <span className={`ntf-icon ntf-icon--${t.tone}`} aria-hidden="true">
                  <Icon name={t.icon} size={20} />
                </span>
                <div className="ntf__body">
                  <p className="ntf__meta">
                    <span>{t.label}</span>
                    <time dateTime={n.createdAt} title={formatDateTimeBR(n.createdAt)}>
                      {relativeTime(n.createdAt)}
                    </time>
                    {!n.read && <span className="ntf__dot">Nova</span>}
                  </p>
                  <p className="ntf__title">{n.title}</p>
                  {n.text && <p className="ntf__text">{n.text}</p>}
                  {n.link && (
                    <button type="button" className="text-link ntf__open" onClick={() => open(n)}>
                      Abrir <Icon name="arrow_forward" size={16} />
                    </button>
                  )}
                </div>
                <div className="ntf__actions">
                  <button
                    type="button"
                    className={`icon-btn${n.important ? ' is-on' : ''}`}
                    aria-pressed={n.important}
                    aria-label={n.important ? `Remover destaque de "${n.title}"` : `Marcar "${n.title}" como importante`}
                    title={n.important ? 'Remover destaque' : 'Marcar como importante'}
                    disabled={busy === n.id}
                    onClick={() => act(n.id, () => toggleImportant(n.id))}
                  >
                    <Icon name="star" fill={n.important} size={20} />
                  </button>
                  <button
                    type="button"
                    className="icon-btn"
                    aria-label={n.read ? `Marcar "${n.title}" como não lida` : `Marcar "${n.title}" como lida`}
                    title={n.read ? 'Marcar como não lida' : 'Marcar como lida'}
                    disabled={busy === n.id}
                    onClick={() => act(n.id, () => markRead(n.id, !n.read))}
                  >
                    <Icon name={n.read ? 'mark_email_unread' : 'mark_email_read'} size={20} />
                  </button>
                  <button
                    type="button"
                    className="icon-btn icon-btn--danger"
                    aria-label={`Excluir "${n.title}"`}
                    title="Excluir"
                    disabled={busy === n.id}
                    onClick={() => act(n.id, () => removeNotification(n.id), 'Notificação excluída')}
                  >
                    <Icon name="delete" size={20} />
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </>
  );

  if (embedded) return <div className="ntf-page">{content}</div>;
  return (
    <div className="page ntf-page ntf-page--standalone">
      <div className="container container--narrow">
        <nav className="breadcrumb" aria-label="Você está em">
          <ol>
            <li>
              <Link to="/painel">Dashboard</Link>
            </li>
            <li aria-current="page">Notificações</li>
          </ol>
        </nav>
        {content}
      </div>
    </div>
  );
}

export default function NotificationsPage() {
  return <NotificationsView />;
}

export function EmbeddedNotificationsPage() {
  return <NotificationsView embedded />;
}
