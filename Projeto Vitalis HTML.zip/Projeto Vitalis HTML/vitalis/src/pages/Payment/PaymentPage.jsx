import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, Navigate, useLocation, useNavigate, useParams } from 'react-router-dom';
import QRCode from 'qrcode';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import { TextField } from '../../components/ui/Field';
import { DemoBadge, EmptyState, ErrorState, Notice, Spinner } from '../../components/ui/Feedback';
import OrderSummary from '../../components/booking/OrderSummary';
import { Stepper } from '../../components/booking/Schedule';
import { useAuth } from '../../context/AuthContext';
import { useBooking } from '../../context/BookingContext';
import { useToast } from '../../context/ToastContext';
import { getAppointment } from '../../services/appointmentService';
import { DEMO_CARDS, confirmPix, createPixCharge, payWithCard } from '../../services/paymentService';
import { useAsync, useDocumentTitle, useForm } from '../../hooks';
import { cardBrand, validateCardName, validateCardNumber, validateCvv, validateExpiry } from '../../utils/validation';
import { maskCardNumber, maskDigits, maskExpiry } from '../../utils/masks';
import { formatCurrency } from '../../utils/format';
import './payment.css';

const EMPTY_CARD = { number: '', name: '', expiry: '', cvv: '' };

function CardForm({ appointment, onProcessing, onResult }) {
  const validators = useMemo(
    () => ({
      number: validateCardNumber,
      name: validateCardName,
      expiry: validateExpiry,
      cvv: (v, vals) => validateCvv(v, cardBrand(vals.number)),
    }),
    [],
  );
  const { values, errors, setField, onBlur, validateAll, setValues, setErrors } = useForm(EMPTY_CARD, validators);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { user } = useAuth();
  const brand = cardBrand(values.number);

  const fillTest = (card) => {
    const next = new Date();
    const exp = `${String(next.getMonth() + 1).padStart(2, '0')}/${String((next.getFullYear() + 3) % 100).padStart(2, '0')}`;
    setValues({ number: card.number, name: user.name.toUpperCase(), expiry: exp, cvv: '123' });
    setErrors({});
  };

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    const errs = validateAll();
    if (Object.keys(errs).length) {
      document.querySelector(`[name="card-${Object.keys(errs)[0]}"]`)?.focus();
      return;
    }
    setLoading(true);
    onProcessing(true);
    try {
      const payment = await payWithCard(user.id, appointment.id, values);
      setValues(EMPTY_CARD); // os dados do cartão são descartados após o envio
      onResult(payment);
    } catch (err) {
      onProcessing(false);
      setLoading(false);
      if (err.field === 'number') setErrors((x) => ({ ...x, number: err.message }));
      else setError(err.message);
    }
  };

  return (
    <form onSubmit={submit} noValidate className="pay-form" autoComplete="on">
      <div className="test-cards">
        <p>
          <Icon name="info" size={18} /> Use um cartão de teste:
        </p>
        <div className="test-cards__list">
          {DEMO_CARDS.map((c) => (
            <button key={c.number} type="button" className={`test-card test-card--${c.result}`} onClick={() => fillTest(c)}>
              <span>{c.number}</span>
              <small>{c.label}</small>
            </button>
          ))}
        </div>
      </div>

      {error && <Notice tone="error">{error}</Notice>}

      <TextField
        label="Número do cartão"
        name="card-number"
        icon="add_card"
        inputMode="numeric"
        autoComplete="cc-number"
        placeholder="1234 5678 9101 1121"
        value={values.number}
        onChange={(e) => setField('number', maskCardNumber(e.target.value))}
        onBlur={() => onBlur('number')}
        error={errors.number}
        hint={values.number.replace(/\D/g, '').length >= 6 ? `Bandeira: ${brand}` : undefined}
        required
      />
      <TextField
        label="Nome no Cartão"
        name="card-name"
        icon="person"
        autoComplete="cc-name"
        placeholder="Nome como está no cartão"
        value={values.name}
        onChange={(e) => setField('name', e.target.value.toUpperCase())}
        onBlur={() => onBlur('name')}
        error={errors.name}
        required
      />
      <div className="pay-form__row">
        <TextField
          label="Validade"
          name="card-expiry"
          icon="calendar_month"
          inputMode="numeric"
          autoComplete="cc-exp"
          placeholder="MM/AA"
          value={values.expiry}
          onChange={(e) => setField('expiry', maskExpiry(e.target.value))}
          onBlur={() => onBlur('expiry')}
          error={errors.expiry}
          required
        />
        <TextField
          label="CVV"
          name="card-cvv"
          icon="lock"
          inputMode="numeric"
          autoComplete="cc-csc"
          placeholder={brand === 'American Express' ? '1234' : '123'}
          value={values.cvv}
          onChange={(e) => setField('cvv', maskDigits(e.target.value, 4))}
          onBlur={() => onBlur('cvv')}
          error={errors.cvv}
          required
        />
      </div>
      <Button type="submit" variant="primary" size="lg" block loading={loading} loadingText="Processando…">
        Confirmar Pagamento · {formatCurrency(appointment.total)}
      </Button>
      <p className="pay-secure">
        <Icon name="lock" size={18} /> Os dados do cartão não são armazenados — apenas bandeira e 4 últimos dígitos.
      </p>
    </form>
  );
}

function PixPanel({ appointment, onProcessing, onResult }) {
  const { user } = useAuth();
  const toast = useToast();
  const [charge, setCharge] = useState(null);
  const [qr, setQr] = useState('');
  const [remaining, setRemaining] = useState(0);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const copyTimer = useRef(null);

  const generate = async () => {
    setCharge(null);
    setQr('');
    setError('');
    try {
      const c = await createPixCharge(user.id, appointment.id);
      setCharge(c);
      setQr(await QRCode.toDataURL(c.qrPayload, { margin: 1, width: 240, color: { dark: '#111111', light: '#ffffff' } }));
    } catch (err) {
      setError(err.message);
    }
  };

  useEffect(() => {
    generate();
    return () => clearTimeout(copyTimer.current);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!charge) return undefined;
    const tick = () => setRemaining(Math.max(0, Math.round((new Date(charge.expiresAt) - Date.now()) / 1000)));
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [charge]);

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(charge.code);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = charge.code;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
    }
    setCopied(true);
    toast.success('Código PIX copiado', 'Cole no app do seu banco.');
    clearTimeout(copyTimer.current);
    copyTimer.current = setTimeout(() => setCopied(false), 2500);
  };

  const confirm = async (simulateFailure = false) => {
    setLoading(true);
    onProcessing(true);
    try {
      const payment = await confirmPix(user.id, appointment.id, { simulateFailure });
      onResult(payment);
    } catch (err) {
      onProcessing(false);
      setLoading(false);
      setError(err.message);
    }
  };

  const expired = charge && remaining === 0;
  const mm = String(Math.floor(remaining / 60)).padStart(2, '0');
  const ss = String(remaining % 60).padStart(2, '0');

  return (
    <div className="pix">
      {error && <Notice tone="error">{error}</Notice>}
      <div className="pix__box">
        <div className="pix__qr">
          {qr ? <img src={qr} alt="QR Code PIX de demonstração" width="200" height="200" /> : <Spinner />}
          {qr && <span className="pix__qr-tag">DEMONSTRAÇÃO</span>}
          {expired && (
            <div className="pix__expired">
              <p>Código expirado</p>
              <Button variant="primary" size="sm" icon="refresh" onClick={generate}>
                Gerar novo
              </Button>
            </div>
          )}
        </div>
        {charge && (
          <p className={`pix__timer${remaining < 120 ? ' is-ending' : ''}`} aria-live="off">
            <Icon name="timer" size={18} /> Expira em{' '}
            <strong>
              {mm}:{ss}
            </strong>
          </p>
        )}
        <div className="pix__code">
          <p className="pix__code-label">Código Pix Copia e Cola</p>
          <div className="pix__code-row">
            <code>{charge ? charge.code : 'Gerando código…'}</code>
            <Button
              variant={copied ? 'soft-green' : 'soft'}
              size="sm"
              icon={copied ? 'check' : 'content_copy'}
              iconSize={18}
              onClick={copy}
              disabled={!charge || expired}
            >
              {copied ? 'Copiado!' : 'Copiar'}
            </Button>
          </div>
        </div>
      </div>
      <Button
        variant="primary"
        size="lg"
        block
        onClick={() => confirm(false)}
        loading={loading}
        loadingText="Verificando pagamento…"
        disabled={!charge || expired}
      >
        Já fiz o Pagamento
      </Button>
      <button type="button" className="pix__simulate" onClick={() => confirm(true)} disabled={!charge || expired || loading}>
        Simular pagamento não identificado (teste de recusa)
      </button>
      <p className="pay-secure">
        <Icon name="lock" size={18} /> Código fictício: nenhum banco processa esta cobrança.
      </p>
    </div>
  );
}

export default function PaymentPage() {
  useDocumentTitle('Pagamento');
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [method, setMethod] = useState(location.state?.method === 'pix' ? 'pix' : 'card');
  const [processing, setProcessing] = useState(false);
  const { data: appt, loading, error, reload } = useAsync(() => getAppointment(user.id, id), [id]);
  const { reset: resetDraft } = useBooking();

  // Agendamento recém-criado: o rascunho da reserva já foi usado
  useEffect(() => {
    if (location.state?.fromBooking) resetDraft();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onResult = (payment) => {
    setProcessing(false);
    navigate(`/pagamento/${id}/${payment.status === 'aprovado' ? 'aprovado' : 'recusado'}`, {
      replace: true,
      state: { paymentId: payment.id, method: payment.method },
    });
  };

  if (loading) return <Spinner label="Carregando pagamento…" />;
  if (error) {
    return (
      <div className="container page">
        {error.code === 'NOT_FOUND' ? (
          <EmptyState
            icon="receipt_long"
            title="Agendamento não encontrado"
            text="Não encontramos este agendamento na sua conta."
            actions={
              <Button variant="primary" to="/consultas">
                Ver minhas consultas
              </Button>
            }
          />
        ) : (
          <ErrorState error={error} onRetry={reload} />
        )}
      </div>
    );
  }
  if (appt.status === 'agendada' || appt.status === 'concluida')
    return <Navigate to={`/consultas/${appt.id}`} replace state={{ paid: true }} />;
  if (appt.status === 'cancelada') {
    return (
      <div className="container page">
        <EmptyState
          icon="event_busy"
          title="Agendamento cancelado"
          text="Este agendamento foi cancelado e não pode mais ser pago."
          actions={
            <Button variant="primary" to="/agendar">
              Fazer novo agendamento
            </Button>
          }
        />
      </div>
    );
  }

  const lastFailed = appt.attempts.filter((a) => a.status === 'recusado').at(-1);

  return (
    <div className="container page payment-page">
      <header className="page-header booking-page__header">
        <div>
          <h1 className="page-title">Finalizar pagamento</h1>
          <p className="page-subtitle">Complete seu pagamento para confirmar seu agendamento</p>
        </div>
        <Stepper current={5} />
      </header>

      <Notice tone="demo" className="payment-page__demo">
        <strong>Ambiente de demonstração.</strong> Nenhuma cobrança real é feita e nenhum provedor de pagamento está conectado.
        Não digite dados reais de cartão — use os cartões de teste abaixo.
      </Notice>

      {lastFailed && (
        <Notice tone="warning" className="payment-page__demo">
          A última tentativa foi recusada{lastFailed.failureReason ? `: ${lastFailed.failureReason}` : '.'} Tente novamente ou use
          outro método.
        </Notice>
      )}

      <div className="payment-layout">
        <section className="pay-card" aria-labelledby="method-title">
          <div className="pay-card__head">
            <h2 id="method-title" className="pay-card__title">
              Método de pagamento
            </h2>
            <DemoBadge />
          </div>
          <div className="methods" role="radiogroup" aria-label="Método de pagamento">
            <button
              type="button"
              role="radio"
              aria-checked={method === 'card'}
              className={`method${method === 'card' ? ' is-selected' : ''}`}
              onClick={() => setMethod('card')}
            >
              <Icon name="add_card" size={30} />
              <span>
                <strong>Cartão de Crédito</strong>
                <small>Débito ou Crédito</small>
              </span>
            </button>
            <button
              type="button"
              role="radio"
              aria-checked={method === 'pix'}
              className={`method${method === 'pix' ? ' is-selected' : ''}`}
              onClick={() => setMethod('pix')}
            >
              <Icon name="mobile_2" size={30} />
              <span>
                <strong>PIX</strong>
                <small>Aprovação Instantânea</small>
              </span>
            </button>
          </div>

          <div className="pay-card__body" key={method}>
            {method === 'card' ? (
              <CardForm appointment={appt} onProcessing={setProcessing} onResult={onResult} />
            ) : (
              <PixPanel appointment={appt} onProcessing={setProcessing} onResult={onResult} />
            )}
          </div>
        </section>

        <OrderSummary appointment={appt}>
          <Link to={`/consultas/${appt.id}`} className="text-link order-summary__link">
            Pagar depois (fica como “pagamento pendente”)
          </Link>
        </OrderSummary>
      </div>

      <Modal open={processing} onClose={() => {}} dismissible={false} labelledBy="processing-title">
        <div className="processing" role="status" aria-live="assertive">
          <span className="processing__ring">
            <span className="spinner spinner--lg" />
          </span>
          <p id="processing-title" className="processing__title">
            {method === 'pix' ? 'Verificando pagamento PIX…' : 'Processando pagamento…'}
          </p>
          <p className="muted">Não feche esta página.</p>
          <span className="processing__bar" />
        </div>
      </Modal>
    </div>
  );
}
