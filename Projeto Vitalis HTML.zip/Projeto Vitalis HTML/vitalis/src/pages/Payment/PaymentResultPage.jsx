import { Navigate, useNavigate, useParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { DemoBadge, EmptyState, Spinner } from '../../components/ui/Feedback';
import { useAuth } from '../../context/AuthContext';
import { getAppointment } from '../../services/appointmentService';
import { useAsync, useDocumentTitle } from '../../hooks';
import { downloadCalendarEvent, downloadReceipt } from '../../utils/download';
import { formatCurrency, formatDateBR, formatDateLong, toISODate } from '../../utils/format';
import './payment.css';

function methodLabel(p) {
  if (!p) return '—';
  return p.method === 'pix' ? 'PIX' : `${p.brand} •••• ${p.last4}`;
}

export default function PaymentResultPage({ result }) {
  const approved = result === 'aprovado';
  useDocumentTitle(approved ? 'Pagamento aprovado' : 'Pagamento recusado');
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { data: appt, loading, error } = useAsync(() => getAppointment(user.id, id), [id]);

  if (loading) return <Spinner />;
  if (error) {
    return (
      <div className="container page">
        <EmptyState
          icon="receipt_long"
          title="Pagamento não encontrado"
          actions={
            <Button variant="primary" to="/consultas">
              Minhas consultas
            </Button>
          }
        />
      </div>
    );
  }

  const isPaid = appt.status === 'agendada' || appt.status === 'concluida';
  // Mantém a URL coerente com o estado real do agendamento
  if (approved && !isPaid) return <Navigate to={`/pagamento/${id}`} replace />;
  if (!approved && isPaid) return <Navigate to={`/pagamento/${id}/aprovado`} replace />;

  const lastAttempt = appt.attempts.at(-1);

  if (approved) {
    const payment = appt.payment;
    return (
      <div className="container page result-page">
        <section className="result-card" aria-labelledby="result-title">
          <div className="result-icon result-icon--success" aria-hidden="true">
            <svg viewBox="0 0 52 52" width="64" height="64">
              <circle className="result-icon__circle" cx="26" cy="26" r="23" fill="none" />
              <path className="result-icon__check" fill="none" d="M15 27l7 7 15-15" />
            </svg>
          </div>
          <h1 id="result-title" className="result-card__title">
            Pagamento aprovado!
          </h1>
          <p className="result-card__text">Sua consulta foi confirmada com sucesso.</p>
          <DemoBadge>Demonstração — nenhuma cobrança real foi feita</DemoBadge>

          <dl className="result-info">
            <div>
              <dt>Valor pago</dt>
              <dd>{formatCurrency(payment?.amount ?? appt.total)}</dd>
            </div>
            <div>
              <dt>Data</dt>
              <dd>{payment?.paidAt ? formatDateBR(toISODate(new Date(payment.paidAt))) : '—'}</dd>
            </div>
            <div>
              <dt>Método</dt>
              <dd>{methodLabel(payment)}</dd>
            </div>
            <div>
              <dt>Protocolo</dt>
              <dd>{appt.protocol}</dd>
            </div>
          </dl>

          <div className="result-appt">
            <Icon name="event_available" size={26} />
            <div>
              <p>
                <strong>{appt.serviceName}</strong> com {appt.professionalName}
              </p>
              <p className="result-appt__when">
                {formatDateLong(appt.date, true)} às {appt.time}
              </p>
            </div>
          </div>

          <div className="result-actions">
            <Button variant="primary" block to={`/consultas/${appt.id}`} icon="description">
              Ver detalhes da consulta
            </Button>
            <div className="result-actions__row">
              <Button variant="soft-green" size="sm" icon="event" iconSize={18} onClick={() => downloadCalendarEvent(appt)}>
                Adicionar à agenda
              </Button>
              <Button variant="soft" size="sm" icon="download" iconSize={18} onClick={() => downloadReceipt(appt, payment)}>
                Comprovante
              </Button>
            </div>
            <Button variant="ghost" onClick={() => navigate('/painel')}>
              VOLTAR
            </Button>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="container page result-page">
      <section className="result-card result-card--error" aria-labelledby="result-title">
        <div className="result-icon result-icon--error" aria-hidden="true">
          <Icon name="cancel" size={56} />
        </div>
        <h1 id="result-title" className="result-card__title">
          Pagamento recusado!
        </h1>
        <p className="result-card__text">Não foi possível processar seu pagamento. Verifique seus dados e tente novamente.</p>
        {lastAttempt?.failureReason && (
          <p className="result-reason">
            <Icon name="info" size={18} /> {lastAttempt.failureReason}
          </p>
        )}
        <p className="muted result-card__small">Seu horário continua reservado como “pagamento pendente”.</p>

        <div className="result-actions">
          <Button
            variant="primary"
            block
            size="lg"
            icon="refresh"
            onClick={() => navigate(`/pagamento/${id}`, { replace: true, state: { method: lastAttempt?.method } })}
          >
            Tentar Novamente
          </Button>
          <Button
            variant="outline"
            block
            onClick={() =>
              navigate(`/pagamento/${id}`, { replace: true, state: { method: lastAttempt?.method === 'pix' ? 'card' : 'pix' } })
            }
          >
            {lastAttempt?.method === 'pix' ? 'Pagar com cartão' : 'Pagar com PIX'}
          </Button>
          <div className="result-actions__row">
            <Button variant="ghost" size="sm" to={`/consultas/${appt.id}`}>
              Ver agendamento
            </Button>
            <Button variant="ghost" size="sm" to="/ajuda?secao=contato">
              Falar com suporte
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
