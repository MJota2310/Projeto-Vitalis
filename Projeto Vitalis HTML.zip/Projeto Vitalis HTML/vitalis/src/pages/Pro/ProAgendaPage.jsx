import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState } from '../../components/ui/Feedback';
import { Checkbox } from '../../components/ui/Field';
import { PanelHeader } from '../../components/panel/PanelLayout';
import { useAsync, useDocumentTitle, useMediaQuery } from '../../hooks';
import { getAgenda, listAgenda } from '../../services/professionalService';
import { PRO_APPT_STATUS, toMinutes } from '../../services/proModel';
import { ApptRow, ProAppointmentModal } from './ProComponents';
import {
  MONTHS,
  WEEKDAYS_LONG,
  WEEKDAYS_SHORT,
  addDays,
  formatDateBR,
  formatDateLong,
  formatTimeRange,
  normalize,
  parseISODate,
  startOfWeek,
  toISODate,
} from '../../utils/format';

const VIEWS = [
  { id: 'dia', label: 'Dia', icon: 'view_day' },
  { id: 'semana', label: 'Semana', icon: 'view_week' },
  { id: 'mes', label: 'Mês', icon: 'calendar_view_month' },
  { id: 'lista', label: 'Lista', icon: 'view_agenda' },
];
const PERIODS = [
  { id: 'hoje', label: 'Hoje' },
  { id: 'proximos', label: 'Próximos' },
  { id: 'anteriores', label: 'Anteriores' },
];
const LEGEND = ['agendada', 'pendente_pagamento', 'concluida', 'cancelada', 'indisponivel'];
const PX = 1.1; // pixels por minuto na linha do tempo

function rangeFor(view, anchor) {
  if (view === 'dia') return [anchor, anchor];
  if (view === 'semana') {
    const s = startOfWeek(anchor);
    return [s, addDays(s, 6)];
  }
  const first = new Date(anchor.getFullYear(), anchor.getMonth(), 1);
  const gridStart = startOfWeek(first);
  const last = new Date(anchor.getFullYear(), anchor.getMonth() + 1, 0);
  const gridEnd = addDays(startOfWeek(last), 6);
  return [gridStart, gridEnd];
}

function shift(view, anchor, dir) {
  if (view === 'dia') return addDays(anchor, dir);
  if (view === 'semana') return addDays(anchor, dir * 7);
  return new Date(anchor.getFullYear(), anchor.getMonth() + dir, 1);
}

function titleFor(view, anchor) {
  if (view === 'dia') return formatDateLong(toISODate(anchor), true);
  if (view === 'semana') {
    const s = startOfWeek(anchor);
    const e = addDays(s, 6);
    return `${s.getDate()} ${s.getMonth() !== e.getMonth() ? `de ${MONTHS[s.getMonth()]} ` : ''}a ${e.getDate()} de ${MONTHS[e.getMonth()]} de ${e.getFullYear()}`;
  }
  return `${MONTHS[anchor.getMonth()]} de ${anchor.getFullYear()}`;
}

/** Faixa de horas exibida (expediente + consultas fora dele, se houver). */
function timeBounds(days, appts) {
  let start = 24 * 60;
  let end = 0;
  days.forEach((d) => {
    if (d.hours) {
      start = Math.min(start, toMinutes(d.hours.start));
      end = Math.max(end, toMinutes(d.hours.end));
    }
  });
  appts.forEach((a) => {
    start = Math.min(start, toMinutes(a.time));
    end = Math.max(end, toMinutes(a.time) + (a.duration || 60));
  });
  if (start >= end) return [8 * 60, 18 * 60];
  return [Math.floor(start / 60) * 60, Math.ceil(end / 60) * 60];
}

function DayColumn({ day, appts, bounds, onOpen, showCanceled, compact }) {
  const [b0, b1] = bounds;
  const fullBlock = day.exceptions.find((e) => e.type === 'bloqueio' && e.allDay);
  const list = appts.filter((a) => showCanceled || a.status !== 'cancelada');
  const pos = (start, dur) => ({ top: (start - b0) * PX, height: Math.max(dur * PX - 3, 22) });
  return (
    <div className={`tl-col${day.hours ? '' : ' is-off'}${day.date === toISODate(new Date()) ? ' is-today' : ''}`}>
      {!day.hours && !list.length && (
        <div className="tl-off" style={{ height: (b1 - b0) * PX }}>
          <span>{fullBlock ? fullBlock.reason || 'Bloqueado' : 'Sem atendimento'}</span>
        </div>
      )}
      {day.hours?.breakStart && day.hours?.breakEnd && (
        <div
          className="tl-break"
          style={pos(toMinutes(day.hours.breakStart), toMinutes(day.hours.breakEnd) - toMinutes(day.hours.breakStart))}
        >
          <Icon name="coffee" size={14} /> Intervalo
        </div>
      )}
      {day.exceptions
        .filter((e) => e.type === 'bloqueio' && !e.allDay)
        .map((e) => (
          <div
            key={e.id}
            className="tl-block"
            style={pos(toMinutes(e.start), toMinutes(e.end) - toMinutes(e.start))}
            title={e.reason}
          >
            <Icon name="block" size={14} /> {compact ? '' : e.reason || 'Indisponível'}
          </div>
        ))}
      {list.map((a) => {
        const s = toMinutes(a.time);
        return (
          <button
            key={a.id}
            type="button"
            className={`tl-appt tl-appt--${a.status}${a.attendance === 'faltou' ? ' is-noshow' : ''}${(a.duration || 60) <= 30 ? ' is-short' : ''}`}
            style={pos(s, a.duration || 60)}
            onClick={() => onOpen(a)}
            aria-label={`${formatTimeRange(a.time, a.duration)}, ${a.client.name}, ${a.offeringName || a.serviceName}, ${PRO_APPT_STATUS[a.status]?.label}`}
          >
            <strong>{a.time}</strong>
            <span className="tl-appt__name">{a.client.name}</span>
            {!compact && <span className="tl-appt__svc">{a.offeringName || a.serviceName}</span>}
          </button>
        );
      })}
    </div>
  );
}

function Timeline({ days, appts, onOpen, showCanceled, mobile }) {
  const bounds = timeBounds(days, appts);
  const hours = [];
  for (let m = bounds[0]; m <= bounds[1]; m += 60) hours.push(m);
  const nowMin = new Date().getHours() * 60 + new Date().getMinutes();
  const todayIdx = days.findIndex((d) => d.date === toISODate(new Date()));
  return (
    <div className={`timeline-grid${days.length > 1 ? ' is-week' : ''}`} style={{ '--cols': days.length }}>
      {days.length > 1 && (
        <div className="tl-head">
          <span />
          {days.map((d) => {
            const date = parseISODate(d.date);
            return (
              <span key={d.date} className={d.date === toISODate(new Date()) ? 'is-today' : ''}>
                <small>{WEEKDAYS_SHORT[date.getDay()]}</small>
                <strong>{date.getDate()}</strong>
              </span>
            );
          })}
        </div>
      )}
      <div className="tl-body" style={{ height: (bounds[1] - bounds[0]) * PX }}>
        <div className="tl-hours" aria-hidden="true">
          {hours.map((m) => (
            <span key={m} style={{ top: (m - bounds[0]) * PX }}>
              {String(m / 60).padStart(2, '0')}:00
            </span>
          ))}
        </div>
        <div className="tl-lines" aria-hidden="true">
          {hours.map((m) => (
            <span key={m} style={{ top: (m - bounds[0]) * PX }} />
          ))}
        </div>
        {todayIdx >= 0 && nowMin > bounds[0] && nowMin < bounds[1] && (
          <span
            className="tl-now"
            style={{ top: (nowMin - bounds[0]) * PX, '--col': todayIdx, '--cols': days.length }}
            aria-hidden="true"
          />
        )}
        <div className="tl-cols">
          {days.map((d) => (
            <DayColumn
              key={d.date}
              day={d}
              appts={appts.filter((a) => a.date === d.date)}
              bounds={bounds}
              onOpen={onOpen}
              showCanceled={showCanceled}
              compact={days.length > 1 || mobile}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

function MonthGrid({ anchor, days, appts, onPick }) {
  const month = anchor.getMonth();
  const today = toISODate(new Date());
  return (
    <div className="month-grid" role="grid" aria-label={`Agenda de ${MONTHS[month]}`}>
      {[1, 2, 3, 4, 5, 6, 0].map((w) => (
        <span key={w} className="month-grid__dow" role="columnheader">
          {WEEKDAYS_SHORT[w]}
        </span>
      ))}
      {days.map((d) => {
        const date = parseISODate(d.date);
        const list = appts.filter((a) => a.date === d.date && a.status !== 'cancelada');
        const blocked = d.exceptions.some((e) => e.type === 'bloqueio');
        return (
          <button
            key={d.date}
            type="button"
            role="gridcell"
            className={`month-cell${date.getMonth() !== month ? ' is-out' : ''}${d.date === today ? ' is-today' : ''}${d.hours ? '' : ' is-off'}`}
            onClick={() => onPick(d.date)}
            aria-label={`${formatDateLong(d.date)}: ${list.length} atendimento(s)${blocked ? ', com bloqueio' : ''}${d.hours ? '' : ', sem atendimento'}`}
          >
            <span className="month-cell__day">{date.getDate()}</span>
            {blocked && <Icon name="block" size={14} className="month-cell__block" />}
            {list.length > 0 && (
              <>
                <span className="month-cell__count">{list.length}</span>
                <ul className="month-cell__items" aria-hidden="true">
                  {list.slice(0, 3).map((a) => (
                    <li key={a.id} className={`dot dot--${a.status}`}>
                      {a.time} {a.client.name.split(' ')[0]}
                    </li>
                  ))}
                  {list.length > 3 && <li className="more">+{list.length - 3}</li>}
                </ul>
              </>
            )}
          </button>
        );
      })}
    </div>
  );
}

function ListView({ params, setParam, onOpen, version }) {
  const period = PERIODS.some((p) => p.id === params.get('periodo')) ? params.get('periodo') : 'proximos';
  const status = params.get('status') || '';
  const [query, setQuery] = useState('');
  const { data, loading, error, reload } = useAsync(() => listAgenda({ period, status }), [period, status, version]);
  const filtered = useMemo(() => {
    const q = normalize(query.trim());
    return (data || []).filter((a) => !q || normalize(`${a.client.name} ${a.offeringName} ${a.protocol}`).includes(q));
  }, [data, query]);
  const groups = useMemo(() => {
    const map = new Map();
    filtered.forEach((a) => {
      if (!map.has(a.date)) map.set(a.date, []);
      map.get(a.date).push(a);
    });
    return [...map.entries()];
  }, [filtered]);

  return (
    <div>
      <div className="toolbar">
        <div className="tabs" role="tablist" aria-label="Período">
          {PERIODS.map((p) => (
            <button
              key={p.id}
              type="button"
              role="tab"
              className="tab"
              aria-selected={period === p.id}
              onClick={() => setParam({ periodo: p.id })}
            >
              {p.label}
            </button>
          ))}
        </div>
        <div className="field field--icon toolbar__search">
          <label htmlFor="agenda-q" className="sr-only">
            Buscar por cliente, serviço ou protocolo
          </label>
          <div className="field__control">
            <Icon name="search" size={20} className="field__icon" />
            <input
              id="agenda-q"
              className="input"
              type="search"
              placeholder="Buscar cliente, serviço ou protocolo"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
        </div>
        <label className="sr-only" htmlFor="agenda-status">
          Situação
        </label>
        <select id="agenda-status" className="select" value={status} onChange={(e) => setParam({ status: e.target.value })}>
          <option value="">Todas as situações</option>
          {['agendada', 'pendente_pagamento', 'concluida', 'cancelada'].map((s) => (
            <option key={s} value={s}>
              {PRO_APPT_STATUS[s].label}
            </option>
          ))}
        </select>
      </div>
      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : loading ? (
        <div className="stack">
          {[0, 1, 2].map((i) => (
            <span key={i} className="skeleton" style={{ height: 64 }} />
          ))}
        </div>
      ) : groups.length === 0 ? (
        <EmptyState
          icon={period === 'hoje' ? 'beach_access' : 'event_note'}
          title="Nenhum agendamento encontrado"
          text={
            query || status
              ? 'Ajuste a busca ou o filtro de situação.'
              : period === 'hoje'
                ? 'Você não tem atendimentos hoje.'
                : 'Os agendamentos aparecerão aqui.'
          }
        />
      ) : (
        <div className="agenda-groups">
          {groups.map(([date, list]) => (
            <section key={date} className="agenda-group">
              <h3 className="agenda-group__title">
                {formatDateLong(date)} <span className="muted">· {formatDateBR(date)}</span>
              </h3>
              <ul className="appt-rows">
                {list.map((a) => (
                  <li key={a.id}>
                    <ApptRow appt={a} onOpen={onOpen} />
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}

export default function ProAgendaPage() {
  useDocumentTitle('Agenda');
  const [params, setParams] = useSearchParams();
  const mobile = useMediaQuery('(max-width: 760px)');
  const view = VIEWS.some((v) => v.id === params.get('visao')) ? params.get('visao') : 'semana';
  const anchor = parseISODate(params.get('data') || toISODate(new Date()));
  const anchorIso = toISODate(anchor);
  const [openId, setOpenId] = useState(null);
  const [showCanceled, setShowCanceled] = useState(false);
  const [version, setVersion] = useState(0);
  const [mobileDay, setMobileDay] = useState(anchorIso);

  const setParam = (patch) => {
    const next = new URLSearchParams(params);
    Object.entries(patch).forEach(([k, v]) => (v ? next.set(k, v) : next.delete(k)));
    setParams(next, { replace: true });
  };

  const [from, to] = rangeFor(view, anchor);
  const { data, loading, error, reload } = useAsync(
    () => (view === 'lista' ? Promise.resolve(null) : getAgenda({ from: toISODate(from), to: toISODate(to) })),
    [view, toISODate(from), toISODate(to), version],
  );

  useEffect(() => {
    setMobileDay(anchorIso);
  }, [anchorIso, view]);

  const go = (dir) => setParam({ data: toISODate(shift(view, anchor, dir)) });
  const goToday = () => setParam({ data: '' });
  const changed = () => {
    setVersion((v) => v + 1);
    reload();
  };

  const weekMobile = view === 'semana' && mobile;
  let timelineDays = data?.days || [];
  if (weekMobile) timelineDays = timelineDays.filter((d) => d.date === mobileDay);

  return (
    <div className="pro-agenda">
      <PanelHeader
        eyebrow="Agenda"
        title="Seus atendimentos"
        subtitle="Acompanhe o dia, a semana e o mês. Toque em um horário para ver detalhes e ações."
        actions={
          <Button variant="soft-green" size="sm" to="/profissional/horarios?novo=bloqueio" icon="event_busy" iconSize={18}>
            Bloquear horário
          </Button>
        }
      />

      <div className="agenda-bar">
        <div className="tabs agenda-views" role="tablist" aria-label="Visualização da agenda">
          {VIEWS.map((v) => (
            <button
              key={v.id}
              type="button"
              role="tab"
              className="tab"
              aria-selected={view === v.id}
              onClick={() => setParam({ visao: v.id })}
            >
              <Icon name={v.icon} size={18} /> {v.label}
            </button>
          ))}
        </div>
        {view !== 'lista' && (
          <div className="agenda-nav">
            <button type="button" className="icon-btn" onClick={() => go(-1)} aria-label="Período anterior">
              <Icon name="chevron_left" />
            </button>
            <p className="agenda-nav__title" aria-live="polite">
              {titleFor(view, anchor)}
            </p>
            <button type="button" className="icon-btn" onClick={() => go(1)} aria-label="Próximo período">
              <Icon name="chevron_right" />
            </button>
            <Button variant="ghost" size="sm" onClick={goToday}>
              Hoje
            </Button>
          </div>
        )}
      </div>

      <ul className="agenda-legend" aria-label="Legenda">
        {LEGEND.map((s) => (
          <li key={s}>
            <span className={`legend-sw legend-sw--${s}`} aria-hidden="true" /> {PRO_APPT_STATUS[s].label}
          </li>
        ))}
        {view !== 'lista' && view !== 'mes' && (
          <li className="agenda-legend__toggle">
            <Checkbox label="Mostrar cancelados" checked={showCanceled} onChange={(e) => setShowCanceled(e.target.checked)} />
          </li>
        )}
      </ul>

      <section className="panel-card agenda-card" aria-label="Agenda">
        {view === 'lista' ? (
          <ListView params={params} setParam={setParam} onOpen={(a) => setOpenId(a.id)} version={version} />
        ) : error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : !data ? (
          <span className="skeleton" style={{ height: 420, display: 'block' }} />
        ) : (
          <div className={loading ? 'is-refreshing' : ''}>
            {weekMobile && (
              <div className="week-strip" role="tablist" aria-label="Dia da semana">
                {data.days.map((d) => {
                  const date = parseISODate(d.date);
                  const n = data.appointments.filter((a) => a.date === d.date && a.status !== 'cancelada').length;
                  return (
                    <button
                      key={d.date}
                      type="button"
                      role="tab"
                      aria-selected={mobileDay === d.date}
                      className={`week-strip__day${d.date === toISODate(new Date()) ? ' is-today' : ''}`}
                      onClick={() => setMobileDay(d.date)}
                    >
                      <small>{WEEKDAYS_SHORT[date.getDay()]}</small>
                      <strong>{date.getDate()}</strong>
                      <span className={n ? 'has-items' : ''}>{n || '·'}</span>
                    </button>
                  );
                })}
              </div>
            )}
            {view === 'mes' ? (
              <MonthGrid
                anchor={anchor}
                days={data.days}
                appts={data.appointments}
                onPick={(d) => setParam({ visao: 'dia', data: d })}
              />
            ) : (
              <>
                {(view === 'dia' || weekMobile) && timelineDays[0] && (
                  <p className="agenda-day-note">
                    {timelineDays[0].hours
                      ? `Expediente ${timelineDays[0].hours.start}–${timelineDays[0].hours.end}${
                          timelineDays[0].hours.breakStart
                            ? ` · intervalo ${timelineDays[0].hours.breakStart}–${timelineDays[0].hours.breakEnd}`
                            : ''
                        }`
                      : `${WEEKDAYS_LONG[parseISODate(timelineDays[0].date).getDay()]}: sem atendimento configurado.`}{' '}
                    {timelineDays[0].exceptions.map((e) => (
                      <span key={e.id} className="badge badge--gray">
                        <Icon name={e.type === 'bloqueio' ? 'block' : 'event_upcoming'} size={14} /> {e.reason}
                      </span>
                    ))}
                  </p>
                )}
                <div className="timeline-scroll">
                  <Timeline
                    days={timelineDays}
                    appts={data.appointments}
                    onOpen={(a) => setOpenId(a.id)}
                    showCanceled={showCanceled}
                    mobile={mobile}
                  />
                </div>
                {(view === 'dia' || weekMobile) &&
                  !data.appointments.some(
                    (a) => a.date === timelineDays[0]?.date && (showCanceled || a.status !== 'cancelada'),
                  ) && (
                    <p className="agenda-empty-day">
                      <Icon name="event_available" size={20} /> Nenhum atendimento neste dia.{' '}
                      <Link to="/profissional/horarios" className="text-link">
                        Ver horários livres
                      </Link>
                    </p>
                  )}
              </>
            )}
          </div>
        )}
      </section>

      <ProAppointmentModal apptId={openId} onClose={() => setOpenId(null)} onChanged={changed} />
    </div>
  );
}
