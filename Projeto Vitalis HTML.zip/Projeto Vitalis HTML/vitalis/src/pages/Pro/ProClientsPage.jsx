import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import { EmptyState, ErrorState, Notice, Spinner } from '../../components/ui/Feedback';
import { UserAvatar } from '../../components/ui/Avatar';
import { PanelHeader, SearchBox, ToneBadge, useDebounced } from '../../components/panel/PanelLayout';
import { useAsync, useDocumentTitle } from '../../hooks';
import { CLIENT_STATUS, getClient, listMyClients } from '../../services/professionalService';
import { formatDateBR, formatDateLong, pluralize } from '../../utils/format';
import { ApptRow, ProAppointmentModal } from './ProComponents';

const FILTERS = [{ id: '', label: 'Todos' }, ...Object.entries(CLIENT_STATUS).map(([id, s]) => ({ id, label: s.label }))];

function ClientModal({ clientId, onClose, onOpenAppt }) {
  const { data, loading, error, reload } = useAsync(() => (clientId ? getClient(clientId) : Promise.resolve(null)), [clientId]);
  const done = data?.history.filter((a) => a.status === 'concluida').length || 0;
  return (
    <Modal open={!!clientId} onClose={onClose} title="Cliente" width={560}>
      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : loading || !data ? (
        <Spinner label="Carregando cliente…" />
      ) : (
        <div className="client-detail">
          <div className="client-detail__head">
            <UserAvatar user={{ name: data.name }} size={56} />
            <div>
              <p className="client-detail__name">{data.name}</p>
              <p className="muted">
                Cliente desde {formatDateBR(data.since)} · {pluralize(done, 'atendimento concluído', 'atendimentos concluídos')}
              </p>
            </div>
          </div>

          <section aria-labelledby="client-contact">
            <h3 id="client-contact" className="detail-title">
              Contato
            </h3>
            {data.contact ? (
              <p className="client-detail__contact">
                {data.contact.phone && (
                  <a className="text-link" href={`tel:${data.contact.phone.replace(/\D/g, '')}`}>
                    <Icon name="call" size={18} /> {data.contact.phone}
                  </a>
                )}
                {data.contact.email && (
                  <a className="text-link" href={`mailto:${data.contact.email}`}>
                    <Icon name="mail" size={18} /> {data.contact.email}
                  </a>
                )}
                {!data.contact.phone && !data.contact.email && <span className="muted">O cliente não informou contato.</span>}
              </p>
            ) : (
              <p className="muted">
                <Icon name="lock" size={16} /> Disponível somente enquanto houver um agendamento ativo com este cliente.
              </p>
            )}
          </section>

          <section aria-labelledby="client-history">
            <h3 id="client-history" className="detail-title">
              Histórico com você
            </h3>
            <ul className="appt-rows">
              {data.history.map((a) => (
                <li key={a.id}>
                  <ApptRow appt={a} onOpen={(x) => onOpenAppt(x.id)} showDate />
                </li>
              ))}
            </ul>
          </section>

          <p className="pro-appt__privacy">
            <Icon name="shield" size={14} /> O Vitalis não armazena prontuários nem informações clínicas. Registros de saúde devem
            ficar no sistema próprio do seu consultório, conforme as regras do seu conselho profissional.
          </p>
        </div>
      )}
    </Modal>
  );
}

export default function ProClientsPage() {
  useDocumentTitle('Clientes');
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('');
  const [apptId, setApptId] = useState(null);
  const clientId = params.get('cliente');

  const debounced = useDebounced(query);

  const { data, loading, error, reload } = useAsync(() => listMyClients({ query: debounced, status }), [debounced, status]);
  const list = data || [];

  const openClient = (id) => setParams(id ? { cliente: id } : {}, { replace: !id });

  return (
    <div className="pro-clients">
      <PanelHeader
        eyebrow="Relacionamento"
        title="Clientes"
        subtitle="Pessoas que agendaram com você. Mostramos apenas o necessário para o atendimento: nome, histórico de agendamentos e contato enquanto houver horário marcado."
      />

      <div className="toolbar">
        <SearchBox
          id="client-q"
          label="Buscar cliente pelo nome"
          placeholder="Buscar pelo nome"
          value={query}
          onChange={setQuery}
        />
        <div className="chip-row" role="group" aria-label="Filtrar por situação">
          {FILTERS.map((f) => (
            <button
              key={f.id || 'all'}
              type="button"
              className="chip chip--sm"
              aria-pressed={status === f.id}
              onClick={() => setStatus(f.id)}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data ? (
        <div className="client-grid">
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className="skeleton" style={{ height: 150, borderRadius: 16 }} />
          ))}
        </div>
      ) : list.length === 0 ? (
        <div className="panel-card">
          <EmptyState
            icon="group"
            title={debounced || status ? 'Nenhum cliente encontrado' : 'Você ainda não tem clientes'}
            text={debounced || status ? 'Ajuste a busca ou o filtro.' : 'Quando alguém agendar com você, o cliente aparece aqui.'}
            actions={
              (debounced || status) && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setQuery('');
                    setStatus('');
                  }}
                >
                  Limpar filtros
                </Button>
              )
            }
          />
        </div>
      ) : (
        <>
          <p className="offer-summary" aria-live="polite">
            {pluralize(list.length, 'cliente', 'clientes')}
          </p>
          <ul className={`client-grid${loading ? ' is-refreshing' : ''}`}>
            {list.map((c, i) => {
              const st = CLIENT_STATUS[c.status];
              return (
                <li key={c.id} style={{ animationDelay: `${i * 40}ms` }}>
                  <button type="button" className="client-card" onClick={() => openClient(c.id)} aria-label={`Abrir ${c.name}`}>
                    <span className="client-card__top">
                      <UserAvatar user={{ name: c.name }} size={44} />
                      <span className="client-card__id">
                        <strong>{c.name}</strong>
                        <ToneBadge tone={st.tone}>{st.label}</ToneBadge>
                      </span>
                    </span>
                    <span className="client-card__facts">
                      <span>
                        <Icon name="event_available" size={16} /> {pluralize(c.completed, 'concluído', 'concluídos')}
                        {c.canceled > 0 && ` · ${c.canceled} cancelado(s)`}
                      </span>
                      <span>
                        <Icon name="medical_services" size={16} /> {c.services.slice(0, 2).join(', ')}
                        {c.services.length > 2 && ` +${c.services.length - 2}`}
                      </span>
                      <span>
                        <Icon name="schedule" size={16} />{' '}
                        {c.next
                          ? `Próximo: ${formatDateLong(c.next.date)} às ${c.next.time}`
                          : c.last
                            ? `Último: ${formatDateBR(c.last.date)}`
                            : 'Sem atendimentos concluídos'}
                      </span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        </>
      )}

      <Notice tone="info" className="section-gap">
        Os clientes de demonstração são fictícios (domínio @exemplo.com). Nenhuma informação clínica é registrada no Vitalis.
      </Notice>

      <ClientModal clientId={apptId ? null : clientId} onClose={() => openClient(null)} onOpenAppt={setApptId} />
      <ProAppointmentModal
        apptId={apptId}
        onClose={() => setApptId(null)}
        onChanged={() => {
          reload();
        }}
      />
    </div>
  );
}
