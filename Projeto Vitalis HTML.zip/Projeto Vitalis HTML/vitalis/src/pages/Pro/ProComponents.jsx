import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Modal from '../../components/ui/Modal';
import Button from '../../components/ui/Button';
import Icon from '../../components/ui/Icon';
import { Notice, Spinner } from '../../components/ui/Feedback';
import { TextField } from '../../components/ui/Field';
import { UserAvatar } from '../../components/ui/Avatar';
import { useToast } from '../../context/ToastContext';
import { getProAppointment, markAttendance, proCancelAppointment } from '../../services/professionalService';
import { PRO_APPT_STATUS, hasStarted } from '../../services/proModel';
import { downloadCalendarEvent } from '../../utils/download';
import { formatCurrency, formatDateLong, formatDateTimeBR, formatTimeRange, relativeDay } from '../../utils/format';

/** Situação de um agendamento na visão do profissional. */
export function ProStatusBadge({ appt, short }) {
  if (appt.attendance === 'faltou') {
    return (
      <span className="badge badge--gray">
        <Icon name="person_off" size={15} /> {short ? 'Faltou' : 'Não compareceu'}
      </span>
    );
  }
  const s = PRO_APPT_STATUS[appt.status] || PRO_APPT_STATUS.indisponivel;
  return (
    <span className={`badge badge--${s.tone}`}>
      <Icon name={s.icon} size={15} /> {short && appt.status === 'pendente_pagamento' ? 'Aguardando' : s.label}
    </span>
  );
}

/** Linha compacta de agendamento (listas da visão geral e da agenda). */
export function ApptRow({ appt, onOpen, showDate }) {
  return (
    <button type="button" className={`appt-row appt-row--${appt.status}`} onClick={() => onOpen(appt)}>
      <span className="appt-row__time">
        <strong>{appt.time}</strong>
        <small>{appt.duration || 60} min</small>
      </span>
      <span className="appt-row__body">
        <strong>{appt.client?.name || appt.clientName}</strong>
        <small>
          {appt.offeringName || appt.serviceName}
          {showDate && ` · ${formatDateLong(appt.date)}`}
        </small>
      </span>
      <ProStatusBadge appt={appt} short />
    </button>
  );
}

/** Detalhes de um agendamento com as ações do profissional. */
export function ProAppointmentModal({ apptId, onClose, onChanged }) {
  const toast = useToast();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [mode, setMode] = useState('view');
  const [reason, setReason] = useState('');
  const [reasonError, setReasonError] = useState('');
  const [busy, setBusy] = useState('');

  useEffect(() => {
    if (!apptId) return undefined;
    let alive = true;
    setData(null);
    setError(null);
    setMode('view');
    setReason('');
    setReasonError('');
    getProAppointment(apptId)
      .then((a) => alive && setData(a))
      .catch((e) => alive && setError(e));
    return () => {
      alive = false;
    };
  }, [apptId]);

  if (!apptId) return null;
  const a = data;
  const active = a && (a.status === 'agendada' || a.status === 'pendente_pagamento');
  const canCancel = active && !hasStarted(a);
  const canAttend = a && hasStarted(a) && (a.status === 'agendada' || a.status === 'concluida');

  const cancel = async () => {
    setReasonError('');
    if (reason.trim().length < 5) {
      setReasonError('Informe o motivo para o cliente (mínimo de 5 caracteres).');
      return;
    }
    setBusy('cancel');
    try {
      const updated = await proCancelAppointment(a.id, reason);
      toast.success('Agendamento cancelado', 'O cliente foi avisado por notificação.');
      onChanged?.(updated);
      onClose();
    } catch (err) {
      if (err.field === 'reason') setReasonError(err.message);
      else toast.error('Não foi possível cancelar', err.message);
    } finally {
      setBusy('');
    }
  };

  const attend = async (value) => {
    setBusy(value);
    try {
      const updated = await markAttendance(a.id, value);
      setData((d) => ({ ...d, ...updated }));
      toast.success(value === 'faltou' ? 'Ausência registrada' : 'Presença registrada');
      onChanged?.(updated);
    } catch (err) {
      toast.error('Não foi possível registrar', err.message);
    } finally {
      setBusy('');
    }
  };

  const footer = !a ? null : mode === 'cancel' ? (
    <>
      <Button variant="ghost" onClick={() => setMode('view')} disabled={busy === 'cancel'}>
        Voltar
      </Button>
      <Button variant="danger-solid" onClick={cancel} loading={busy === 'cancel'} loadingText="Cancelando…">
        Confirmar cancelamento
      </Button>
    </>
  ) : (
    <>
      <Button variant="ghost" onClick={onClose}>
        Fechar
      </Button>
      {canCancel && (
        <Button variant="danger" icon="event_busy" onClick={() => setMode('cancel')}>
          Cancelar agendamento
        </Button>
      )}
    </>
  );

  return (
    <Modal
      open={!!apptId}
      onClose={busy ? () => {} : onClose}
      title={mode === 'cancel' ? 'Cancelar agendamento?' : 'Detalhes do agendamento'}
      width={560}
      footer={footer}
    >
      {error ? (
        <Notice tone="error">{error.message}</Notice>
      ) : !a ? (
        <Spinner size="md" label="Carregando agendamento…" />
      ) : mode === 'cancel' ? (
        <div className="stack">
          <p>
            <strong>{a.client.name}</strong> · {a.offeringName || a.serviceName}
            <br />
            {formatDateLong(a.date, true)}, {formatTimeRange(a.time, a.duration)}
          </p>
          <Notice tone="warning">
            {a.status === 'agendada'
              ? 'Como o cancelamento parte de você, o cliente recebe reembolso integral (demonstração) e é avisado por notificação.'
              : 'O agendamento ainda não foi pago. O horário será liberado e o cliente avisado.'}
          </Notice>
          <TextField
            as="textarea"
            rows={3}
            label="Motivo (enviado ao cliente)"
            name="pro-cancel-reason"
            maxLength={280}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            error={reasonError}
            hint={`${reason.length}/280`}
            data-autofocus
            required
          />
        </div>
      ) : (
        <div className="pro-appt">
          <div className="pro-appt__head">
            <UserAvatar user={{ name: a.client.name }} size={52} />
            <div>
              <p className="pro-appt__client">{a.client.name}</p>
              <p className="muted">
                {a.previous > 0 ? `${a.previous} outro(s) agendamento(s) com você` : 'Primeiro agendamento com você'}
              </p>
            </div>
            <ProStatusBadge appt={a} />
          </div>
          <ul className="detail-facts pro-appt__facts">
            <li>
              <Icon name="calendar_today" size={20} />
              <span>
                <small>Data</small>
                {formatDateLong(a.date, true)} <em className="muted">({relativeDay(a.date)})</em>
              </span>
            </li>
            <li>
              <Icon name="schedule" size={20} />
              <span>
                <small>Horário</small>
                {formatTimeRange(a.time, a.duration)}
              </span>
            </li>
            <li>
              <Icon name="medical_services" size={20} />
              <span>
                <small>Serviço</small>
                {a.offeringName || a.serviceName}
              </span>
            </li>
            <li>
              <Icon name="payments" size={20} />
              <span>
                <small>Valor da consulta</small>
                {formatCurrency(a.price)}{' '}
                <em className="muted">
                  {a.payment?.status === 'aprovado'
                    ? `· pago via ${a.payment.method === 'pix' ? 'PIX' : 'cartão'}`
                    : a.payment?.status === 'reembolsado'
                      ? '· reembolsado'
                      : a.status === 'pendente_pagamento'
                        ? '· aguardando pagamento'
                        : ''}
                </em>
              </span>
            </li>
          </ul>
          {a.contact && (
            <div className="pro-appt__contact">
              <p className="detail-title">Contato do cliente</p>
              <p>
                {a.contact.phone && (
                  <a href={`tel:${a.contact.phone.replace(/\D/g, '')}`} className="text-link">
                    <Icon name="call" size={16} /> {a.contact.phone}
                  </a>
                )}
                {a.contact.email && (
                  <a href={`mailto:${a.contact.email}`} className="text-link">
                    <Icon name="mail" size={16} /> {a.contact.email}
                  </a>
                )}
              </p>
              <p className="pro-appt__privacy">
                <Icon name="lock" size={14} /> Visível apenas enquanto houver atendimento marcado.
              </p>
            </div>
          )}
          {a.cancelReason && a.status === 'cancelada' && (
            <Notice tone="info">
              Cancelado{' '}
              {a.canceledBy === 'profissional' ? 'por você' : a.canceledBy === 'sistema' ? 'automaticamente' : 'pelo cliente'}
              {a.canceledAt ? ` em ${formatDateTimeBR(a.canceledAt)}` : ''}. Motivo: {a.cancelReason}
            </Notice>
          )}
          {canAttend && (
            <div className="pro-appt__attend">
              <p className="detail-title">Presença</p>
              <div className="pro-appt__attend-btns" role="group" aria-label="Registrar presença">
                <Button
                  variant={a.attendance === 'compareceu' ? 'primary' : 'soft-green'}
                  size="sm"
                  icon="how_to_reg"
                  loading={busy === 'compareceu'}
                  onClick={() => attend('compareceu')}
                  aria-pressed={a.attendance === 'compareceu'}
                >
                  Compareceu
                </Button>
                <Button
                  variant={a.attendance === 'faltou' ? 'danger-solid' : 'danger'}
                  size="sm"
                  icon="person_off"
                  loading={busy === 'faltou'}
                  onClick={() => attend('faltou')}
                  aria-pressed={a.attendance === 'faltou'}
                >
                  Não compareceu
                </Button>
              </div>
            </div>
          )}
          <div className="pro-appt__links">
            <Link to={`/profissional/clientes?cliente=${a.client.id}`} className="text-link" onClick={onClose}>
              <Icon name="person_search" size={18} /> Histórico do cliente
            </Link>
            {active && (
              <button
                type="button"
                className="text-link"
                onClick={() =>
                  downloadCalendarEvent({ ...a, serviceName: a.offeringName || a.serviceName, professionalName: a.client.name })
                }
              >
                <Icon name="event" size={18} /> Adicionar ao calendário
              </button>
            )}
          </div>
          <p className="pro-appt__protocol">
            Protocolo {a.protocol} · {a.payment?.demo !== false ? 'pagamento em modo demonstração' : ''}
          </p>
          <p className="pro-appt__note">
            <Icon name="policy" size={15} /> O Vitalis não armazena prontuários nem informações clínicas.
          </p>
        </div>
      )}
    </Modal>
  );
}
