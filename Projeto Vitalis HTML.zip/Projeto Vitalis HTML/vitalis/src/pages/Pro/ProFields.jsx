import { useRef, useState } from 'react';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { TextField, Toggle } from '../../components/ui/Field';
import { ProAvatar } from '../../components/ui/Avatar';
import { COUNCILS, MODALITIES, UFS, CATALOG_OPTIONS } from '../../services/proModel';
import { resizeImage } from '../../utils/avatar';

export const PREFIX_OPTIONS = [
  { value: '', label: 'Sem tratamento' },
  { value: 'Dr.', label: 'Dr.' },
  { value: 'Dra.', label: 'Dra.' },
  { value: 'Prof.', label: 'Prof.' },
  { value: 'Profª.', label: 'Profª.' },
];

/** Estado inicial do formulário a partir do perfil. */
export function profileValues(pro) {
  return {
    namePrefix: pro.namePrefix || '',
    displayName: pro.displayName || pro.name || '',
    title: pro.title || '',
    specialty: pro.specialty || '',
    service: pro.service || '',
    registry: { council: pro.registry?.council || '', number: pro.registry?.number || '', uf: pro.registry?.uf || 'SP' },
    city: pro.city || '',
    address: pro.address || '',
    modality: pro.modality || 'presencial',
    bio: pro.bio || '',
    education: pro.education?.length ? [...pro.education] : [],
    experienceYears: pro.experienceYears ?? '',
    experience: pro.experience || '',
    publicContact: { showPhone: !!pro.publicContact?.showPhone, showEmail: !!pro.publicContact?.showEmail },
    photo: pro.photo || null,
  };
}

/** Foto do perfil (redimensionada no navegador antes de salvar). */
export function PhotoField({ value, name, gender, onChange }) {
  const input = useRef(null);
  const [error, setError] = useState('');
  const pick = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    setError('');
    try {
      onChange(await resizeImage(file, 256));
    } catch (err) {
      setError(err.message);
    }
  };
  return (
    <div className="photo-field">
      <ProAvatar pro={{ photo: value, name, gender }} size={88} />
      <div>
        <p className="field__label">Foto do perfil</p>
        <p className="field__hint">PNG, JPG ou WEBP de até 5 MB. A imagem é recortada em formato quadrado.</p>
        <div className="photo-field__btns">
          <Button variant="soft-green" size="sm" icon="photo_camera" iconSize={18} onClick={() => input.current?.click()}>
            {value ? 'Trocar foto' : 'Enviar foto'}
          </Button>
          {value && (
            <Button variant="ghost" size="sm" icon="delete" iconSize={18} onClick={() => onChange(null)}>
              Remover
            </Button>
          )}
        </div>
        <input
          ref={input}
          type="file"
          accept="image/png,image/jpeg,image/webp"
          className="sr-only"
          tabIndex={-1}
          aria-hidden="true"
          onChange={pick}
        />
        {error && (
          <p className="field__error" role="alert">
            <Icon name="error" size={16} /> {error}
          </p>
        )}
      </div>
    </div>
  );
}

/** Nome, profissão, registro profissional e cidade. */
export function BasicsFields({ values, errors, set }) {
  return (
    <div className="form-grid">
      <TextField
        as="select"
        label="Tratamento"
        name="namePrefix"
        value={values.namePrefix}
        onChange={(e) => set('namePrefix', e.target.value)}
        error={errors.namePrefix}
      >
        {PREFIX_OPTIONS.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </TextField>
      <TextField
        label="Nome de exibição"
        name="displayName"
        icon="person"
        maxLength={80}
        value={values.displayName}
        onChange={(e) => set('displayName', e.target.value)}
        error={errors.displayName}
        required
      />
      <TextField
        label="Profissão"
        name="title"
        icon="badge"
        placeholder="Ex.: Fisioterapeuta"
        maxLength={60}
        value={values.title}
        onChange={(e) => set('title', e.target.value)}
        error={errors.title}
        required
      />
      <TextField
        label="Cidade de atendimento"
        name="city"
        icon="location_on"
        placeholder="Ex.: Barueri, SP"
        maxLength={60}
        value={values.city}
        onChange={(e) => set('city', e.target.value)}
        error={errors.city}
        required
      />
      <fieldset className="form-grid__full registry">
        <legend className="field__label">
          Registro no conselho profissional
          <span className="req" aria-hidden="true">
            *
          </span>
        </legend>
        <div className="registry__row">
          <TextField
            as="select"
            label="Conselho"
            name="council"
            value={values.registry.council}
            onChange={(e) => set('registry', { ...values.registry, council: e.target.value })}
            error={errors.council}
          >
            <option value="">Escolha…</option>
            {COUNCILS.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </TextField>
          <TextField
            label="Número"
            name="registryNumber"
            maxLength={20}
            placeholder="000000"
            value={values.registry.number}
            onChange={(e) => set('registry', { ...values.registry, number: e.target.value })}
            error={errors.registryNumber}
          />
          <TextField
            as="select"
            label="UF"
            name="uf"
            value={values.registry.uf}
            onChange={(e) => set('registry', { ...values.registry, uf: e.target.value })}
            error={errors.uf}
          >
            {UFS.map((u) => (
              <option key={u} value={u}>
                {u}
              </option>
            ))}
          </TextField>
        </div>
        <p className="field__hint">
          Usado pela equipe Vitalis na verificação do perfil. Nenhum documento é consultado automaticamente nesta versão.
        </p>
      </fieldset>
    </div>
  );
}

/** Área do catálogo, especialidade e modalidade. */
export function SpecialtyFields({ values, errors, set }) {
  return (
    <div className="stack">
      <div className="form-grid">
        <TextField
          as="select"
          label="Área principal no catálogo"
          name="service"
          value={values.service}
          onChange={(e) => set('service', e.target.value)}
          error={errors.service}
          required
        >
          <option value="">Escolha…</option>
          {CATALOG_OPTIONS.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </TextField>
        <TextField
          label="Especialidade"
          name="specialty"
          placeholder="Ex.: Fisioterapia ortopédica"
          maxLength={60}
          value={values.specialty}
          onChange={(e) => set('specialty', e.target.value)}
          error={errors.specialty}
          required
        />
      </div>
      <fieldset className="seg seg--3" aria-label="Modalidade de atendimento">
        <legend className="field__label">Modalidade</legend>
        {MODALITIES.map((m) => (
          <label key={m.id} className={`seg__opt${values.modality === m.id ? ' is-on' : ''}`}>
            <input
              type="radio"
              name="modality"
              className="sr-only"
              checked={values.modality === m.id}
              onChange={() => set('modality', m.id)}
            />
            <Icon name={m.icon} size={20} /> {m.label}
          </label>
        ))}
      </fieldset>
      {values.modality !== 'presencial' && (
        <p className="field__hint">
          <Icon name="info" size={14} /> A videochamada não é integrada ao Vitalis: o link do atendimento online é combinado entre
          você e o cliente.
        </p>
      )}
      <TextField
        label="Endereço ou região de atendimento (opcional)"
        name="address"
        icon="home_health"
        maxLength={140}
        placeholder="Ex.: Centro, Barueri – SP (endereço completo enviado após o agendamento)"
        value={values.address}
        onChange={(e) => set('address', e.target.value)}
      />
    </div>
  );
}

/** Apresentação, formação, experiência e contato público. */
export function AboutFields({ values, errors, set }) {
  const [item, setItem] = useState('');
  const addItem = () => {
    const v = item.trim();
    if (!v || values.education.length >= 6) return;
    set('education', [...values.education, v.slice(0, 120)]);
    setItem('');
  };
  return (
    <div className="stack">
      <TextField
        as="textarea"
        rows={5}
        label="Apresentação"
        name="bio"
        maxLength={1200}
        placeholder="Conte como você atende, seu foco e o que o cliente pode esperar (mínimo de 40 caracteres)."
        value={values.bio}
        onChange={(e) => set('bio', e.target.value)}
        error={errors.bio}
        hint={`${values.bio.length}/1200 ${values.bio.trim().length < 40 ? '· mínimo de 40 caracteres' : ''}`}
        required
      />
      <div className="field">
        <label className="field__label" htmlFor="edu-input">
          Formação (até 6 itens)
        </label>
        {values.education.length > 0 && (
          <ul className="edu-list">
            {values.education.map((e, i) => (
              <li key={`${e}-${i}`}>
                <Icon name="school" size={18} /> <span>{e}</span>
                <button
                  type="button"
                  className="icon-btn"
                  aria-label={`Remover ${e}`}
                  onClick={() =>
                    set(
                      'education',
                      values.education.filter((_, j) => j !== i),
                    )
                  }
                >
                  <Icon name="close" size={16} />
                </button>
              </li>
            ))}
          </ul>
        )}
        <div className="edu-add">
          <input
            id="edu-input"
            className="input"
            placeholder="Ex.: Especialização em Fisioterapia Esportiva"
            value={item}
            maxLength={120}
            onChange={(e) => setItem(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addItem();
              }
            }}
            disabled={values.education.length >= 6}
          />
          <Button
            variant="soft-green"
            size="sm"
            icon="add"
            iconSize={18}
            onClick={addItem}
            disabled={!item.trim() || values.education.length >= 6}
          >
            Adicionar
          </Button>
        </div>
        {errors.education && <p className="field__error">{errors.education}</p>}
      </div>
      <div className="form-grid">
        <TextField
          label="Anos de experiência"
          name="experienceYears"
          type="number"
          min={0}
          max={60}
          value={values.experienceYears}
          onChange={(e) => set('experienceYears', e.target.value)}
          error={errors.experienceYears}
        />
        <TextField
          label="Experiência (resumo)"
          name="experience"
          maxLength={400}
          placeholder="Ex.: atendimento em clínica de reabilitação"
          value={values.experience}
          onChange={(e) => set('experience', e.target.value)}
        />
      </div>
      <div className="stack" style={{ '--stack-gap': '10px' }}>
        <p className="field__label">Contato no perfil público</p>
        <div className="setting-row setting-row--bordered">
          <div>
            <p className="setting-row__title">Mostrar telefone</p>
            <p className="setting-row__text">Por padrão, o contato só é compartilhado depois do agendamento.</p>
          </div>
          <Toggle
            checked={values.publicContact.showPhone}
            label="Mostrar telefone no perfil público"
            onChange={(v) => set('publicContact', { ...values.publicContact, showPhone: v })}
          />
        </div>
        <div className="setting-row setting-row--bordered">
          <div>
            <p className="setting-row__title">Mostrar e-mail</p>
            <p className="setting-row__text">O e-mail da sua conta fica visível para qualquer visitante.</p>
          </div>
          <Toggle
            checked={values.publicContact.showEmail}
            label="Mostrar e-mail no perfil público"
            onChange={(v) => set('publicContact', { ...values.publicContact, showEmail: v })}
          />
        </div>
      </div>
    </div>
  );
}
