import { useMemo, useState } from 'react';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState, Notice } from '../../components/ui/Feedback';
import { TextField } from '../../components/ui/Field';
import { KpiCard, PanelHeader, ToneBadge } from '../../components/panel/PanelLayout';
import { BarList, ColumnChart } from '../../components/panel/Charts';
import { useAsync, useDocumentTitle } from '../../hooks';
import { FINANCE_STATUS, getFinance } from '../../services/professionalService';
import { SERVICE_FEE } from '../../data/catalog';
import {
  MONTHS_SHORT,
  addDays,
  formatCurrency,
  formatCurrencyCompact,
  formatDateBR,
  monthLabel,
  pluralize,
  startOfWeek,
  toISODate,
} from '../../utils/format';
import { downloadFile } from '../../utils/download';

const PERIODS = [
  { id: 'hoje', label: 'Hoje' },
  { id: 'semana', label: 'Esta semana' },
  { id: 'mes', label: 'Este mês' },
  { id: 'personalizado', label: 'Personalizado' },
];

function rangeFor(period, custom) {
  const now = new Date();
  const today = toISODate(now);
  if (period === 'hoje') return { from: today, to: today };
  if (period === 'semana') {
    const start = startOfWeek(now);
    return { from: toISODate(start), to: toISODate(addDays(start, 6)) };
  }
  if (period === 'mes') {
    return {
      from: toISODate(new Date(now.getFullYear(), now.getMonth(), 1)),
      to: toISODate(new Date(now.getFullYear(), now.getMonth() + 1, 0)),
    };
  }
  return custom;
}

const METHOD = { pix: 'Pix', card: 'Cartão' };

export default function ProFinancePage() {
  useDocumentTitle('Financeiro');
  const [period, setPeriod] = useState('mes');
  const [custom, setCustom] = useState(() => {
    const now = new Date();
    return { from: toISODate(addDays(now, -30)), to: toISODate(now) };
  });
  const [draft, setDraft] = useState(custom);
  const [customError, setCustomError] = useState('');
  const [status, setStatus] = useState('');
  const range = rangeFor(period, custom);
  const { data, loading, error, reload } = useAsync(() => getFinance(range), [range.from, range.to]);

  const applyCustom = (e) => {
    e.preventDefault();
    if (!draft.from || !draft.to) return setCustomError('Informe as duas datas.');
    if (draft.from > draft.to) return setCustomError('A data inicial deve ser anterior à final.');
    setCustomError('');
    setCustom(draft);
    return undefined;
  };

  const items = useMemo(() => (data?.items || []).filter((i) => !status || i.financeStatus === status), [data, status]);
  const t = data?.totals;
  const chart = (data?.months || []).map((m) => ({
    key: m.key,
    label: MONTHS_SHORT[m.month],
    full: monthLabel(m.month, m.year),
    value: m.value,
  }));

  const exportCsv = () => {
    const rows = [
      ['Data', 'Horário', 'Cliente', 'Serviço', 'Situação', 'Forma', 'Valor da consulta (R$)'],
      ...items.map((i) => [
        formatDateBR(i.date),
        i.time,
        i.client.name,
        i.offeringName || i.serviceName,
        FINANCE_STATUS[i.financeStatus].label,
        METHOD[i.payment?.method] || '—',
        i.price.toFixed(2).replace('.', ','),
      ]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(';')).join('\n');
    downloadFile(`vitalis-financeiro-${range.from}_${range.to}.csv`, `﻿${csv}`, 'text/csv;charset=utf-8');
  };

  return (
    <div className="pro-finance">
      <PanelHeader
        eyebrow="Gestão"
        title="Financeiro"
        subtitle="Valores das consultas agendadas pelo Vitalis, organizados pela data do atendimento."
        actions={
          <Button variant="outline" size="sm" icon="download" iconSize={18} onClick={exportCsv} disabled={!items.length}>
            Exportar CSV
          </Button>
        }
      />

      <Notice tone="demo" title="Ambiente de demonstração.">
        Os pagamentos do Vitalis são simulados: nenhum valor abaixo corresponde a uma transação real, e não há repasse para conta
        bancária nesta versão.
      </Notice>

      <div className="toolbar section-gap">
        <div className="tabs" role="tablist" aria-label="Período">
          {PERIODS.map((p) => (
            <button
              key={p.id}
              type="button"
              role="tab"
              className="tab"
              aria-selected={period === p.id}
              onClick={() => setPeriod(p.id)}
            >
              {p.label}
            </button>
          ))}
        </div>
        <label htmlFor="fin-status" className="sr-only">
          Situação
        </label>
        <select id="fin-status" className="select" value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="">Todas as situações</option>
          {Object.entries(FINANCE_STATUS).map(([id, s]) => (
            <option key={id} value={id}>
              {s.label}
            </option>
          ))}
        </select>
      </div>
      {period === 'personalizado' && (
        <form className="fin-custom" onSubmit={applyCustom} noValidate>
          <TextField
            label="De"
            type="date"
            name="fin-from"
            value={draft.from}
            onChange={(e) => setDraft((d) => ({ ...d, from: e.target.value }))}
          />
          <TextField
            label="Até"
            type="date"
            name="fin-to"
            value={draft.to}
            onChange={(e) => setDraft((d) => ({ ...d, to: e.target.value }))}
          />
          <Button type="submit" variant="primary" size="sm" icon="filter_alt" iconSize={18}>
            Aplicar
          </Button>
          {customError && (
            <p className="field__error" role="alert">
              <Icon name="error" size={16} /> {customError}
            </p>
          )}
        </form>
      )}
      <p className="offer-summary">
        Período:{' '}
        <strong>
          {range.from === range.to ? formatDateBR(range.from) : `${formatDateBR(range.from)} a ${formatDateBR(range.to)}`}
        </strong>
      </p>

      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : (
        <>
          <div className="kpi-grid">
            {!t ? (
              Array.from({ length: 4 }, (_, i) => <span key={i} className="skeleton" style={{ height: 96, borderRadius: 16 }} />)
            ) : (
              <>
                <KpiCard
                  icon="savings"
                  label="Recebido (simulado)"
                  value={formatCurrency(t.received)}
                  hint="consultas realizadas e pagas"
                />
                <KpiCard
                  icon="schedule"
                  label="A receber (simulado)"
                  value={formatCurrency(t.toReceive)}
                  tone="blue"
                  hint="pagas, atendimento futuro"
                  delay={60}
                />
                <KpiCard
                  icon="hourglass_empty"
                  label="Aguardando pagamento"
                  value={formatCurrency(t.pending)}
                  tone="yellow"
                  hint="ainda não confirmadas"
                  delay={120}
                />
                <KpiCard
                  icon="undo"
                  label="Reembolsado"
                  value={formatCurrency(t.refunded)}
                  tone="red"
                  hint="cancelamentos no prazo"
                  delay={180}
                />
              </>
            )}
          </div>

          <div className="panel-grid panel-grid--main section-gap">
            <section className="panel-card" aria-labelledby="fin-month">
              <div className="panel-card__head">
                <div>
                  <h2 id="fin-month" className="panel-card__title">
                    <Icon name="bar_chart" size={22} /> Recebido por mês
                  </h2>
                  <p className="panel-card__sub">Últimos 6 meses · consultas concluídas e pagas (simulado)</p>
                </div>
              </div>
              {!data ? (
                <span className="skeleton" style={{ height: 200, display: 'block' }} />
              ) : chart.every((m) => m.value === 0) ? (
                <EmptyState
                  icon="bar_chart"
                  title="Sem valores recebidos"
                  text="Os valores aparecem depois dos primeiros atendimentos concluídos."
                />
              ) : (
                <ColumnChart
                  data={chart}
                  format={formatCurrencyCompact}
                  highlight={chart.length - 1}
                  height={200}
                  label="Valor recebido por mês, últimos 6 meses"
                />
              )}
            </section>

            <section className="panel-card" aria-labelledby="fin-balance">
              <div className="panel-card__head">
                <h2 id="fin-balance" className="panel-card__title">
                  <Icon name="account_balance_wallet" size={22} /> Saldo estimado
                </h2>
              </div>
              {!t ? (
                <span className="skeleton" style={{ height: 200, display: 'block' }} />
              ) : (
                <div className="fin-balance">
                  <p className="fin-balance__value">{formatCurrency(t.estimated)}</p>
                  <p className="muted">
                    recebido + a receber no período · {pluralize(t.paidCount, 'consulta paga', 'consultas pagas')}
                  </p>
                  {t.paidCount > 0 && (
                    <BarList
                      label="Valor por forma de pagamento"
                      format={formatCurrency}
                      data={[
                        { key: 'pix', label: 'Pix', value: t.byMethod.pix, badge: <Icon name="qr_code_2" size={16} /> },
                        { key: 'card', label: 'Cartão', value: t.byMethod.card, badge: <Icon name="credit_card" size={16} /> },
                      ]}
                    />
                  )}
                  <ul className="hint-list">
                    <li>
                      <Icon name="percent" size={16} /> Comissão do Vitalis sobre a consulta: <strong>{t.commissionRate}%</strong>{' '}
                      nesta versão.
                    </li>
                    <li>
                      <Icon name="receipt_long" size={16} /> Taxa de serviço de {formatCurrency(SERVICE_FEE)} por agendamento é
                      paga pelo cliente e fica com a plataforma ({formatCurrency(t.platformFees)} no período).
                    </li>
                    <li>
                      <Icon name="info" size={16} /> Cancelamentos com menos de 24 h não são reembolsados e contam como recebidos.
                    </li>
                  </ul>
                </div>
              )}
            </section>
          </div>

          <section className="panel-card panel-card--flush section-gap" aria-labelledby="fin-items">
            <div className="panel-card__head">
              <h2 id="fin-items" className="panel-card__title">
                <Icon name="receipt_long" size={22} /> Movimentações
              </h2>
              {data && <span className="muted">{pluralize(items.length, 'registro', 'registros')}</span>}
            </div>
            {!data ? (
              <span className="skeleton" style={{ height: 240, display: 'block', margin: 16 }} />
            ) : items.length === 0 ? (
              <EmptyState
                icon="receipt_long"
                title="Nada neste período"
                text="Escolha outro período ou situação para ver as movimentações."
              />
            ) : (
              <div className={`data-table-wrap${loading ? ' is-refreshing' : ''}`}>
                <table className="data-table data-table--cards">
                  <thead>
                    <tr>
                      <th scope="col">Atendimento</th>
                      <th scope="col">Data</th>
                      <th scope="col">Situação</th>
                      <th scope="col">Forma</th>
                      <th scope="col" className="num">
                        Consulta
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((i) => {
                      const st = FINANCE_STATUS[i.financeStatus];
                      return (
                        <tr key={i.id}>
                          <td className="cell-first">
                            <span className="cell-main">
                              <strong>{i.client.name}</strong>
                              <small>{i.offeringName || i.serviceName}</small>
                            </span>
                          </td>
                          <td data-label="Data">
                            {formatDateBR(i.date)} · {i.time}
                          </td>
                          <td data-label="Situação">
                            <ToneBadge tone={st.tone}>{st.label}</ToneBadge>
                          </td>
                          <td data-label="Forma">{METHOD[i.payment?.method] || '—'}</td>
                          <td data-label="Consulta" className="num">
                            {formatCurrency(i.price)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </>
      )}
    </div>
  );
}
