import { useCallback, useEffect, useState } from 'react';
import { Navigate, useLocation, useOutletContext } from 'react-router-dom';
import PanelLayout from '../../components/panel/PanelLayout';
import { ProAvatar } from '../../components/ui/Avatar';
import Button from '../../components/ui/Button';
import Icon from '../../components/ui/Icon';
import { Spinner, ErrorState } from '../../components/ui/Feedback';
import { getMyProfessional } from '../../services/professionalService';
import { unreadCount } from '../../services/notificationService';
import { PRO_STATUS } from '../../services/proModel';
import './pro.css';

/** Dados do profissional compartilhados pelas páginas da área (via Outlet). */
export function usePro() {
  return useOutletContext();
}

export default function ProLayout() {
  const location = useLocation();
  const [state, setState] = useState({ data: null, error: null });
  const [unread, setUnread] = useState(() => unreadCount());

  const load = useCallback(async () => {
    try {
      const data = await getMyProfessional();
      setState({ data, error: null });
      return data;
    } catch (error) {
      setState((s) => ({ data: s.data, error }));
      return null;
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    const onChange = () => setUnread(unreadCount());
    window.addEventListener('vitalis:db', onChange);
    return () => window.removeEventListener('vitalis:db', onChange);
  }, []);

  if (state.error && !state.data) {
    return (
      <div className="container page">
        <ErrorState error={state.error} onRetry={load} />
      </div>
    );
  }
  if (!state.data) return <Spinner label="Carregando área do profissional…" />;

  const { pro, progress } = state.data;
  const onboarding = location.pathname.startsWith('/profissional/onboarding');
  // cadastro ainda em configuração: o onboarding é o ponto de partida
  if (pro.status === 'rascunho' && !onboarding && location.pathname === '/profissional') {
    return <Navigate to="/profissional/onboarding" replace />;
  }
  const status = PRO_STATUS[pro.status] || PRO_STATUS.rascunho;

  const items = [
    { to: '/profissional', end: true, icon: 'dashboard', label: 'Visão geral' },
    { to: '/profissional/agenda', icon: 'calendar_month', label: 'Agenda' },
    { to: '/profissional/horarios', icon: 'more_time', label: 'Horários' },
    { to: '/profissional/servicos', icon: 'medical_services', label: 'Meus serviços' },
    { to: '/profissional/clientes', icon: 'group', label: 'Clientes' },
    { to: '/profissional/financeiro', icon: 'account_balance_wallet', label: 'Financeiro' },
    { to: '/profissional/notificacoes', icon: 'notifications', label: 'Notificações', badge: unread },
    { to: '/profissional/perfil', icon: 'badge', label: 'Perfil profissional' },
    { to: '/profissional/configuracoes', icon: 'settings', label: 'Configurações' },
  ];
  if (pro.status === 'rascunho' || pro.status === 'recusado') {
    items.unshift({
      to: '/profissional/onboarding',
      icon: 'rocket_launch',
      label: 'Configurar perfil',
      badge: progress.total - progress.done,
    });
  }

  const identity = (
    <>
      <ProAvatar pro={pro} size={72} />
      <p className="panel-side__name">{pro.name}</p>
      <p className="panel-side__meta">{pro.title || 'Profissional'}</p>
      <span className={`badge badge--${status.tone}`}>
        <Icon name={status.icon} size={15} /> {status.label}
      </span>
    </>
  );

  const footer =
    pro.status === 'publicado' ? (
      <Button variant="soft-green" size="sm" block to={`/profissionais/${pro.id}`} icon="visibility" iconSize={18}>
        Ver perfil público
      </Button>
    ) : (
      <p className="pro-side-note">
        <Icon name="info" size={16} /> {status.text}
      </p>
    );

  return (
    <PanelLayout
      label="Área do profissional"
      identity={identity}
      items={items}
      footer={footer}
      context={{ ...state.data, reload: load }}
    />
  );
}
