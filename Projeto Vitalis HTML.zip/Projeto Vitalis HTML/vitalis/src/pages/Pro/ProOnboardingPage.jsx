import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import { EmptyState, ErrorState, Notice } from '../../components/ui/Feedback';
import ProfessionalCard from '../../components/booking/ProfessionalCard';
import { useToast } from '../../context/ToastContext';
import { useAsync, useDocumentTitle } from '../../hooks';
import {
  deleteOffering,
  listMyOfferings,
  saveOffering,
  submitForReview,
  updateMyProfessional,
  validateProfile,
} from '../../services/professionalService';
import { PRO_STATUS, serviceName } from '../../services/proModel';
import { formatCurrency, formatDateTimeBR, WEEKDAYS_SHORT } from '../../utils/format';
import { AboutFields, BasicsFields, PhotoField, SpecialtyFields, profileValues } from './ProFields';
import { OfferingForm } from './ProServicesPage';
import { WeeklyEditor } from './ProSchedulePage';
import { previewPro } from './ProProfilePage';
import { usePro } from './ProLayout';
import { scrollBehavior } from '../../utils/motion';

const STEPS = [
  { id: 'cadastro', label: 'Cadastro', icon: 'how_to_reg' },
  { id: 'dados', label: 'Dados profissionais', icon: 'badge' },
  { id: 'especialidade', label: 'Especialidade', icon: 'stethoscope' },
  { id: 'servicos', label: 'Serviços', icon: 'medical_services' },
  { id: 'disponibilidade', label: 'Disponibilidade', icon: 'more_time' },
  { id: 'perfil', label: 'Perfil', icon: 'person' },
  { id: 'revisao', label: 'Revisão', icon: 'fact_check' },
  { id: 'publicacao', label: 'Publicação', icon: 'rocket_launch' },
];

/** Campos validados em cada etapa (chaves de validateProfile). */
const STEP_FIELDS = {
  1: ['namePrefix', 'displayName', 'title', 'council', 'registryNumber', 'uf', 'city'],
  2: ['service', 'specialty', 'modality'],
  5: ['bio', 'education', 'experienceYears'],
};

const SUBMITTED = ['em_analise', 'publicado', 'pausado', 'suspenso'];

function Stepper({ step, maxReached, onGo, submitted }) {
  return (
    <nav className="onb-steps" aria-label="Etapas do cadastro">
      <p className="onb-steps__mobile" aria-hidden="true">
        Etapa {step + 1} de {STEPS.length} · <strong>{STEPS[step].label}</strong>
      </p>
      <ol>
        {STEPS.map((s, i) => {
          const done = i < step || (submitted && i < 7) || i === 0;
          const current = i === step;
          const reachable = !submitted && i > 0 && i <= maxReached && i < 7;
          return (
            <li key={s.id} className={`onb-step${done ? ' is-done' : ''}${current ? ' is-current' : ''}`}>
              {reachable && !current ? (
                <button type="button" className="onb-step__btn" onClick={() => onGo(i)}>
                  <span className="onb-step__dot">{done ? <Icon name="check" size={16} /> : i}</span>
                  <span className="onb-step__label">{s.label}</span>
                </button>
              ) : (
                <span className="onb-step__btn" aria-current={current ? 'step' : undefined}>
                  <span className="onb-step__dot">{(done && !current) || i === 0 ? <Icon name="check" size={16} /> : i}</span>
                  <span className="onb-step__label">{s.label}</span>
                </span>
              )}
            </li>
          );
        })}
      </ol>
      <div className="onb-steps__bar" aria-hidden="true">
        <span style={{ '--w': `${(step / (STEPS.length - 1)) * 100}%` }} />
      </div>
    </nav>
  );
}

function StepNav({ onBack, onNext, nextLabel = 'Salvar e continuar', loading, disabled }) {
  return (
    <div className="form-actions onb-nav">
      {onBack && (
        <Button variant="ghost" icon="arrow_back" onClick={onBack} className="push-left">
          Voltar
        </Button>
      )}
      <Button
        variant="primary"
        iconRight="arrow_forward"
        onClick={onNext}
        loading={loading}
        loadingText="Salvando…"
        disabled={disabled}
      >
        {nextLabel}
      </Button>
    </div>
  );
}

function ServicesStep({ pro, onBack, onNext }) {
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => listMyOfferings(), []);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [serverError, setServerError] = useState(null);
  const list = data || [];
  const active = list.filter((o) => o.active);

  useEffect(() => {
    if (data && data.length === 0) setEditing({});
  }, [data]);

  const save = async (values) => {
    setSaving(true);
    setServerError(null);
    try {
      await saveOffering({ ...values, id: editing?.id });
      toast.success(editing?.id ? 'Serviço atualizado' : 'Serviço adicionado', values.name);
      setEditing(null);
      reload();
    } catch (err) {
      setServerError(err);
      if (!err.field) toast.error('Não foi possível salvar', err.message);
    } finally {
      setSaving(false);
    }
  };

  const remove = async (o) => {
    try {
      await deleteOffering(o.id);
      toast.success('Serviço removido', o.name);
      reload();
    } catch (err) {
      toast.error('Não foi possível remover', err.message);
    }
  };

  return (
    <>
      <p className="muted">Cadastre o que você atende, com duração e preço. Você pode ajustar tudo depois em “Meus serviços”.</p>
      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data ? (
        <span className="skeleton" style={{ height: 120, display: 'block' }} />
      ) : list.length === 0 ? (
        <EmptyState icon="medical_services" title="Nenhum serviço ainda" text="Adicione pelo menos um serviço para continuar." />
      ) : (
        <ul className="onb-offers">
          {list.map((o) => (
            <li key={o.id} className={o.active ? '' : 'is-inactive'}>
              <span className="onb-offers__body">
                <strong>{o.name}</strong>
                <small>
                  {serviceName(o.serviceSlug)} · {o.duration} min · {formatCurrency(o.price)}
                  {!o.active && ' · inativo'}
                </small>
              </span>
              <button
                type="button"
                className="icon-btn"
                aria-label={`Editar ${o.name}`}
                onClick={() => setEditing({ ...o, price: String(o.price).replace('.', ',') })}
              >
                <Icon name="edit" size={20} />
              </button>
              <button
                type="button"
                className="icon-btn icon-btn--danger"
                aria-label={`Remover ${o.name}`}
                onClick={() => remove(o)}
              >
                <Icon name="delete" size={20} />
              </button>
            </li>
          ))}
        </ul>
      )}
      <Button variant="soft-green" size="sm" icon="add" iconSize={18} className="section-gap" onClick={() => setEditing({})}>
        Adicionar serviço
      </Button>
      <StepNav onBack={onBack} onNext={onNext} disabled={!active.length} nextLabel="Continuar" />
      {!active.length && list.length > 0 && (
        <p className="field__hint onb-hint">Ative ou adicione pelo menos um serviço para continuar.</p>
      )}

      <Modal
        open={!!editing}
        onClose={saving ? () => {} : () => setEditing(null)}
        title={editing?.id ? 'Editar serviço' : 'Novo serviço'}
        width={560}
        footer={
          <>
            <Button variant="ghost" onClick={() => setEditing(null)} disabled={saving}>
              Cancelar
            </Button>
            <Button variant="primary" type="submit" form="onb-offering" icon="save" loading={saving} loadingText="Salvando…">
              {editing?.id ? 'Salvar' : 'Adicionar'}
            </Button>
          </>
        }
      >
        {editing && (
          <OfferingForm
            id="onb-offering"
            key={editing.id || 'new'}
            initial={editing.id ? editing : null}
            defaultService={pro.service}
            onSubmit={save}
            serverError={serverError}
          />
        )}
      </Modal>
    </>
  );
}

function ReviewStep({ pro, progress, values, onBack, onGo, onSubmitted }) {
  const toast = useToast();
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const preview = useMemo(() => previewPro(pro, values), [pro, values]);
  const pendingStep = { dados: 1, especialidade: 2, servicos: 3, disponibilidade: 4, perfil: 5 };
  const ready = progress.done === progress.total;
  const days = (pro.availability?.weekly || []).filter((d) => d.enabled);

  const send = async () => {
    setSending(true);
    setError('');
    try {
      await submitForReview();
      toast.success('Perfil enviado', 'A equipe Vitalis vai verificar seus dados.');
      onSubmitted();
    } catch (err) {
      setError(err.message);
    } finally {
      setSending(false);
    }
  };

  return (
    <>
      <div className="onb-review">
        <div>
          <h3 className="detail-title">Checklist</h3>
          <ul className="onb-check">
            {progress.list.map((i) => (
              <li key={i.id} className={i.done ? 'is-done' : ''}>
                <Icon name={i.done ? 'check_circle' : 'radio_button_unchecked'} size={20} />
                <span>{i.label}</span>
                {!i.done && (
                  <button type="button" className="text-link" onClick={() => onGo(pendingStep[i.id])}>
                    Completar
                  </button>
                )}
              </li>
            ))}
          </ul>
          <h3 className="detail-title section-gap">Resumo</h3>
          <dl className="pf-facts">
            <div>
              <dt>Registro</dt>
              <dd>{pro.registry?.council ? `${pro.registry.council} ${pro.registry.number}/${pro.registry.uf}` : '—'}</dd>
            </div>
            <div>
              <dt>Área</dt>
              <dd>{serviceName(pro.service) || '—'}</dd>
            </div>
            <div>
              <dt>Serviços ativos</dt>
              <dd>{(pro.offerings || []).filter((o) => o.active).length}</dd>
            </div>
            <div>
              <dt>Atendimento</dt>
              <dd>{days.length ? days.map((d) => WEEKDAYS_SHORT[d.day]).join(', ') : '—'}</dd>
            </div>
          </dl>
        </div>
        <div>
          <h3 className="detail-title">Como os clientes verão</h3>
          <ProfessionalCard pro={preview} preview actionTo="#" showService />
        </div>
      </div>
      <Notice tone="info" className="section-gap">
        Ao enviar, a equipe Vitalis confere o registro profissional e os dados do perfil. Enquanto isso, você pode continuar
        ajustando serviços e horários.
      </Notice>
      {error && (
        <Notice tone="error" className="section-gap">
          {error}
        </Notice>
      )}
      <StepNav onBack={onBack} onNext={send} loading={sending} disabled={!ready} nextLabel="Enviar para verificação" />
    </>
  );
}

function PublishedStep({ pro }) {
  const status = PRO_STATUS[pro.status] || PRO_STATUS.rascunho;
  return (
    <div className="onb-done">
      <span className={`onb-done__icon onb-done__icon--${status.tone}`}>
        <Icon name={status.icon} size={44} />
      </span>
      <h3>{status.label}</h3>
      <p>{status.text}</p>
      {pro.status === 'em_analise' && (
        <>
          {pro.submittedAt && <p className="muted">Enviado em {formatDateTimeBR(pro.submittedAt)}</p>}
          <Notice tone="demo" className="section-gap" title="Demonstração:">
            a aprovação é feita pela conta de administração, em Administração → Profissionais. Não há verificação automática de
            documentos.
          </Notice>
        </>
      )}
      <div className="onb-done__actions">
        <Button variant="outline" to="/profissional" icon="dashboard">
          Ir para a visão geral
        </Button>
        {pro.status === 'publicado' ? (
          <Button variant="primary" to={`/profissionais/${pro.id}`} icon="visibility">
            Ver perfil público
          </Button>
        ) : (
          <Button variant="primary" to="/profissional/horarios" icon="more_time">
            Revisar horários
          </Button>
        )}
      </div>
    </div>
  );
}

export default function ProOnboardingPage() {
  useDocumentTitle('Configurar perfil');
  const toast = useToast();
  const { pro, progress, reload } = usePro();
  const submitted = SUBMITTED.includes(pro.status);
  const startStep = submitted ? 7 : Math.min(Math.max(Number(pro.onboardingStep) || 1, 1), 6);
  const [step, setStep] = useState(startStep);
  const [maxReached, setMaxReached] = useState(startStep);
  const [values, setValues] = useState(() => profileValues(pro));
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const topRef = useRef(null);

  useEffect(() => {
    if (submitted) setStep(7);
  }, [submitted]);

  const set = (k, v) =>
    setValues((prev) => {
      const next = { ...prev, [k]: v };
      if (Object.keys(errors).length) {
        const all = validateProfile(next, { strict: true });
        setErrors(Object.fromEntries(Object.entries(all).filter(([key]) => (STEP_FIELDS[step] || []).includes(key))));
      }
      return next;
    });

  const go = (i) => {
    setStep(i);
    setMaxReached((m) => Math.max(m, i));
    setErrors({});
    requestAnimationFrame(() => topRef.current?.scrollIntoView({ behavior: scrollBehavior(), block: 'start' }));
  };

  /** Valida os campos da etapa, salva o perfil inteiro e avança. */
  const saveProfileStep = async () => {
    const fields = STEP_FIELDS[step] || [];
    const all = validateProfile(values, { strict: true });
    const errs = Object.fromEntries(Object.entries(all).filter(([k]) => fields.includes(k)));
    setErrors(errs);
    const first = Object.keys(errs)[0];
    if (first) {
      document.querySelector(`.onb-card [name="${first}"]`)?.focus();
      return;
    }
    setSaving(true);
    try {
      // etapas ainda não preenchidas seguem vazias: valida só o que já foi informado
      await updateMyProfessional({ ...values, onboardingStep: Math.max(step + 1, Number(pro.onboardingStep) || 1) });
      await reload();
      go(step + 1);
    } catch (err) {
      if (err.field) setErrors({ [err.field]: err.message });
      toast.error('Não foi possível salvar', err.message);
    } finally {
      setSaving(false);
    }
  };

  const advanceTo = async (next) => {
    try {
      if ((Number(pro.onboardingStep) || 1) < next) await updateMyProfessional({ ...values, onboardingStep: next });
      await reload();
    } catch {
      /* avanço local mesmo assim */
    }
    go(next);
  };

  if (pro.status === 'suspenso') {
    return (
      <div className="panel-card">
        <EmptyState
          icon="block"
          title="Perfil suspenso"
          text="Fale com o suporte para entender o motivo e reativar seu perfil."
          actions={<Button to="/ajuda?secao=contato">Falar com o suporte</Button>}
        />
      </div>
    );
  }

  const current = STEPS[step];

  return (
    <div className="pro-onboarding" ref={topRef}>
      <header className="onb-hero">
        <div>
          <p className="panel-header__eyebrow">Primeiros passos</p>
          <h1 className="panel-header__title">{submitted ? 'Cadastro enviado' : 'Configure seu perfil profissional'}</h1>
          <p className="panel-header__subtitle">
            {submitted
              ? 'Acompanhe aqui a publicação do seu perfil.'
              : 'Leva poucos minutos. Seu progresso é salvo a cada etapa.'}
          </p>
        </div>
        <div className="onb-hero__pct" aria-label={`${progress.pct}% do perfil completo`}>
          <strong>{progress.pct}%</strong>
          <span>completo</span>
        </div>
      </header>

      {pro.status === 'recusado' && pro.reviewNote && (
        <Notice tone="warning" title="Ajustes pedidos pela verificação:" className="section-gap">
          {pro.reviewNote}
        </Notice>
      )}

      <Stepper step={step} maxReached={maxReached} onGo={go} submitted={submitted} />

      <section className="panel-card onb-card" aria-labelledby="onb-title" key={step}>
        <h2 id="onb-title" className="panel-card__title">
          <Icon name={current.icon} size={22} /> {current.label}
        </h2>

        {step === 1 && (
          <div className="stack section-gap">
            <p className="muted">Como você aparece para os clientes e seu registro no conselho profissional.</p>
            <PhotoField
              value={values.photo}
              name={previewPro(pro, values).name}
              gender={previewPro(pro, values).gender}
              onChange={(v) => set('photo', v)}
            />
            <BasicsFields values={values} errors={errors} set={set} />
            <StepNav onNext={saveProfileStep} loading={saving} />
          </div>
        )}

        {step === 2 && (
          <div className="stack section-gap">
            <p className="muted">Escolha a área do catálogo em que você aparece e como atende.</p>
            <SpecialtyFields values={values} errors={errors} set={set} />
            <StepNav onBack={() => go(1)} onNext={saveProfileStep} loading={saving} />
          </div>
        )}

        {step === 3 && (
          <div className="section-gap">
            <ServicesStep pro={pro} onBack={() => go(2)} onNext={() => advanceTo(4)} />
          </div>
        )}

        {step === 4 && (
          <div className="onb-weekly section-gap">
            <WeeklyEditor
              availability={pro.availability}
              submitLabel="Salvar e continuar"
              alwaysEnabled
              onSaved={() => advanceTo(5)}
              footerStart={
                <Button variant="ghost" icon="arrow_back" onClick={() => go(3)} className="push-left">
                  Voltar
                </Button>
              }
            />
            <p className="field__hint onb-hint">
              Bloqueios, folgas e horários especiais ficam em “Horários”, depois do cadastro.
            </p>
          </div>
        )}

        {step === 5 && (
          <div className="stack section-gap">
            <p className="muted">Uma boa apresentação ajuda o cliente a escolher. Escreva em linguagem simples.</p>
            <AboutFields values={values} errors={errors} set={set} />
            <StepNav onBack={() => go(4)} onNext={saveProfileStep} loading={saving} />
          </div>
        )}

        {step === 6 && (
          <div className="section-gap">
            <ReviewStep
              pro={pro}
              progress={progress}
              values={values}
              onBack={() => go(5)}
              onGo={go}
              onSubmitted={async () => {
                await reload();
                setStep(7);
              }}
            />
          </div>
        )}

        {step === 7 && (
          <div className="section-gap">
            <PublishedStep pro={pro} />
          </div>
        )}
      </section>

      {!submitted && (
        <p className="onb-later">
          Quer terminar depois? Seu progresso fica salvo. <Link to="/profissional/configuracoes">Configurações da conta</Link>
        </p>
      )}
    </div>
  );
}
