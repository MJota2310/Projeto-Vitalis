import { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState, Notice } from '../../components/ui/Feedback';
import { KpiCard } from '../../components/panel/PanelLayout';
import { ColumnChart, Meter } from '../../components/panel/Charts';
import { useAsync, useDocumentTitle } from '../../hooks';
import { useToast } from '../../context/ToastContext';
import { getOverview } from '../../services/professionalService';
import { NOTIFICATION_TYPES } from '../../services/notificationService';
import { PRO_STATUS } from '../../services/proModel';
import { ApptRow, ProAppointmentModal } from './ProComponents';
import {
  WEEKDAYS_SHORT,
  firstName,
  formatCurrency,
  formatDateLong,
  parseISODate,
  relativeTime,
  toISODate,
} from '../../utils/format';
import { usePro } from './ProLayout';
import '../Account/account.css';

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Bom dia';
  if (h < 18) return 'Boa tarde';
  return 'Boa noite';
}

const SHORTCUTS = [
  { to: '/profissional/agenda', icon: 'calendar_month', label: 'Ver agenda', text: 'Dia, semana ou mês' },
  { to: '/profissional/horarios?novo=bloqueio', icon: 'event_busy', label: 'Bloquear horário', text: 'Folgas e imprevistos' },
  { to: '/profissional/servicos?novo=1', icon: 'add_circle', label: 'Novo serviço', text: 'Nome, duração e preço' },
  { to: '/profissional/perfil', icon: 'badge', label: 'Editar perfil', text: 'Foto, apresentação e contato' },
];

function StatusBanner({ pro }) {
  const s = PRO_STATUS[pro.status];
  if (!s || pro.status === 'publicado') return null;
  const tone = { em_analise: 'warning', pausado: 'info', recusado: 'error', suspenso: 'error', rascunho: 'info' }[pro.status];
  return (
    <Notice tone={tone} className="pro-banner" title={`Perfil ${s.label.toLowerCase()}.`}>
      {s.text}
      {pro.reviewNote && pro.status === 'recusado' && (
        <>
          {' '}
          Observação da equipe: <em>{pro.reviewNote}</em>
        </>
      )}{' '}
      {pro.status === 'pausado' && (
        <Link to="/profissional/configuracoes" className="text-link">
          Reativar perfil
        </Link>
      )}
      {(pro.status === 'rascunho' || pro.status === 'recusado') && (
        <Link to="/profissional/onboarding" className="text-link">
          Continuar configuração
        </Link>
      )}
    </Notice>
  );
}

export default function ProOverviewPage() {
  useDocumentTitle('Painel do profissional');
  const { user } = usePro();
  const toast = useToast();
  const { data, loading, error, reload } = useAsync(() => getOverview(), []);
  const [openId, setOpenId] = useState(null);

  if (error) return <ErrorState error={error} onRetry={reload} />;

  const today = toISODate(new Date());
  const pro = data?.pro;
  const weekData = (data?.week || []).map((d) => {
    const date = parseISODate(d.date);
    return {
      key: d.date,
      label: d.date === today ? 'Hoje' : WEEKDAYS_SHORT[date.getDay()],
      full: `${formatDateLong(d.date)} — ${d.count} atendimento(s)`,
      value: d.count,
      muted: d.available === 0,
    };
  });

  const copyLink = async () => {
    const url = `${window.location.origin}${window.location.pathname}#/profissionais/${pro.id}`;
    try {
      await navigator.clipboard.writeText(url);
      toast.success('Link copiado', 'Envie aos seus clientes para agendarem direto com você.');
    } catch {
      toast.info('Seu link', url, { duration: 8000 });
    }
  };

  return (
    <div className="pro-overview">
      <header className="dash-hero pro-hero">
        <div>
          <p className="dash-hero__eyebrow">{greeting()},</p>
          <h1 className="dash-hero__title">
            {pro ? firstName(pro.displayName || pro.name) : firstName(user.name)} <span aria-hidden="true">👋</span>
          </h1>
          <p className="dash-hero__text">
            {loading
              ? 'Carregando o resumo do seu dia…'
              : `${formatDateLong(today)} · ${
                  data.counts.today === 0
                    ? 'nenhum atendimento hoje'
                    : `${data.counts.today} atendimento${data.counts.today > 1 ? 's' : ''} hoje`
                }`}
          </p>
        </div>
        <div className="pro-hero__actions">
          <Button variant="light" to="/profissional/agenda" icon="calendar_month">
            Abrir agenda
          </Button>
          {pro?.status === 'publicado' && (
            <button type="button" className="next-card__link" onClick={copyLink}>
              <Icon name="link" size={18} /> Copiar link do perfil
            </button>
          )}
        </div>
      </header>

      {pro && <StatusBanner pro={pro} />}

      {data && data.progress.done < data.progress.total && (
        <section className="panel-card pro-progress section-gap" aria-labelledby="progress-title">
          <div className="panel-card__head">
            <h2 id="progress-title" className="panel-card__title">
              <Icon name="checklist" size={22} /> Complete seu perfil
            </h2>
            <span className="muted">
              {data.progress.done} de {data.progress.total} etapas
            </span>
          </div>
          <div className="pro-progress__bar" aria-hidden="true">
            <span style={{ '--w': `${data.progress.pct}%` }} />
          </div>
          <ul className="pro-progress__list">
            {data.progress.list.map((i) => (
              <li key={i.id} className={i.done ? 'is-done' : ''}>
                <Icon name={i.done ? 'check_circle' : 'pending'} size={18} /> {i.label}
              </li>
            ))}
          </ul>
          <Button variant="primary" size="sm" to="/profissional/onboarding" iconRight="arrow_forward">
            Continuar configuração
          </Button>
        </section>
      )}

      <div className="kpi-grid section-gap">
        {loading ? (
          Array.from({ length: 4 }, (_, i) => <span key={i} className="skeleton" style={{ height: 96, borderRadius: 16 }} />)
        ) : (
          <>
            <KpiCard
              icon="today"
              label="Atendimentos hoje"
              value={data.counts.today}
              hint="agenda do dia"
              to="/profissional/agenda?visao=dia"
            />
            <KpiCard
              icon="event_upcoming"
              label="Próximos 7 dias"
              value={data.counts.next7}
              tone="blue"
              hint={`${data.counts.freeSlots7} horários livres`}
              to="/profissional/agenda?visao=semana"
              delay={60}
            />
            <KpiCard
              icon="hourglass_empty"
              label="Aguardando pagamento"
              value={data.counts.pending}
              tone="yellow"
              hint="confirma ao pagar"
              to="/profissional/agenda?visao=lista&status=pendente_pagamento"
              delay={120}
            />
            <KpiCard
              icon="account_balance_wallet"
              label="A receber"
              value={formatCurrency(data.finance.toReceive)}
              tone="green"
              hint="valores simulados"
              to="/profissional/financeiro"
              delay={180}
            />
          </>
        )}
      </div>

      <div className="panel-grid panel-grid--main">
        <div className="panel-stack">
          <section className="panel-card" aria-labelledby="today-title">
            <div className="panel-card__head">
              <h2 id="today-title" className="panel-card__title">
                <Icon name="today" size={22} /> Agenda de hoje
              </h2>
              <Link to="/profissional/agenda?visao=dia" className="text-link">
                Ver dia completo
              </Link>
            </div>
            {loading ? (
              <span className="skeleton" style={{ height: 150, display: 'block' }} />
            ) : data.today.length === 0 ? (
              <EmptyState
                icon="beach_access"
                title="Nenhum atendimento hoje"
                text={
                  data.counts.next7
                    ? 'Aproveite para organizar a semana. Seus próximos atendimentos estão ao lado.'
                    : 'Quando um cliente agendar, o horário aparece aqui.'
                }
              />
            ) : (
              <ul className="appt-rows">
                {data.today.map((a) => (
                  <li key={a.id}>
                    <ApptRow appt={a} onOpen={(x) => setOpenId(x.id)} />
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="panel-card" aria-labelledby="next-title">
            <div className="panel-card__head">
              <h2 id="next-title" className="panel-card__title">
                <Icon name="upcoming" size={22} /> Próximos atendimentos
              </h2>
              <Link to="/profissional/agenda?visao=lista" className="text-link">
                Ver todos
              </Link>
            </div>
            {loading ? (
              <span className="skeleton" style={{ height: 180, display: 'block' }} />
            ) : data.upcoming.length === 0 ? (
              <EmptyState
                icon="event_available"
                title="Nenhum atendimento marcado"
                text="Confira seus horários e compartilhe o link do perfil para receber agendamentos."
                actions={
                  <Button variant="outline" size="sm" to="/profissional/horarios" icon="more_time">
                    Revisar horários
                  </Button>
                }
              />
            ) : (
              <ul className="appt-rows">
                {data.upcoming.map((a) => (
                  <li key={a.id}>
                    <ApptRow appt={a} onOpen={(x) => setOpenId(x.id)} showDate />
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        <div className="panel-stack">
          <section className="panel-card" aria-labelledby="week-title">
            <div className="panel-card__head">
              <h2 id="week-title" className="panel-card__title">
                <Icon name="bar_chart" size={22} /> Atendimentos nos próximos 7 dias
              </h2>
            </div>
            {loading ? (
              <span className="skeleton" style={{ height: 190, display: 'block' }} />
            ) : (
              <>
                <ColumnChart
                  data={weekData}
                  label="Atendimentos marcados por dia nos próximos 7 dias"
                  highlight={0}
                  height={150}
                />
                <div className="section-gap">
                  <Meter
                    value={data.occupancy}
                    label="Ocupação da agenda (7 dias)"
                    hint={`Tempo reservado sobre o tempo disponível configurado em Horários.${data.counts.freeSlots7 ? ` ${data.counts.freeSlots7} horários livres.` : ''}`}
                  />
                </div>
              </>
            )}
          </section>

          <section className="panel-card" aria-labelledby="ntf-title">
            <div className="panel-card__head">
              <h2 id="ntf-title" className="panel-card__title">
                <Icon name="notifications" size={22} /> Notificações
                {data?.unread > 0 && <span className="badge badge--red">{data.unread} nova(s)</span>}
              </h2>
              <Link to="/profissional/notificacoes" className="text-link">
                Ver todas
              </Link>
            </div>
            {loading ? (
              <span className="skeleton" style={{ height: 120, display: 'block' }} />
            ) : data.notifications.length === 0 ? (
              <p className="muted">Nenhuma notificação.</p>
            ) : (
              <ul className="mini-ntf">
                {data.notifications.map((n) => {
                  const t = NOTIFICATION_TYPES[n.type] || NOTIFICATION_TYPES.sistema;
                  return (
                    <li key={n.id} className={n.read ? '' : 'is-unread'}>
                      <span className={`ntf-icon ntf-icon--${t.tone}`}>
                        <Icon name={t.icon} size={18} />
                      </span>
                      <span>
                        <strong>{n.title}</strong>
                        <small>{relativeTime(n.createdAt)}</small>
                      </span>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>

          <section className="panel-card" aria-labelledby="short-title">
            <h2 id="short-title" className="panel-card__title">
              <Icon name="electric_bolt" size={22} /> Atalhos
            </h2>
            <ul className="quick__grid">
              {SHORTCUTS.map((q) => (
                <li key={q.to}>
                  <Link to={q.to} className="quick__item">
                    <span className="quick__icon">
                      <Icon name={q.icon} size={22} />
                    </span>
                    <span>
                      <strong>{q.label}</strong>
                      <small>{q.text}</small>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        </div>
      </div>

      <ProAppointmentModal apptId={openId} onClose={() => setOpenId(null)} onChanged={() => reload()} />
    </div>
  );
}
