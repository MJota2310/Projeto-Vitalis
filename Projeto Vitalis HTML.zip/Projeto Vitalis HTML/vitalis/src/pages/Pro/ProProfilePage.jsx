import { useMemo, useState } from 'react';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { Notice } from '../../components/ui/Feedback';
import { PanelHeader, ToneBadge } from '../../components/panel/PanelLayout';
import ProfessionalCard from '../../components/booking/ProfessionalCard';
import { useToast } from '../../context/ToastContext';
import { useDocumentTitle } from '../../hooks';
import { updateMyProfessional, validateProfile } from '../../services/professionalService';
import { MODALITIES, PRO_STATUS, activeOfferings, serviceName } from '../../services/proModel';
import { formatDateTimeBR } from '../../utils/format';
import { AboutFields, BasicsFields, PhotoField, SpecialtyFields, profileValues } from './ProFields';
import { usePro } from './ProLayout';

/** Monta como o perfil aparece para os clientes a partir do formulário. */
export function previewPro(pro, values) {
  const prices = activeOfferings(pro).map((o) => o.price);
  return {
    ...pro,
    ...values,
    name: `${values.namePrefix ? `${values.namePrefix} ` : ''}${values.displayName || 'Seu nome'}`,
    specialty: values.specialty || 'Sua especialidade',
    gender: values.namePrefix ? (['Dra.', 'Profª.'].includes(values.namePrefix) ? 'f' : 'm') : pro.gender,
    price: prices.length ? Math.min(...prices) : 0,
    priceFrom: new Set(prices).size > 1,
  };
}

export function copyProfileLink(id, toast) {
  const url = `${window.location.origin}${window.location.pathname}#/profissionais/${id}`;
  navigator.clipboard
    .writeText(url)
    .then(() => toast.success('Link copiado', 'Envie aos seus clientes para agendarem direto com você.'))
    .catch(() => toast.info('Seu link', url, { duration: 8000 }));
}

export default function ProProfilePage() {
  useDocumentTitle('Perfil profissional');
  const toast = useToast();
  const { pro, reload } = usePro();
  const [values, setValues] = useState(() => profileValues(pro));
  const [base, setBase] = useState(() => profileValues(pro));
  const [errors, setErrors] = useState({});
  const [saving, setSaving] = useState(false);
  const dirty = JSON.stringify(values) !== JSON.stringify(base);
  const strict = ['publicado', 'em_analise', 'pausado'].includes(pro.status);
  const status = PRO_STATUS[pro.status] || PRO_STATUS.rascunho;

  const set = (k, v) => {
    setValues((prev) => {
      const next = { ...prev, [k]: v };
      if (Object.keys(errors).length) setErrors(validateProfile(next, { strict }));
      return next;
    });
  };

  const save = async (e) => {
    e.preventDefault();
    const errs = validateProfile(values, { strict });
    setErrors(errs);
    const first = Object.keys(errs)[0];
    if (first) {
      document.querySelector(`.pro-profile [name="${first}"]`)?.focus();
      toast.error('Revise os campos destacados', errs[first]);
      return;
    }
    setSaving(true);
    try {
      await updateMyProfessional(values);
      const fresh = await reload();
      const next = fresh ? profileValues(fresh.pro) : values;
      setValues(next);
      setBase(next);
      toast.success(
        'Perfil atualizado',
        pro.status === 'publicado' ? 'As alterações já aparecem no perfil público.' : 'Alterações salvas.',
      );
    } catch (err) {
      if (err.field) setErrors({ [err.field]: err.message });
      toast.error('Não foi possível salvar', err.message);
    } finally {
      setSaving(false);
    }
  };

  const preview = useMemo(() => previewPro(pro, values), [pro, values]);
  const modality = MODALITIES.find((m) => m.id === values.modality);

  return (
    <form className="pro-profile" onSubmit={save} noValidate>
      <PanelHeader
        eyebrow="Vitrine"
        title="Perfil profissional"
        subtitle="Estas informações aparecem para os clientes na busca e na sua página pública."
        actions={
          pro.status === 'publicado' && (
            <>
              <Button variant="outline" size="sm" icon="link" iconSize={18} onClick={() => copyProfileLink(pro.id, toast)}>
                Copiar link
              </Button>
              <Button variant="soft-green" size="sm" icon="open_in_new" iconSize={18} to={`/profissionais/${pro.id}`}>
                Ver perfil público
              </Button>
            </>
          )
        }
      />

      <div className="pro-banner pro-banner--inline">
        <ToneBadge tone={status.tone} icon={status.icon}>
          {status.label}
        </ToneBadge>
        <p>{status.text}</p>
      </div>
      {pro.status === 'recusado' && pro.reviewNote && (
        <Notice tone="warning" title="Ajustes pedidos pela verificação:" className="section-gap">
          {pro.reviewNote}
        </Notice>
      )}

      <div className="pro-profile__grid section-gap">
        <div className="panel-stack">
          <section className="panel-card" aria-labelledby="pf-id">
            <h2 id="pf-id" className="panel-card__title">
              <Icon name="badge" size={22} /> Identificação e registro
            </h2>
            <div className="stack section-gap">
              <PhotoField value={values.photo} name={preview.name} gender={preview.gender} onChange={(v) => set('photo', v)} />
              <BasicsFields values={values} errors={errors} set={set} />
              {pro.verified && (
                <p className="field__hint">
                  <Icon name="info" size={14} /> Alterar o registro profissional avisa a equipe Vitalis, que pode conferir os
                  dados novamente.
                </p>
              )}
            </div>
          </section>

          <section className="panel-card" aria-labelledby="pf-spec">
            <h2 id="pf-spec" className="panel-card__title">
              <Icon name="stethoscope" size={22} /> Especialidade e atendimento
            </h2>
            <div className="section-gap">
              <SpecialtyFields values={values} errors={errors} set={set} />
            </div>
          </section>

          <section className="panel-card" aria-labelledby="pf-about">
            <h2 id="pf-about" className="panel-card__title">
              <Icon name="person" size={22} /> Apresentação
            </h2>
            <div className="section-gap">
              <AboutFields values={values} errors={errors} set={set} />
            </div>
          </section>
        </div>

        <aside className="pro-profile__preview" aria-labelledby="pf-prev">
          <div className="panel-card">
            <h2 id="pf-prev" className="panel-card__title">
              <Icon name="visibility" size={22} /> Prévia para o cliente
            </h2>
            <p className="panel-card__sub">Atualiza enquanto você edita.</p>
            <div className="section-gap">
              <ProfessionalCard pro={preview} preview actionTo="#" actionLabel="Agendar" showService />
            </div>
            <dl className="pf-facts">
              <div>
                <dt>Área no catálogo</dt>
                <dd>{values.service ? serviceName(values.service) : '—'}</dd>
              </div>
              <div>
                <dt>Modalidade</dt>
                <dd>{modality?.label || '—'}</dd>
              </div>
              <div>
                <dt>Registro</dt>
                <dd>
                  {values.registry.council && values.registry.number
                    ? `${values.registry.council} ${values.registry.number}/${values.registry.uf}`
                    : '—'}
                </dd>
              </div>
              <div>
                <dt>Serviços ativos</dt>
                <dd>{activeOfferings(pro).length}</dd>
              </div>
            </dl>
            {values.bio && <p className="pf-bio">{values.bio.length > 220 ? `${values.bio.slice(0, 220)}…` : values.bio}</p>}
            <ul className="hint-list section-gap">
              <li>
                <Icon name="star" size={16} /> Avaliações de clientes ainda não fazem parte do Vitalis. Perfis novos aparecem como
                “Novo no Vitalis”.
              </li>
              <li>
                <Icon name="lock" size={16} /> Telefone e e-mail só aparecem se você ativar o contato público.
              </li>
            </ul>
            {pro.updatedAt && <p className="pf-updated">Última atualização: {formatDateTimeBR(pro.updatedAt)}</p>}
          </div>
        </aside>
      </div>

      <div className={`sticky-save${dirty ? ' is-visible' : ''}`} aria-hidden={!dirty}>
        <p>
          <Icon name="edit" size={18} /> Alterações não salvas
        </p>
        <div>
          <Button
            variant="ghost"
            size="sm"
            tabIndex={dirty ? 0 : -1}
            onClick={() => {
              setValues(base);
              setErrors({});
            }}
          >
            Descartar
          </Button>
          <Button
            type="submit"
            variant="primary"
            size="sm"
            icon="save"
            iconSize={18}
            loading={saving}
            loadingText="Salvando…"
            tabIndex={dirty ? 0 : -1}
          >
            Salvar perfil
          </Button>
        </div>
      </div>
    </form>
  );
}
