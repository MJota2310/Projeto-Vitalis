import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import { EmptyState, ErrorState, Notice } from '../../components/ui/Feedback';
import { TextField, Toggle } from '../../components/ui/Field';
import { PanelHeader } from '../../components/panel/PanelLayout';
import { useToast } from '../../context/ToastContext';
import { useAsync, useDocumentTitle } from '../../hooks';
import {
  addException,
  getMyProfessional,
  previewSchedule,
  removeException,
  updateWeekly,
} from '../../services/professionalService';
import { DEFAULT_HOURS, SLOT_OPTIONS, validateWeekly } from '../../services/proModel';
import { WEEKDAYS_LONG, WEEKDAYS_SHORT, formatDateBR, formatDateLong, parseISODate, toISODate } from '../../utils/format';
import { usePro } from './ProLayout';

const ORDER = [1, 2, 3, 4, 5, 6, 0];

/** Editor do horário semanal (também usado no onboarding). */
export function WeeklyEditor({
  availability,
  onSaved,
  submitLabel = 'Salvar horários',
  alwaysEnabled = false,
  footerStart = null,
}) {
  const toast = useToast();
  const [weekly, setWeekly] = useState(() => availability.weekly.map((d) => ({ ...d })));
  const [slot, setSlot] = useState(availability.slotMinutes || 60);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);
  const [confirm, setConfirm] = useState('');
  const dirty =
    JSON.stringify(weekly) !== JSON.stringify(availability.weekly) || Number(slot) !== Number(availability.slotMinutes);

  const set = (day, patch) => setWeekly((w) => w.map((d) => (d.day === day ? { ...d, ...patch } : d)));
  const copyToAll = (from) => {
    const src = weekly.find((d) => d.day === from);
    setWeekly((w) =>
      w.map((d) =>
        d.enabled ? { ...d, start: src.start, end: src.end, breakStart: src.breakStart, breakEnd: src.breakEnd } : d,
      ),
    );
    toast.info('Horário copiado', `O horário de ${WEEKDAYS_LONG[from]} foi aplicado aos dias ativos.`);
  };

  const save = async (force = false) => {
    const msg = validateWeekly(weekly);
    setError(msg);
    if (msg) return;
    if (!dirty && alwaysEnabled) {
      onSaved();
      return;
    }
    setSaving(true);
    try {
      await updateWeekly({ weekly, slotMinutes: slot }, { force });
      if (!alwaysEnabled) toast.success('Horários salvos', 'A agenda pública já usa a nova configuração.');
      setConfirm('');
      onSaved();
    } catch (err) {
      if (err.code === 'OUTSIDE_HOURS') setConfirm(err.message);
      else setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="panel-card" aria-labelledby="weekly-title">
      <div className="panel-card__head">
        <div>
          <h2 id="weekly-title" className="panel-card__title">
            <Icon name="calendar_month" size={22} /> Horário semanal
          </h2>
          <p className="panel-card__sub">
            Defina os dias, o expediente e o intervalo. Os clientes só veem horários em que o atendimento inteiro cabe.
          </p>
        </div>
        <label className="slot-select">
          <span>Novos horários a cada</span>
          <select className="select" value={slot} onChange={(e) => setSlot(Number(e.target.value))}>
            {SLOT_OPTIONS.map((m) => (
              <option key={m} value={m}>
                {m} minutos
              </option>
            ))}
          </select>
        </label>
      </div>

      <div className="week-editor" role="table" aria-label="Horário de atendimento por dia">
        <div className="week-editor__row week-editor__row--head" role="row">
          <span role="columnheader">Dia</span>
          <span role="columnheader">Início</span>
          <span role="columnheader">Fim</span>
          <span role="columnheader">Intervalo</span>
          <span role="columnheader" className="sr-only">
            Ações
          </span>
        </div>
        {ORDER.map((day) => {
          const d = weekly.find((x) => x.day === day);
          return (
            <div key={day} className={`week-editor__row${d.enabled ? '' : ' is-off'}`} role="row">
              <span role="cell" className="week-editor__day">
                <Toggle
                  checked={d.enabled}
                  label={`Atender ${WEEKDAYS_LONG[day]}`}
                  onChange={(v) => set(day, { enabled: v, ...(v && !d.start ? DEFAULT_HOURS : {}) })}
                />
                <strong>{WEEKDAYS_LONG[day]}</strong>
              </span>
              {d.enabled ? (
                <>
                  <span role="cell">
                    <input
                      type="time"
                      step={1800}
                      className="input input--time"
                      aria-label={`Início de ${WEEKDAYS_LONG[day]}`}
                      value={d.start}
                      onChange={(e) => set(day, { start: e.target.value })}
                    />
                  </span>
                  <span role="cell">
                    <input
                      type="time"
                      step={1800}
                      className="input input--time"
                      aria-label={`Fim de ${WEEKDAYS_LONG[day]}`}
                      value={d.end}
                      onChange={(e) => set(day, { end: e.target.value })}
                    />
                  </span>
                  <span role="cell" className="week-editor__break">
                    <input
                      type="time"
                      step={1800}
                      className="input input--time"
                      aria-label={`Início do intervalo de ${WEEKDAYS_LONG[day]}`}
                      value={d.breakStart}
                      onChange={(e) => set(day, { breakStart: e.target.value })}
                    />
                    <span aria-hidden="true">–</span>
                    <input
                      type="time"
                      step={1800}
                      className="input input--time"
                      aria-label={`Fim do intervalo de ${WEEKDAYS_LONG[day]}`}
                      value={d.breakEnd}
                      onChange={(e) => set(day, { breakEnd: e.target.value })}
                    />
                  </span>
                  <span role="cell" className="week-editor__act">
                    <button
                      type="button"
                      className="icon-btn"
                      title="Copiar para os dias ativos"
                      aria-label={`Copiar horário de ${WEEKDAYS_LONG[day]} para os dias ativos`}
                      onClick={() => copyToAll(day)}
                    >
                      <Icon name="content_copy" size={18} />
                    </button>
                  </span>
                </>
              ) : (
                <span role="cell" className="week-editor__closed">
                  Sem atendimento
                </span>
              )}
            </div>
          );
        })}
      </div>
      {error && (
        <p className="field__error section-gap" role="alert">
          <Icon name="error" size={16} /> {error}
        </p>
      )}
      <div className="form-actions">
        {footerStart}
        {dirty && (
          <Button
            variant="ghost"
            onClick={() => {
              setWeekly(availability.weekly.map((d) => ({ ...d })));
              setSlot(availability.slotMinutes);
              setError('');
            }}
          >
            Desfazer alterações
          </Button>
        )}
        <Button
          variant="primary"
          icon={alwaysEnabled ? undefined : 'save'}
          iconRight={alwaysEnabled ? 'arrow_forward' : undefined}
          onClick={() => save(false)}
          loading={saving}
          loadingText="Salvando…"
          disabled={!dirty && !alwaysEnabled}
        >
          {submitLabel}
        </Button>
      </div>

      <Modal
        open={!!confirm}
        onClose={() => setConfirm('')}
        title="Agendamentos fora do novo horário"
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirm('')}>
              Revisar
            </Button>
            <Button variant="primary" onClick={() => save(true)} loading={saving}>
              Salvar mesmo assim
            </Button>
          </>
        }
      >
        <Notice tone="warning">{confirm}</Notice>
        <p className="section-gap muted">
          Os agendamentos já marcados não são cancelados automaticamente. Se precisar, cancele-os pela agenda — o cliente é
          avisado.
        </p>
      </Modal>
    </section>
  );
}

function ExceptionModal({ open, onClose, onSaved }) {
  const toast = useToast();
  const today = toISODate(new Date());
  const [form, setForm] = useState({ type: 'bloqueio', date: today, allDay: true, start: '13:00', end: '17:00', reason: '' });
  const [error, setError] = useState({});
  const [saving, setSaving] = useState(false);
  useEffect(() => {
    if (open) {
      setForm({ type: 'bloqueio', date: today, allDay: true, start: '13:00', end: '17:00', reason: '' });
      setError({});
    }
  }, [open, today]);
  const set = (patch) => setForm((f) => ({ ...f, ...patch }));
  const submit = async (e) => {
    e.preventDefault();
    setError({});
    setSaving(true);
    try {
      await addException(form);
      toast.success(form.type === 'bloqueio' ? 'Período bloqueado' : 'Horário especial criado', formatDateLong(form.date));
      onSaved();
      onClose();
    } catch (err) {
      setError({ [err.field || 'form']: err.message });
    } finally {
      setSaving(false);
    }
  };
  const special = form.type === 'horario_especial';
  return (
    <Modal
      open={open}
      onClose={onClose}
      title="Bloqueio ou horário especial"
      width={520}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            Cancelar
          </Button>
          <Button variant="primary" type="submit" form="exception-form" loading={saving} loadingText="Salvando…">
            Salvar
          </Button>
        </>
      }
    >
      <form id="exception-form" className="stack" onSubmit={submit} noValidate>
        <fieldset className="seg" aria-label="Tipo">
          <label className={`seg__opt${!special ? ' is-on' : ''}`}>
            <input
              type="radio"
              name="exc-type"
              className="sr-only"
              checked={!special}
              onChange={() => set({ type: 'bloqueio' })}
            />
            <Icon name="event_busy" size={20} /> Bloquear período
          </label>
          <label className={`seg__opt${special ? ' is-on' : ''}`}>
            <input
              type="radio"
              name="exc-type"
              className="sr-only"
              checked={special}
              onChange={() => set({ type: 'horario_especial', allDay: false })}
            />
            <Icon name="event_upcoming" size={20} /> Horário especial
          </label>
        </fieldset>
        <p className="muted">
          {special
            ? 'Atende em um dia fora da sua rotina (ex.: um sábado) ou com horário diferente. Substitui o horário semanal nessa data.'
            : 'Folga, compromisso ou imprevisto: os horários do período deixam de aparecer para os clientes.'}
        </p>
        <TextField
          label="Data"
          type="date"
          name="exc-date"
          min={today}
          value={form.date}
          onChange={(e) => set({ date: e.target.value })}
          error={error.date}
          required
        />
        {!special && (
          <div className="setting-row">
            <div>
              <p className="setting-row__title">Dia inteiro</p>
              <p className="setting-row__text">Desative para bloquear apenas algumas horas.</p>
            </div>
            <Toggle checked={form.allDay} label="Bloquear o dia inteiro" onChange={(v) => set({ allDay: v })} />
          </div>
        )}
        {(special || !form.allDay) && (
          <div className="form-grid">
            <TextField
              label="Início"
              type="time"
              step={1800}
              name="exc-start"
              value={form.start}
              onChange={(e) => set({ start: e.target.value })}
              error={error.start}
              required
            />
            <TextField
              label="Fim"
              type="time"
              step={1800}
              name="exc-end"
              value={form.end}
              onChange={(e) => set({ end: e.target.value })}
              error={error.end}
              required
            />
          </div>
        )}
        <TextField
          label="Motivo (opcional, só você vê)"
          name="exc-reason"
          maxLength={80}
          placeholder={special ? 'Ex.: Mutirão de avaliações' : 'Ex.: Férias, congresso'}
          value={form.reason}
          onChange={(e) => set({ reason: e.target.value })}
        />
        {error.form && <Notice tone="error">{error.form}</Notice>}
      </form>
    </Modal>
  );
}

function Preview({ version, slotMinutes }) {
  const { data, loading, error, reload } = useAsync(() => previewSchedule(toISODate(new Date()), 7), [version]);
  if (error) return <ErrorState error={error} onRetry={reload} />;
  return (
    <div className={`preview-grid${loading && data ? ' is-refreshing' : ''}`}>
      {!data
        ? Array.from({ length: 7 }, (_, i) => <span key={i} className="skeleton" style={{ height: 120 }} />)
        : data.map((d) => {
            const date = parseISODate(d.date);
            const free = d.slots.filter((s) => s.status === 'livre').length;
            return (
              <div key={d.date} className={`preview-day${d.hours ? '' : ' is-off'}`}>
                <p className="preview-day__head">
                  <strong>{WEEKDAYS_SHORT[date.getDay()]}</strong> {formatDateBR(d.date).slice(0, 5)}
                </p>
                {d.hours ? (
                  <>
                    <p className="preview-day__hours">
                      {d.hours.start}–{d.hours.end}
                    </p>
                    <ul className="preview-day__slots" aria-label={`Horários de ${formatDateLong(d.date)}`}>
                      {d.slots.map((s) => (
                        <li
                          key={s.time}
                          className={`pslot pslot--${s.status}`}
                          title={`${s.time} — ${s.status === 'livre' ? 'livre' : s.status === 'ocupado' ? 'ocupado ou bloqueado' : 'já passou'}`}
                        >
                          {s.time}
                        </li>
                      ))}
                    </ul>
                    <p className="preview-day__free">{free ? `${free} livre(s)` : 'sem horários livres'}</p>
                  </>
                ) : (
                  <p className="preview-day__off">{d.exceptions.find((e) => e.allDay)?.reason || 'Sem atendimento'}</p>
                )}
              </div>
            );
          })}
      <p className="preview-note">
        <span className="pslot pslot--livre">livre</span> <span className="pslot pslot--ocupado">ocupado/bloqueado</span>{' '}
        <span className="pslot pslot--passado">antecedência mínima</span> · Intervalo de {slotMinutes} min entre inícios.
      </p>
    </div>
  );
}

export default function ProSchedulePage() {
  useDocumentTitle('Horários');
  const toast = useToast();
  const { reload: reloadLayout } = usePro();
  const [params, setParams] = useSearchParams();
  const [version, setVersion] = useState(0);
  const { data, loading, error, reload } = useAsync(() => getMyProfessional(), [version]);
  const [modal, setModal] = useState(params.get('novo') === 'bloqueio');
  const [removing, setRemoving] = useState('');

  useEffect(() => {
    if (params.get('novo')) setParams({}, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refresh = () => {
    setVersion((v) => v + 1);
    reloadLayout();
  };
  const today = toISODate(new Date());
  const exceptions = useMemo(
    () => (data?.pro.availability.exceptions || []).filter((e) => e.date >= today).sort((a, b) => a.date.localeCompare(b.date)),
    [data, today],
  );

  const remove = async (exc) => {
    setRemoving(exc.id);
    try {
      await removeException(exc.id);
      toast.success('Exceção removida', formatDateLong(exc.date));
      refresh();
    } catch (err) {
      toast.error('Não foi possível remover', err.message);
    } finally {
      setRemoving('');
    }
  };

  if (error) return <ErrorState error={error} onRetry={reload} />;

  return (
    <div className="pro-schedule">
      <PanelHeader
        eyebrow="Disponibilidade"
        title="Horários de atendimento"
        subtitle="Configure quando você atende. O sistema impede conflitos: nenhum horário fica disponível se sobrepuser outro atendimento, um bloqueio ou o intervalo."
        actions={
          <Button variant="primary" size="sm" icon="event_busy" iconSize={18} onClick={() => setModal(true)}>
            Bloquear horário
          </Button>
        }
      />
      {!data ? (
        <span className="skeleton" style={{ height: 420, display: 'block' }} />
      ) : (
        <div className="panel-stack">
          <WeeklyEditor key={`${version}`} availability={data.pro.availability} onSaved={refresh} />

          <section className="panel-card" aria-labelledby="exc-title">
            <div className="panel-card__head">
              <div>
                <h2 id="exc-title" className="panel-card__title">
                  <Icon name="event_busy" size={22} /> Bloqueios e horários especiais
                </h2>
                <p className="panel-card__sub">
                  Exceções para datas específicas. Bloqueios não podem cobrir horários já agendados.
                </p>
              </div>
              <Button variant="soft-green" size="sm" icon="add" iconSize={18} onClick={() => setModal(true)}>
                Adicionar
              </Button>
            </div>
            {exceptions.length === 0 ? (
              <EmptyState
                icon="event_available"
                title="Nenhuma exceção programada"
                text="Use bloqueios para folgas e imprevistos, e horários especiais para atender fora da rotina."
              />
            ) : (
              <ul className="exc-list">
                {exceptions.map((e) => (
                  <li key={e.id} className={`exc exc--${e.type}`}>
                    <span className="exc__icon">
                      <Icon name={e.type === 'bloqueio' ? 'block' : 'event_upcoming'} size={20} />
                    </span>
                    <span className="exc__body">
                      <strong>{formatDateLong(e.date, true)}</strong>
                      <small>
                        {e.type === 'bloqueio' ? 'Bloqueio' : 'Horário especial'} ·{' '}
                        {e.allDay ? 'dia inteiro' : `${e.start}–${e.end}`}
                        {e.reason ? ` · ${e.reason}` : ''}
                      </small>
                    </span>
                    <Button
                      variant="ghost"
                      size="sm"
                      icon="delete"
                      iconSize={18}
                      loading={removing === e.id}
                      onClick={() => remove(e)}
                      aria-label={`Remover exceção de ${formatDateBR(e.date)}`}
                    >
                      Remover
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="panel-card" aria-labelledby="prev-title">
            <div className="panel-card__head">
              <div>
                <h2 id="prev-title" className="panel-card__title">
                  <Icon name="visibility" size={22} /> Como os clientes veem os próximos 7 dias
                </h2>
                <p className="panel-card__sub">
                  Prévia com a duração mínima de atendimento ({data.pro.availability.slotMinutes} min).
                </p>
              </div>
            </div>
            <Preview version={version} slotMinutes={data.pro.availability.slotMinutes} />
          </section>
        </div>
      )}
      <ExceptionModal open={modal} onClose={() => setModal(false)} onSaved={refresh} />
    </div>
  );
}
