import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import { EmptyState, ErrorState, Notice } from '../../components/ui/Feedback';
import { TextField, Toggle } from '../../components/ui/Field';
import { PanelHeader } from '../../components/panel/PanelLayout';
import { useToast } from '../../context/ToastContext';
import { useAsync, useDocumentTitle } from '../../hooks';
import { deleteOffering, listMyOfferings, saveOffering, setOfferingActive } from '../../services/professionalService';
import { CATALOG_OPTIONS, DURATION_OPTIONS, serviceName, validateOffering } from '../../services/proModel';
import { serviceBySlug, SERVICE_FEE } from '../../data/catalog';
import { formatCurrency } from '../../utils/format';
import { usePro } from './ProLayout';

const EMPTY = { serviceSlug: '', name: '', description: '', duration: 60, price: '' };

/** Formulário de serviço (usado também no onboarding). */
export function OfferingForm({ id = 'offering-form', initial, defaultService, onSubmit, serverError }) {
  const [values, setValues] = useState(() => ({ ...EMPTY, serviceSlug: defaultService || '', ...(initial || {}) }));
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState(false);
  useEffect(() => {
    if (serverError?.field) setErrors((e) => ({ ...e, [serverError.field]: serverError.message }));
  }, [serverError]);
  const set = (k, v) => {
    const next = { ...values, [k]: v };
    setValues(next);
    if (touched) setErrors(validateOffering(next));
  };
  const submit = (e) => {
    e.preventDefault();
    setTouched(true);
    const errs = validateOffering(values);
    setErrors(errs);
    if (Object.keys(errs).length) {
      document.querySelector(`#${id} [name="off-${Object.keys(errs)[0]}"]`)?.focus();
      return;
    }
    onSubmit({ ...values, price: Number(String(values.price).replace(',', '.')) });
  };
  const price = Number(String(values.price).replace(',', '.')) || 0;
  return (
    <form id={id} className="stack" onSubmit={submit} noValidate>
      <TextField
        label="Nome do serviço"
        name="off-name"
        placeholder="Ex.: Sessão de fisioterapia"
        maxLength={60}
        value={values.name}
        onChange={(e) => set('name', e.target.value)}
        error={errors.name}
        required
      />
      <TextField
        as="select"
        label="Categoria no catálogo"
        name="off-serviceSlug"
        value={values.serviceSlug}
        onChange={(e) => set('serviceSlug', e.target.value)}
        error={errors.serviceSlug}
        hint="Define em qual serviço do catálogo você aparece."
        required
      >
        <option value="">Escolha…</option>
        {CATALOG_OPTIONS.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </TextField>
      <TextField
        as="textarea"
        rows={3}
        label="Descrição (opcional)"
        name="off-description"
        maxLength={240}
        placeholder="O que o cliente pode esperar deste atendimento"
        value={values.description}
        onChange={(e) => set('description', e.target.value)}
        error={errors.description}
        hint={`${values.description.length}/240`}
      />
      <div className="form-grid">
        <TextField
          as="select"
          label="Duração"
          name="off-duration"
          value={values.duration}
          onChange={(e) => set('duration', Number(e.target.value))}
          error={errors.duration}
          required
        >
          {DURATION_OPTIONS.map((d) => (
            <option key={d} value={d}>
              {d >= 60 ? `${Math.floor(d / 60)}h${d % 60 ? ` ${d % 60}min` : ''}` : `${d} min`}
            </option>
          ))}
        </TextField>
        <TextField
          label="Preço (R$)"
          name="off-price"
          icon="payments"
          inputMode="decimal"
          placeholder="150,00"
          value={values.price}
          onChange={(e) => set('price', e.target.value.replace(/[^\d,.]/g, ''))}
          error={errors.price}
          required
        />
      </div>
      {price > 0 && (
        <p className="offer-hint">
          <Icon name="info" size={16} /> O cliente verá {formatCurrency(price)} + taxa de serviço de {formatCurrency(SERVICE_FEE)}{' '}
          (retida pela plataforma). Você recebe o valor da consulta.
        </p>
      )}
    </form>
  );
}

function OfferingCard({ o, onEdit, onToggle, onDelete, onView, busy }) {
  const svc = serviceBySlug(o.serviceSlug);
  return (
    <article className={`offer-card${o.active ? '' : ' is-inactive'}`}>
      <div className="offer-card__top">
        <span className={`icon-tile icon-tile--${svc?.tile || 'mint'}`} style={{ '--tile': '46px' }}>
          <Icon name={svc?.icon || 'medical_services'} size={26} />
        </span>
        <div className="offer-card__id">
          <h3>{o.name}</h3>
          <p className="muted">{serviceName(o.serviceSlug)}</p>
        </div>
        <span className={`badge badge--${o.active ? 'green' : 'gray'}`}>{o.active ? 'Ativo' : 'Inativo'}</span>
      </div>
      {o.description && <p className="offer-card__desc">{o.description}</p>}
      <dl className="offer-card__facts">
        <div>
          <dt>Duração</dt>
          <dd>{o.duration} min</dd>
        </div>
        <div>
          <dt>Preço</dt>
          <dd>{formatCurrency(o.price)}</dd>
        </div>
        <div>
          <dt>Agendamentos</dt>
          <dd>
            {o.stats.total}
            {o.stats.upcoming > 0 && <small> ({o.stats.upcoming} futuros)</small>}
          </dd>
        </div>
      </dl>
      <div className="offer-card__actions">
        <span className="offer-card__switch">
          <Toggle
            checked={o.active}
            disabled={busy === o.id}
            label={`${o.active ? 'Desativar' : 'Ativar'} ${o.name}`}
            onChange={(v) => onToggle(o, v)}
          />
          <small>{o.active ? 'Disponível para agendamento' : 'Oculto dos clientes'}</small>
        </span>
        <div className="offer-card__btns">
          <button
            type="button"
            className="icon-btn"
            aria-label={`Visualizar ${o.name}`}
            title="Visualizar"
            onClick={() => onView(o)}
          >
            <Icon name="visibility" size={20} />
          </button>
          <button type="button" className="icon-btn" aria-label={`Editar ${o.name}`} title="Editar" onClick={() => onEdit(o)}>
            <Icon name="edit" size={20} />
          </button>
          <button
            type="button"
            className="icon-btn icon-btn--danger"
            aria-label={`Excluir ${o.name}`}
            title="Excluir"
            onClick={() => onDelete(o)}
          >
            <Icon name="delete" size={20} />
          </button>
        </div>
      </div>
    </article>
  );
}

export default function ProServicesPage() {
  useDocumentTitle('Meus serviços');
  const toast = useToast();
  const { pro, reload: reloadLayout } = usePro();
  const [params, setParams] = useSearchParams();
  const { data, loading, error, reload } = useAsync(() => listMyOfferings(), []);
  const [editing, setEditing] = useState(params.get('novo') ? {} : null);
  const [viewing, setViewing] = useState(null);
  const [deleting, setDeleting] = useState(null);
  const [saving, setSaving] = useState(false);
  const [serverError, setServerError] = useState(null);
  const [busy, setBusy] = useState('');

  useEffect(() => {
    if (params.get('novo')) setParams({}, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const refresh = () => {
    reload();
    reloadLayout();
  };

  const save = async (values) => {
    setSaving(true);
    setServerError(null);
    try {
      await saveOffering({ ...values, id: editing?.id });
      toast.success(editing?.id ? 'Serviço atualizado' : 'Serviço adicionado', values.name);
      setEditing(null);
      refresh();
    } catch (err) {
      setServerError(err);
      if (!err.field) toast.error('Não foi possível salvar', err.message);
    } finally {
      setSaving(false);
    }
  };

  const toggle = async (o, active) => {
    const activeCount = data.filter((x) => x.active).length;
    setBusy(o.id);
    try {
      await setOfferingActive(o.id, active);
      toast.success(active ? 'Serviço ativado' : 'Serviço desativado', o.name);
      if (!active && activeCount === 1) {
        toast.warning('Nenhum serviço ativo', 'Seu perfil deixa de aparecer nas buscas até você ativar um serviço.', {
          duration: 6000,
        });
      }
      refresh();
    } catch (err) {
      toast.error('Não foi possível alterar', err.message);
    } finally {
      setBusy('');
    }
  };

  const confirmDelete = async () => {
    setSaving(true);
    try {
      await deleteOffering(deleting.id);
      toast.success('Serviço excluído', deleting.name);
      setDeleting(null);
      refresh();
    } catch (err) {
      toast.error('Não foi possível excluir', err.message);
      setDeleting(null);
    } finally {
      setSaving(false);
    }
  };

  const list = data || [];
  const active = list.filter((o) => o.active);

  return (
    <div className="pro-services">
      <PanelHeader
        eyebrow="Catálogo"
        title="Meus serviços"
        subtitle="Os serviços ativos aparecem no seu perfil e na agenda pública, com duração e preço próprios."
        actions={
          <Button
            variant="primary"
            size="sm"
            icon="add"
            iconSize={18}
            onClick={() => {
              setServerError(null);
              setEditing({});
            }}
          >
            Adicionar serviço
          </Button>
        }
      />
      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data ? (
        <div className="offer-grid">
          {[0, 1, 2].map((i) => (
            <span key={i} className="skeleton" style={{ height: 230, borderRadius: 18 }} />
          ))}
        </div>
      ) : list.length === 0 ? (
        <div className="panel-card">
          <EmptyState
            icon="medical_services"
            title="Você ainda não cadastrou serviços"
            text="Adicione pelo menos um serviço para aparecer nas buscas e receber agendamentos."
            actions={
              <Button variant="primary" icon="add" onClick={() => setEditing({})}>
                Adicionar primeiro serviço
              </Button>
            }
          />
        </div>
      ) : (
        <>
          {active.length === 0 && (
            <Notice tone="warning" className="section-gap-b">
              Nenhum serviço ativo: seu perfil não aparece nas buscas. Ative pelo menos um serviço.
            </Notice>
          )}
          <p className="offer-summary">
            {active.length} ativo(s) de {list.length} · área principal:{' '}
            <strong>{serviceName(pro.service) || 'não definida'}</strong>
          </p>
          <div className="offer-grid">
            {list.map((o, i) => (
              <div key={o.id} className="offer-grid__item" style={{ animationDelay: `${i * 60}ms` }}>
                <OfferingCard
                  o={o}
                  busy={busy}
                  onEdit={(x) => {
                    setServerError(null);
                    setEditing(x);
                  }}
                  onToggle={toggle}
                  onDelete={setDeleting}
                  onView={setViewing}
                />
              </div>
            ))}
          </div>
        </>
      )}

      <Modal
        open={!!editing}
        onClose={saving ? () => {} : () => setEditing(null)}
        title={editing?.id ? 'Editar serviço' : 'Novo serviço'}
        width={560}
        footer={
          <>
            <Button variant="ghost" onClick={() => setEditing(null)} disabled={saving}>
              Cancelar
            </Button>
            <Button variant="primary" type="submit" form="offering-form" icon="save" loading={saving} loadingText="Salvando…">
              {editing?.id ? 'Salvar alterações' : 'Adicionar serviço'}
            </Button>
          </>
        }
      >
        {editing && (
          <OfferingForm
            key={editing.id || 'new'}
            initial={editing.id ? { ...editing, price: String(editing.price).replace('.', ',') } : null}
            defaultService={pro.service}
            onSubmit={save}
            serverError={serverError}
          />
        )}
      </Modal>

      <Modal open={!!viewing} onClose={() => setViewing(null)} title="Como o cliente vê este serviço" width={460}>
        {viewing && (
          <div className="offer-preview">
            <p className="offer-preview__name">{viewing.name}</p>
            <p className="muted">
              {serviceName(viewing.serviceSlug)} · {viewing.duration} min
            </p>
            {viewing.description && <p>{viewing.description}</p>}
            <div className="summary-rows">
              <div className="summary-row">
                <span>Consulta</span>
                <strong>{formatCurrency(viewing.price)}</strong>
              </div>
              <div className="summary-row">
                <span>Taxa de serviço</span>
                <strong>{formatCurrency(SERVICE_FEE)}</strong>
              </div>
              <div className="summary-row summary-row--total">
                <span>Total para o cliente</span>
                <strong>{formatCurrency(viewing.price + SERVICE_FEE)}</strong>
              </div>
            </div>
            {!viewing.active && <Notice tone="info">Este serviço está inativo e não aparece para os clientes.</Notice>}
          </div>
        )}
      </Modal>

      <Modal
        open={!!deleting}
        onClose={() => setDeleting(null)}
        title="Excluir serviço?"
        footer={
          <>
            <Button variant="ghost" onClick={() => setDeleting(null)}>
              Manter
            </Button>
            <Button variant="danger-solid" onClick={confirmDelete} loading={saving}>
              Excluir
            </Button>
          </>
        }
      >
        {deleting && (
          <p>
            <strong>{deleting.name}</strong> será removido.{' '}
            {deleting.stats.total > 0
              ? 'Como ele já tem agendamentos no histórico, a exclusão não é permitida — você pode desativá-lo.'
              : 'Esta ação não pode ser desfeita.'}
          </p>
        )}
      </Modal>
    </div>
  );
}
