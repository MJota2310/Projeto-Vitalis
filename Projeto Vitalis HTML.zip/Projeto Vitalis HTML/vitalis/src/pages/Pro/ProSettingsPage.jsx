import { useState } from 'react';
import { Link } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import { Notice } from '../../components/ui/Feedback';
import { PanelHeader, ToneBadge } from '../../components/panel/PanelLayout';
import { AccountInfoCard, NotificationPrefsCard, PasswordCard, SessionCard } from '../../components/account/AccountSettings';
import { useToast } from '../../context/ToastContext';
import { useDocumentTitle } from '../../hooks';
import { setProfilePaused } from '../../services/professionalService';
import { BOOKING_WINDOW_DAYS, MIN_NOTICE_MINUTES } from '../../services/catalogService';
import { PRO_STATUS, activeOfferings } from '../../services/proModel';
import { usePro } from './ProLayout';

export default function ProSettingsPage() {
  useDocumentTitle('Configurações');
  const toast = useToast();
  const { pro, reload } = usePro();
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const status = PRO_STATUS[pro.status] || PRO_STATUS.rascunho;
  const days = (pro.availability?.weekly || []).filter((d) => d.enabled).length;

  const togglePause = async () => {
    setBusy(true);
    try {
      const pausing = pro.status === 'publicado';
      await setProfilePaused(pausing);
      await reload();
      setConfirm(false);
      toast.success(
        pausing ? 'Perfil pausado' : 'Perfil reativado',
        pausing ? 'Você não aparece nas buscas até reativar.' : 'Seu perfil voltou a aparecer nas buscas.',
      );
    } catch (err) {
      toast.error('Não foi possível alterar', err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="pro-settings">
      <PanelHeader
        eyebrow="Conta"
        title="Configurações"
        subtitle="Dados de acesso, agenda, privacidade, notificações e segurança."
      />

      <div className="panel-grid panel-grid--2">
        <div className="panel-stack">
          <AccountInfoCard photoHint="A foto da conta também aparece no seu perfil público." />

          <section className="panel-card" aria-labelledby="vis-title">
            <h2 id="vis-title" className="panel-card__title">
              <Icon name="travel_explore" size={22} /> Visibilidade do perfil
            </h2>
            <div className="setting-row section-gap">
              <div>
                <p className="setting-row__title">
                  <ToneBadge tone={status.tone} icon={status.icon}>
                    {status.label}
                  </ToneBadge>
                </p>
                <p className="setting-row__text">{status.text}</p>
              </div>
              {(pro.status === 'publicado' || pro.status === 'pausado') && (
                <Button
                  variant={pro.status === 'publicado' ? 'outline' : 'primary'}
                  size="sm"
                  icon={pro.status === 'publicado' ? 'pause_circle' : 'play_circle'}
                  iconSize={18}
                  onClick={() => (pro.status === 'publicado' ? setConfirm(true) : togglePause())}
                  loading={busy && pro.status === 'pausado'}
                >
                  {pro.status === 'publicado' ? 'Pausar perfil' : 'Reativar perfil'}
                </Button>
              )}
              {(pro.status === 'rascunho' || pro.status === 'recusado') && (
                <Button variant="primary" size="sm" to="/profissional/onboarding" iconRight="arrow_forward" iconSize={18}>
                  Concluir cadastro
                </Button>
              )}
            </div>
          </section>

          <PasswordCard />
        </div>

        <div className="panel-stack">
          <section className="panel-card" aria-labelledby="ag-title">
            <h2 id="ag-title" className="panel-card__title">
              <Icon name="calendar_month" size={22} /> Agenda
            </h2>
            <dl className="pf-facts">
              <div>
                <dt>Dias de atendimento</dt>
                <dd>{days ? `${days} por semana` : 'Nenhum'}</dd>
              </div>
              <div>
                <dt>Intervalo entre inícios</dt>
                <dd>{pro.availability?.slotMinutes || 60} min</dd>
              </div>
              <div>
                <dt>Serviços ativos</dt>
                <dd>{activeOfferings(pro).length}</dd>
              </div>
              <div>
                <dt>Exceções futuras</dt>
                <dd>
                  {(pro.availability?.exceptions || []).filter((e) => e.date >= new Date().toISOString().slice(0, 10)).length}
                </dd>
              </div>
            </dl>
            <ul className="hint-list section-gap">
              <li>
                <Icon name="event" size={16} /> Clientes podem agendar com até {BOOKING_WINDOW_DAYS} dias de antecedência e no
                mínimo {MIN_NOTICE_MINUTES / 60} hora antes.
              </li>
              <li>
                <Icon name="hourglass_empty" size={16} /> Agendamentos sem pagamento são liberados automaticamente quando o
                horário passa.
              </li>
              <li>
                <Icon name="event_busy" size={16} /> Cancelamentos feitos por você geram reembolso integral ao cliente.
              </li>
            </ul>
            <div className="form-actions">
              <Button variant="outline" size="sm" to="/profissional/servicos" icon="medical_services" iconSize={18}>
                Serviços
              </Button>
              <Button variant="soft-green" size="sm" to="/profissional/horarios" icon="more_time" iconSize={18}>
                Editar horários
              </Button>
            </div>
          </section>

          <section className="panel-card" aria-labelledby="priv-title">
            <h2 id="priv-title" className="panel-card__title">
              <Icon name="shield" size={22} /> Privacidade
            </h2>
            <ul className="hint-list section-gap">
              <li>
                <Icon name={pro.publicContact?.showPhone ? 'visibility' : 'visibility_off'} size={16} /> Telefone no perfil
                público: <strong>{pro.publicContact?.showPhone ? 'visível' : 'oculto'}</strong>
              </li>
              <li>
                <Icon name={pro.publicContact?.showEmail ? 'visibility' : 'visibility_off'} size={16} /> E-mail no perfil público:{' '}
                <strong>{pro.publicContact?.showEmail ? 'visível' : 'oculto'}</strong>
              </li>
              <li>
                <Icon name="lock" size={16} /> Você vê o contato do cliente somente enquanto houver um agendamento ativo.
              </li>
              <li>
                <Icon name="clinical_notes" size={16} /> O Vitalis não guarda prontuários nem dados clínicos dos atendimentos.
              </li>
            </ul>
            <p className="section-gap">
              <Link to="/profissional/perfil" className="text-link">
                Alterar contato público no perfil profissional
              </Link>
              {' · '}
              <Link to="/privacidade" className="text-link">
                Política de privacidade
              </Link>
            </p>
          </section>

          <NotificationPrefsCard reminderText="Aviso dentro do Vitalis 24 horas antes de cada atendimento marcado." />
          <SessionCard />
        </div>
      </div>

      <Modal
        open={confirm}
        onClose={() => setConfirm(false)}
        title="Pausar o perfil?"
        footer={
          <>
            <Button variant="ghost" onClick={() => setConfirm(false)}>
              Manter publicado
            </Button>
            <Button variant="primary" onClick={togglePause} loading={busy}>
              Pausar perfil
            </Button>
          </>
        }
      >
        <Notice tone="info">
          Seu perfil deixa de aparecer nas buscas e ninguém consegue fazer novos agendamentos. Os atendimentos já marcados
          continuam valendo.
        </Notice>
      </Modal>
    </div>
  );
}
