import { useEffect } from 'react';
import { Link } from 'react-router-dom';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState } from '../../components/ui/Feedback';
import ProfessionalCard, { ProfessionalCardSkeleton } from '../../components/booking/ProfessionalCard';
import FavoriteButton from '../../components/booking/FavoriteButton';
import { ProAvatar } from '../../components/ui/Avatar';
import { useAsync, useDocumentTitle } from '../../hooks';
import { listFavorites } from '../../services/favoriteService';
import { formatDateBR } from '../../utils/format';
import './professionals.css';

/** Profissionais salvos pelo usuário. */
export default function FavoritesPage() {
  useDocumentTitle('Favoritos');
  const { data, loading, error, reload, setData } = useAsync(() => listFavorites(), []);

  // remove da lista assim que o coração é desmarcado
  useEffect(() => {
    const onChange = () =>
      listFavorites()
        .then(setData)
        .catch(() => {});
    window.addEventListener('vitalis:db', onChange);
    return () => window.removeEventListener('vitalis:db', onChange);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const list = data || [];

  return (
    <div className="container page favorites-page">
      <nav className="breadcrumb" aria-label="Você está em">
        <ol>
          <li>
            <Link to="/painel">Dashboard</Link>
          </li>
          <li aria-current="page">Favoritos</li>
        </ol>
      </nav>
      <header className="page-header">
        <h1 className="page-title">Favoritos</h1>
        <p className="page-subtitle">Profissionais que você salvou para agendar de novo com facilidade.</p>
      </header>

      {error ? (
        <ErrorState error={error} onRetry={reload} />
      ) : !data ? (
        <div className="pro-list">
          <ProfessionalCardSkeleton />
          <ProfessionalCardSkeleton />
        </div>
      ) : list.length === 0 ? (
        <EmptyState
          icon="favorite"
          title="Nenhum favorito ainda"
          text="Toque no coração no perfil ou na busca de profissionais para salvar aqui."
          actions={
            <Button variant="primary" to="/profissionais" icon="person_search">
              Buscar profissionais
            </Button>
          }
        />
      ) : (
        <div className="pro-list">
          {list.map((p, i) =>
            p.available ? (
              <div key={p.id} className="pro-list__item" style={{ animationDelay: `${i * 40}ms` }}>
                <ProfessionalCard pro={p} profileLink favorite actionTo={`/agendar?profissional=${p.id}`} showService />
                <p className="fav-saved">Salvo em {formatDateBR(p.savedAt.slice(0, 10))}</p>
              </div>
            ) : (
              <div key={p.id} className="pro-list__item">
                <article className="pro-item pro-item--unavailable">
                  <ProAvatar pro={p} size={null} />
                  <div className="pro-item__body">
                    <h3 className="pro-item__name">{p.name}</h3>
                    <p className="pro-item__spec">{p.specialty}</p>
                    <p className="muted">Este perfil não está recebendo agendamentos no momento.</p>
                  </div>
                  <FavoriteButton proId={p.id} name={p.name} className="pro-item__fav" />
                </article>
              </div>
            ),
          )}
        </div>
      )}
    </div>
  );
}
