import { useMemo } from 'react';
import { Link, useParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState, Notice, Skeleton, Stars } from '../../components/ui/Feedback';
import { ProAvatar } from '../../components/ui/Avatar';
import FavoriteButton from '../../components/booking/FavoriteButton';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useAsync, useDocumentTitle } from '../../hooks';
import { getPublicProfessional, nextAvailableDates } from '../../services/catalogService';
import { MODALITIES, serviceName } from '../../services/proModel';
import { SERVICE_FEE } from '../../data/catalog';
import { WEEKDAYS_LONG, WEEKDAYS_SHORT, formatCurrency, formatDateLong, relativeDay } from '../../utils/format';
import './professionals.css';

const ORDER = [1, 2, 3, 4, 5, 6, 0];

/** Perfil público de um profissional (somente perfis publicados). */
export default function ProfessionalProfilePage() {
  const { id } = useParams();
  const { user, role } = useAuth();
  const toast = useToast();
  const { data: pro, loading, error, reload } = useAsync(() => getPublicProfessional(id), [id]);
  useDocumentTitle(pro ? pro.name : loading ? 'Profissional' : 'Profissional não encontrado');

  const minDuration = useMemo(() => Math.min(...(pro?.offerings || []).map((o) => Number(o.duration) || 60), 60), [pro]);
  const next = useMemo(() => (pro ? nextAvailableDates(pro, 4, minDuration) : []), [pro, minDuration]);
  const own = !!(pro && user && pro.userId === user.id);
  const canBook = role !== 'admin' && !own;

  if (error) return <ErrorState error={error} onRetry={reload} />;
  if (loading && !pro) {
    return (
      <div className="container page pro-profile-page">
        <div className="pp-hero">
          <Skeleton width={120} height={120} radius={24} />
          <div style={{ flex: 1 }}>
            <Skeleton width="50%" height={28} />
            <Skeleton width="30%" height={16} style={{ marginTop: 12 }} />
            <Skeleton width="40%" height={16} style={{ marginTop: 12 }} />
          </div>
        </div>
      </div>
    );
  }
  if (!pro) {
    return (
      <div className="container page">
        <EmptyState
          icon="person_off"
          title="Perfil indisponível"
          text="Este profissional não existe ou não está recebendo agendamentos no momento."
          actions={
            <Button variant="primary" to="/profissionais">
              Ver outros profissionais
            </Button>
          }
        />
      </div>
    );
  }

  const modality = MODALITIES.find((m) => m.id === pro.modality);
  const weekly = pro.availability?.weekly || [];
  const share = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) await navigator.share({ title: pro.name, url });
      else {
        await navigator.clipboard.writeText(url);
        toast.success('Link copiado');
      }
    } catch {
      /* compartilhamento cancelado */
    }
  };

  return (
    <div className="container page pro-profile-page">
      <nav className="breadcrumb" aria-label="Você está em">
        <ol>
          <li>
            <Link to="/">Início</Link>
          </li>
          <li>
            <Link to="/profissionais">Profissionais</Link>
          </li>
          <li aria-current="page">{pro.name}</li>
        </ol>
      </nav>

      {own && (
        <Notice tone="info" className="pp-own">
          Este é o seu perfil público.{' '}
          <Link to="/profissional/perfil" className="text-link">
            Editar perfil
          </Link>
        </Notice>
      )}

      <header className="pp-hero">
        <ProAvatar pro={pro} size={120} className="pp-hero__avatar" />
        <div className="pp-hero__copy">
          <h1 className="page-title">{pro.name}</h1>
          <p className="pp-hero__title">
            {pro.title}
            {pro.specialty && pro.specialty !== pro.title ? ` · ${pro.specialty}` : ''}
          </p>
          <div className="pp-hero__tags">
            {pro.verified && (
              <span className="badge badge--green">
                <Icon name="verified" size={15} /> Perfil verificado
              </span>
            )}
            {pro.rating ? (
              <Stars rating={pro.rating} reviews={pro.reviews} size={15} />
            ) : (
              <span className="badge badge--blue">
                <Icon name="fiber_new" size={15} /> Novo no Vitalis
              </span>
            )}
            {pro.city && (
              <span className="pp-tag">
                <Icon name="distance" size={17} /> {pro.city}
              </span>
            )}
            {modality && (
              <span className="pp-tag">
                <Icon name={modality.icon} size={17} /> {modality.label}
              </span>
            )}
          </div>
        </div>
        <div className="pp-hero__actions">
          {canBook && (
            <Button variant="primary" to={`/agendar?profissional=${pro.id}`} icon="calendar_today">
              Agendar
            </Button>
          )}
          {!own && <FavoriteButton proId={pro.id} name={pro.name} withLabel />}
          <button type="button" className="icon-btn" onClick={share} aria-label="Compartilhar perfil" title="Compartilhar">
            <Icon name="share" size={22} />
          </button>
        </div>
      </header>

      <div className="pp-grid">
        <div className="stack" style={{ '--stack-gap': '20px' }}>
          <section className="card card--pad" aria-labelledby="pp-about">
            <h2 id="pp-about" className="detail-title">
              Sobre
            </h2>
            <p className="pp-bio">{pro.bio || 'Este profissional ainda não escreveu uma apresentação.'}</p>
            {(pro.education?.length > 0 || pro.experienceYears || pro.experience) && (
              <div className="pp-cv">
                {pro.education?.length > 0 && (
                  <div>
                    <h3>Formação</h3>
                    <ul>
                      {pro.education.map((e) => (
                        <li key={e}>
                          <Icon name="school" size={18} /> {e}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {(pro.experienceYears || pro.experience) && (
                  <div>
                    <h3>Experiência</h3>
                    <ul>
                      {pro.experienceYears ? (
                        <li>
                          <Icon name="work_history" size={18} /> {pro.experienceYears} ano(s) de atuação
                        </li>
                      ) : null}
                      {pro.experience && (
                        <li>
                          <Icon name="workspace_premium" size={18} /> {pro.experience}
                        </li>
                      )}
                    </ul>
                  </div>
                )}
              </div>
            )}
            {pro.registry?.council && (
              <p className="pp-registry">
                <Icon name="badge" size={16} /> Registro profissional: {pro.registry.council} {pro.registry.number}/
                {pro.registry.uf}
              </p>
            )}
            {pro.simulated && <p className="pp-registry">Perfil fictício, criado para demonstrar a plataforma.</p>}
          </section>

          <section className="card card--pad" aria-labelledby="pp-services">
            <h2 id="pp-services" className="detail-title">
              Serviços e valores
            </h2>
            {pro.offerings.length === 0 ? (
              <p className="muted">Nenhum serviço disponível no momento.</p>
            ) : (
              <ul className="pp-offers">
                {pro.offerings.map((o) => (
                  <li key={o.id}>
                    <div className="pp-offers__body">
                      <strong>{o.name}</strong>
                      <small>
                        {serviceName(o.serviceSlug)} · {o.duration} min
                      </small>
                      {o.description && <p>{o.description}</p>}
                    </div>
                    <div className="pp-offers__side">
                      <span className="pp-offers__price">{formatCurrency(o.price)}</span>
                      {canBook && (
                        <Button variant="soft-green" size="sm" to={`/agendar?profissional=${pro.id}&oferta=${o.id}`}>
                          Agendar
                        </Button>
                      )}
                    </div>
                  </li>
                ))}
              </ul>
            )}
            <p className="pp-fee">
              + taxa de serviço de {formatCurrency(SERVICE_FEE)} por agendamento. Cancelamento com reembolso total até 24h antes.
            </p>
          </section>
        </div>

        <aside className="stack" style={{ '--stack-gap': '20px' }}>
          <section className="card card--pad" aria-labelledby="pp-next">
            <h2 id="pp-next" className="detail-title">
              Próximas datas com horário livre
            </h2>
            {next.length === 0 ? (
              <p className="muted">Sem horários livres nos próximos dias.</p>
            ) : (
              <ul className="pp-dates">
                {next.map((d) => (
                  <li key={d.date}>
                    {canBook ? (
                      <Link to={`/agendar?profissional=${pro.id}`} className="pp-date">
                        <span>
                          <strong>{formatDateLong(d.date)}</strong>
                          <small>{relativeDay(d.date)}</small>
                        </span>
                        <span className="pp-date__free">{d.free} livre(s)</span>
                      </Link>
                    ) : (
                      <span className="pp-date">
                        <span>
                          <strong>{formatDateLong(d.date)}</strong>
                          <small>{relativeDay(d.date)}</small>
                        </span>
                        <span className="pp-date__free">{d.free} livre(s)</span>
                      </span>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="card card--pad" aria-labelledby="pp-hours">
            <h2 id="pp-hours" className="detail-title">
              Dias de atendimento
            </h2>
            <ul className="pp-hours">
              {ORDER.map((day) => {
                const w = weekly.find((x) => x.day === day);
                return (
                  <li key={day} className={w?.enabled ? '' : 'is-off'}>
                    <span title={WEEKDAYS_LONG[day]}>{WEEKDAYS_SHORT[day]}</span>
                    <span>{w?.enabled ? `${w.start}–${w.end}` : 'Fechado'}</span>
                  </li>
                );
              })}
            </ul>
            <p className="pp-fee">Datas especiais e bloqueios podem alterar estes horários.</p>
          </section>

          {(pro.contact?.phone || pro.contact?.email || pro.address) && (
            <section className="card card--pad" aria-labelledby="pp-contact">
              <h2 id="pp-contact" className="detail-title">
                Contato e local
              </h2>
              <ul className="pp-contact">
                {pro.address && (
                  <li>
                    <Icon name="location_on" size={18} /> {pro.address}
                  </li>
                )}
                {pro.contact?.phone && (
                  <li>
                    <Icon name="call" size={18} /> <a href={`tel:${pro.contact.phone.replace(/\D/g, '')}`}>{pro.contact.phone}</a>
                  </li>
                )}
                {pro.contact?.email && (
                  <li>
                    <Icon name="mail" size={18} /> <a href={`mailto:${pro.contact.email}`}>{pro.contact.email}</a>
                  </li>
                )}
              </ul>
            </section>
          )}
        </aside>
      </div>
    </div>
  );
}
