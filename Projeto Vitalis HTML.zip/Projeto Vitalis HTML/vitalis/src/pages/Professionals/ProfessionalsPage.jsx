import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState } from '../../components/ui/Feedback';
import ProfessionalCard, { ProfessionalCardSkeleton } from '../../components/booking/ProfessionalCard';
import { useAsync, useDocumentTitle } from '../../hooks';
import { enabledServices, listCities, listProfessionals } from '../../services/catalogService';
import { MODALITIES } from '../../services/proModel';
import { WEEKDAYS_LONG, formatCurrency } from '../../utils/format';
import './professionals.css';

const SORTS = [
  { id: '', label: 'Relevância' },
  { id: 'preco', label: 'Menor preço' },
  { id: 'nota', label: 'Mais bem avaliados' },
  { id: 'nome', label: 'Nome (A–Z)' },
  { id: 'novos', label: 'Mais recentes' },
];
const PRICES = [100, 150, 200, 300];
const KEYS = ['q', 'servico', 'cidade', 'modalidade', 'ate', 'dia', 'ordem'];

/** Busca avançada de profissionais (filtros sincronizados com a URL). */
export default function ProfessionalsPage() {
  useDocumentTitle('Profissionais');
  const [params, setParams] = useSearchParams();
  const [query, setQuery] = useState(params.get('q') || '');
  const [showFilters, setShowFilters] = useState(false);
  const f = Object.fromEntries(KEYS.map((k) => [k, params.get(k) || '']));
  const services = useMemo(() => enabledServices(), []);
  const cities = useMemo(() => listCities(), []);

  // busca digitada → URL (com atraso)
  useEffect(() => {
    const t = setTimeout(() => {
      if ((params.get('q') || '') !== query.trim()) setParam('q', query.trim());
    }, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query]);

  function setParam(key, value) {
    const next = new URLSearchParams(params);
    if (value === '' || value == null) next.delete(key);
    else next.set(key, value);
    setParams(next, { replace: true });
  }

  const clear = () => {
    setQuery('');
    setParams(new URLSearchParams(), { replace: true });
  };

  const { data, loading, error, reload } = useAsync(
    () =>
      listProfessionals({
        query: f.q,
        service: f.servico,
        city: f.cidade,
        modality: f.modalidade,
        maxPrice: Number(f.ate) || 0,
        weekday: f.dia,
        sort: f.ordem,
      }),
    [f.q, f.servico, f.cidade, f.modalidade, f.ate, f.dia, f.ordem],
  );

  const active = KEYS.filter((k) => k !== 'ordem' && f[k]).length;
  const list = data || [];

  return (
    <div className="container page pros-page">
      <header className="page-header text-center">
        <h1 className="page-title">Encontre um profissional</h1>
        <p className="page-subtitle">
          Filtre por serviço, cidade, modalidade, preço e dia da semana. Veja o perfil e agende direto.
        </p>
      </header>

      <div className="pros-search" role="search">
        <div className="field field--icon field--action pros-search__q">
          <label htmlFor="pros-q" className="sr-only">
            Buscar por nome, especialidade ou serviço
          </label>
          <div className="field__control">
            <Icon name="search" size={20} className="field__icon" />
            <input
              id="pros-q"
              className="input"
              type="search"
              placeholder="Nome, especialidade ou serviço"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              autoComplete="off"
            />
            {query && (
              <button type="button" className="field__action" onClick={() => setQuery('')} aria-label="Limpar busca">
                <Icon name="close" size={18} />
              </button>
            )}
          </div>
        </div>
        <Button
          variant="outline"
          className="pros-search__toggle"
          icon="tune"
          onClick={() => setShowFilters((v) => !v)}
          aria-expanded={showFilters}
          aria-controls="pros-filters"
        >
          Filtros{active ? ` (${active})` : ''}
        </Button>
      </div>

      <div className="pros-layout">
        <aside id="pros-filters" className={`pros-filters${showFilters ? ' is-open' : ''}`} aria-label="Filtros">
          <div className="pros-filters__head">
            <h2 className="pros-filters__title">Filtros</h2>
            {active > 0 && (
              <button type="button" className="text-link" onClick={clear}>
                Limpar tudo
              </button>
            )}
          </div>
          <label className="pros-filter">
            <span>Serviço</span>
            <select className="select" value={f.servico} onChange={(e) => setParam('servico', e.target.value)}>
              <option value="">Todos os serviços</option>
              {services.map((s) => (
                <option key={s.slug} value={s.slug}>
                  {s.name}
                </option>
              ))}
            </select>
          </label>
          <label className="pros-filter">
            <span>Cidade</span>
            <select className="select" value={f.cidade} onChange={(e) => setParam('cidade', e.target.value)}>
              <option value="">Todas as cidades</option>
              {cities.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </label>
          <fieldset className="pros-filter">
            <legend>Modalidade</legend>
            <div className="chip-row chip-row--wrap">
              {[{ id: '', label: 'Todas' }, ...MODALITIES.filter((m) => m.id !== 'ambos')].map((m) => (
                <button
                  key={m.id || 'all'}
                  type="button"
                  className="chip chip--sm"
                  aria-pressed={f.modalidade === m.id}
                  onClick={() => setParam('modalidade', m.id)}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </fieldset>
          <fieldset className="pros-filter">
            <legend>Preço da consulta</legend>
            <div className="chip-row chip-row--wrap">
              <button type="button" className="chip chip--sm" aria-pressed={!f.ate} onClick={() => setParam('ate', '')}>
                Qualquer
              </button>
              {PRICES.map((p) => (
                <button
                  key={p}
                  type="button"
                  className="chip chip--sm"
                  aria-pressed={f.ate === String(p)}
                  onClick={() => setParam('ate', String(p))}
                >
                  até {formatCurrency(p).replace(',00', '')}
                </button>
              ))}
            </div>
          </fieldset>
          <label className="pros-filter">
            <span>Atende às</span>
            <select className="select" value={f.dia} onChange={(e) => setParam('dia', e.target.value)}>
              <option value="">Qualquer dia</option>
              {[1, 2, 3, 4, 5, 6, 0].map((d) => (
                <option key={d} value={d}>
                  {WEEKDAYS_LONG[d].replace(/^./, (c) => c.toUpperCase())}s
                </option>
              ))}
            </select>
          </label>
          <Button variant="primary" block className="pros-filters__done" onClick={() => setShowFilters(false)}>
            Ver {list.length} resultado(s)
          </Button>
        </aside>

        <section className="pros-results" aria-labelledby="pros-results-title">
          <div className="pros-results__head">
            <h2 id="pros-results-title" className="card-title" aria-live="polite">
              {loading && !data ? 'Buscando…' : `${list.length} ${list.length === 1 ? 'profissional' : 'profissionais'}`}
            </h2>
            <label className="pros-sort">
              <span>Ordenar por</span>
              <select className="select" value={f.ordem} onChange={(e) => setParam('ordem', e.target.value)}>
                {SORTS.map((s) => (
                  <option key={s.id || 'rel'} value={s.id}>
                    {s.label}
                  </option>
                ))}
              </select>
            </label>
          </div>
          {f.ordem === 'nota' && (
            <p className="pros-note">
              As notas exibidas pertencem aos perfis fictícios do catálogo de demonstração. Perfis novos aparecem como “Novo no
              Vitalis”.
            </p>
          )}

          {error ? (
            <ErrorState error={error} onRetry={reload} />
          ) : !data ? (
            <div className="pro-list">
              <ProfessionalCardSkeleton />
              <ProfessionalCardSkeleton />
              <ProfessionalCardSkeleton />
            </div>
          ) : list.length === 0 ? (
            <EmptyState
              icon="person_search"
              title="Nenhum profissional encontrado"
              text="Tente remover algum filtro ou buscar por outro termo."
              actions={
                <Button variant="outline" size="sm" icon="refresh" onClick={clear}>
                  Limpar filtros
                </Button>
              }
            />
          ) : (
            <div className={`pro-list${loading ? ' is-refreshing' : ''}`}>
              {list.map((p, i) => (
                <div key={p.id} className="pro-list__item" style={{ animationDelay: `${Math.min(i, 10) * 40}ms` }}>
                  <ProfessionalCard
                    pro={p}
                    showService={!f.servico}
                    profileLink
                    favorite
                    actionTo={`/agendar?profissional=${p.id}${f.servico ? `&servico=${f.servico}` : ''}`}
                  />
                </div>
              ))}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
