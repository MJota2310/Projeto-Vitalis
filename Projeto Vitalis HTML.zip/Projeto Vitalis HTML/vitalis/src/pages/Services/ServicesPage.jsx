import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState } from '../../components/ui/Feedback';
import ServiceCard, { ServiceCardSkeleton } from '../../components/services/ServiceCard';
import { CATEGORIES, categoryCount } from '../../data/catalog';
import { listServices } from '../../services/catalogService';
import { useAsync, useDocumentTitle } from '../../hooks';
import './services.css';

const VALID = CATEGORIES.map((c) => c.id);

export default function ServicesPage() {
  const [params, setParams] = useSearchParams();
  const navigate = useNavigate();
  const categoryParam = params.get('categoria');
  const category = VALID.includes(categoryParam) ? categoryParam : 'todas';
  const [query, setQuery] = useState(params.get('q') || '');
  const [debounced, setDebounced] = useState(query);
  const current = CATEGORIES.find((c) => c.id === category);

  useDocumentTitle(category === 'todas' ? 'Todos os serviços' : `Serviços de ${current.label}`);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(query), 250);
    return () => clearTimeout(t);
  }, [query]);

  // mantém a URL sincronizada (compartilhável e com botão voltar funcionando)
  useEffect(() => {
    const next = new URLSearchParams(params);
    if (debounced.trim()) next.set('q', debounced.trim());
    else next.delete('q');
    if (next.toString() !== params.toString()) setParams(next, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debounced]);

  const { data, loading, error, reload } = useAsync(() => listServices({ category, query: debounced }), [category, debounced]);

  const selectCategory = (id) => {
    const next = new URLSearchParams(params);
    if (id === 'todas') next.delete('categoria');
    else next.set('categoria', id);
    setParams(next);
  };

  const counts = useMemo(() => Object.fromEntries(CATEGORIES.map((c) => [c.id, categoryCount(c.id)])), []);

  return (
    <div className="services-page">
      <div className="container page">
        <button type="button" className="back-link" onClick={() => (window.history.length > 1 ? navigate(-1) : navigate('/'))}>
          <Icon name="arrow_left_alt" size={26} /> Voltar
        </button>

        <header className="page-header text-center">
          <h1 className="page-title">Todos os serviços</h1>
          <p className="page-subtitle">
            Explore nossa ampla variedade de serviços de saúde e bem-estar com profissionais qualificados
          </p>
        </header>

        <div className="filter-bar" role="search">
          <div className="filter-bar__chips" role="group" aria-label="Filtrar por categoria">
            {CATEGORIES.map((c) => (
              <button
                key={c.id}
                type="button"
                className="chip"
                aria-pressed={category === c.id}
                onClick={() => selectCategory(c.id)}
              >
                {c.label} <span className="chip__count">({counts[c.id]})</span>
              </button>
            ))}
          </div>
          <div className="filter-bar__search field field--icon field--action">
            <label htmlFor="service-search" className="sr-only">
              Buscar serviço ou profissional
            </label>
            <div className="field__control">
              <Icon name="search" size={20} className="field__icon" />
              <input
                id="service-search"
                className="input"
                type="search"
                placeholder="Buscar serviço ou profissional…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                autoComplete="off"
              />
              {query && (
                <button type="button" className="field__action" onClick={() => setQuery('')} aria-label="Limpar busca">
                  <Icon name="close" size={18} />
                </button>
              )}
            </div>
          </div>
        </div>

        <h2 className="sr-only">Lista de serviços</h2>
        <div className="services-page__status" aria-live="polite">
          {!loading && data && (
            <p>
              {data.length === 0
                ? 'Nenhum serviço encontrado'
                : `${data.length} ${data.length === 1 ? 'serviço' : 'serviços'}${category !== 'todas' ? ` em ${current.label}` : ''}${debounced ? ` para “${debounced}”` : ''}`}
            </p>
          )}
        </div>

        {error ? (
          <ErrorState error={error} onRetry={reload} />
        ) : loading ? (
          <div className="service-grid">
            {Array.from({ length: 6 }, (_, i) => (
              <ServiceCardSkeleton key={i} />
            ))}
          </div>
        ) : data.length === 0 ? (
          <EmptyState
            icon="search"
            title="Nenhum serviço encontrado"
            text={`Não encontramos resultados${debounced ? ` para “${debounced}”` : ''}${category !== 'todas' ? ` na categoria ${current.label}` : ''}. Tente outro termo ou veja todas as categorias.`}
            actions={
              <>
                <Button
                  variant="outline"
                  size="sm"
                  icon="refresh"
                  onClick={() => {
                    setQuery('');
                    setDebounced('');
                    setParams(new URLSearchParams());
                  }}
                >
                  Limpar filtros
                </Button>
                <Button variant="primary" size="sm" to="/ajuda?secao=contato">
                  Falar com suporte
                </Button>
              </>
            }
          />
        ) : (
          <div className="service-grid" key={`${category}-${debounced}`}>
            {data.map((s, i) => (
              <ServiceCard key={s.slug} service={s} style={{ animationDelay: `${i * 45}ms` }} />
            ))}
          </div>
        )}

        <section className="help-banner" aria-labelledby="help-banner-title">
          <h2 id="help-banner-title">Não encontrou o que procura?</h2>
          <p>Entre em contato conosco e ajudaremos você a encontrar o profissional ideal para suas necessidades</p>
          <Button variant="light" to="/ajuda?secao=contato">
            Falar com suporte
          </Button>
        </section>
      </div>
    </div>
  );
}
