// Área administrativa: indicadores, moderação de profissionais, usuários,
// catálogo, agendamentos, pagamentos, solicitações de suporte e
// configurações da plataforma. Todas as funções exigem papel "admin".

import { getDb, mutate, resetDb } from './db';
import { ApiError, delay } from './api';
import { requireUser } from './session';
import { pushNotification } from './notificationService';
import { syncStatuses } from './appointmentService';
import { publicUser } from './authService';
import { activeOfferings, completeness } from './proModel';
import { SERVICES } from '../data/catalog';
import { normalize, toDateTime, toISODate } from '../utils/format';

const admin = () => requireUser(['admin']);

function synced() {
  return mutate((db) => {
    syncStatuses(db);
    return db;
  });
}

const paidStatuses = new Set(['aprovado']);

/** Indicadores gerais (dados da demonstração). */
export async function getAdminOverview() {
  await delay(250, 500);
  admin();
  const db = synced();
  const now = new Date();
  const monthKey = toISODate(now).slice(0, 7);
  const approved = db.payments.filter((p) => paidStatuses.has(p.status));
  const byStatus = ['agendada', 'pendente_pagamento', 'concluida', 'cancelada'].map((s) => ({
    status: s,
    count: db.appointments.filter((a) => a.status === s).length,
  }));
  const byService = SERVICES.map((s) => ({
    slug: s.slug,
    name: s.name,
    count: db.appointments.filter((a) => a.serviceSlug === s.slug && a.status !== 'cancelada').length,
  }))
    .filter((x) => x.count > 0)
    .sort((a, b) => b.count - a.count)
    .slice(0, 6);
  const months = [];
  for (let i = 5; i >= 0; i -= 1) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const appts = db.appointments.filter((a) => a.date.startsWith(key) && a.status !== 'cancelada' && a.paymentId);
    months.push({
      key,
      month: d.getMonth(),
      year: d.getFullYear(),
      value: appts.reduce((s, a) => s + (a.fee || 0), 0),
      count: appts.length,
    });
  }
  return {
    users: {
      total: db.users.length,
      patients: db.users.filter((u) => u.role === 'usuario').length,
      professionals: db.users.filter((u) => u.role === 'profissional').length,
      suspended: db.users.filter((u) => u.status === 'suspenso').length,
    },
    professionals: {
      published: db.professionals.filter((p) => p.status === 'publicado').length,
      pending: db.professionals.filter((p) => p.status === 'em_analise').length,
      draft: db.professionals.filter((p) => p.status === 'rascunho').length,
      paused: db.professionals.filter((p) => p.status === 'pausado' || p.status === 'suspenso').length,
    },
    appointments: {
      total: db.appointments.length,
      month: db.appointments.filter((a) => a.date.startsWith(monthKey)).length,
      upcoming: db.appointments.filter((a) => a.status === 'agendada' && toDateTime(a.date, a.time) > now).length,
      byStatus,
      byService,
    },
    revenue: {
      fees: db.appointments.filter((a) => a.status !== 'cancelada' && a.paymentId).reduce((s, a) => s + (a.fee || 0), 0),
      volume: approved.reduce((s, p) => s + p.amount, 0),
      refunded: db.payments.filter((p) => p.status === 'reembolsado').reduce((s, p) => s + p.amount, 0),
      months,
    },
    services: {
      total: SERVICES.length,
      enabled: SERVICES.length - (db.settings?.disabledServices || []).length,
    },
    tickets: {
      open: db.tickets.filter((t) => t.status !== 'resolvido').length,
      total: db.tickets.length,
    },
    pendingPros: db.professionals
      .filter((p) => p.status === 'em_analise')
      .map((p) => ({ id: p.id, name: p.name, title: p.title, submittedAt: p.submittedAt })),
    demo: true,
  };
}

// ------------------------------------------------------------------ usuários

export async function listUsers({ query = '', role = '', status = '' } = {}) {
  await delay(200, 450);
  admin();
  const db = getDb();
  const q = normalize(query.trim());
  return db.users
    .filter((u) => (!role || u.role === role) && (!status || (u.status || 'ativo') === status))
    .filter((u) => !q || normalize(`${u.name} ${u.email}`).includes(q))
    .map((u) => ({
      ...publicUser(u),
      status: u.status || 'ativo',
      canLogin: !!u.password,
      appointments: db.appointments.filter((a) => a.userId === u.id).length,
    }))
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

export async function setUserStatus(userId, status) {
  await delay(300, 500);
  const me = admin();
  if (!['ativo', 'suspenso'].includes(status)) throw new ApiError('Situação inválida.', 'VALIDATION');
  if (userId === me.id) throw new ApiError('Você não pode suspender a sua própria conta.', 'SELF_ACTION');
  return mutate((db) => {
    const u = db.users.find((x) => x.id === userId);
    if (!u) throw new ApiError('Usuário não encontrado.', 'NOT_FOUND');
    if (u.role === 'admin' && status === 'suspenso') {
      throw new ApiError('Contas administrativas não podem ser suspensas por aqui.', 'FORBIDDEN');
    }
    u.status = status;
    u.updatedAt = new Date().toISOString();
    if (status === 'ativo') {
      pushNotification(db, u.id, {
        type: 'sistema',
        title: 'Conta reativada',
        text: 'Sua conta foi reativada pela equipe Vitalis.',
      });
    }
    return publicUser(u);
  });
}

// ------------------------------------------------------------------ profissionais

export async function listProfessionalsAdmin({ query = '', status = '' } = {}) {
  await delay(200, 450);
  admin();
  const db = getDb();
  const q = normalize(query.trim());
  return db.professionals
    .filter((p) => !status || p.status === status)
    .filter((p) => !q || normalize(`${p.name} ${p.title} ${p.specialty} ${p.city}`).includes(q))
    .map((p) => {
      const owner = p.userId ? db.users.find((u) => u.id === p.userId) : null;
      return {
        ...structuredClone(p),
        owner: owner ? { id: owner.id, email: owner.email, name: owner.name, status: owner.status } : null,
        progress: completeness(p),
        activeOfferings: activeOfferings(p).length,
        appointments: db.appointments.filter((a) => a.professionalId === p.id).length,
      };
    })
    .sort((a, b) => {
      const rank = { em_analise: 0, recusado: 1, rascunho: 2, publicado: 3, pausado: 4, suspenso: 5 };
      return (rank[a.status] ?? 9) - (rank[b.status] ?? 9) || a.name.localeCompare(b.name, 'pt-BR');
    });
}

/**
 * Moderação: aprovar (publica), pedir ajustes, suspender ou reativar.
 * O profissional é avisado por notificação em cada decisão.
 */
export async function reviewProfessional(id, action, note = '') {
  await delay(350, 650);
  admin();
  const text = String(note || '')
    .trim()
    .slice(0, 400);
  if (action === 'ajustes' && text.length < 10) {
    throw new ApiError('Explique o que precisa ser ajustado (mínimo de 10 caracteres).', 'VALIDATION', 'note');
  }
  return mutate((db) => {
    const p = db.professionals.find((x) => x.id === id);
    if (!p) throw new ApiError('Profissional não encontrado.', 'NOT_FOUND');
    const now = new Date().toISOString();
    const allowed = {
      aprovar: ['em_analise', 'recusado'],
      ajustes: ['em_analise'],
      suspender: ['publicado', 'pausado', 'em_analise'],
      reativar: ['suspenso'],
    };
    if (!allowed[action]) throw new ApiError('Ação inválida.', 'VALIDATION');
    if (!allowed[action].includes(p.status))
      throw new ApiError('Esta ação não se aplica à situação atual do perfil.', 'INVALID_STATE');
    if (action === 'aprovar') {
      if (!activeOfferings(p).length) throw new ApiError('O perfil não tem serviços ativos.', 'INCOMPLETE');
      p.status = 'publicado';
      p.verified = true;
      p.publishedAt = now;
      p.reviewNote = text;
      pushNotification(db, p.userId, {
        type: 'sistema',
        title: 'Perfil aprovado e publicado',
        text: 'Seu perfil foi verificado e já aparece nas buscas. Bons atendimentos!',
        link: '/profissional',
        important: true,
      });
    } else if (action === 'ajustes') {
      p.status = 'recusado';
      p.reviewNote = text;
      pushNotification(db, p.userId, {
        type: 'aviso',
        title: 'Ajustes solicitados no seu perfil',
        text,
        link: '/profissional/perfil',
        important: true,
      });
    } else if (action === 'suspender') {
      p.status = 'suspenso';
      p.reviewNote = text;
      pushNotification(db, p.userId, {
        type: 'aviso',
        title: 'Perfil suspenso',
        text: text || 'Seu perfil foi suspenso pela administração. Fale com o suporte.',
        link: '/ajuda?secao=contato',
        important: true,
      });
    } else if (action === 'reativar') {
      p.status = 'publicado';
      p.reviewNote = '';
      pushNotification(db, p.userId, {
        type: 'sistema',
        title: 'Perfil reativado',
        text: 'Seu perfil voltou a aparecer nas buscas.',
        link: '/profissional',
      });
    }
    p.reviewedAt = now;
    p.updatedAt = now;
    return structuredClone(p);
  });
}

// ------------------------------------------------------------------ catálogo

export async function listCatalogAdmin() {
  await delay(200, 400);
  admin();
  const db = getDb();
  const disabled = new Set(db.settings?.disabledServices || []);
  return SERVICES.map((s) => {
    const pros = db.professionals.filter((p) => p.status === 'publicado' && activeOfferings(p, s.slug).length);
    const prices = pros.flatMap((p) => activeOfferings(p, s.slug).map((o) => o.price));
    return {
      ...s,
      enabled: !disabled.has(s.slug),
      professionals: pros.length,
      offerings: pros.reduce((n, p) => n + activeOfferings(p, s.slug).length, 0),
      appointments: db.appointments.filter((a) => a.serviceSlug === s.slug).length,
      priceRange: prices.length ? [Math.min(...prices), Math.max(...prices)] : null,
    };
  });
}

export async function setServiceEnabled(slug, enabled) {
  await delay(250, 450);
  admin();
  if (!SERVICES.some((s) => s.slug === slug)) throw new ApiError('Serviço não encontrado.', 'NOT_FOUND');
  return mutate((db) => {
    const set = new Set(db.settings.disabledServices || []);
    if (enabled) set.delete(slug);
    else set.add(slug);
    db.settings.disabledServices = [...set];
    return { slug, enabled };
  });
}

// ------------------------------------------------------------------ agendamentos e pagamentos

export async function listAllAppointments({ query = '', status = '', from = '', to = '' } = {}) {
  await delay(250, 500);
  admin();
  const db = synced();
  const q = normalize(query.trim());
  return db.appointments
    .filter((a) => (!status || a.status === status) && (!from || a.date >= from) && (!to || a.date <= to))
    .filter((a) => !q || normalize(`${a.protocol} ${a.clientName} ${a.professionalName} ${a.serviceName}`).includes(q))
    .sort((a, b) => toDateTime(b.date, b.time) - toDateTime(a.date, a.time))
    .map((a) => ({ ...a, payment: db.payments.find((p) => p.id === a.paymentId) || null }));
}

export async function listAllPayments({ status = '', method = '' } = {}) {
  await delay(250, 500);
  admin();
  const db = getDb();
  return db.payments
    .filter((p) => (!status || p.status === status) && (!method || p.method === method))
    .map((p) => {
      const a = db.appointments.find((x) => x.id === p.appointmentId) || null;
      return {
        ...p,
        appointment: a
          ? { id: a.id, protocol: a.protocol, clientName: a.clientName, professionalName: a.professionalName, fee: a.fee }
          : null,
      };
    })
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

// ------------------------------------------------------------------ solicitações

export const TICKET_STATUS = {
  aberto: { label: 'Aberta', tone: 'yellow' },
  em_andamento: { label: 'Em andamento', tone: 'blue' },
  resolvido: { label: 'Resolvida', tone: 'green' },
};

export async function listTickets({ status = '' } = {}) {
  await delay(200, 400);
  admin();
  return getDb()
    .tickets.map((t) => ({ ...t, status: t.status === 'registrado' ? 'aberto' : t.status }))
    .filter((t) => !status || t.status === status)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

export async function updateTicket(id, { status, adminNote }) {
  await delay(250, 450);
  admin();
  if (status && !TICKET_STATUS[status]) throw new ApiError('Situação inválida.', 'VALIDATION');
  return mutate((db) => {
    const t = db.tickets.find((x) => x.id === id);
    if (!t) throw new ApiError('Solicitação não encontrada.', 'NOT_FOUND');
    if (status) t.status = status;
    if (adminNote !== undefined) t.adminNote = String(adminNote).trim().slice(0, 500);
    t.updatedAt = new Date().toISOString();
    if (status === 'resolvido' && t.userId) {
      pushNotification(db, t.userId, {
        type: 'sistema',
        title: 'Solicitação resolvida',
        text: `Sua solicitação ${t.protocol} (${t.subject}) foi marcada como resolvida.`,
        link: '/ajuda',
      });
    }
    return { ...t };
  });
}

// ------------------------------------------------------------------ configurações

export async function getPlatformSettings() {
  await delay(150, 300);
  admin();
  return structuredClone(getDb().settings);
}

export async function updateAnnouncement({ active, text, tone }) {
  await delay(250, 450);
  admin();
  const clean = String(text || '').trim();
  if (active && (clean.length < 10 || clean.length > 180)) {
    throw new ApiError('O aviso deve ter entre 10 e 180 caracteres.', 'VALIDATION', 'text');
  }
  if (!['info', 'warning', 'success'].includes(tone)) throw new ApiError('Tom inválido.', 'VALIDATION');
  return mutate((db) => {
    db.settings.announcement = { active: !!active, text: clean, tone, updatedAt: new Date().toISOString() };
    return structuredClone(db.settings);
  });
}

/** Restaura todos os dados de demonstração (apaga as alterações feitas neste navegador). */
export async function resetDemoData() {
  await delay(400, 700);
  admin();
  await resetDb();
  return true;
}

/** Aviso global (lido por qualquer visitante — não exige papel). */
export function getAnnouncement() {
  const a = getDb().settings?.announcement;
  return a?.active && a.text ? a : null;
}

/** Contadores do menu da administração (sem latência; 0 se não for admin). */
export function adminBadges() {
  try {
    const me = admin();
    const db = getDb();
    return {
      pendingPros: db.professionals.filter((p) => p.status === 'em_analise').length,
      openTickets: db.tickets.filter((t) => t.status !== 'resolvido').length,
      unread: db.notifications.filter((n) => n.userId === me.id && !n.read).length,
    };
  } catch {
    return { pendingPros: 0, openTickets: 0, unread: 0 };
  }
}
