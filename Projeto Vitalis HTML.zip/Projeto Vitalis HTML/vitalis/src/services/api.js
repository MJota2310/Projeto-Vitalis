// Utilitários compartilhados pela camada de serviços simulada.
// Todas as funções dos serviços são assíncronas e retornam Promises, com a
// mesma "forma" que teriam ao chamar uma API REST — assim, trocar para um
// backend real exige apenas reescrever o corpo de cada serviço.

export class ApiError extends Error {
  constructor(message, code = 'ERROR', field) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.field = field;
  }
}

/** Latência artificial para simular a rede (desativada em testes via ?fast). */
export function delay(min = 250, max = 650) {
  const fast = typeof window !== 'undefined' && /[?&]fast\b/.test(window.location.search);
  const ms = fast ? 0 : Math.round(min + Math.random() * (max - min));
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function uid(prefix = 'id') {
  const rnd = Math.random().toString(36).slice(2, 8);
  return `${prefix}_${Date.now().toString(36)}${rnd}`;
}

/** Protocolo no formato do Figma: VIT-12345 */
export function makeProtocol(existing = []) {
  let code;
  do {
    code = `VIT-${Math.floor(10000 + Math.random() * 90000)}`;
  } while (existing.includes(code));
  return code;
}

/** Hash determinístico simples (usado para gerar ocupação fictícia de agenda). */
export function hashString(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i += 1) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}
