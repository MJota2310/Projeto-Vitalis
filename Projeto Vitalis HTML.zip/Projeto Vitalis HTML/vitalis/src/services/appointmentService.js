// Consultas / agendamentos do usuário (paciente).

import { getDb, mutate } from './db';
import { ApiError, delay, makeProtocol, uid } from './api';
import { isServiceEnabled, isSlotAvailable } from './catalogService';
import { assertSelf, requireUser } from './session';
import { pushNotification, whenText } from './notificationService';
import { resolveOffering } from './proModel';
import { serviceBySlug, SERVICE_FEE } from '../data/catalog';
import { hoursUntil, toDateTime, formatDateBR } from '../utils/format';

export const STATUS = {
  pendente_pagamento: { label: 'Pagamento pendente', tone: 'yellow', icon: 'hourglass_empty' },
  agendada: { label: 'Aguardando', tone: 'blue', icon: 'alarm' },
  concluida: { label: 'Concluída', tone: 'green', icon: 'check_circle' },
  cancelada: { label: 'Cancelada', tone: 'red', icon: 'cancel' },
};

export const CANCEL_REFUND_HOURS = 24; // "cancele até 24h antes e receba reembolso total"
export const RESCHEDULE_MIN_HOURS = 24;
export const REMINDER_HOURS = 24;

const proUserId = (db, proId) => db.professionals.find((p) => p.id === proId)?.userId || null;

/**
 * Atualiza situações que dependem do tempo:
 * - consultas confirmadas cujo horário já terminou → concluídas;
 * - agendamentos não pagos cujo horário já começou → cancelados (expirados);
 * - lembretes dentro da plataforma 24h antes da consulta.
 */
export function syncStatuses(db) {
  const now = Date.now();
  let changed = false;
  db.appointments.forEach((a) => {
    const start = toDateTime(a.date, a.time).getTime();
    const end = start + (Number(a.duration) || 60) * 60 * 1000;
    if (a.status === 'agendada' && end < now) {
      a.status = 'concluida';
      a.history = [...(a.history || []), { at: new Date().toISOString(), label: 'Consulta realizada' }];
      changed = true;
    } else if (a.status === 'pendente_pagamento' && start < now) {
      a.status = 'cancelada';
      a.canceledBy = 'sistema';
      a.canceledAt = new Date().toISOString();
      a.history = [...(a.history || []), { at: a.canceledAt, label: 'Agendamento expirado sem pagamento' }];
      pushNotification(db, a.userId, {
        type: 'cancelamento',
        title: 'Agendamento expirado',
        text: `${a.serviceName} com ${a.professionalName} (${whenText(a)}) não foi pago a tempo e o horário foi liberado.`,
        link: `/consultas/${a.id}`,
      });
      changed = true;
    } else if (a.status === 'agendada' && !a.reminderSent && start > now && start - now <= REMINDER_HOURS * 36e5) {
      a.reminderSent = true;
      const owner = db.users.find((u) => u.id === a.userId);
      if (owner?.prefs?.reminders !== false) {
        pushNotification(db, a.userId, {
          type: 'lembrete',
          title: 'Lembrete de consulta',
          text: `${a.serviceName} com ${a.professionalName} ${whenText(a)}.`,
          link: `/consultas/${a.id}`,
        });
      }
      const proUser = db.users.find((u) => u.id === proUserId(db, a.professionalId));
      if (proUser && proUser.prefs?.reminders !== false) {
        pushNotification(db, proUser.id, {
          type: 'lembrete',
          title: 'Atendimento nas próximas 24h',
          text: `${a.clientName || 'Cliente'} · ${a.offeringName || a.serviceName} ${whenText(a)}.`,
          link: '/profissional/agenda',
        });
      }
      changed = true;
    }
  });
  return changed;
}

function withPayment(db, appt) {
  const payment = db.payments.find((p) => p.id === appt.paymentId) || null;
  const attempts = db.payments.filter((p) => p.appointmentId === appt.id);
  return { ...appt, payment, attempts };
}

function sortAppointments(list) {
  const rank = { pendente_pagamento: 0, agendada: 1, concluida: 2, cancelada: 3 };
  return [...list].sort((a, b) => {
    if (rank[a.status] !== rank[b.status]) return rank[a.status] - rank[b.status];
    const ta = toDateTime(a.date, a.time).getTime();
    const tb = toDateTime(b.date, b.time).getTime();
    // futuras: mais próximas primeiro; passadas: mais recentes primeiro
    return a.status === 'agendada' || a.status === 'pendente_pagamento' ? ta - tb : tb - ta;
  });
}

export async function listAppointments(userId) {
  await delay(300, 650);
  assertSelf(userId);
  const db = mutate((d) => {
    syncStatuses(d);
    return d;
  });
  return sortAppointments(db.appointments.filter((a) => a.userId === userId)).map((a) => withPayment(db, a));
}

export async function getAppointment(userId, id) {
  await delay(200, 450);
  assertSelf(userId);
  const db = mutate((d) => {
    syncStatuses(d);
    return d;
  });
  const appt = db.appointments.find((a) => a.id === id && a.userId === userId);
  if (!appt) throw new ApiError('Consulta não encontrada.', 'NOT_FOUND');
  return withPayment(db, appt);
}

export function computeStats(list) {
  return {
    total: list.length,
    concluidas: list.filter((a) => a.status === 'concluida').length,
    agendadas: list.filter((a) => a.status === 'agendada').length,
    pendentes: list.filter((a) => a.status === 'pendente_pagamento').length,
    canceladas: list.filter((a) => a.status === 'cancelada').length,
  };
}

/** Cria a consulta com status "pagamento pendente" (confirmada após o pagamento). */
export async function createAppointment(userId, { serviceSlug, professionalId, offeringId, date, time }) {
  await delay(500, 900);
  const user = requireUser(['usuario', 'profissional']);
  assertSelf(userId);
  const db = getDb();
  const pro = db.professionals.find((p) => p.id === professionalId);
  if (!pro || pro.status !== 'publicado') {
    throw new ApiError('Este profissional não está recebendo agendamentos no momento.', 'INVALID_SELECTION');
  }
  if (pro.userId && pro.userId === user.id) {
    throw new ApiError('Você não pode agendar um horário com o seu próprio perfil.', 'SELF_BOOKING');
  }
  const offering = resolveOffering(pro, serviceSlug, offeringId);
  const service = serviceBySlug(offering?.serviceSlug);
  if (!offering || !service || (serviceSlug && offering.serviceSlug !== serviceSlug && !offeringId)) {
    throw new ApiError('Profissional ou serviço inválido. Refaça a seleção.', 'INVALID_SELECTION');
  }
  if (!isServiceEnabled(service.slug)) {
    throw new ApiError('Este serviço está temporariamente indisponível.', 'SERVICE_DISABLED');
  }
  if (!isSlotAvailable(pro.id, date, time, { duration: offering.duration })) {
    throw new ApiError('Este horário acabou de ficar indisponível. Escolha outro horário.', 'SLOT_TAKEN', 'time');
  }
  return mutate((d) => {
    const now = new Date().toISOString();
    const appt = {
      id: uid('apt'),
      protocol: makeProtocol(d.appointments.map((a) => a.protocol)),
      userId,
      clientName: user.name,
      serviceSlug: service.slug,
      serviceName: service.name,
      offeringId: offering.id,
      offeringName: offering.name,
      duration: Number(offering.duration) || 60,
      professionalId: pro.id,
      professionalName: pro.name,
      specialty: pro.specialty,
      location: pro.city,
      date,
      time,
      price: offering.price,
      fee: SERVICE_FEE,
      total: offering.price + SERVICE_FEE,
      status: 'pendente_pagamento',
      createdAt: now,
      updatedAt: now,
      paymentId: null,
      history: [{ at: now, label: 'Agendamento criado — aguardando pagamento' }],
    };
    d.appointments.push(appt);
    return { ...appt, payment: null, attempts: [] };
  });
}

export function cancellationPolicy(appt) {
  const hours = hoursUntil(appt.date, appt.time);
  const paid = appt.status === 'agendada';
  return {
    hours,
    canCancel: appt.status === 'agendada' || appt.status === 'pendente_pagamento',
    refundable: paid && hours >= CANCEL_REFUND_HOURS,
    canReschedule: (appt.status === 'agendada' || appt.status === 'pendente_pagamento') && hours >= RESCHEDULE_MIN_HOURS,
  };
}

export async function cancelAppointment(userId, id, reason = '') {
  await delay(500, 900);
  assertSelf(userId);
  return mutate((db) => {
    const appt = db.appointments.find((a) => a.id === id && a.userId === userId);
    if (!appt) throw new ApiError('Consulta não encontrada.', 'NOT_FOUND');
    const policy = cancellationPolicy(appt);
    if (!policy.canCancel) throw new ApiError('Esta consulta não pode mais ser cancelada.', 'NOT_CANCELABLE');
    const wasPaid = appt.status === 'agendada';
    const now = new Date().toISOString();
    appt.status = 'cancelada';
    appt.canceledAt = now;
    appt.canceledBy = 'cliente';
    appt.cancelReason = reason.trim();
    appt.updatedAt = now;
    const payment = db.payments.find((p) => p.id === appt.paymentId);
    if (payment && payment.status === 'aprovado') {
      if (policy.refundable) {
        payment.status = 'reembolsado';
        appt.refund = { amount: payment.amount, status: 'reembolsado' };
        appt.history.push({ at: now, label: 'Consulta cancelada com reembolso total' });
      } else {
        appt.refund = { amount: 0, status: 'fora_do_prazo' };
        appt.history.push({ at: now, label: 'Consulta cancelada com menos de 24h de antecedência' });
      }
    } else {
      appt.history.push({ at: now, label: 'Agendamento cancelado antes do pagamento' });
    }
    if (wasPaid) {
      pushNotification(db, proUserId(db, appt.professionalId), {
        type: 'cancelamento',
        title: 'Agendamento cancelado pelo cliente',
        text: `${appt.clientName || 'Cliente'} cancelou ${appt.offeringName || appt.serviceName} de ${whenText(appt)}. O horário foi liberado.`,
        link: '/profissional/agenda',
      });
    }
    return withPayment(db, appt);
  });
}

export async function rescheduleAppointment(userId, id, { date, time }) {
  await delay(500, 900);
  assertSelf(userId);
  const current = getDb().appointments.find((a) => a.id === id && a.userId === userId);
  if (!current) throw new ApiError('Consulta não encontrada.', 'NOT_FOUND');
  if (!cancellationPolicy(current).canReschedule) {
    throw new ApiError('A remarcação só é possível até 24h antes do horário marcado.', 'NOT_RESCHEDULABLE');
  }
  if (current.date === date && current.time === time) {
    throw new ApiError('Escolha uma data ou horário diferente do atual.', 'SAME_SLOT');
  }
  if (!isSlotAvailable(current.professionalId, date, time, { ignoreAppointmentId: id, duration: current.duration })) {
    throw new ApiError('Este horário não está mais disponível. Escolha outro.', 'SLOT_TAKEN', 'time');
  }
  return mutate((db) => {
    const appt = db.appointments.find((a) => a.id === id);
    const now = new Date().toISOString();
    const before = `${formatDateBR(appt.date)} ${appt.time}`;
    appt.history.push({
      at: now,
      label: `Remarcada de ${before} para ${formatDateBR(date)} ${time}`,
    });
    appt.date = date;
    appt.time = time;
    appt.updatedAt = now;
    appt.reminderSent = false;
    if (appt.status === 'agendada') {
      pushNotification(db, proUserId(db, appt.professionalId), {
        type: 'remarcacao',
        title: 'Horário alterado pelo cliente',
        text: `${appt.clientName || 'Cliente'} remarcou de ${before} para ${whenText(appt)}.`,
        link: '/profissional/agenda',
      });
    }
    return withPayment(db, appt);
  });
}
