// Autenticação (modo demonstração, 100% local).
// Para integrar um backend real, substitua o corpo destas funções por chamadas
// HTTP (ex.: POST /auth/login) mantendo as mesmas assinaturas.

import { getDb, mutate } from './db';
import { ApiError, delay, uid } from './api';
import { assertSelf, clearSession, readSession, writeSession, currentUserRecord } from './session';
import { emptyAvailability, syncDerived } from './proModel';
import { hashPassword, verifyPassword } from '../utils/crypto';
import { normalize } from '../utils/format';

/** Remove campos sensíveis antes de expor o usuário à interface. */
export function publicUser(user) {
  if (!user) return null;
  // eslint-disable-next-line no-unused-vars
  const { password, ...rest } = user;
  return rest;
}

function findByEmail(email) {
  const target = String(email).trim().toLowerCase();
  return getDb().users.find((u) => u.email.toLowerCase() === target) || null;
}

export function getSessionUser() {
  return publicUser(currentUserRecord());
}

/** Dados da sessão atual (para a tela de configurações). */
export function getSessionInfo() {
  const s = readSession();
  return s ? { createdAt: s.createdAt, remember: !!s.remember } : null;
}

export async function login({ email, password, remember }) {
  await delay(450, 800);
  const user = findByEmail(email);
  const ok = user && user.password ? await verifyPassword(password, user.password) : false;
  if (!ok) throw new ApiError('E-mail ou senha incorretos.', 'INVALID_CREDENTIALS');
  if (user.status === 'suspenso') {
    throw new ApiError('Esta conta está suspensa. Fale com o suporte para mais informações.', 'ACCOUNT_SUSPENDED');
  }
  writeSession(user.id, remember);
  const updated = mutate((db) => {
    const u = db.users.find((x) => x.id === user.id);
    u.lastLoginAt = new Date().toISOString();
    return u;
  });
  return publicUser(updated);
}

function slugify(text) {
  return normalize(text)
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 40);
}

/** Rascunho de perfil criado no cadastro de um profissional (completado no onboarding). */
export function createDraftProfessional(db, user) {
  const id = `${slugify(user.name) || 'profissional'}-${uid('').slice(-5)}`;
  const pro = syncDerived({
    id,
    userId: user.id,
    name: user.name,
    namePrefix: '',
    gender: null,
    title: '',
    specialty: '',
    service: '',
    bio: '',
    education: [],
    experienceYears: null,
    experience: '',
    registry: { council: '', number: '', uf: 'SP' },
    city: '',
    address: '',
    modality: 'presencial',
    photo: null,
    publicContact: { showPhone: false, showEmail: false },
    status: 'rascunho',
    verified: false,
    rating: null,
    reviews: null,
    simulated: false,
    offerings: [],
    availability: emptyAvailability(),
    onboardingStep: 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  });
  db.professionals.push(pro);
  return pro;
}

export async function register({ name, email, phone, password, role }) {
  await delay(500, 900);
  if (findByEmail(email)) {
    throw new ApiError('Já existe uma conta com este e-mail.', 'EMAIL_IN_USE', 'email');
  }
  const hashed = await hashPassword(password);
  const user = mutate((db) => {
    const isPro = role === 'profissional';
    const u = {
      id: uid('usr'),
      role: isPro ? 'profissional' : 'usuario',
      status: 'ativo',
      name: name.trim().replace(/\s+/g, ' '),
      email: email.trim().toLowerCase(),
      phone,
      birthDate: '',
      address: '',
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      password: hashed,
      prefs: isPro
        ? { twoFactor: false, notifyEmail: true, notifySms: false, notifyWhatsapp: false, notifySystem: true, reminders: true }
        : { twoFactor: false, notifyEmail: true, notifySms: false, notifyWhatsapp: false },
    };
    db.users.push(u);
    if (isPro) u.professionalId = createDraftProfessional(db, u).id;
    return u;
  });
  writeSession(user.id, true);
  return publicUser(user);
}

export async function logout() {
  await delay(150, 300);
  clearSession();
}

export async function updateProfile(userId, data) {
  await delay(400, 700);
  assertSelf(userId);
  const email = data.email?.trim().toLowerCase();
  const other = email ? findByEmail(email) : null;
  if (other && other.id !== userId) {
    throw new ApiError('Este e-mail já está em uso por outra conta.', 'EMAIL_IN_USE', 'email');
  }
  const updated = mutate((db) => {
    const u = db.users.find((x) => x.id === userId);
    if (!u) throw new ApiError('Usuário não encontrado.', 'NOT_FOUND');
    Object.assign(u, {
      name: data.name.trim().replace(/\s+/g, ' '),
      email,
      phone: data.phone,
      ...(data.birthDate !== undefined ? { birthDate: data.birthDate } : {}),
      ...(data.address !== undefined ? { address: data.address.trim() } : {}),
      ...(data.photo !== undefined ? { photo: data.photo } : {}),
      updatedAt: new Date().toISOString(),
    });
    // a foto da conta do profissional também é a foto do perfil público
    if (data.photo !== undefined && u.professionalId) {
      const pro = db.professionals.find((p) => p.id === u.professionalId && p.userId === u.id);
      if (pro) pro.photo = data.photo;
    }
    return u;
  });
  return publicUser(updated);
}

export async function updatePreferences(userId, prefs) {
  await delay(200, 400);
  assertSelf(userId);
  const updated = mutate((db) => {
    const u = db.users.find((x) => x.id === userId);
    if (!u) throw new ApiError('Usuário não encontrado.', 'NOT_FOUND');
    u.prefs = { ...u.prefs, ...prefs };
    return u;
  });
  return publicUser(updated);
}

export async function changePassword(userId, currentPassword, newPassword) {
  await delay(500, 800);
  assertSelf(userId);
  const user = getDb().users.find((u) => u.id === userId);
  if (!user) throw new ApiError('Usuário não encontrado.', 'NOT_FOUND');
  const ok = await verifyPassword(currentPassword, user.password);
  if (!ok) throw new ApiError('A senha atual está incorreta.', 'INVALID_PASSWORD', 'current');
  const same = await verifyPassword(newPassword, user.password);
  if (same) throw new ApiError('A nova senha deve ser diferente da atual.', 'SAME_PASSWORD', 'next');
  const hashed = await hashPassword(newPassword);
  mutate((db) => {
    const u = db.users.find((x) => x.id === userId);
    u.password = hashed;
    u.passwordChangedAt = new Date().toISOString();
  });
  return true;
}

/**
 * Recuperação de senha. Sem servidor de e-mail na demonstração, apenas
 * valida a solicitação — a interface informa claramente que nenhum e-mail é
 * enviado. A resposta é a mesma exista ou não a conta (boa prática de segurança).
 */
export async function requestPasswordReset(email) {
  await delay(500, 800);
  return { email: String(email).trim().toLowerCase(), sent: false, demo: true };
}
