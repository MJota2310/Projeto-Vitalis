// Catálogo: serviços, profissionais publicados e disponibilidade de agenda.
// Os perfis vêm do banco local (db.professionals) — inclusive os criados e
// editados pelos próprios profissionais — e só aparecem quando publicados.

import { SERVICES, PROFESSIONALS, serviceBySlug, servicesInCategory } from '../data/catalog';
import { getDb } from './db';
import { delay, hashString } from './api';
import {
  activeOfferings,
  apptRange,
  candidateStarts,
  dayHours,
  overlaps,
  partialBlocks,
  resolveOffering,
  toHHMM,
  toMinutes,
} from './proModel';
import { normalize, parseISODate, toDateTime, toISODate, addDays } from '../utils/format';

export const BOOKING_WINDOW_DAYS = 45;
export const MIN_NOTICE_MINUTES = 60;

const ownerActive = (db, p) => !p.userId || db.users.find((u) => u.id === p.userId)?.status !== 'suspenso';

/** Serviços do catálogo liberados pela administração. */
export function enabledServices() {
  const disabled = new Set(getDb().settings?.disabledServices || []);
  return SERVICES.filter((s) => !disabled.has(s.slug));
}

export function isServiceEnabled(slug) {
  return !(getDb().settings?.disabledServices || []).includes(slug);
}

/** Profissionais visíveis ao público (publicados, com serviço ativo e conta ativa). */
export function publicProfessionals() {
  const db = getDb();
  const disabled = new Set(db.settings?.disabledServices || []);
  return (db.professionals || []).filter(
    (p) => p.status === 'publicado' && ownerActive(db, p) && activeOfferings(p).some((o) => !disabled.has(o.serviceSlug)),
  );
}

export function offersService(p, slug) {
  return activeOfferings(p, slug).length > 0;
}

/** Visão pública de um profissional para uma listagem (preço "a partir de" no serviço). */
function listing(p, serviceSlug) {
  const offers = activeOfferings(p, serviceSlug || undefined);
  const prices = (offers.length ? offers : activeOfferings(p)).map((o) => o.price);
  return {
    ...p,
    price: prices.length ? Math.min(...prices) : p.price,
    priceFrom: new Set(prices).size > 1,
    offeringCount: offers.length,
  };
}

export async function listServices({ category = 'todas', query = '' } = {}) {
  await delay(200, 450);
  const q = normalize(query.trim());
  const pros = publicProfessionals();
  const enabled = new Set(enabledServices().map((s) => s.slug));
  return servicesInCategory(category).filter((s) => {
    if (!enabled.has(s.slug)) return false;
    if (!q) return true;
    const list = pros.filter((p) => offersService(p, s.slug));
    const haystack = normalize([s.name, s.description, s.short, ...list.map((p) => `${p.name} ${p.specialty}`)].join(' '));
    return haystack.includes(q);
  });
}

export async function getService(slug) {
  await delay(150, 350);
  return serviceBySlug(slug);
}

export function professionalCount(slug) {
  return publicProfessionals().filter((p) => offersService(p, slug)).length;
}

/** Cidades com profissionais publicados (filtro de localização). */
export function listCities() {
  return [
    ...new Set(
      publicProfessionals()
        .map((p) => p.city)
        .filter(Boolean),
    ),
  ].sort();
}

/**
 * Busca de profissionais.
 * Filtros: serviço, texto, cidade, modalidade, preço máximo, dia da semana;
 * ordenação: relevância, menor preço, maior nota, nome.
 */
export async function listProfessionals({
  service = '',
  query = '',
  city = '',
  modality = '',
  maxPrice = 0,
  weekday = '',
  sort = '',
} = {}) {
  await delay(250, 500);
  const q = normalize(query.trim());
  let list = publicProfessionals().filter((p) => {
    if (service && !offersService(p, service)) return false;
    if (city && p.city !== city) return false;
    if (modality && !(p.modality === modality || p.modality === 'ambos')) return false;
    if (weekday !== '' && weekday != null && !p.days.includes(Number(weekday))) return false;
    if (q) {
      const names = activeOfferings(p)
        .map((o) => `${o.name} ${serviceBySlug(o.serviceSlug)?.name || ''}`)
        .join(' ');
      const hay = normalize(`${p.name} ${p.specialty} ${p.title} ${names}`);
      if (!hay.includes(q)) return false;
    }
    return true;
  });
  list = list.map((p) => listing(p, service));
  if (maxPrice) list = list.filter((p) => p.price <= Number(maxPrice));
  if (sort === 'preco') list.sort((a, b) => a.price - b.price);
  else if (sort === 'nota') list.sort((a, b) => (b.rating || 0) - (a.rating || 0));
  else if (sort === 'nome') list.sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
  else if (sort === 'novos') list.sort((a, b) => new Date(b.publishedAt || 0) - new Date(a.publishedAt || 0));
  return list;
}

/** Perfil público completo (somente perfis publicados). */
export async function getPublicProfessional(id) {
  await delay(150, 350);
  const p = publicProfessionals().find((x) => x.id === id);
  if (!p) return null;
  const owner = p.userId ? getDb().users.find((u) => u.id === p.userId) : null;
  return {
    ...listing(p),
    offerings: activeOfferings(p).filter((o) => isServiceEnabled(o.serviceSlug)),
    contact: {
      phone: p.publicContact?.showPhone ? owner?.phone || '' : '',
      email: p.publicContact?.showEmail ? owner?.email || '' : '',
    },
  };
}

export async function getProfessional(id) {
  await delay(100, 250);
  return publicProfessionals().find((p) => p.id === id) || null;
}

/** Próximas datas com horário livre (usado no perfil público). */
export function nextAvailableDates(pro, count = 4, duration) {
  const out = [];
  const today = parseISODate(toISODate(new Date()));
  for (let i = 0; i <= BOOKING_WINDOW_DAYS && out.length < count; i += 1) {
    const iso = toISODate(addDays(today, i));
    const free = getSlots(pro.id, iso, { duration }).filter((s) => s.status === 'livre').length;
    if (free > 0) out.push({ date: iso, free });
  }
  return out;
}

/** A data é atendida pelo profissional e está dentro da janela de agendamento? */
export function isBookableDate(pro, iso) {
  if (!pro || !iso) return false;
  const d = parseISODate(iso);
  const today = parseISODate(toISODate(new Date()));
  const limit = addDays(today, BOOKING_WINDOW_DAYS);
  if (d < today || d > limit) return false;
  if (pro.availability) return !!dayHours(pro, iso);
  return (pro.days || []).includes(d.getDay());
}

/**
 * Horários de um profissional em uma data.
 * status: 'livre' | 'ocupado' (reservado, bloqueado ou fictício) | 'passado'
 *
 * Os horários seguem a disponibilidade configurada pelo profissional (início,
 * fim, intervalo e duração do atendimento). Um horário só fica livre se o
 * atendimento inteiro couber sem sobrepor outra consulta, um bloqueio ou o
 * intervalo. Nos perfis fictícios do catálogo, parte da agenda aparece
 * ocupada de forma determinística, para a demonstração parecer realista.
 */
export function getSlots(proId, iso, { ignoreAppointmentId, duration, offeringId } = {}) {
  const db = getDb();
  const pro = db.professionals.find((p) => p.id === proId) || PROFESSIONALS.find((p) => p.id === proId);
  if (!pro || !isBookableDate(pro, iso)) return [];
  const off = offeringId ? (pro.offerings || []).find((o) => o.id === offeringId) : null;
  const dur = Number(duration) || Number(off?.duration) || 60;
  const busy = db.appointments
    .filter(
      (a) =>
        a.professionalId === proId &&
        a.date === iso &&
        a.id !== ignoreAppointmentId &&
        (a.status === 'agendada' || a.status === 'pendente_pagamento'),
    )
    .map(apptRange);
  const blocks = partialBlocks(pro, iso);
  const now = Date.now();
  return candidateStarts(pro, iso, dur).map((start) => {
    const time = toHHMM(start);
    const dt = toDateTime(iso, time).getTime();
    let status = 'livre';
    if (dt <= now + MIN_NOTICE_MINUTES * 60 * 1000) status = 'passado';
    else if (
      busy.some(([b0, b1]) => overlaps(start, start + dur, b0, b1)) ||
      blocks.some(([b0, b1]) => overlaps(start, start + dur, b0, b1)) ||
      (pro.simulated && hashString(`${proId}|${iso}|${time}`) % 5 === 0)
    ) {
      status = 'ocupado';
    }
    return { time, status };
  });
}

export async function fetchSlots(proId, iso, opts) {
  await delay(200, 400);
  return getSlots(proId, iso, opts);
}

export function isSlotAvailable(proId, iso, time, opts) {
  return getSlots(proId, iso, opts).some((s) => s.time === time && s.status === 'livre');
}

export { SERVICES, PROFESSIONALS, resolveOffering, toMinutes };
