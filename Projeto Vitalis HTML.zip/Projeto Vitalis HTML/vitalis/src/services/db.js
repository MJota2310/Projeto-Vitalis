// "Banco de dados" local da demonstração (persistido no localStorage).
// Estrutura pensada para espelhar tabelas de um backend real:
// users, professionals, appointments, payments, tickets, notifications,
// favorites e settings.
//
// Versão 2 do esquema: perfis de profissionais, serviços oferecidos,
// disponibilidade, notificações, favoritos e configurações da plataforma.
// Dados da versão 1 são migrados sem perda (ver seed.js → migrate).

import { local, KEYS } from './storage';
import { registerDirectory } from '../data/catalog';
import { DEMO_ACCOUNTS, SCHEMA_VERSION, emptyDb, migrate, seed } from './seed';

export { DEMO_ACCOUNTS } from './seed';
/** Conta de paciente de demonstração (mantida por compatibilidade). */
export const DEMO_ACCOUNT = DEMO_ACCOUNTS[0];

let cache = null;

export function getDb() {
  if (!cache) {
    const stored = local.get(KEYS.db, null);
    cache = stored && stored.version === SCHEMA_VERSION ? stored : emptyDb();
  }
  return cache;
}

/** Avisa a interface que os dados mudaram (sino de notificações, listas abertas). */
function emitChange() {
  if (typeof window !== 'undefined') window.dispatchEvent(new CustomEvent('vitalis:db'));
}

export function saveDb(next = cache) {
  cache = next;
  local.set(KEYS.db, cache);
  emitChange();
  return cache;
}

/** Aplica uma alteração no banco e persiste. */
export function mutate(fn) {
  const db = getDb();
  const result = fn(db);
  saveDb(db);
  return result;
}

// Os componentes consultam profissionais por id via data/catalog.js.
registerDirectory((id) => getDb().professionals?.find((p) => p.id === id) || null);

// Outra aba alterou os dados: descarta o cache para ler a versão atual.
if (typeof window !== 'undefined') {
  window.addEventListener('storage', (e) => {
    if (e.key === KEYS.db) {
      cache = null;
      emitChange();
    }
  });
}

/** Inicializa o banco (cria os dados de demonstração ou migra a versão anterior). */
export async function initDb() {
  const stored = local.get(KEYS.db, null);
  if (stored && stored.version === SCHEMA_VERSION && Array.isArray(stored.users)) {
    cache = stored;
    return cache;
  }
  const db = stored && Array.isArray(stored.users) ? await migrate(stored) : await seed();
  saveDb(db);
  return db;
}

/** Restaura os dados de demonstração (Configurações da administração). */
export async function resetDb() {
  const db = await seed();
  saveDb(db);
  return db;
}
