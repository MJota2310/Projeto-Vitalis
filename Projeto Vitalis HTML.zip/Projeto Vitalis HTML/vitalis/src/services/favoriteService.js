// Favoritos do paciente (profissionais salvos).

import { getDb, mutate } from './db';
import { ApiError, delay } from './api';
import { requireUser } from './session';
import { publicProfessionals } from './catalogService';

export function isFavorite(professionalId) {
  try {
    const user = requireUser(['usuario', 'profissional']);
    return getDb().favorites.some((f) => f.userId === user.id && f.professionalId === professionalId);
  } catch {
    return false;
  }
}

export async function toggleFavorite(professionalId) {
  await delay(120, 250);
  const user = requireUser(['usuario', 'profissional']);
  if (!getDb().professionals.some((p) => p.id === professionalId)) {
    throw new ApiError('Profissional não encontrado.', 'NOT_FOUND');
  }
  return mutate((db) => {
    const exists = db.favorites.some((f) => f.userId === user.id && f.professionalId === professionalId);
    if (exists) db.favorites = db.favorites.filter((f) => !(f.userId === user.id && f.professionalId === professionalId));
    else db.favorites.push({ userId: user.id, professionalId, createdAt: new Date().toISOString() });
    return !exists;
  });
}

/** Favoritos do usuário; perfis que deixaram de ser públicos vêm marcados como indisponíveis. */
export async function listFavorites() {
  await delay(200, 400);
  const user = requireUser(['usuario', 'profissional']);
  const db = getDb();
  const visible = new Set(publicProfessionals().map((p) => p.id));
  return db.favorites
    .filter((f) => f.userId === user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .map((f) => {
      const p = db.professionals.find((x) => x.id === f.professionalId);
      return p ? { ...p, savedAt: f.createdAt, available: visible.has(p.id) } : null;
    })
    .filter(Boolean);
}

/**
 * Sugestões simples e explicáveis com base no histórico do usuário (sem IA):
 * 1) agendar de novo com profissionais já consultados;
 * 2) outros profissionais dos serviços que a pessoa já usou;
 * 3) sem histórico: profissionais com horários livres nos serviços mais procurados.
 * Cada item informa o motivo da sugestão.
 */
export async function getRecommendations(limit = 3) {
  await delay(150, 300);
  const user = requireUser(['usuario', 'profissional']);
  const db = getDb();
  const pros = publicProfessionals().filter((p) => p.userId !== user.id);
  const mine = db.appointments
    .filter((a) => a.userId === user.id)
    .sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  const out = [];
  const seen = new Set();
  const add = (p, reason) => {
    if (!p || seen.has(p.id) || out.length >= limit) return;
    seen.add(p.id);
    out.push({ ...p, reason });
  };
  const upcomingWith = new Set(
    mine.filter((a) => a.status === 'agendada' || a.status === 'pendente_pagamento').map((a) => a.professionalId),
  );
  // 1) agendar de novo
  mine
    .filter((a) => a.status === 'concluida' && !upcomingWith.has(a.professionalId))
    .forEach((a) =>
      add(
        pros.find((p) => p.id === a.professionalId),
        `Você já se consultou com ${a.professionalName.split(' ').slice(0, 2).join(' ')}`,
      ),
    );
  // 2) mesmos serviços, outros profissionais
  const services = [...new Set(mine.map((a) => a.serviceSlug))];
  services.forEach((slug) => {
    pros
      .filter(
        (p) =>
          (p.offerings || []).some((o) => o.active && o.serviceSlug === slug) && !mine.some((a) => a.professionalId === p.id),
      )
      .sort((a, b) => (b.rating || 0) - (a.rating || 0) || a.price - b.price)
      .slice(0, 2)
      .forEach((p) => add(p, `Porque você agendou ${mine.find((a) => a.serviceSlug === slug)?.serviceName || 'este serviço'}`));
  });
  // 3) sem histórico suficiente: serviços mais procurados na plataforma
  if (out.length < limit) {
    const popular = {};
    db.appointments.forEach((a) => {
      popular[a.serviceSlug] = (popular[a.serviceSlug] || 0) + 1;
    });
    pros
      .slice()
      .sort((a, b) => (popular[b.service] || 0) - (popular[a.service] || 0) || (b.rating || 0) - (a.rating || 0))
      .forEach((p) => add(p, 'Popular na Vitalis'));
  }
  return out;
}
