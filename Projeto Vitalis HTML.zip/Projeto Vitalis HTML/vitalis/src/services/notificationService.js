// Notificações dentro da plataforma (sino do cabeçalho e páginas de avisos).
// São criadas pelos próprios serviços quando algo acontece (novo agendamento,
// cancelamento, pagamento, verificação de perfil…). Não há envio de e-mail,
// SMS ou WhatsApp nesta versão.

import { getDb, mutate } from './db';
import { ApiError, delay, uid } from './api';
import { requireUser } from './session';
import { formatDateBR } from '../utils/format';

export const NOTIFICATION_TYPES = {
  agendamento: { label: 'Agendamento', icon: 'event_available', tone: 'green' },
  cancelamento: { label: 'Cancelamento', icon: 'event_busy', tone: 'red' },
  remarcacao: { label: 'Alteração de horário', icon: 'event_repeat', tone: 'blue' },
  pagamento: { label: 'Pagamento', icon: 'payments', tone: 'green' },
  lembrete: { label: 'Lembrete', icon: 'alarm', tone: 'yellow' },
  aviso: { label: 'Aviso da plataforma', icon: 'campaign', tone: 'blue' },
  sistema: { label: 'Atualização', icon: 'info', tone: 'gray' },
};

/** Cria uma notificação dentro de uma transação do banco (uso interno dos serviços). */
export function pushNotification(db, userId, { type = 'sistema', title, text = '', link = '', important = false }) {
  if (!userId) return null;
  db.notifications = db.notifications || [];
  const n = { id: uid('ntf'), userId, type, title, text, link, important, read: false, createdAt: new Date().toISOString() };
  db.notifications.push(n);
  return n;
}

/** Notifica todos os administradores. */
export function notifyAdmins(db, payload) {
  db.users.filter((u) => u.role === 'admin' && u.status !== 'suspenso').forEach((u) => pushNotification(db, u.id, payload));
}

/** Texto curto "dd/mm às hh:mm" para mensagens. */
export const whenText = (a) => `${formatDateBR(a.date).slice(0, 5)} às ${a.time}`;

export async function listNotifications({ filter = 'todas' } = {}) {
  await delay(150, 350);
  const user = requireUser();
  return getDb()
    .notifications.filter((n) => n.userId === user.id)
    .filter((n) => (filter === 'nao_lidas' ? !n.read : filter === 'importantes' ? n.important : true))
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}

/** Contagem rápida para o sino (sem latência artificial). */
export function unreadCount() {
  try {
    const user = requireUser();
    return getDb().notifications.filter((n) => n.userId === user.id && !n.read).length;
  } catch {
    return 0;
  }
}

function updateOwn(id, fn) {
  const user = requireUser();
  return mutate((db) => {
    const n = db.notifications.find((x) => x.id === id && x.userId === user.id);
    if (!n) throw new ApiError('Notificação não encontrada.', 'NOT_FOUND');
    fn(n);
    return { ...n };
  });
}

export async function markRead(id, read = true) {
  await delay(60, 150);
  return updateOwn(id, (n) => {
    n.read = read;
  });
}

export async function toggleImportant(id) {
  await delay(60, 150);
  return updateOwn(id, (n) => {
    n.important = !n.important;
  });
}

export async function markAllRead() {
  await delay(150, 300);
  const user = requireUser();
  return mutate((db) => {
    let count = 0;
    db.notifications.forEach((n) => {
      if (n.userId === user.id && !n.read) {
        n.read = true;
        count += 1;
      }
    });
    return count;
  });
}

export async function removeNotification(id) {
  await delay(80, 160);
  const user = requireUser();
  return mutate((db) => {
    const before = db.notifications.length;
    db.notifications = db.notifications.filter((n) => !(n.id === id && n.userId === user.id));
    if (db.notifications.length === before) throw new ApiError('Notificação não encontrada.', 'NOT_FOUND');
    return true;
  });
}
