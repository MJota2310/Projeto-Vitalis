// Regras e utilitários puros do domínio "profissional": disponibilidade,
// serviços oferecidos, status do perfil e completude do cadastro.
// Não acessa o banco — é usado tanto pelo banco (seed/migração) quanto pelos
// serviços e pela interface.

import { SERVICES, serviceBySlug } from '../data/catalog';
import { parseISODate, toDateTime } from '../utils/format';

export const SLOT_OPTIONS = [30, 60];
export const DURATION_OPTIONS = [30, 45, 60, 90, 120];
export const DEFAULT_HOURS = { start: '08:00', end: '18:00', breakStart: '12:00', breakEnd: '14:00' };

export const MODALITIES = [
  { id: 'presencial', label: 'Presencial', icon: 'location_on' },
  { id: 'online', label: 'Online', icon: 'videocam' },
  { id: 'ambos', label: 'Presencial e online', icon: 'devices' },
];

export const COUNCILS = ['CRM', 'CRP', 'CREFITO', 'CRN', 'CREF', 'COREN', 'CRO', 'CRBM', 'Outro'];

export const UFS = 'AC AL AM AP BA CE DF ES GO MA MG MS MT PA PB PE PI PR RJ RN RO RR RS SC SE SP TO'.split(' ');

/** Status do perfil profissional (moderado pela administração). */
export const PRO_STATUS = {
  rascunho: { label: 'Em configuração', tone: 'gray', icon: 'edit_note', text: 'Complete o cadastro e envie para verificação.' },
  em_analise: {
    label: 'Em análise',
    tone: 'yellow',
    icon: 'pending',
    text: 'A equipe Vitalis está verificando seus dados. Você será avisado por notificação.',
  },
  publicado: {
    label: 'Publicado',
    tone: 'green',
    icon: 'verified',
    text: 'Seu perfil aparece nas buscas e recebe agendamentos.',
  },
  pausado: {
    label: 'Pausado',
    tone: 'blue',
    icon: 'pause_circle',
    text: 'Seu perfil está oculto das buscas. Reative quando quiser.',
  },
  recusado: {
    label: 'Ajustes solicitados',
    tone: 'red',
    icon: 'report',
    text: 'A verificação pediu ajustes. Revise os dados e envie novamente.',
  },
  suspenso: { label: 'Suspenso', tone: 'red', icon: 'block', text: 'Perfil suspenso pela administração. Fale com o suporte.' },
};

/** Como cada status de consulta aparece para o profissional (agenda). */
export const PRO_APPT_STATUS = {
  agendada: { label: 'Confirmado', tone: 'green', icon: 'event_available' },
  pendente_pagamento: { label: 'Aguardando confirmação', tone: 'yellow', icon: 'hourglass_empty' },
  concluida: { label: 'Concluído', tone: 'blue', icon: 'task_alt' },
  cancelada: { label: 'Cancelado', tone: 'red', icon: 'cancel' },
  indisponivel: { label: 'Indisponível', tone: 'gray', icon: 'block' },
};

export const toMinutes = (hhmm) => {
  const [h, m] = String(hhmm || '0:0')
    .split(':')
    .map(Number);
  return (h || 0) * 60 + (m || 0);
};
export const toHHMM = (min) => `${String(Math.floor(min / 60)).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`;

/** Disponibilidade semanal padrão a partir dos dias de atendimento (0=dom … 6=sáb). */
export function availabilityFromDays(days = [], hours = DEFAULT_HOURS, slotMinutes = 60) {
  return {
    slotMinutes,
    weekly: Array.from({ length: 7 }, (_, day) => ({ day, enabled: days.includes(day), ...hours })),
    exceptions: [],
  };
}

export function emptyAvailability() {
  return availabilityFromDays([1, 2, 3, 4, 5]);
}

/** Recalcula campos derivados usados pelo catálogo (dias, preço "a partir de"). */
export function syncDerived(pro) {
  const active = (pro.offerings || []).filter((o) => o.active);
  pro.days = (pro.availability?.weekly || []).filter((d) => d.enabled).map((d) => d.day);
  const inPrimary = active.filter((o) => o.serviceSlug === pro.service);
  const pool = inPrimary.length ? inPrimary : active;
  pro.price = pool.length ? Math.min(...pool.map((o) => Number(o.price) || 0)) : 0;
  pro.serviceSlugs = [...new Set(active.map((o) => o.serviceSlug))];
  return pro;
}

/** Serviços ativos de um profissional, opcionalmente filtrados por serviço do catálogo. */
export function activeOfferings(pro, serviceSlug) {
  return (pro?.offerings || []).filter((o) => o.active && (!serviceSlug || o.serviceSlug === serviceSlug));
}

/** Serviço escolhido (ou o padrão para o serviço do catálogo). */
export function resolveOffering(pro, serviceSlug, offeringId) {
  const list = activeOfferings(pro);
  if (offeringId) {
    const found = list.find((o) => o.id === offeringId);
    if (found) return found;
  }
  return (
    list.filter((o) => o.serviceSlug === serviceSlug).sort((a, b) => a.price - b.price)[0] ||
    list.filter((o) => o.serviceSlug === pro?.service).sort((a, b) => a.price - b.price)[0] ||
    list[0] ||
    null
  );
}

/** Exceções (bloqueios e horários especiais) de uma data. */
export function exceptionsOn(pro, iso) {
  return (pro?.availability?.exceptions || []).filter((e) => e.date === iso);
}

/**
 * Horário de atendimento em uma data, considerando horários especiais e
 * bloqueios de dia inteiro. Retorna null quando não há atendimento.
 */
export function dayHours(pro, iso) {
  if (!pro?.availability || !iso) return null;
  const ex = exceptionsOn(pro, iso);
  if (ex.some((e) => e.type === 'bloqueio' && e.allDay)) return null;
  const special = ex.find((e) => e.type === 'horario_especial');
  if (special) return { start: special.start, end: special.end, breakStart: '', breakEnd: '' };
  const d = parseISODate(iso);
  const w = pro.availability.weekly?.find((x) => x.day === d.getDay());
  if (!w || !w.enabled) return null;
  return { start: w.start, end: w.end, breakStart: w.breakStart || '', breakEnd: w.breakEnd || '' };
}

/** Intervalos bloqueados (parciais) de uma data, em minutos. */
export function partialBlocks(pro, iso) {
  return exceptionsOn(pro, iso)
    .filter((e) => e.type === 'bloqueio' && !e.allDay)
    .map((e) => [toMinutes(e.start), toMinutes(e.end)]);
}

export const overlaps = (a0, a1, b0, b1) => a0 < b1 && b0 < a1;

/** Minutos de início e fim de uma consulta. */
export function apptRange(a) {
  const s = toMinutes(a.time);
  return [s, s + (Number(a.duration) || 60)];
}

/** Horários candidatos de início em um dia (sem considerar ocupação). */
export function candidateStarts(pro, iso, duration = 60) {
  const h = dayHours(pro, iso);
  if (!h) return [];
  const step = Number(pro.availability.slotMinutes) || 60;
  const start = toMinutes(h.start);
  const end = toMinutes(h.end);
  const b0 = h.breakStart ? toMinutes(h.breakStart) : null;
  const b1 = h.breakEnd ? toMinutes(h.breakEnd) : null;
  const out = [];
  for (let t = start; t + duration <= end; t += step) {
    if (b0 != null && b1 != null && b1 > b0 && overlaps(t, t + duration, b0, b1)) continue;
    out.push(t);
  }
  return out;
}

/** Minutos disponíveis de atendimento em um dia (para taxa de ocupação). */
export function availableMinutes(pro, iso) {
  const h = dayHours(pro, iso);
  if (!h) return 0;
  let total = toMinutes(h.end) - toMinutes(h.start);
  if (h.breakStart && h.breakEnd) total -= Math.max(0, toMinutes(h.breakEnd) - toMinutes(h.breakStart));
  partialBlocks(pro, iso).forEach(([a, b]) => {
    total -= Math.max(0, b - a);
  });
  return Math.max(0, total);
}

/** Valida uma grade semanal; retorna mensagem de erro ou ''. */
export function validateWeekly(weekly) {
  for (const d of weekly) {
    if (!d.enabled) continue;
    const s = toMinutes(d.start);
    const e = toMinutes(d.end);
    if (!d.start || !d.end) return 'Informe início e fim em todos os dias ativos.';
    if (e - s < 30) return 'O expediente precisa ter pelo menos 30 minutos.';
    if (d.breakStart || d.breakEnd) {
      if (!d.breakStart || !d.breakEnd) return 'Informe início e fim do intervalo (ou deixe os dois em branco).';
      const bs = toMinutes(d.breakStart);
      const be = toMinutes(d.breakEnd);
      if (be <= bs) return 'O fim do intervalo deve ser depois do início.';
      if (bs < s || be > e) return 'O intervalo precisa estar dentro do horário de atendimento.';
    }
  }
  if (!weekly.some((d) => d.enabled)) return 'Ative pelo menos um dia de atendimento.';
  return '';
}

/** Valida um serviço oferecido; retorna { campo: erro }. */
export function validateOffering(o) {
  const errors = {};
  const name = String(o.name || '').trim();
  if (name.length < 3) errors.name = 'Dê um nome com pelo menos 3 caracteres.';
  else if (name.length > 60) errors.name = 'Use no máximo 60 caracteres.';
  if (!serviceBySlug(o.serviceSlug)) errors.serviceSlug = 'Escolha a categoria do catálogo.';
  const desc = String(o.description || '').trim();
  if (desc.length > 240) errors.description = 'Use no máximo 240 caracteres.';
  const price = Number(o.price);
  if (!Number.isFinite(price) || price < 20) errors.price = 'Informe um valor a partir de R$ 20,00.';
  else if (price > 5000) errors.price = 'Valor acima do limite (R$ 5.000,00).';
  if (!DURATION_OPTIONS.includes(Number(o.duration))) errors.duration = 'Escolha uma duração.';
  return errors;
}

/** Itens de completude do perfil (usados no onboarding e no painel). */
export function profileChecklist(pro) {
  if (!pro) return [];
  return [
    {
      id: 'dados',
      label: 'Dados profissionais',
      done: !!(pro.title && pro.registry?.council && pro.registry?.number && pro.city),
    },
    { id: 'especialidade', label: 'Especialidade', done: !!(pro.service && pro.specialty) },
    { id: 'servicos', label: 'Serviços oferecidos', done: activeOfferings(pro).length > 0 },
    { id: 'disponibilidade', label: 'Disponibilidade', done: (pro.availability?.weekly || []).some((d) => d.enabled) },
    { id: 'perfil', label: 'Apresentação', done: String(pro.bio || '').trim().length >= 40 },
  ];
}

export function completeness(pro) {
  const list = profileChecklist(pro);
  const done = list.filter((i) => i.done).length;
  return { list, done, total: list.length, pct: list.length ? Math.round((done / list.length) * 100) : 0 };
}

export const serviceName = (slug) => serviceBySlug(slug)?.name || slug;
export const CATALOG_OPTIONS = SERVICES.map((s) => ({ value: s.slug, label: s.name }));

/** A consulta já começou? (usada para presença/falta). */
export function hasStarted(a) {
  return toDateTime(a.date, a.time).getTime() <= Date.now();
}
