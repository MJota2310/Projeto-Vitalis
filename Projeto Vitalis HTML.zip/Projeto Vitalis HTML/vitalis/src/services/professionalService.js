// Área do profissional: perfil, serviços oferecidos, disponibilidade, agenda,
// clientes, financeiro e visão geral.
//
// Todas as funções exigem uma sessão com papel "profissional" e operam somente
// sobre o perfil vinculado à conta da sessão (nunca sobre um id vindo da tela).

import { getDb, mutate } from './db';
import { ApiError, delay, uid } from './api';
import { requireProfessional } from './session';
import { notifyAdmins, pushNotification, whenText } from './notificationService';
import { syncStatuses } from './appointmentService';
import { getSlots, BOOKING_WINDOW_DAYS } from './catalogService';
import { createDraftProfessional, publicUser } from './authService';
import {
  COUNCILS,
  MODALITIES,
  UFS,
  activeOfferings,
  apptRange,
  availableMinutes,
  completeness,
  dayHours,
  exceptionsOn,
  hasStarted,
  overlaps,
  syncDerived,
  toMinutes,
  validateOffering,
  validateWeekly,
} from './proModel';
import { serviceBySlug } from '../data/catalog';
import { addDays, formatDateBR, normalize, parseISODate, toDateTime, toISODate } from '../utils/format';

const PREFIXES = ['Dr.', 'Dra.', 'Prof.', 'Profª.'];
const ACTIVE = (a) => a.status === 'agendada' || a.status === 'pendente_pagamento';

/** Profissional da sessão (cria o rascunho do perfil se ainda não existir). */
function session() {
  const { user, pro } = requireProfessional();
  if (pro) return { user, pro };
  const created = mutate((db) => {
    const u = db.users.find((x) => x.id === user.id);
    const p = createDraftProfessional(db, u);
    u.professionalId = p.id;
    return p;
  });
  return { user: getDb().users.find((u) => u.id === user.id), pro: created };
}

function mutatePro(fn) {
  const { pro } = session();
  return mutate((db) => {
    const p = db.professionals.find((x) => x.id === pro.id);
    const result = fn(p, db);
    p.updatedAt = new Date().toISOString();
    syncDerived(p);
    return result === undefined ? structuredClone(p) : result;
  });
}

function splitName(name = '') {
  const prefix = PREFIXES.find((x) => name.startsWith(`${x} `));
  return { namePrefix: prefix || '', displayName: prefix ? name.slice(prefix.length + 1) : name };
}

/** Perfil completo do profissional da sessão. */
export async function getMyProfessional() {
  await delay(150, 350);
  const { user, pro } = session();
  const full = getDb().professionals.find((p) => p.id === pro.id);
  return {
    user: publicUser(user),
    pro: { ...structuredClone(full), ...splitName(full.name) },
    progress: completeness(full),
  };
}

function cleanText(v, max) {
  return String(v ?? '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, max);
}

/** Valida os dados do perfil; retorna { campo: erro }. */
export function validateProfile(data, { strict = false } = {}) {
  const e = {};
  const name = cleanText(data.displayName, 80);
  if (name.split(' ').length < 2) e.displayName = 'Informe nome e sobrenome.';
  if (data.namePrefix && !PREFIXES.includes(data.namePrefix)) e.namePrefix = 'Tratamento inválido.';
  if (strict || data.title) {
    const t = cleanText(data.title, 60);
    if (t.length < 3) e.title = 'Informe sua profissão (ex.: Fisioterapeuta).';
  }
  if (strict || data.specialty) {
    if (cleanText(data.specialty, 60).length < 3) e.specialty = 'Informe sua especialidade principal.';
  }
  if (strict && !serviceBySlug(data.service)) e.service = 'Escolha a área do catálogo.';
  if (strict || data.registry?.council || data.registry?.number) {
    if (!COUNCILS.includes(data.registry?.council)) e.council = 'Escolha o conselho profissional.';
    const n = cleanText(data.registry?.number, 20);
    if (n.length < 3) e.registryNumber = 'Informe o número de registro.';
    if (!UFS.includes(data.registry?.uf)) e.uf = 'Escolha a UF.';
  }
  if (strict || data.city) {
    if (cleanText(data.city, 60).length < 3) e.city = 'Informe a cidade de atendimento (ex.: Barueri, SP).';
  }
  if (data.modality && !MODALITIES.some((m) => m.id === data.modality)) e.modality = 'Modalidade inválida.';
  const bio = String(data.bio ?? '').trim();
  if (bio.length > 1200) e.bio = 'Use no máximo 1.200 caracteres.';
  if (strict && bio.length < 40) e.bio = 'Escreva uma apresentação com pelo menos 40 caracteres.';
  const years = data.experienceYears;
  if (years !== '' && years != null && (!(Number(years) >= 0) || Number(years) > 60)) {
    e.experienceYears = 'Informe um número entre 0 e 60.';
  }
  if ((data.education || []).some((x) => String(x).length > 120)) e.education = 'Cada item deve ter até 120 caracteres.';
  return e;
}

/** Atualiza o perfil profissional (parcial). */
export async function updateMyProfessional(data) {
  await delay(350, 700);
  const errors = validateProfile(data);
  const key = Object.keys(errors)[0];
  if (key) throw new ApiError(errors[key], 'VALIDATION', key);
  return mutatePro((p, db) => {
    const registryBefore = JSON.stringify(p.registry || {});
    if (data.displayName !== undefined) {
      const prefix = data.namePrefix || '';
      p.namePrefix = prefix;
      p.name = `${prefix ? `${prefix} ` : ''}${cleanText(data.displayName, 80)}`;
      if (prefix) p.gender = prefix === 'Dra.' || prefix === 'Profª.' ? 'f' : 'm';
    }
    ['title', 'specialty', 'city', 'address', 'experience'].forEach((k) => {
      if (data[k] !== undefined) p[k] = cleanText(data[k], k === 'experience' ? 400 : k === 'address' ? 140 : 60);
    });
    if (data.service !== undefined && serviceBySlug(data.service)) p.service = data.service;
    if (data.modality !== undefined) p.modality = data.modality;
    if (data.bio !== undefined) p.bio = String(data.bio).trim().slice(0, 1200);
    if (data.education !== undefined)
      p.education = data.education
        .map((x) => cleanText(x, 120))
        .filter(Boolean)
        .slice(0, 6);
    if (data.experienceYears !== undefined) p.experienceYears = data.experienceYears === '' ? null : Number(data.experienceYears);
    if (data.registry !== undefined) {
      p.registry = { council: data.registry.council, number: cleanText(data.registry.number, 20), uf: data.registry.uf };
    }
    if (data.publicContact !== undefined) p.publicContact = { ...p.publicContact, ...data.publicContact };
    if (data.photo !== undefined) {
      p.photo = data.photo;
      const u = db.users.find((x) => x.id === p.userId);
      if (u) u.photo = data.photo;
    }
    if (data.onboardingStep !== undefined) p.onboardingStep = data.onboardingStep;
    if (p.verified && JSON.stringify(p.registry || {}) !== registryBefore) {
      notifyAdmins(db, {
        type: 'aviso',
        title: 'Registro profissional alterado',
        text: `${p.name} alterou o registro para ${p.registry.council} ${p.registry.number}/${p.registry.uf}. Confira os dados.`,
        link: '/admin/profissionais',
      });
    }
  });
}

/** Envia o perfil para a verificação da equipe Vitalis. */
export async function submitForReview() {
  await delay(500, 900);
  const { pro } = session();
  const c = completeness(pro);
  if (c.done < c.total) {
    throw new ApiError(
      `Complete as etapas pendentes: ${c.list
        .filter((i) => !i.done)
        .map((i) => i.label.toLowerCase())
        .join(', ')}.`,
      'INCOMPLETE',
    );
  }
  if (!['rascunho', 'recusado'].includes(pro.status)) {
    throw new ApiError('Seu perfil já foi enviado para verificação.', 'ALREADY_SUBMITTED');
  }
  return mutatePro((p, db) => {
    p.status = 'em_analise';
    p.submittedAt = new Date().toISOString();
    p.reviewNote = '';
    notifyAdmins(db, {
      type: 'aviso',
      title: 'Profissional aguardando verificação',
      text: `${p.name} (${p.title}) enviou o perfil para análise.`,
      link: '/admin/profissionais?status=em_analise',
      important: true,
    });
    pushNotification(db, p.userId, {
      type: 'sistema',
      title: 'Perfil enviado para verificação',
      text: 'A equipe Vitalis vai conferir seus dados. Você será avisado aqui quando o perfil for publicado.',
      link: '/profissional',
    });
  });
}

/** Pausa (oculta das buscas) ou reativa um perfil publicado. */
export async function setProfilePaused(paused) {
  await delay(300, 500);
  const { pro } = session();
  if (paused && pro.status !== 'publicado') throw new ApiError('Só é possível pausar um perfil publicado.', 'INVALID_STATE');
  if (!paused && pro.status !== 'pausado') throw new ApiError('O perfil não está pausado.', 'INVALID_STATE');
  return mutatePro((p) => {
    p.status = paused ? 'pausado' : 'publicado';
  });
}

// ------------------------------------------------------------------ serviços oferecidos

export async function listMyOfferings() {
  await delay(200, 400);
  const { pro } = session();
  const db = getDb();
  const mine = db.appointments.filter((a) => a.professionalId === pro.id);
  return (getDb().professionals.find((p) => p.id === pro.id).offerings || []).map((o) => ({
    ...o,
    stats: {
      total: mine.filter((a) => a.offeringId === o.id).length,
      upcoming: mine.filter((a) => a.offeringId === o.id && ACTIVE(a)).length,
    },
  }));
}

export async function saveOffering(data) {
  await delay(350, 650);
  const errors = validateOffering(data);
  const key = Object.keys(errors)[0];
  if (key) throw new ApiError(errors[key], 'VALIDATION', key);
  return mutatePro((p) => {
    const clean = {
      serviceSlug: data.serviceSlug,
      name: cleanText(data.name, 60),
      description: String(data.description || '')
        .trim()
        .slice(0, 240),
      duration: Number(data.duration),
      price: Math.round(Number(data.price) * 100) / 100,
    };
    const dup = p.offerings.find((o) => o.id !== data.id && normalize(o.name) === normalize(clean.name));
    if (dup) throw new ApiError('Você já tem um serviço com este nome.', 'DUPLICATE', 'name');
    let saved;
    if (data.id) {
      saved = p.offerings.find((o) => o.id === data.id);
      if (!saved) throw new ApiError('Serviço não encontrado.', 'NOT_FOUND');
      Object.assign(saved, clean, { updatedAt: new Date().toISOString() });
    } else {
      saved = { id: uid('off'), ...clean, active: data.active !== false, createdAt: new Date().toISOString() };
      p.offerings.push(saved);
    }
    if (!p.service) p.service = clean.serviceSlug;
    return { ...saved };
  });
}

export async function setOfferingActive(id, active) {
  await delay(200, 400);
  return mutatePro((p) => {
    const o = p.offerings.find((x) => x.id === id);
    if (!o) throw new ApiError('Serviço não encontrado.', 'NOT_FOUND');
    o.active = !!active;
    return { ...o };
  });
}

export async function deleteOffering(id) {
  await delay(250, 450);
  const { pro } = session();
  if (getDb().appointments.some((a) => a.professionalId === pro.id && a.offeringId === id)) {
    throw new ApiError('Este serviço já tem agendamentos no histórico. Desative-o em vez de excluir.', 'HAS_APPOINTMENTS');
  }
  return mutatePro((p) => {
    p.offerings = p.offerings.filter((o) => o.id !== id);
    return true;
  });
}

// ------------------------------------------------------------------ disponibilidade

/** Consultas ativas futuras do profissional que ficariam fora de uma nova grade. */
function outsideHours(db, pro, nextAvailability) {
  const probe = { ...pro, availability: nextAvailability };
  return db.appointments.filter((a) => {
    if (a.professionalId !== pro.id || !ACTIVE(a) || hasStarted(a)) return false;
    const h = dayHours(probe, a.date);
    if (!h) return true;
    const [s, e] = apptRange(a);
    if (s < toMinutes(h.start) || e > toMinutes(h.end)) return true;
    if (h.breakStart && h.breakEnd && overlaps(s, e, toMinutes(h.breakStart), toMinutes(h.breakEnd))) return true;
    return false;
  });
}

const conflictList = (list) =>
  list
    .slice(0, 5)
    .map((a) => `${formatDateBR(a.date)} ${a.time} (${a.clientName || 'cliente'})`)
    .join('; ');

export async function updateWeekly({ weekly, slotMinutes }, { force = false } = {}) {
  await delay(400, 700);
  const msg = validateWeekly(weekly);
  if (msg) throw new ApiError(msg, 'VALIDATION');
  if (![30, 60].includes(Number(slotMinutes))) throw new ApiError('Intervalo entre horários inválido.', 'VALIDATION');
  const { pro } = session();
  const db = getDb();
  const next = { ...pro.availability, slotMinutes: Number(slotMinutes), weekly: weekly.map((d) => ({ ...d })) };
  const out = outsideHours(db, pro, next);
  if (out.length && !force) {
    const err = new ApiError(
      `${out.length} agendamento(s) futuro(s) ficariam fora do novo horário: ${conflictList(out)}. Eles serão mantidos se você confirmar.`,
      'OUTSIDE_HOURS',
    );
    err.details = out.map((a) => a.id);
    throw err;
  }
  return mutatePro((p) => {
    p.availability = next;
    return structuredClone(p.availability);
  });
}

export async function addException(data) {
  await delay(350, 600);
  const { pro } = session();
  const db = getDb();
  const date = data.date;
  const d = parseISODate(date);
  const today = parseISODate(toISODate(new Date()));
  if (!d || Number.isNaN(d.getTime())) throw new ApiError('Informe a data.', 'VALIDATION', 'date');
  if (d < today) throw new ApiError('Escolha hoje ou uma data futura.', 'VALIDATION', 'date');
  if (d > addDays(today, 180)) throw new ApiError('Escolha uma data nos próximos 6 meses.', 'VALIDATION', 'date');
  const type = data.type === 'horario_especial' ? 'horario_especial' : 'bloqueio';
  const allDay = type === 'bloqueio' && !!data.allDay;
  if (!allDay) {
    if (!data.start || !data.end) throw new ApiError('Informe o início e o fim.', 'VALIDATION', 'start');
    if (toMinutes(data.end) - toMinutes(data.start) < 30) {
      throw new ApiError('O período precisa ter pelo menos 30 minutos.', 'VALIDATION', 'end');
    }
  }
  const reason = cleanText(data.reason, 80);
  if (type === 'bloqueio') {
    const range = allDay ? [0, 24 * 60] : [toMinutes(data.start), toMinutes(data.end)];
    const conflicts = db.appointments.filter(
      (a) => a.professionalId === pro.id && a.date === date && ACTIVE(a) && overlaps(...apptRange(a), ...range),
    );
    if (conflicts.length) {
      throw new ApiError(
        `Há ${conflicts.length} agendamento(s) nesse período: ${conflictList(conflicts)}. Cancele ou remarque antes de bloquear.`,
        'CONFLICT',
      );
    }
  }
  return mutatePro((p) => {
    if (type === 'horario_especial') {
      p.availability.exceptions = p.availability.exceptions.filter((e) => !(e.date === date && e.type === 'horario_especial'));
    }
    const exc = {
      id: uid('exc'),
      date,
      type,
      allDay,
      start: allDay ? '' : data.start,
      end: allDay ? '' : data.end,
      reason: reason || (type === 'bloqueio' ? 'Indisponível' : 'Horário especial'),
      createdAt: new Date().toISOString(),
    };
    p.availability.exceptions.push(exc);
    p.availability.exceptions.sort((a, b) => a.date.localeCompare(b.date));
    return { ...exc };
  });
}

export async function removeException(id) {
  await delay(250, 450);
  const { pro } = session();
  const exc = (pro.availability.exceptions || []).find((e) => e.id === id);
  if (!exc) throw new ApiError('Exceção não encontrada.', 'NOT_FOUND');
  if (exc.type === 'horario_especial') {
    const probe = {
      ...pro,
      availability: { ...pro.availability, exceptions: pro.availability.exceptions.filter((e) => e.id !== id) },
    };
    const out = outsideHours(getDb(), pro, probe.availability).filter((a) => a.date === exc.date);
    if (out.length) {
      throw new ApiError(`Existem agendamentos nesse horário especial: ${conflictList(out)}.`, 'CONFLICT');
    }
  }
  return mutatePro((p) => {
    p.availability.exceptions = p.availability.exceptions.filter((e) => e.id !== id);
    return true;
  });
}

/** Prévia de horários (livres, ocupados, bloqueados) para os próximos dias. */
export async function previewSchedule(startIso, days = 7) {
  await delay(150, 300);
  const { pro } = session();
  const fresh = getDb().professionals.find((p) => p.id === pro.id);
  const start = parseISODate(startIso || toISODate(new Date()));
  return Array.from({ length: days }, (_, i) => {
    const iso = toISODate(addDays(start, i));
    const hours = dayHours(fresh, iso);
    const slots = hours ? getSlots(fresh.id, iso, { duration: fresh.availability.slotMinutes }) : [];
    return { date: iso, hours, slots, exceptions: exceptionsOn(fresh, iso) };
  });
}

// ------------------------------------------------------------------ agenda

function clientOf(db, a) {
  const u = db.users.find((x) => x.id === a.userId);
  return { id: a.userId, name: a.clientName || u?.name || 'Cliente' };
}

function proAppt(db, a) {
  const payment = db.payments.find((p) => p.id === a.paymentId) || null;
  return { ...a, client: clientOf(db, a), payment };
}

function syncAll() {
  return mutate((db) => {
    syncStatuses(db);
    return db;
  });
}

/** Consultas do profissional em um intervalo de datas (inclusive) + exceções. */
export async function getAgenda({ from, to } = {}) {
  await delay(200, 450);
  const { pro } = session();
  const db = syncAll();
  const fresh = db.professionals.find((p) => p.id === pro.id);
  const list = db.appointments
    .filter((a) => a.professionalId === pro.id && (!from || a.date >= from) && (!to || a.date <= to))
    .sort((a, b) => toDateTime(a.date, a.time) - toDateTime(b.date, b.time))
    .map((a) => proAppt(db, a));
  const days = [];
  if (from && to) {
    for (let d = parseISODate(from); d <= parseISODate(to); d = addDays(d, 1)) {
      const iso = toISODate(d);
      days.push({ date: iso, hours: dayHours(fresh, iso), exceptions: exceptionsOn(fresh, iso) });
    }
  }
  return { appointments: list, days, availability: structuredClone(fresh.availability) };
}

/** Lista para a visão "lista" da agenda. */
export async function listAgenda({ period = 'proximos', status = '', query = '' } = {}) {
  await delay(200, 450);
  const { pro } = session();
  const db = syncAll();
  const today = toISODate(new Date());
  const q = normalize(query.trim());
  let list = db.appointments.filter((a) => a.professionalId === pro.id);
  if (period === 'hoje') list = list.filter((a) => a.date === today);
  else if (period === 'proximos') list = list.filter((a) => toDateTime(a.date, a.time) >= new Date() || ACTIVE(a));
  else if (period === 'anteriores') list = list.filter((a) => toDateTime(a.date, a.time) < new Date() && !ACTIVE(a));
  if (status) list = list.filter((a) => a.status === status);
  if (q) list = list.filter((a) => normalize(`${a.clientName} ${a.offeringName} ${a.serviceName} ${a.protocol}`).includes(q));
  list.sort((a, b) =>
    period === 'anteriores'
      ? toDateTime(b.date, b.time) - toDateTime(a.date, a.time)
      : toDateTime(a.date, a.time) - toDateTime(b.date, b.time),
  );
  return list.map((a) => proAppt(db, a));
}

export async function getProAppointment(id) {
  await delay(150, 300);
  const { pro } = session();
  const db = syncAll();
  const a = db.appointments.find((x) => x.id === id && x.professionalId === pro.id);
  if (!a) throw new ApiError('Agendamento não encontrado.', 'NOT_FOUND');
  const u = db.users.find((x) => x.id === a.userId);
  const showContact = ACTIVE(a);
  return {
    ...proAppt(db, a),
    contact: showContact ? { phone: u?.phone || '', email: u?.email || '' } : null,
    previous: db.appointments.filter((x) => x.professionalId === pro.id && x.userId === a.userId && x.id !== a.id).length,
  };
}

/** Cancelamento pelo profissional: o cliente recebe reembolso integral. */
export async function proCancelAppointment(id, reason) {
  await delay(450, 800);
  const { pro } = session();
  const text = cleanText(reason, 280);
  if (text.length < 5) throw new ApiError('Informe o motivo para o cliente (mínimo de 5 caracteres).', 'VALIDATION', 'reason');
  return mutate((db) => {
    const a = db.appointments.find((x) => x.id === id && x.professionalId === pro.id);
    if (!a) throw new ApiError('Agendamento não encontrado.', 'NOT_FOUND');
    if (!ACTIVE(a) || hasStarted(a)) throw new ApiError('Este agendamento não pode mais ser cancelado.', 'NOT_CANCELABLE');
    const now = new Date().toISOString();
    const payment = db.payments.find((p) => p.id === a.paymentId);
    a.status = 'cancelada';
    a.canceledAt = now;
    a.canceledBy = 'profissional';
    a.cancelReason = text;
    a.updatedAt = now;
    if (payment && payment.status === 'aprovado') {
      payment.status = 'reembolsado';
      a.refund = { amount: payment.amount, status: 'reembolsado' };
      a.history.push({ at: now, label: 'Cancelada pelo profissional — reembolso total' });
    } else {
      a.history.push({ at: now, label: 'Cancelada pelo profissional antes do pagamento' });
    }
    pushNotification(db, a.userId, {
      type: 'cancelamento',
      title: 'Consulta cancelada pelo profissional',
      text: `${a.professionalName} cancelou ${a.serviceName} de ${whenText(a)}. Motivo: ${text}${
        a.refund ? ' O valor será reembolsado integralmente (demonstração).' : ''
      }`,
      link: `/consultas/${a.id}`,
      important: true,
    });
    return proAppt(db, a);
  });
}

/** Registro de presença ou falta (somente depois do horário de início). */
export async function markAttendance(id, attendance) {
  await delay(250, 450);
  const { pro } = session();
  if (!['compareceu', 'faltou'].includes(attendance)) throw new ApiError('Opção inválida.', 'VALIDATION');
  return mutate((db) => {
    const a = db.appointments.find((x) => x.id === id && x.professionalId === pro.id);
    if (!a) throw new ApiError('Agendamento não encontrado.', 'NOT_FOUND');
    if (!hasStarted(a)) throw new ApiError('A presença só pode ser registrada depois do horário de início.', 'TOO_EARLY');
    if (a.status === 'cancelada' || a.status === 'pendente_pagamento') {
      throw new ApiError('Não há presença a registrar para este agendamento.', 'INVALID_STATE');
    }
    a.attendance = attendance;
    a.history.push({
      at: new Date().toISOString(),
      label:
        attendance === 'faltou' ? 'Profissional registrou ausência do cliente' : 'Profissional registrou presença do cliente',
    });
    return proAppt(db, a);
  });
}

// ------------------------------------------------------------------ clientes

function clientStatus(c) {
  if (c.upcoming) return 'ativo';
  if (c.completed >= 2) return 'recorrente';
  if (c.completed === 1) return 'novo';
  return 'inativo';
}

export const CLIENT_STATUS = {
  ativo: { label: 'Com horário marcado', tone: 'green' },
  recorrente: { label: 'Recorrente', tone: 'blue' },
  novo: { label: 'Primeiro atendimento', tone: 'yellow' },
  inativo: { label: 'Sem atendimentos', tone: 'gray' },
};

/** Clientes atendidos (ou com horário) — somente dados necessários ao atendimento. */
export async function listMyClients({ query = '', status = '' } = {}) {
  await delay(250, 500);
  const { pro } = session();
  const db = syncAll();
  const map = new Map();
  db.appointments
    .filter((a) => a.professionalId === pro.id)
    .forEach((a) => {
      const c = map.get(a.userId) || {
        id: a.userId,
        name: clientOf(db, a).name,
        total: 0,
        completed: 0,
        canceled: 0,
        services: new Set(),
        next: null,
        last: null,
      };
      c.total += 1;
      if (a.status === 'concluida') {
        c.completed += 1;
        if (!c.last || a.date > c.last.date) c.last = { date: a.date, time: a.time };
      }
      if (a.status === 'cancelada') c.canceled += 1;
      c.services.add(a.offeringName || a.serviceName);
      if (ACTIVE(a) && toDateTime(a.date, a.time) > new Date()) {
        if (!c.next || toDateTime(a.date, a.time) < toDateTime(c.next.date, c.next.time)) {
          c.next = { id: a.id, date: a.date, time: a.time, status: a.status };
        }
      }
      map.set(a.userId, c);
    });
  const q = normalize(query.trim());
  return [...map.values()]
    .map((c) => ({ ...c, services: [...c.services], upcoming: !!c.next }))
    .map((c) => ({ ...c, status: clientStatus(c) }))
    .filter((c) => (!q || normalize(c.name).includes(q)) && (!status || c.status === status))
    .sort((a, b) => {
      if (a.next && b.next) return toDateTime(a.next.date, a.next.time) - toDateTime(b.next.date, b.next.time);
      if (a.next) return -1;
      if (b.next) return 1;
      return (b.last?.date || '').localeCompare(a.last?.date || '');
    });
}

export async function getClient(userId) {
  await delay(200, 400);
  const { pro } = session();
  const db = syncAll();
  const history = db.appointments
    .filter((a) => a.professionalId === pro.id && a.userId === userId)
    .sort((a, b) => toDateTime(b.date, b.time) - toDateTime(a.date, a.time));
  if (!history.length) throw new ApiError('Cliente não encontrado.', 'NOT_FOUND');
  const u = db.users.find((x) => x.id === userId);
  const hasUpcoming = history.some((a) => ACTIVE(a) && toDateTime(a.date, a.time) > new Date());
  return {
    id: userId,
    name: history[0].clientName || u?.name || 'Cliente',
    since: history[history.length - 1].date,
    contact: hasUpcoming ? { phone: u?.phone || '', email: u?.email || '' } : null,
    history: history.map((a) => proAppt(db, a)),
  };
}

// ------------------------------------------------------------------ financeiro

export const FINANCE_STATUS = {
  recebido: { label: 'Recebido', tone: 'green' },
  a_receber: { label: 'A receber', tone: 'blue' },
  pendente: { label: 'Aguardando pagamento', tone: 'yellow' },
  reembolsado: { label: 'Reembolsado', tone: 'red' },
  retido: { label: 'Cancelamento tardio', tone: 'gray' },
};

function financeStatus(a, payment) {
  if (a.status === 'pendente_pagamento') return 'pendente';
  if (a.status === 'cancelada') {
    if (a.refund?.status === 'fora_do_prazo') return 'retido';
    if (payment) return 'reembolsado';
    return null;
  }
  if (!payment || payment.status !== 'aprovado') return null;
  return a.status === 'concluida' ? 'recebido' : 'a_receber';
}

/**
 * Resumo financeiro por data de atendimento. MODO DEMONSTRAÇÃO: os valores
 * vêm de pagamentos simulados — nenhuma transação real existe.
 */
export async function getFinance({ from, to } = {}) {
  await delay(250, 500);
  const { pro } = session();
  const db = syncAll();
  const items = db.appointments
    .filter((a) => a.professionalId === pro.id && (!from || a.date >= from) && (!to || a.date <= to))
    .map((a) => {
      const payment = db.payments.find((p) => p.id === a.paymentId) || null;
      return { ...a, client: clientOf(db, a), payment, financeStatus: financeStatus(a, payment) };
    })
    .filter((a) => a.financeStatus)
    .sort((a, b) => toDateTime(b.date, b.time) - toDateTime(a.date, a.time));
  const sum = (st) => items.filter((i) => i.financeStatus === st).reduce((s, i) => s + i.price, 0);
  const paid = items.filter((i) => ['recebido', 'a_receber', 'retido'].includes(i.financeStatus));
  const received = sum('recebido') + sum('retido');
  const toReceive = sum('a_receber');
  // série mensal (últimos 6 meses, independe do filtro)
  const months = [];
  const base = new Date();
  for (let i = 5; i >= 0; i -= 1) {
    const d = new Date(base.getFullYear(), base.getMonth() - i, 1);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    const value = db.appointments
      .filter((a) => a.professionalId === pro.id && a.date.startsWith(key))
      .filter((a) => {
        const p = db.payments.find((x) => x.id === a.paymentId);
        const st = financeStatus(a, p);
        return st === 'recebido' || st === 'retido';
      })
      .reduce((s, a) => s + a.price, 0);
    months.push({ key, month: d.getMonth(), year: d.getFullYear(), value });
  }
  return {
    items,
    totals: {
      received,
      toReceive,
      pending: sum('pendente'),
      refunded: sum('reembolsado'),
      estimated: received + toReceive,
      paidCount: paid.length,
      platformFees: paid.reduce((s, i) => s + (i.fee || 0), 0),
      commissionRate: 0,
      byMethod: {
        pix: paid.filter((i) => i.payment?.method === 'pix').reduce((s, i) => s + i.price, 0),
        card: paid.filter((i) => i.payment?.method === 'card').reduce((s, i) => s + i.price, 0),
      },
    },
    months,
    demo: true,
  };
}

// ------------------------------------------------------------------ visão geral

export async function getOverview() {
  await delay(250, 500);
  const { user, pro } = session();
  const db = syncAll();
  const fresh = db.professionals.find((p) => p.id === pro.id);
  const now = new Date();
  const today = toISODate(now);
  const mine = db.appointments.filter((a) => a.professionalId === pro.id);
  const todayList = mine
    .filter((a) => a.date === today && a.status !== 'cancelada')
    .sort((a, b) => a.time.localeCompare(b.time))
    .map((a) => proAppt(db, a));
  const upcoming = mine
    .filter((a) => ACTIVE(a) && toDateTime(a.date, a.time) > now)
    .sort((a, b) => toDateTime(a.date, a.time) - toDateTime(b.date, b.time))
    .map((a) => proAppt(db, a));
  const week = Array.from({ length: 7 }, (_, i) => {
    const iso = toISODate(addDays(now, i));
    const dayAppts = mine.filter((a) => a.date === iso && ACTIVE(a));
    const booked = dayAppts.reduce((s, a) => s + (Number(a.duration) || 60), 0);
    const freeSlots = getSlots(fresh.id, iso, { duration: fresh.availability?.slotMinutes || 60 }).filter(
      (s) => s.status === 'livre',
    ).length;
    return { date: iso, count: dayAppts.length, booked, available: availableMinutes(fresh, iso), freeSlots };
  });
  const bookedMin = week.reduce((s, d) => s + d.booked, 0);
  const availMin = week.reduce((s, d) => s + d.available, 0);
  const monthKey = today.slice(0, 7);
  const monthReceived = mine
    .filter((a) => a.date.startsWith(monthKey) && a.status === 'concluida')
    .filter((a) => db.payments.find((p) => p.id === a.paymentId)?.status === 'aprovado')
    .reduce((s, a) => s + a.price, 0);
  const toReceive = mine
    .filter((a) => a.status === 'agendada')
    .filter((a) => db.payments.find((p) => p.id === a.paymentId)?.status === 'aprovado')
    .reduce((s, a) => s + a.price, 0);
  const notifications = db.notifications
    .filter((n) => n.userId === user.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 4);
  return {
    pro: { ...structuredClone(fresh), ...splitName(fresh.name) },
    progress: completeness(fresh),
    today: todayList,
    upcoming: upcoming.slice(0, 6),
    counts: {
      today: todayList.filter((a) => a.status !== 'cancelada').length,
      next7: week.reduce((s, d) => s + d.count, 0),
      pending: upcoming.filter((a) => a.status === 'pendente_pagamento').length,
      activeOfferings: activeOfferings(fresh).length,
      freeSlots7: week.reduce((s, d) => s + d.freeSlots, 0),
      clients: new Set(mine.map((a) => a.userId)).size,
    },
    occupancy: availMin ? Math.round((bookedMin / availMin) * 100) : 0,
    week,
    finance: { monthReceived, toReceive },
    notifications,
    unread: db.notifications.filter((n) => n.userId === user.id && !n.read).length,
    windowDays: BOOKING_WINDOW_DAYS,
  };
}
