// Dados de demonstração do banco local.
// Tudo o que é criado aqui é FICTÍCIO: profissionais, clientes, consultas,
// pagamentos, notificações e solicitações existem apenas para demonstrar a
// plataforma e são identificados com `demo: true`.

import { hashPassword } from '../utils/crypto';
import { addDays, toISODate, toDateTime } from '../utils/format';
import { PROFESSIONALS, SERVICE_FEE, serviceBySlug } from '../data/catalog';
import { availabilityFromDays, resolveOffering, syncDerived } from './proModel';
import { hashString, uid } from './api';

export const SCHEMA_VERSION = 2;

export const DEMO_PASSWORD = 'Vitalis@123';
export const DEMO_ACCOUNTS = [
  { role: 'usuario', label: 'Paciente', icon: 'person', email: 'demo@vitalis.com', password: DEMO_PASSWORD },
  {
    role: 'profissional',
    label: 'Profissional',
    icon: 'stethoscope',
    email: 'profissional@vitalis.com',
    password: DEMO_PASSWORD,
  },
  { role: 'admin', label: 'Administrador', icon: 'admin_panel_settings', email: 'admin@vitalis.com', password: DEMO_PASSWORD },
];

const DEMO_PRO_ID = 'roberto-alves';

export function emptyDb() {
  return {
    version: SCHEMA_VERSION,
    users: [],
    professionals: [],
    appointments: [],
    payments: [],
    tickets: [],
    notifications: [],
    favorites: [],
    settings: defaultSettings(),
  };
}

export function defaultSettings() {
  return { announcement: { active: false, tone: 'info', text: '' }, disabledServices: [] };
}

const OFFERING_NAMES = {
  'consultas-medicas': (p) => `Consulta – ${p.specialty}`,
  psicologia: () => 'Sessão de psicoterapia',
  fisioterapia: () => 'Sessão de fisioterapia',
  'atividades-fisicas': (p) => `Aula – ${p.specialty}`,
  estetica: (p) => `Atendimento – ${p.specialty}`,
  nutricao: () => 'Consulta nutricional',
  'terapia-de-casal': () => 'Sessão de terapia de casal',
};

/** Perfil do catálogo inicial (fictício) no formato do banco. */
export function catalogProfessional(base) {
  const service = serviceBySlug(base.service);
  const name = (OFFERING_NAMES[base.service] || ((p) => `Consulta de ${p.specialty}`))(base);
  const pro = {
    id: base.id,
    userId: null,
    name: base.name,
    gender: base.gender,
    title: base.title,
    specialty: base.specialty,
    service: base.service,
    bio: `${base.title} com atendimento em ${base.city}. Este é um perfil fictício, criado para demonstrar como a plataforma funciona.`,
    education: [],
    experienceYears: null,
    experience: '',
    registry: null,
    city: base.city,
    address: '',
    modality: 'presencial',
    photo: null,
    publicContact: { showPhone: false, showEmail: false },
    status: 'publicado',
    verified: true,
    rating: base.rating,
    reviews: base.reviews,
    simulated: true,
    offerings: [
      {
        id: `off_${base.id}`,
        serviceSlug: base.service,
        name,
        description: service?.description || '',
        duration: 60,
        price: base.price,
        active: true,
        createdAt: '2024-01-10T12:00:00.000Z',
      },
    ],
    availability: availabilityFromDays(base.days),
    createdAt: '2024-01-10T12:00:00.000Z',
    updatedAt: '2024-01-10T12:00:00.000Z',
    publishedAt: '2024-01-10T12:00:00.000Z',
    demo: true,
  };
  return syncDerived(pro);
}

function nextWeekday(from, offset, allowedDays) {
  let d = addDays(from, offset);
  for (let i = 0; i < 7; i += 1) {
    if (allowedDays.includes(d.getDay())) return d;
    d = addDays(d, 1);
  }
  return d;
}

function prevWeekday(from, offset, allowedDays) {
  let d = addDays(from, -offset);
  for (let i = 0; i < 7; i += 1) {
    if (allowedDays.includes(d.getDay())) return d;
    d = addDays(d, -1);
  }
  return d;
}

/** Consulta + pagamento coerentes (modo demonstração). */
function buildAppointment(db, { user, pro, offering, date, time, status, protocol, method = 'card', attendance, canceledBy }) {
  const service = serviceBySlug(offering.serviceSlug);
  const start = toDateTime(date, time);
  const createdAt = new Date(Math.min(start.getTime() - 5 * 864e5, Date.now() - 36e5)).toISOString();
  const appt = {
    id: uid('apt'),
    protocol,
    userId: user.id,
    clientName: user.name,
    serviceSlug: service.slug,
    serviceName: service.name,
    offeringId: offering.id,
    offeringName: offering.name,
    duration: offering.duration,
    professionalId: pro.id,
    professionalName: pro.name,
    specialty: pro.specialty,
    location: pro.city,
    date,
    time,
    price: offering.price,
    fee: SERVICE_FEE,
    total: offering.price + SERVICE_FEE,
    status,
    createdAt,
    updatedAt: createdAt,
    paymentId: null,
    history: [{ at: createdAt, label: 'Agendamento criado' }],
    demo: true,
  };
  if (attendance) appt.attendance = attendance;
  if (status !== 'pendente_pagamento') {
    const payment = {
      id: uid('pay'),
      appointmentId: appt.id,
      userId: user.id,
      professionalId: pro.id,
      method,
      brand: method === 'card' ? 'Visa' : null,
      last4: method === 'card' ? '4242' : null,
      amount: appt.total,
      status: 'aprovado',
      createdAt,
      paidAt: createdAt,
      demo: true,
    };
    appt.paymentId = payment.id;
    appt.history.push({ at: createdAt, label: `Pagamento aprovado (${method === 'pix' ? 'PIX' : 'cartão'})` });
    if (status === 'cancelada') {
      const at = new Date(new Date(createdAt).getTime() + 2 * 864e5).toISOString();
      appt.canceledAt = at;
      appt.canceledBy = canceledBy || 'cliente';
      const late = canceledBy === 'cliente-tarde';
      appt.canceledBy = late ? 'cliente' : appt.canceledBy;
      if (late) {
        appt.refund = { amount: 0, status: 'fora_do_prazo' };
        appt.history.push({ at, label: 'Consulta cancelada com menos de 24h de antecedência' });
      } else {
        appt.refund = { amount: appt.total, status: 'reembolsado' };
        payment.status = 'reembolsado';
        appt.history.push({ at, label: 'Consulta cancelada com reembolso total' });
      }
    }
    if (status === 'concluida') {
      appt.history.push({ at: new Date(start.getTime() + appt.duration * 6e4).toISOString(), label: 'Consulta realizada' });
    }
    db.payments.push(payment);
  }
  db.appointments.push(appt);
  return appt;
}

const CLIENTS = [
  ['Mariana Souza', 'mariana.souza'],
  ['Pedro Henrique Lima', 'pedro.lima'],
  ['Juliana Castro', 'juliana.castro'],
  ['Rafael Mendes', 'rafael.mendes'],
  ['Beatriz Nogueira', 'beatriz.nogueira'],
  ['Lucas Ferreira', 'lucas.ferreira'],
  ['Camila Duarte', 'camila.duarte'],
];

function note(db, userId, { type, title, text, link = '', important = false, read = false, at }) {
  db.notifications.push({
    id: uid('ntf'),
    userId,
    type,
    title,
    text,
    link,
    important,
    read,
    createdAt: at || new Date().toISOString(),
    demo: true,
  });
}

/** Banco completo de demonstração. */
export async function seed() {
  const db = emptyDb();
  const now = new Date();
  const today = toISODate(now);
  const password = await hashPassword(DEMO_PASSWORD);
  let protocolSeq = 12345;
  const nextProtocol = () => `VIT-${protocolSeq++}`;

  // ---------------------------------------------------------------- perfis do catálogo (fictícios)
  db.professionals = PROFESSIONALS.map(catalogProfessional);

  // ---------------------------------------------------------------- contas de demonstração
  const patient = {
    id: 'usr_demo',
    role: 'usuario',
    status: 'ativo',
    name: 'Silvia Sandra Menezes',
    email: DEMO_ACCOUNTS[0].email,
    phone: '(11) 99999-9999',
    birthDate: '2001-05-15',
    address: 'Rua das Flores, 123 - São Paulo, SP',
    createdAt: '2024-03-12T10:00:00.000Z',
    password,
    prefs: { twoFactor: false, notifyEmail: true, notifySms: false, notifyWhatsapp: true },
    demo: true,
  };
  const proUser = {
    id: 'usr_pro_demo',
    role: 'profissional',
    status: 'ativo',
    professionalId: DEMO_PRO_ID,
    name: 'Roberto Alves',
    email: DEMO_ACCOUNTS[1].email,
    phone: '(11) 98888-0000',
    birthDate: '',
    address: '',
    createdAt: '2024-02-02T10:00:00.000Z',
    password,
    prefs: { twoFactor: false, notifyEmail: true, notifySms: false, notifyWhatsapp: false, notifySystem: true, reminders: true },
    demo: true,
  };
  const admin = {
    id: 'usr_admin',
    role: 'admin',
    status: 'ativo',
    name: 'Administração Vitalis',
    email: DEMO_ACCOUNTS[2].email,
    phone: '(11) 97777-0000',
    birthDate: '',
    address: '',
    createdAt: '2024-01-05T10:00:00.000Z',
    password,
    prefs: { twoFactor: false, notifyEmail: true, notifySms: false, notifyWhatsapp: false },
    demo: true,
  };
  db.users.push(patient, proUser, admin);

  const clients = CLIENTS.map(([name, slug], i) => ({
    id: `usr_cli_${i + 1}`,
    role: 'usuario',
    status: 'ativo',
    name,
    email: `${slug}@exemplo.com`,
    phone: `(11) 90000-00${String(i + 10)}`,
    birthDate: '',
    address: '',
    createdAt: addDays(now, -120 + i * 9).toISOString(),
    password: null, // contas fictícias: não é possível entrar com elas
    prefs: { twoFactor: false, notifyEmail: true, notifySms: false, notifyWhatsapp: false },
    demo: true,
  }));
  db.users.push(...clients);

  // ---------------------------------------------------------------- profissional de demonstração (conta real)
  const rob = db.professionals.find((p) => p.id === DEMO_PRO_ID);
  Object.assign(rob, {
    userId: proUser.id,
    name: 'Dr. Roberto Alves',
    title: 'Fisioterapeuta',
    specialty: 'Fisioterapia ortopédica',
    bio: 'Fisioterapeuta com foco em reabilitação ortopédica, dores na coluna e retorno ao esporte. Atendo com avaliação individual, exercícios terapêuticos e orientação para o dia a dia. Perfil fictício de demonstração.',
    education: ['Graduação em Fisioterapia', 'Especialização em Fisioterapia Ortopédica e Esportiva'],
    experienceYears: 9,
    experience: 'Atendimento em clínica de reabilitação e acompanhamento de atletas amadores.',
    registry: { council: 'CREFITO', number: '000000-F', uf: 'SP' },
    address: 'Centro, Guarulhos – SP (endereço completo enviado após o agendamento)',
    modality: 'presencial',
    simulated: false,
    offerings: [
      {
        id: 'off_rob_sessao',
        serviceSlug: 'fisioterapia',
        name: 'Sessão de fisioterapia',
        description: 'Atendimento individual com exercícios terapêuticos e recursos manuais.',
        duration: 60,
        price: 150,
        active: true,
        createdAt: '2024-02-02T12:00:00.000Z',
      },
      {
        id: 'off_rob_avaliacao',
        serviceSlug: 'fisioterapia',
        name: 'Avaliação fisioterapêutica',
        description: 'Primeira consulta: avaliação postural e funcional e plano de tratamento.',
        duration: 60,
        price: 180,
        active: true,
        createdAt: '2024-02-02T12:00:00.000Z',
      },
      {
        id: 'off_rob_retorno',
        serviceSlug: 'fisioterapia',
        name: 'Retorno / reavaliação',
        description: 'Acompanhamento da evolução e ajuste dos exercícios.',
        duration: 30,
        price: 90,
        active: true,
        createdAt: '2024-03-15T12:00:00.000Z',
      },
      {
        id: 'off_rob_pilates',
        serviceSlug: 'atividades-fisicas',
        name: 'Pilates clínico',
        description: 'Aulas individuais de pilates com foco em reabilitação (em preparação).',
        duration: 60,
        price: 120,
        active: false,
        createdAt: '2024-06-01T12:00:00.000Z',
      },
    ],
    availability: availabilityFromDays(
      [1, 2, 3, 4, 5],
      { start: '08:00', end: '17:00', breakStart: '12:00', breakEnd: '13:00' },
      30,
    ),
  });
  // Bloqueio parcial na próxima semana e atendimento extra (exemplos de exceções)
  const blockDay = toISODate(nextWeekday(now, 8, [5]));
  rob.availability.exceptions.push({
    id: 'exc_rob_curso',
    date: blockDay,
    type: 'bloqueio',
    allDay: false,
    start: '13:00',
    end: '17:00',
    reason: 'Curso de atualização',
  });
  const extraDay = toISODate(nextWeekday(now, 9, [6]));
  rob.availability.exceptions.push({
    id: 'exc_rob_sabado',
    date: extraDay,
    type: 'horario_especial',
    allDay: false,
    start: '08:00',
    end: '12:00',
    reason: 'Mutirão de avaliações',
  });
  // Demonstração em fim de semana: abre um horário especial hoje para a agenda não ficar vazia
  if (now.getDay() === 0 || now.getDay() === 6) {
    rob.availability.exceptions.push({
      id: 'exc_rob_hoje',
      date: today,
      type: 'horario_especial',
      allDay: false,
      start: '08:00',
      end: '18:00',
      reason: 'Atendimento extra',
    });
  }
  syncDerived(rob);

  // ---------------------------------------------------------------- profissional aguardando verificação
  const liviaUser = {
    id: 'usr_pro_pendente',
    role: 'profissional',
    status: 'ativo',
    professionalId: 'livia-andrade',
    name: 'Lívia Andrade',
    email: 'livia.andrade@exemplo.com',
    phone: '(11) 90000-0099',
    birthDate: '',
    address: '',
    createdAt: addDays(now, -3).toISOString(),
    password: null,
    prefs: { twoFactor: false, notifyEmail: true, notifySms: false, notifyWhatsapp: false, notifySystem: true, reminders: true },
    demo: true,
  };
  db.users.push(liviaUser);
  const livia = syncDerived({
    id: 'livia-andrade',
    userId: liviaUser.id,
    name: 'Dra. Lívia Andrade',
    gender: 'f',
    title: 'Nutricionista',
    specialty: 'Nutrição clínica',
    service: 'nutricao',
    bio: 'Nutricionista com atendimento voltado à reeducação alimentar e ao acompanhamento de rotina. Perfil fictício enviado para verificação.',
    education: ['Graduação em Nutrição'],
    experienceYears: 4,
    experience: 'Atendimento em consultório e orientação em academias.',
    registry: { council: 'CRN', number: '00000', uf: 'SP' },
    city: 'Barueri, SP',
    address: '',
    modality: 'ambos',
    photo: null,
    publicContact: { showPhone: false, showEmail: false },
    status: 'em_analise',
    verified: false,
    rating: null,
    reviews: null,
    simulated: false,
    offerings: [
      {
        id: 'off_livia_consulta',
        serviceSlug: 'nutricao',
        name: 'Consulta nutricional',
        description: 'Avaliação, plano alimentar e orientações.',
        duration: 60,
        price: 170,
        active: true,
        createdAt: addDays(now, -2).toISOString(),
      },
      {
        id: 'off_livia_retorno',
        serviceSlug: 'nutricao',
        name: 'Retorno nutricional',
        description: 'Acompanhamento e ajustes do plano.',
        duration: 30,
        price: 100,
        active: true,
        createdAt: addDays(now, -2).toISOString(),
      },
    ],
    availability: availabilityFromDays([2, 4], { start: '09:00', end: '17:00', breakStart: '12:00', breakEnd: '13:00' }, 30),
    submittedAt: addDays(now, -2).toISOString(),
    createdAt: addDays(now, -3).toISOString(),
    updatedAt: addDays(now, -2).toISOString(),
    demo: true,
  });
  db.professionals.push(livia);

  // ---------------------------------------------------------------- consultas da conta de paciente (Silvia)
  const proOf = (id) => db.professionals.find((p) => p.id === id);
  const silviaPlan = [
    { proId: 'carlos-silva', when: prevWeekday(now, 12, [1, 3, 5]), time: '10:00', status: 'concluida' },
    { proId: 'ana-costa', when: prevWeekday(now, 16, [2, 4]), time: '14:00', status: 'concluida', method: 'pix' },
    { proId: 'joao-santos', when: prevWeekday(now, 55, [1, 3, 5]), time: '11:00', status: 'concluida' },
    { proId: 'carla-mendes', when: prevWeekday(now, 30, [2, 4]), time: '16:00', status: 'cancelada' },
    { proId: 'roberto-alves', when: nextWeekday(now, 6, [1, 2, 3, 4, 5]), time: '09:00', status: 'agendada', method: 'pix' },
    { proId: 'patricia-lima', when: nextWeekday(now, 20, [1, 2, 3, 4, 5]), time: '15:00', status: 'agendada' },
  ];
  silviaPlan.forEach((p) => {
    const pro = proOf(p.proId);
    const offering = p.proId === DEMO_PRO_ID ? pro.offerings[0] : resolveOffering(pro, pro.service);
    buildAppointment(db, {
      user: patient,
      pro,
      offering,
      date: toISODate(p.when),
      time: p.time,
      status: p.status,
      protocol: nextProtocol(),
      method: p.method,
    });
  });

  // ---------------------------------------------------------------- agenda do profissional de demonstração
  const robDays = (iso) => {
    const d = new Date(`${iso}T12:00:00`);
    const ex = rob.availability.exceptions.find((e) => e.date === iso && e.type === 'horario_especial');
    return ex || [1, 2, 3, 4, 5].includes(d.getDay());
  };
  const silviaRob = toISODate(silviaPlan[4].when);
  const times = ['08:00', '10:00', '14:00', '15:30'];
  let k = 0;
  for (let offset = -28; offset <= 14; offset += 1) {
    const iso = toISODate(addDays(now, offset));
    if (!robDays(iso)) continue;
    if (iso === extraDay) continue; // sábado extra fica livre para novos agendamentos
    const h = hashString(`rob|${iso}`);
    const count = offset === 0 ? 3 : 1 + (h % 2);
    for (let j = 0; j < count; j += 1) {
      const time = times[(h + j * 2) % times.length];
      if (iso === blockDay && toDateTime(iso, time).getHours() >= 13) continue;
      if (db.appointments.some((a) => a.professionalId === rob.id && a.date === iso && a.time === time)) continue;
      if (iso === silviaRob && time === '08:00') continue;
      const offering = rob.offerings[[0, 0, 1, 2][(h + j) % 4]];
      const start = toDateTime(iso, time);
      const past = start.getTime() + offering.duration * 6e4 < now.getTime();
      // os dois últimos clientes só têm histórico (variedade de situações na lista de clientes)
      const client = past ? clients[k % clients.length] : clients[k % 5];
      let status = past ? 'concluida' : 'agendada';
      let canceledBy;
      let attendance;
      if (past && k % 7 === 3) {
        status = 'cancelada';
        canceledBy = k % 2 ? 'cliente' : 'cliente-tarde';
      }
      if (past && status === 'concluida') attendance = k % 9 === 5 ? 'faltou' : 'compareceu';
      if (!past && offset > 1 && k % 6 === 2) status = 'pendente_pagamento';
      buildAppointment(db, {
        user: client,
        pro: rob,
        offering,
        date: iso,
        time,
        status,
        protocol: nextProtocol(),
        method: k % 2 ? 'pix' : 'card',
        attendance,
        canceledBy,
      });
      k += 1;
    }
  }

  // ---------------------------------------------------------------- notificações
  const hoursAgo = (h) => new Date(now.getTime() - h * 36e5).toISOString();
  const nextRob = db.appointments
    .filter((a) => a.professionalId === rob.id && a.status === 'agendada' && toDateTime(a.date, a.time) > now)
    .sort((a, b) => toDateTime(a.date, a.time) - toDateTime(b.date, b.time));
  if (nextRob[0]) {
    note(db, proUser.id, {
      type: 'agendamento',
      title: 'Novo agendamento confirmado',
      text: `${nextRob[0].clientName} · ${nextRob[0].offeringName} em ${nextRob[0].date.split('-').reverse().join('/')} às ${nextRob[0].time}.`,
      link: '/profissional/agenda',
      at: hoursAgo(2),
    });
  }
  const canceledRob = db.appointments.find((a) => a.professionalId === rob.id && a.status === 'cancelada');
  if (canceledRob) {
    note(db, proUser.id, {
      type: 'cancelamento',
      title: 'Agendamento cancelado pelo cliente',
      text: `${canceledRob.clientName} cancelou o horário de ${canceledRob.date.split('-').reverse().join('/')} às ${canceledRob.time}.`,
      link: '/profissional/agenda?visao=lista&periodo=anteriores',
      at: hoursAgo(20),
      read: true,
    });
  }
  note(db, proUser.id, {
    type: 'pagamento',
    title: 'Pagamento confirmado (demonstração)',
    text: 'Um cliente concluiu o pagamento de um agendamento. Nenhum valor real foi transferido.',
    link: '/profissional/financeiro',
    at: hoursAgo(5),
  });
  note(db, proUser.id, {
    type: 'aviso',
    title: 'Bem-vindo ao painel do profissional',
    text: 'Configure seus horários e serviços para receber agendamentos. Os dados desta conta são fictícios.',
    link: '/profissional/horarios',
    important: true,
    at: hoursAgo(30),
  });
  note(db, proUser.id, {
    type: 'sistema',
    title: 'Perfil verificado',
    text: 'Seus dados profissionais foram verificados pela equipe Vitalis.',
    link: '/profissional/perfil',
    read: true,
    at: hoursAgo(24 * 40),
  });
  note(db, patient.id, {
    type: 'pagamento',
    title: 'Pagamento aprovado',
    text: 'O pagamento da sua consulta de Fisioterapia foi aprovado (demonstração).',
    link: '/consultas',
    read: true,
    at: hoursAgo(26),
  });
  note(db, patient.id, {
    type: 'aviso',
    title: 'Novidade: favoritos',
    text: 'Agora você pode salvar profissionais nos favoritos e encontrá-los rapidamente.',
    link: '/profissionais',
    at: hoursAgo(3),
  });
  note(db, admin.id, {
    type: 'aviso',
    title: 'Profissional aguardando verificação',
    text: `${livia.name} (${livia.title}) enviou o perfil para análise.`,
    link: '/admin/profissionais?status=em_analise',
    important: true,
    at: hoursAgo(40),
  });

  // ---------------------------------------------------------------- solicitações de suporte
  db.tickets.push(
    {
      id: uid('tkt'),
      protocol: 'SUP-104211',
      userId: clients[2].id,
      name: clients[2].name,
      email: clients[2].email,
      subject: 'Pagamento',
      message: 'Apareceu um pagamento recusado no meu histórico, mas a consulta foi confirmada depois pelo PIX. Está tudo certo?',
      createdAt: hoursAgo(50),
      status: 'em_andamento',
      adminNote: 'Verificado: a tentativa recusada não gera cobrança. Responder ao cliente.',
      demo: true,
    },
    {
      id: uid('tkt'),
      protocol: 'SUP-104288',
      userId: null,
      name: 'Clínica Bem Viver (visitante)',
      email: 'contato@exemplo.com',
      subject: 'Para profissionais',
      message: 'Somos uma clínica pequena com três profissionais. Como funciona o cadastro de vários profissionais?',
      createdAt: hoursAgo(9),
      status: 'aberto',
      adminNote: '',
      demo: true,
    },
  );
  note(db, admin.id, {
    type: 'sistema',
    title: 'Nova solicitação de suporte',
    text: 'Clínica Bem Viver (visitante) — Para profissionais.',
    link: '/admin/solicitacoes',
    at: hoursAgo(9),
  });

  return db;
}

/**
 * Migração não destrutiva: mantém usuários, consultas, pagamentos e mensagens
 * de uma versão anterior e acrescenta somente o que falta.
 */
export async function migrate(stored) {
  const fresh = await seed();
  const db = { ...emptyDb(), ...stored, version: SCHEMA_VERSION };
  db.users = (stored.users || []).map((u) => ({ status: 'ativo', ...u }));
  const emails = new Set(db.users.map((u) => String(u.email).toLowerCase()));
  const keptIds = new Set(db.users.map((u) => u.id));
  fresh.users.forEach((u) => {
    if (!emails.has(u.email) && !keptIds.has(u.id)) db.users.push(u);
  });
  const userIds = new Set(db.users.map((u) => u.id));
  const storedApptUsers = new Set((stored.appointments || []).map((a) => a.userId));

  db.professionals = stored.professionals?.length ? stored.professionals : fresh.professionals;
  db.appointments = (stored.appointments || []).map((a) => ({ duration: 60, clientName: '', ...a }));
  db.appointments.forEach((a) => {
    if (!a.clientName) a.clientName = db.users.find((u) => u.id === a.userId)?.name || 'Cliente';
    if (!a.offeringId) {
      const pro = db.professionals.find((p) => p.id === a.professionalId);
      const off = pro && resolveOffering(pro, a.serviceSlug);
      if (off) {
        a.offeringId = off.id;
        a.offeringName = off.name;
      }
    }
  });
  const newAppts = fresh.appointments.filter((a) => userIds.has(a.userId) && !storedApptUsers.has(a.userId));
  db.appointments.push(...newAppts);
  const newApptIds = new Set(newAppts.map((a) => a.id));
  db.payments = (stored.payments || []).map((p) => ({
    professionalId: db.appointments.find((a) => a.id === p.appointmentId)?.professionalId || null,
    ...p,
  }));
  db.payments.push(...fresh.payments.filter((p) => newApptIds.has(p.appointmentId)));
  db.tickets = [
    ...(stored.tickets || []).map((t) => ({ ...t, status: t.status === 'registrado' ? 'aberto' : t.status })),
    ...fresh.tickets,
  ];
  db.notifications = [...(stored.notifications || []), ...fresh.notifications.filter((n) => userIds.has(n.userId))];
  db.favorites = stored.favorites || [];
  db.settings = { ...defaultSettings(), ...(stored.settings || {}) };
  return db;
}
