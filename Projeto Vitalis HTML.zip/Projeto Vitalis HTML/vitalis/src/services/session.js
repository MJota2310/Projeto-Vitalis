// Sessão e autorização da camada de serviços.
//
// Esta camada faz o papel do back-end da demonstração: cada operação protegida
// descobre QUEM está chamando a partir da sessão (como um servidor faria com um
// cookie ou token) e confere o PAPEL no registro do usuário — nunca no que a
// tela informa. Assim, esconder um menu não é a única proteção: chamar uma
// função de profissional ou de administrador sem permissão gera erro.
//
// Importante: como tudo roda no navegador, esta verificação organiza as regras,
// mas não substitui um servidor. Em produção, a mesma lógica deve ficar na API.

import { getDb } from './db';
import { local, session, KEYS } from './storage';
import { ApiError } from './api';

export const ROLES = {
  usuario: { label: 'Paciente', home: '/painel' },
  profissional: { label: 'Profissional', home: '/profissional' },
  admin: { label: 'Administrador', home: '/admin' },
};

export function readSession() {
  return session.get(KEYS.session) || local.get(KEYS.session) || null;
}

export function writeSession(userId, remember) {
  const data = { userId, createdAt: new Date().toISOString(), remember: !!remember };
  if (remember) {
    local.set(KEYS.session, data);
    session.remove(KEYS.session);
  } else {
    session.set(KEYS.session, data);
    local.remove(KEYS.session);
  }
  return data;
}

export function clearSession() {
  local.remove(KEYS.session);
  session.remove(KEYS.session);
}

/** Usuário da sessão atual (registro completo do banco) ou null. */
export function currentUserRecord() {
  const s = readSession();
  if (!s?.userId) return null;
  const user = getDb().users.find((u) => u.id === s.userId);
  if (!user || user.status === 'suspenso') return null;
  return user;
}

/** Exige sessão válida e, opcionalmente, um dos papéis informados. */
export function requireUser(roles) {
  const user = currentUserRecord();
  if (!user) throw new ApiError('Sua sessão expirou. Entre novamente.', 'UNAUTHENTICATED');
  if (roles && !roles.includes(user.role)) {
    throw new ApiError('Você não tem permissão para acessar este recurso.', 'FORBIDDEN');
  }
  return user;
}

/** Garante que a operação é feita pelo próprio titular dos dados. */
export function assertSelf(userId) {
  const user = requireUser();
  if (user.id !== userId) throw new ApiError('Você não tem permissão para acessar este recurso.', 'FORBIDDEN');
  return user;
}

/** Profissional da sessão (exige papel "profissional"). */
export function requireProfessional() {
  const user = requireUser(['profissional']);
  const pro = getDb().professionals.find((p) => p.id === user.professionalId && p.userId === user.id) || null;
  return { user, pro };
}

export function homeFor(user) {
  return ROLES[user?.role]?.home || '/painel';
}
