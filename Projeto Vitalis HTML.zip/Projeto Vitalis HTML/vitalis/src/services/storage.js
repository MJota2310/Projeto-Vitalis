// Acesso seguro ao armazenamento do navegador.
// Em janelas privadas ou quando o armazenamento está bloqueado, os métodos
// nativos podem lançar exceções — nesses casos usamos memória como fallback,
// para que a aplicação continue funcionando durante a sessão.

const memory = { local: new Map(), session: new Map() };

function getStore(kind) {
  try {
    const store = kind === 'session' ? window.sessionStorage : window.localStorage;
    const probe = '__vitalis_probe__';
    store.setItem(probe, '1');
    store.removeItem(probe);
    return store;
  } catch {
    return null;
  }
}

function makeApi(kind) {
  return {
    get(key, fallback = null) {
      const store = getStore(kind);
      try {
        const raw = store ? store.getItem(key) : memory[kind].get(key);
        return raw == null ? fallback : JSON.parse(raw);
      } catch {
        return fallback;
      }
    },
    set(key, value) {
      const raw = JSON.stringify(value);
      const store = getStore(kind);
      try {
        if (store) store.setItem(key, raw);
        else memory[kind].set(key, raw);
      } catch {
        memory[kind].set(key, raw);
      }
    },
    remove(key) {
      const store = getStore(kind);
      try {
        if (store) store.removeItem(key);
      } catch {
        /* ignora */
      }
      memory[kind].delete(key);
    },
  };
}

export const local = makeApi('local');
export const session = makeApi('session');

export const KEYS = {
  db: 'vitalis:db:v1',
  session: 'vitalis:session',
  bookingDraft: 'vitalis:booking-draft',
  demoNotice: 'vitalis:demo-notice-dismissed',
};
