// Utilitários de avatar (separados para evitar dependências circulares).
export { initials } from './format';
export { proEmoji } from '../data/catalog';

/**
 * Reduz uma imagem escolhida pelo usuário para um quadrado de até `size` px e
 * devolve um data URL JPEG (cabe no armazenamento local da demonstração).
 */
export function resizeImage(file, size = 256) {
  return new Promise((resolve, reject) => {
    if (!file || !/^image\/(png|jpe?g|webp)$/.test(file.type)) {
      reject(new Error('Envie uma imagem PNG, JPG ou WEBP.'));
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      reject(new Error('A imagem deve ter no máximo 5 MB.'));
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const side = Math.min(img.width, img.height);
      const canvas = document.createElement('canvas');
      canvas.width = size;
      canvas.height = size;
      const ctx = canvas.getContext('2d');
      ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, size, size);
      URL.revokeObjectURL(url);
      resolve(canvas.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Não foi possível ler esta imagem.'));
    };
    img.src = url;
  });
}
