// Hash de senha para o modo demonstração.
// A senha NUNCA é salva em texto puro: guardamos apenas um hash PBKDF2-SHA256
// com sal aleatório. Em produção, a autenticação deve ser feita no servidor.

const ITERATIONS = 120_000;

function toHex(buffer) {
  return Array.from(new Uint8Array(buffer))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

function fromHex(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i += 1) bytes[i] = parseInt(hex.substr(i * 2, 2), 16);
  return bytes;
}

function hasSubtle() {
  return typeof crypto !== 'undefined' && crypto.subtle && typeof crypto.subtle.importKey === 'function';
}

// Fallback simples (ambientes sem WebCrypto, ex.: http inseguro). Não é
// criptograficamente forte, mas mantém a senha fora do armazenamento.
function fallbackHash(password, saltHex) {
  let h1 = 0xdeadbeef;
  let h2 = 0x41c6ce57;
  const str = `${saltHex}:${password}`;
  for (let r = 0; r < 2000; r += 1) {
    for (let i = 0; i < str.length; i += 1) {
      const ch = str.charCodeAt(i) + r;
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
  }
  return `${(h1 >>> 0).toString(16)}${(h2 >>> 0).toString(16)}`;
}

export function randomHex(bytes = 16) {
  const arr = new Uint8Array(bytes);
  if (typeof crypto !== 'undefined' && crypto.getRandomValues) crypto.getRandomValues(arr);
  else for (let i = 0; i < bytes; i += 1) arr[i] = Math.floor(Math.random() * 256);
  return toHex(arr);
}

export async function hashPassword(password, saltHex = randomHex(16)) {
  if (!hasSubtle()) return { salt: saltHex, hash: fallbackHash(password, saltHex), algo: 'fallback' };
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt: fromHex(saltHex), iterations: ITERATIONS, hash: 'SHA-256' },
    key,
    256,
  );
  return { salt: saltHex, hash: toHex(bits), algo: 'pbkdf2-sha256' };
}

export async function verifyPassword(password, record) {
  if (!record?.salt || !record?.hash) return false;
  const { hash } = await hashPassword(password, record.salt);
  // comparação em tempo constante
  if (hash.length !== record.hash.length) return false;
  let diff = 0;
  for (let i = 0; i < hash.length; i += 1) diff |= hash.charCodeAt(i) ^ record.hash.charCodeAt(i);
  return diff === 0;
}
