// Formatação (moeda, datas e textos) no padrão pt-BR.

const currencyFmt = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

/** 250 → "R$ 250,00" */
export function formatCurrency(value) {
  return currencyFmt.format(Number(value) || 0).replace(/ /g, ' ');
}

/** 250 → "R$ 250" (usado nos cards de profissionais, como no Figma) */
export function formatPriceShort(value) {
  const n = Number(value) || 0;
  return Number.isInteger(n) ? `R$ ${n}` : formatCurrency(n);
}

export const WEEKDAYS_SHORT = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
export const WEEKDAYS_LONG = ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'];
export const MONTHS = [
  'janeiro',
  'fevereiro',
  'março',
  'abril',
  'maio',
  'junho',
  'julho',
  'agosto',
  'setembro',
  'outubro',
  'novembro',
  'dezembro',
];

const pad = (n) => String(n).padStart(2, '0');

/** Date → "2026-05-15" (data local, sem fuso) */
export function toISODate(date) {
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;
}

/** "2026-05-15" → Date (meia-noite local) */
export function parseISODate(iso) {
  if (!iso) return null;
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d);
}

/** "2026-05-15" + "10:00" → Date */
export function toDateTime(iso, time = '00:00') {
  const d = parseISODate(iso);
  if (!d) return null;
  const [h, min] = time.split(':').map(Number);
  d.setHours(h || 0, min || 0, 0, 0);
  return d;
}

/** "2026-05-15" → "15/05/2026" */
export function formatDateBR(iso) {
  const d = parseISODate(iso);
  if (!d) return '—';
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
}

/** "2026-05-15" → "sexta-feira, 15 de maio" */
export function formatDateLong(iso, withYear = false) {
  const d = parseISODate(iso);
  if (!d) return '—';
  const base = `${WEEKDAYS_LONG[d.getDay()]}, ${d.getDate()} de ${MONTHS[d.getMonth()]}`;
  return withYear ? `${base} de ${d.getFullYear()}` : base;
}

/** Timestamp ISO completo → "15/05/2026 às 10:32" */
export function formatDateTimeBR(isoString) {
  if (!isoString) return '—';
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return '—';
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} às ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export function addDays(date, days) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

/** Diferença em horas entre agora e a data/hora informada (negativa = passado). */
export function hoursUntil(iso, time) {
  const target = toDateTime(iso, time);
  if (!target) return 0;
  return (target.getTime() - Date.now()) / 36e5;
}

/** Texto relativo curto: "hoje", "amanhã", "em 5 dias", "há 3 dias". */
export function relativeDay(iso) {
  const today = parseISODate(toISODate(new Date()));
  const d = parseISODate(iso);
  if (!d) return '';
  const diff = Math.round((d - today) / 864e5);
  if (diff === 0) return 'hoje';
  if (diff === 1) return 'amanhã';
  if (diff === -1) return 'ontem';
  if (diff > 1) return `em ${diff} dias`;
  return `há ${Math.abs(diff)} dias`;
}

export function firstName(name = '') {
  return name.trim().split(/\s+/)[0] || '';
}

export function initials(name = '') {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return '?';
  const first = parts[0][0];
  const last = parts.length > 1 ? parts[parts.length - 1][0] : '';
  return (first + last).toUpperCase();
}

export function normalize(text = '') {
  return String(text)
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '');
}

export function pluralize(count, singular, plural) {
  return `${count} ${count === 1 ? singular : plural}`;
}

/** Timestamp ISO → "agora", "há 5 min", "há 2 h", "ontem", "há 3 dias" ou a data. */
export function relativeTime(isoString) {
  const d = new Date(isoString);
  if (Number.isNaN(d.getTime())) return '';
  const diff = (Date.now() - d.getTime()) / 1000;
  if (diff < 60) return 'agora';
  if (diff < 3600) return `há ${Math.floor(diff / 60)} min`;
  if (diff < 86400) return `há ${Math.floor(diff / 3600)} h`;
  const days = Math.floor(diff / 86400);
  if (days === 1) return 'ontem';
  if (days < 7) return `há ${days} dias`;
  return formatDateBR(toISODate(d));
}

/** "09:00" + 60 → "09:00–10:00" */
export function formatTimeRange(time, duration = 60) {
  const [h, m] = String(time).split(':').map(Number);
  const end = h * 60 + m + Number(duration || 60);
  return `${time}–${pad(Math.floor(end / 60))}:${pad(end % 60)}`;
}

/** Segunda-feira da semana da data informada. */
export function startOfWeek(date) {
  const d = new Date(date.getFullYear(), date.getMonth(), date.getDate());
  const dow = (d.getDay() + 6) % 7;
  d.setDate(d.getDate() - dow);
  return d;
}

/** 7 → "julho de 2026" (mês com base 0) */
export function monthLabel(month, year) {
  return `${MONTHS[month]} de ${year}`;
}

/** Abreviação de mês: 0 → "jan" */
export const MONTHS_SHORT = ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'];

/** "2026-05-15" → "15 mai" */
export function formatDayMonth(iso) {
  const d = parseISODate(iso);
  return d ? `${d.getDate()} ${MONTHS_SHORT[d.getMonth()]}` : '—';
}

/** Moeda compacta para eixos e cartões: 1500 → "R$ 1,5 mil" */
export function formatCurrencyCompact(value) {
  const n = Number(value) || 0;
  if (Math.abs(n) >= 1000) return `R$ ${(n / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 })} mil`;
  return `R$ ${n.toLocaleString('pt-BR', { maximumFractionDigits: 0 })}`;
}
