/** 'smooth' ou 'auto', respeitando a preferência "reduzir movimento" do sistema. */
export function scrollBehavior() {
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth';
  } catch {
    return 'smooth';
  }
}
