// Regras de validação dos formulários. Cada função retorna uma mensagem de erro
// (string) ou '' quando o valor é válido.

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export const required =
  (label = 'Este campo') =>
  (v) =>
    String(v ?? '').trim() ? '' : `${label} é obrigatório.`;

export function validateName(v) {
  const value = String(v ?? '').trim();
  if (!value) return 'Informe seu nome completo.';
  if (value.split(/\s+/).length < 2) return 'Digite nome e sobrenome.';
  if (value.length > 80) return 'O nome deve ter no máximo 80 caracteres.';
  if (!/^[A-Za-zÀ-ÖØ-öø-ÿ'\-\s.]+$/.test(value)) return 'Use apenas letras no nome.';
  return '';
}

export function validateEmail(v) {
  const value = String(v ?? '').trim();
  if (!value) return 'Informe seu e-mail.';
  if (!EMAIL_RE.test(value)) return 'Digite um e-mail válido (ex.: seu@email.com).';
  if (value.length > 120) return 'E-mail muito longo.';
  return '';
}

export function validatePhone(v) {
  const digits = String(v ?? '').replace(/\D/g, '');
  if (!digits) return 'Informe seu telefone.';
  if (digits.length < 10 || digits.length > 11) return 'Telefone deve ter DDD + número (10 ou 11 dígitos).';
  return '';
}

export function passwordChecks(v = '') {
  return {
    length: v.length >= 8,
    letter: /[A-Za-zÀ-ÿ]/.test(v),
    number: /\d/.test(v),
    special: /[^A-Za-z0-9À-ÿ]/.test(v),
  };
}

/** 0 a 4 — usado no medidor de força da senha. */
export function passwordStrength(v = '') {
  if (!v) return 0;
  const c = passwordChecks(v);
  let score = [c.length, c.letter, c.number, c.special].filter(Boolean).length;
  if (v.length >= 12 && score >= 3) score = 4;
  return Math.min(score, 4);
}

export function validatePassword(v) {
  const value = String(v ?? '');
  if (!value) return 'Crie uma senha.';
  const c = passwordChecks(value);
  if (!c.length) return 'A senha deve ter pelo menos 8 caracteres.';
  if (!c.letter || !c.number) return 'Use letras e números na senha.';
  if (value.length > 64) return 'A senha deve ter no máximo 64 caracteres.';
  return '';
}

export const validateConfirm = (password) => (v) => {
  if (!v) return 'Confirme sua senha.';
  return v === password ? '' : 'As senhas não coincidem.';
};

export function validateBirthDate(v) {
  if (!v) return 'Informe sua data de nascimento.';
  const d = new Date(`${v}T00:00:00`);
  if (Number.isNaN(d.getTime())) return 'Data inválida.';
  const now = new Date();
  if (d > now) return 'A data não pode estar no futuro.';
  if (now.getFullYear() - d.getFullYear() > 120) return 'Verifique o ano informado.';
  return '';
}

/* ---------------------------------------------------------------------------
   Cartão (usado apenas para validar o formulário no modo demonstração —
   nenhum dado de cartão é armazenado).
   --------------------------------------------------------------------------- */
export function luhnCheck(number) {
  const digits = String(number).replace(/\D/g, '');
  let sum = 0;
  let double = false;
  for (let i = digits.length - 1; i >= 0; i -= 1) {
    let d = Number(digits[i]);
    if (double) {
      d *= 2;
      if (d > 9) d -= 9;
    }
    sum += d;
    double = !double;
  }
  return digits.length > 0 && sum % 10 === 0;
}

export function cardBrand(number) {
  const n = String(number).replace(/\D/g, '');
  if (/^4/.test(n)) return 'Visa';
  if (/^(5[1-5]|2[2-7])/.test(n)) return 'Mastercard';
  if (/^3[47]/.test(n)) return 'American Express';
  if (/^(606282|3841)/.test(n)) return 'Hipercard';
  if (/^(4011|4312|4389|4514|4576|5041|5066|5067|509|6277|6362|6363|650|6516|6550)/.test(n)) return 'Elo';
  return 'Cartão';
}

export function validateCardNumber(v) {
  const digits = String(v ?? '').replace(/\D/g, '');
  if (!digits) return 'Informe o número do cartão.';
  if (digits.length < 13 || digits.length > 19) return 'Número do cartão incompleto.';
  if (!luhnCheck(digits)) return 'Número do cartão inválido.';
  return '';
}

export function validateCardName(v) {
  const value = String(v ?? '').trim();
  if (!value) return 'Informe o nome impresso no cartão.';
  if (value.length < 3) return 'Nome muito curto.';
  if (!/^[A-Za-zÀ-ÿ'\s.]+$/.test(value)) return 'Use apenas letras.';
  return '';
}

export function validateExpiry(v) {
  const m = String(v ?? '').match(/^(\d{2})\/(\d{2})$/);
  if (!m) return 'Use o formato MM/AA.';
  const month = Number(m[1]);
  const year = 2000 + Number(m[2]);
  if (month < 1 || month > 12) return 'Mês inválido.';
  const now = new Date();
  const endOfMonth = new Date(year, month, 0, 23, 59, 59);
  if (endOfMonth < now) return 'Cartão vencido.';
  if (year > now.getFullYear() + 20) return 'Ano inválido.';
  return '';
}

export function validateCvv(v, brand) {
  const digits = String(v ?? '').replace(/\D/g, '');
  const len = brand === 'American Express' ? 4 : 3;
  if (!digits) return 'Informe o CVV.';
  if (digits.length !== len) return `O CVV tem ${len} dígitos.`;
  return '';
}

/** Executa um mapa de validadores { campo: fn } e retorna { campo: erro }. */
export function runValidators(values, validators) {
  const errors = {};
  Object.entries(validators).forEach(([field, fn]) => {
    const msg = fn(values[field], values);
    if (msg) errors[field] = msg;
  });
  return errors;
}
