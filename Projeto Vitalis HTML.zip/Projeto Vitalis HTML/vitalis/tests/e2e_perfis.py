"""
Testes ponta a ponta dos três perfis do Vitalis (paciente, profissional e
administração), das permissões e do layout no celular (Playwright para Python).

Como rodar:
  1. npm run dev                      (servidor em http://127.0.0.1:5173)
  2. pip install playwright && playwright install chromium
  3. mkdir -p e2e && python tests/e2e_perfis.py

Cada etapa imprime "OK" ao passar; screenshots ficam em e2e/perfis-*.png.
"""
import asyncio, re, json
from playwright.async_api import async_playwright, expect

BASE = 'http://127.0.0.1:5173/?fast#'
OUT = 'e2e/perfis-'
PASSWORD = 'Vitalis@123'
errors = []


def log(*a):
    print('•', *a, flush=True)


async def shot(pg, name, full=False):
    await pg.wait_for_timeout(300)
    await pg.screenshot(path=OUT + name + '.png', full_page=full)


def watch(pg):
    pg.on('console', lambda m: errors.append(f'[{m.type}] {m.text}') if m.type in ('error', 'warning') else None)
    pg.on('pageerror', lambda e: errors.append(f'[pageerror] {e}'))


async def login(pg, email, password=PASSWORD):
    await pg.goto(BASE + '/entrar')
    await pg.locator('input[name=email]').fill(email)
    await pg.locator('input[name=password]').fill(password)
    await pg.get_by_role('button', name='Entrar', exact=True).click()


async def logout(pg):
    await pg.evaluate("localStorage.removeItem('vitalis:session'); sessionStorage.removeItem('vitalis:session')")
    await pg.goto(BASE + '/')
    await pg.reload()


async def pick_slot(pg, scope=None):
    """Escolhe o primeiro dia disponível que tenha um horário livre."""
    root = scope or pg
    days = root.locator('.day.is-available')
    for i in range(await days.count()):
        await days.nth(i).click()
        await pg.wait_for_timeout(700)
        if await root.locator('.slot--livre').count():
            await root.locator('.slot--livre').first.click()
            return True
    raise AssertionError('nenhum horário livre no mês')


async def no_hscroll(pg, label):
    # força um novo layout (o Chrome mantém o overflow de animações já concluídas até o próximo layout)
    over = await pg.evaluate("""() => { const r = document.getElementById('root'); r.style.display = 'none'; void r.offsetWidth;
        r.style.display = ''; return document.documentElement.scrollWidth - window.innerWidth; }""")
    assert over <= 1, f'{label}: rolagem horizontal de {over}px'


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        ctx = await b.new_context(viewport={'width': 1366, 'height': 900})
        pg = await ctx.new_page()
        watch(pg)

        # ================================================================ permissões
        await pg.goto(BASE + '/admin')
        await expect(pg).to_have_url(re.compile('entrar'))
        await pg.goto(BASE + '/profissional/agenda')
        await expect(pg).to_have_url(re.compile('entrar'))
        log('visitante em /admin e /profissional → login OK')

        await login(pg, 'demo@vitalis.com')
        await expect(pg).to_have_url(re.compile('painel'), timeout=8000)
        await pg.goto(BASE + '/profissional')
        await expect(pg.get_by_role('heading', name='Acesso negado')).to_be_visible()
        await shot(pg, '01-403')
        await pg.goto(BASE + '/admin/usuarios')
        await expect(pg.get_by_role('heading', name='Acesso negado')).to_be_visible()
        log('paciente em /profissional e /admin → 403 OK')
        # a camada de serviços também recusa (não é só o menu)
        res = await pg.evaluate("""async () => {
            const m = await import('/src/services/adminService.js');
            try { await m.listUsers(); return 'liberado'; } catch (e) { return e.code; }
        }""")
        assert res == 'FORBIDDEN', res
        res = await pg.evaluate("""async () => {
            const m = await import('/src/services/professionalService.js');
            try { await m.getFinance(); return 'liberado'; } catch (e) { return e.code; }
        }""")
        assert res == 'FORBIDDEN', res
        log('serviços de admin/profissional chamados pelo paciente → FORBIDDEN OK')

        # ================================================================ paciente: busca, perfil público, favoritos, sugestões
        await pg.goto(BASE + '/painel')
        await expect(pg.get_by_role('heading', name='Sugestões para você')).to_be_visible(timeout=6000)
        log('dashboard com sugestões OK')
        await pg.goto(BASE + '/profissionais')
        await expect(pg.get_by_role('heading', name='Encontre um profissional')).to_be_visible()
        await expect(pg.locator('#pros-results-title')).to_have_text(re.compile(r'^\d+ profission'))
        total = await pg.locator('.pro-item').count()
        await pg.locator('.pros-filters select').first.select_option('fisioterapia')
        await expect(pg).to_have_url(re.compile('servico=fisioterapia'))
        await pg.wait_for_timeout(600)
        fisio = await pg.locator('.pro-item').count()
        assert 0 < fisio < total, (fisio, total)
        log(f'busca: {total} profissionais → {fisio} em fisioterapia OK')
        await pg.get_by_label('Nome, especialidade ou serviço', exact=False).fill('roberto')
        await expect(pg.locator('.pro-item')).to_have_count(1, timeout=5000)
        await pg.locator('.pro-item').first.get_by_role('button', name=re.compile('Salvar .* nos favoritos')).click()
        await expect(pg.get_by_text('Adicionado aos favoritos')).to_be_visible()
        await pg.locator('.pro-item').first.get_by_role('link', name='Dr. Roberto Alves').click()
        await expect(pg.get_by_role('heading', name='Dr. Roberto Alves', level=1)).to_be_visible()
        await expect(pg.get_by_role('heading', name='Serviços e valores')).to_be_visible()
        n_off = await pg.locator('.pp-offers li').count()
        assert n_off == 3, n_off  # 4 serviços, 1 inativo
        await shot(pg, '02-perfil-publico', True)
        log('perfil público: 3 serviços ativos (inativo oculto) OK')
        await pg.goto(BASE + '/favoritos')
        await expect(pg.locator('.pro-item')).to_have_count(1)
        log('favoritos OK')

        # agendamento escolhendo um serviço específico (duração 30 min)
        await pg.goto(BASE + '/profissionais/roberto-alves')
        await pg.locator('.pp-offers li', has_text='Retorno').get_by_role('link', name='Agendar').click()
        await expect(pg.locator('.panel-pro__name')).to_have_text('Dr. Roberto Alves')
        await expect(pg.locator('.offer-pick__opt.is-on')).to_contain_text('Retorno')
        await pick_slot(pg)
        await expect(pg.locator('.slots__label')).to_contain_text('30 min')
        await pg.get_by_role('button', name='Confirmar Agendamento').click()
        await expect(pg).to_have_url(re.compile('agendar/revisao'))
        await expect(pg.get_by_text('Retorno / reavaliação').first).to_be_visible()
        await pg.get_by_role('button', name='Ir para o pagamento').click()
        await expect(pg.get_by_role('heading', name='Finalizar pagamento')).to_be_visible(timeout=8000)
        await pg.get_by_role('radio', name=re.compile('PIX')).click()
        await pg.get_by_role('button', name='Já fiz o Pagamento').click()
        await expect(pg.get_by_role('heading', name='Pagamento aprovado!')).to_be_visible(timeout=8000)
        log('paciente agendou "Retorno" (30 min) com Roberto e pagou (PIX simulado) OK')
        await logout(pg)

        # ================================================================ profissional publicado (Roberto)
        await login(pg, 'profissional@vitalis.com')
        await expect(pg).to_have_url(re.compile('/profissional$'), timeout=8000)
        await expect(pg.locator('.dash-hero__title')).to_contain_text('Roberto')
        await expect(pg.locator('.kpi')).to_have_count(4)
        await shot(pg, '03-pro-visao-geral', True)
        log('profissional → visão geral com indicadores OK')
        # notificação do pagamento do paciente
        await pg.goto(BASE + '/profissional/notificacoes')
        await expect(pg.get_by_text('Novo agendamento confirmado').first).to_be_visible()
        await pg.get_by_role('tab', name='Não lidas').click()
        if await pg.get_by_role('button', name='Marcar todas como lidas').count():
            await pg.get_by_role('button', name='Marcar todas como lidas').click()
            await expect(pg.get_by_role('heading', name='Tudo lido por aqui')).to_be_visible()
        log('notificação de novo agendamento + marcar todas como lidas OK')

        # agenda: visões
        await pg.goto(BASE + '/profissional/agenda')
        for v in ['Dia', 'Semana', 'Mês', 'Lista']:
            await pg.get_by_role('tab', name=v).click()
            await pg.wait_for_timeout(450)
        await expect(pg.locator('.appt-row').first).to_be_visible()
        await pg.locator('.appt-row').first.click()
        dlg = pg.get_by_role('dialog')
        await expect(dlg).to_be_visible()
        await expect(dlg.get_by_text('O Vitalis não armazena', exact=False)).to_be_visible()
        await pg.keyboard.press('Escape')
        await expect(dlg).to_be_hidden()
        await shot(pg, '04-agenda-lista', True)
        log('agenda: dia/semana/mês/lista + modal (Esc fecha) OK')
        await pg.get_by_role('tab', name='Semana').click()
        await shot(pg, '05-agenda-semana', True)

        # horários: bloqueio + remoção
        await pg.goto(BASE + '/profissional/horarios')
        await expect(pg.get_by_role('heading', name='Horários de atendimento')).to_be_visible()
        await pg.get_by_role('button', name='Bloquear horário').click()
        dlg = pg.get_by_role('dialog')
        future = await pg.evaluate("""() => { const d = new Date(); d.setDate(d.getDate() + 40); return d.toISOString().slice(0, 10); }""")
        await dlg.get_by_label('Data').fill(future)
        await dlg.get_by_label('Motivo (opcional, só você vê)').fill('Teste automatizado')
        await dlg.get_by_role('button', name='Salvar').click()
        await expect(pg.get_by_text('Período bloqueado').first).to_be_visible(timeout=6000)
        exc = pg.locator('.exc', has_text='Teste automatizado')
        await expect(exc).to_have_count(1)
        await exc.get_by_role('button', name=re.compile('Remover')).click()
        await expect(pg.locator('.exc', has_text='Teste automatizado')).to_have_count(0, timeout=6000)
        log('bloqueio criado e removido OK')
        # horário semanal: intervalo inválido
        await pg.get_by_label('Início do intervalo de segunda-feira').fill('07:00')
        await pg.get_by_role('button', name='Salvar horários').click()
        await expect(pg.get_by_text('O intervalo precisa estar dentro do horário de atendimento.')).to_be_visible()
        await pg.get_by_role('button', name='Desfazer alterações').click()
        log('validação do horário semanal OK')
        await shot(pg, '06-horarios', True)

        # serviços: validação, criar, desativar, excluir
        await pg.goto(BASE + '/profissional/servicos')
        await pg.get_by_role('button', name='Adicionar serviço').first.click()
        dlg = pg.get_by_role('dialog')
        await dlg.get_by_role('button', name='Adicionar serviço').click()
        await expect(dlg.locator('.field__error').first).to_be_visible()
        await dlg.get_by_label('Nome do serviço').fill('Pilates clínico')
        await dlg.get_by_label('Preço (R$)').fill('120')
        await dlg.get_by_role('button', name='Adicionar serviço').click()
        await expect(dlg.get_by_text('Você já tem um serviço com este nome.')).to_be_visible()
        await dlg.get_by_label('Nome do serviço').fill('Liberação miofascial')
        await dlg.get_by_label('Preço (R$)').fill('10')
        await dlg.get_by_role('button', name='Adicionar serviço').click()
        await expect(dlg.get_by_text('Informe um valor a partir de R$ 20,00.')).to_be_visible()
        await dlg.get_by_label('Preço (R$)').fill('120')
        await dlg.get_by_role('button', name='Adicionar serviço').click()
        await expect(pg.get_by_text('Serviço adicionado').first).to_be_visible(timeout=6000)
        card = pg.locator('.offer-card', has_text='Liberação miofascial')
        await expect(card).to_have_count(1)
        await card.get_by_role('switch').click()
        await expect(card.get_by_text('Inativo')).to_be_visible(timeout=6000)
        await card.get_by_role('button', name='Excluir Liberação miofascial').click()
        await expect(pg.get_by_role('dialog').get_by_text('Esta ação não pode ser desfeita.')).to_be_visible()
        await pg.get_by_role('dialog').get_by_role('button', name='Excluir').click()
        await expect(pg.locator('.offer-card', has_text='Liberação miofascial')).to_have_count(0, timeout=6000)
        log('serviço: validação, criação, desativação e exclusão OK')

        # clientes e financeiro
        await pg.goto(BASE + '/profissional/clientes')
        await expect(pg.locator('.client-card').first).to_be_visible(timeout=6000)
        await pg.locator('.client-card').first.click()
        await expect(pg.get_by_role('dialog').get_by_text('Histórico com você')).to_be_visible()
        await pg.keyboard.press('Escape')
        log('clientes + histórico OK')
        await pg.goto(BASE + '/profissional/financeiro')
        await expect(pg.get_by_text('Ambiente de demonstração.')).to_be_visible()
        for t in ['Hoje', 'Esta semana', 'Este mês']:
            await pg.get_by_role('tab', name=t).click()
            await pg.wait_for_timeout(400)
        await pg.get_by_role('tab', name='Personalizado').click()
        await pg.get_by_label('De', exact=True).fill('2030-01-10')
        await pg.get_by_label('Até', exact=True).fill('2030-01-01')
        await pg.get_by_role('button', name='Aplicar').click()
        await expect(pg.get_by_text('A data inicial deve ser anterior à final.')).to_be_visible()
        await shot(pg, '07-financeiro', True)
        log('financeiro: filtros + período inválido OK')

        # perfil profissional e configurações
        await pg.goto(BASE + '/profissional/perfil')
        await pg.get_by_role('textbox', name='Apresentação').fill('Bio curta')
        await pg.get_by_role('button', name='Salvar perfil').click()
        await expect(pg.get_by_text('Escreva uma apresentação com pelo menos 40 caracteres.').first).to_be_visible()
        await pg.get_by_role('button', name='Descartar').click()
        await pg.get_by_label('Anos de experiência').fill('10')
        await pg.get_by_role('button', name='Salvar perfil').click()
        await expect(pg.get_by_text('Perfil atualizado')).to_be_visible(timeout=6000)
        await shot(pg, '08-perfil-pro', True)
        log('perfil profissional: validação + salvar OK')
        await pg.goto(BASE + '/profissional/configuracoes')
        await pg.get_by_role('button', name='Pausar perfil').click()
        await pg.get_by_role('dialog').get_by_role('button', name='Pausar perfil').click()
        await expect(pg.get_by_text('Perfil pausado').first).to_be_visible(timeout=6000)
        await pg.goto(BASE + '/profissionais/roberto-alves')
        await expect(pg.get_by_role('heading', name='Perfil indisponível')).to_be_visible()
        await pg.goto(BASE + '/profissional/configuracoes')
        await pg.get_by_role('button', name='Reativar perfil').click()
        await expect(pg.get_by_text('Perfil reativado').first).to_be_visible(timeout=6000)
        log('pausar perfil oculta a página pública; reativar OK')
        # profissional não acessa a administração
        await pg.goto(BASE + '/admin')
        await expect(pg.get_by_role('heading', name='Acesso negado')).to_be_visible()
        await pg.goto(BASE + '/painel')
        await expect(pg).to_have_url(re.compile('/profissional$'))
        log('profissional: /admin → 403, /painel → área do profissional OK')
        await logout(pg)

        # ================================================================ novo profissional: cadastro → onboarding → envio
        await pg.goto(BASE + '/cadastro?tipo=profissional')
        await pg.get_by_label('Nome completo').fill('Marina Duarte')
        await pg.get_by_label('Telefone').fill('11912345678')
        await pg.locator('input[name=email]').fill('marina.duarte@exemplo.com')
        await pg.locator('input[name=password]').fill('Marina2026')
        await pg.get_by_label('Confirmar senha').fill('Marina2026')
        await pg.locator('input[name=terms]').check()
        await pg.get_by_role('button', name=re.compile('Criar conta')).last.click()
        await expect(pg).to_have_url(re.compile('profissional/onboarding'), timeout=8000)
        await expect(pg.get_by_role('heading', name='Configure seu perfil profissional')).to_be_visible()
        log('cadastro profissional → onboarding OK')
        # 1. dados profissionais (validação)
        await pg.get_by_role('button', name='Salvar e continuar').click()
        await expect(pg.locator('.onb-card .field__error').first).to_be_visible()
        await pg.get_by_label('Tratamento').select_option('Dra.')
        await pg.get_by_label('Profissão').fill('Nutricionista')
        await pg.get_by_label('Cidade de atendimento').fill('Osasco, SP')
        await pg.get_by_label('Conselho').select_option('CRN')
        await pg.get_by_label('Número').fill('12345')
        await pg.get_by_role('button', name='Salvar e continuar').click()
        # 2. especialidade
        await expect(pg.get_by_role('heading', name='Especialidade', level=2)).to_be_visible(timeout=6000)
        await pg.get_by_label('Área principal no catálogo').select_option('nutricao')
        await pg.get_by_role('textbox', name='Especialidade').fill('Nutrição esportiva')
        await pg.get_by_role('button', name='Salvar e continuar').click()
        # 3. serviços (o formulário abre sozinho)
        dlg = pg.get_by_role('dialog')
        await expect(dlg).to_be_visible(timeout=6000)
        await dlg.get_by_label('Nome do serviço').fill('Consulta nutricional')
        await dlg.get_by_label('Preço (R$)').fill('160')
        await dlg.get_by_role('button', name='Adicionar').click()
        await expect(pg.locator('.onb-offers li')).to_have_count(1, timeout=6000)
        await pg.get_by_role('button', name='Continuar').click()
        # 4. disponibilidade (mantém o padrão)
        await expect(pg.get_by_role('heading', name='Disponibilidade', level=2)).to_be_visible(timeout=6000)
        await pg.get_by_role('button', name='Salvar e continuar').click()
        # 5. perfil
        await expect(pg.get_by_role('textbox', name='Apresentação')).to_be_visible(timeout=6000)
        await pg.get_by_role('textbox', name='Apresentação').fill('Nutricionista com foco em alimentação para quem pratica esportes e rotina saudável.')
        await pg.get_by_role('button', name='Salvar e continuar').click()
        # 6. revisão → envio
        await expect(pg.get_by_role('heading', name='Revisão', level=2)).to_be_visible(timeout=6000)
        await expect(pg.locator('.onb-check li.is-done')).to_have_count(5)
        await shot(pg, '09-onboarding-revisao', True)
        await pg.get_by_role('button', name='Enviar para verificação').click()
        await expect(pg.get_by_role('heading', name='Em análise')).to_be_visible(timeout=8000)
        log('onboarding completo (5/5) e enviado para verificação OK')
        await logout(pg)

        # ================================================================ administração
        await login(pg, 'admin@vitalis.com')
        await expect(pg).to_have_url(re.compile('/admin$'), timeout=8000)
        await expect(pg.get_by_text('Dados de demonstração.')).to_be_visible()
        await expect(pg.locator('.adm-list li', has_text='Marina Duarte')).to_be_visible(timeout=6000)
        await shot(pg, '10-admin', True)
        log('admin: visão geral com verificação pendente da Marina OK')
        # aprovar Marina
        await pg.locator('.adm-list li', has_text='Marina Duarte').get_by_role('link', name='Revisar').click()
        dlg = pg.get_by_role('dialog')
        await expect(dlg.get_by_text('Dra. Marina Duarte')).to_be_visible(timeout=6000)
        await dlg.get_by_role('button', name='Aprovar e publicar').click()
        await dlg.get_by_role('button', name=re.compile('Confirmar')).click()
        await expect(pg.get_by_text('Aprovar e publicar: concluído')).to_be_visible(timeout=6000)
        log('admin aprovou a Marina OK')
        # pedir ajustes à Lívia (nota obrigatória)
        await pg.goto(BASE + '/admin/profissionais?status=em_analise')
        await pg.locator('tr', has_text='Lívia').get_by_role('button', name='Revisar').click()
        dlg = pg.get_by_role('dialog')
        await dlg.get_by_role('button', name='Pedir ajustes').click()
        await dlg.get_by_role('button', name=re.compile('Confirmar')).click()
        await expect(dlg.get_by_text('Explique o que precisa ser ajustado', exact=False)).to_be_visible()
        await dlg.get_by_label(re.compile('O que precisa ser ajustado')).fill('Envie o número de registro completo, por favor.')
        await dlg.get_by_role('button', name=re.compile('Confirmar')).click()
        await expect(pg.get_by_text('Pedir ajustes: concluído')).to_be_visible(timeout=6000)
        log('pedir ajustes exige justificativa OK')
        # usuários: suspende a paciente de demonstração (o contexto do teste é descartado no fim)
        await pg.goto(BASE + '/admin/usuarios')
        await pg.get_by_label('Buscar usuário').fill('silvia')
        row = pg.locator('tr', has_text='Silvia')
        await expect(row).to_have_count(1, timeout=6000)
        await row.get_by_role('button', name='Suspender').click()
        await pg.get_by_role('dialog').get_by_role('button', name='Suspender').click()
        await expect(pg.get_by_text('Conta suspensa').first).to_be_visible(timeout=6000)
        await pg.get_by_label('Buscar usuário').fill('admin')
        await expect(pg.locator('tr', has_text='(você)').get_by_role('button')).to_have_count(0)
        log('admin suspendeu a paciente demo; própria conta sem ação OK')
        # serviços: desativar e reativar
        await pg.goto(BASE + '/admin/servicos')
        row = pg.locator('tr', has_text='Oftalmologia')
        await row.get_by_role('switch').click()
        dlg = pg.get_by_role('dialog')
        if await dlg.count():
            await dlg.get_by_role('button', name='Desativar').click()
        await expect(row.get_by_text('Desativado')).to_be_visible(timeout=6000)
        log('serviço desativado OK')
        # aviso global
        await pg.goto(BASE + '/admin/configuracoes')
        await pg.get_by_role('switch', name='Exibir aviso no topo do site').click()
        await pg.get_by_label('Texto do aviso').fill('Manutenção programada no domingo às 22h.')
        await pg.get_by_role('button', name='Salvar aviso').click()
        await expect(pg.get_by_text('Aviso publicado')).to_be_visible(timeout=6000)
        await expect(pg.locator('.announce[role=status]')).to_contain_text('Manutenção programada')
        log('aviso global publicado OK')
        # solicitações
        await pg.goto(BASE + '/admin/solicitacoes')
        await pg.locator('.adm-ticket').first.click()
        dlg = pg.get_by_role('dialog')
        await dlg.get_by_text('Em andamento').click()
        await dlg.get_by_label('Nota interna (só a administração vê)').fill('Respondido por e-mail.')
        await dlg.get_by_role('button', name='Salvar').click()
        await expect(pg.get_by_text('Solicitação atualizada')).to_be_visible(timeout=6000)
        log('solicitação atualizada OK')
        for path, h in [('/admin/agendamentos', 'Agendamentos'), ('/admin/pagamentos', 'Pagamentos'), ('/admin/notificacoes', 'Notificações')]:
            await pg.goto(BASE + path)
            await expect(pg.get_by_role('heading', name=h, level=1)).to_be_visible()
        await expect(pg.get_by_text('Profissional aguardando verificação').first).to_be_visible()
        await shot(pg, '11-admin-pagamentos')
        log('admin: agendamentos, pagamentos e notificações OK')
        # admin não agenda
        await pg.goto(BASE + '/agendar?profissional=carlos-silva')
        await expect(pg.get_by_text('Contas de administração não fazem agendamentos', exact=False)).to_be_visible()
        await pg.goto(BASE + '/consultas')
        await expect(pg.get_by_role('heading', name='Acesso negado')).to_be_visible()
        log('admin não agenda e não vê /consultas OK')
        await logout(pg)

        # efeitos das decisões do admin
        await pg.goto(BASE + '/servicos')
        await expect(pg.locator('.service-card')).to_have_count(11)
        log('serviço desativado some do catálogo (11) OK')
        await pg.goto(BASE + '/profissionais?q=marina')
        await expect(pg.locator('.pro-item', has_text='Dra. Marina Duarte')).to_have_count(1, timeout=6000)
        await expect(pg.locator('.pro-item', has_text='Dra. Marina Duarte').get_by_text('Novo no Vitalis')).to_be_visible()
        log('Marina aprovada aparece na busca como "Novo no Vitalis" OK')
        await login(pg, 'demo@vitalis.com')
        await expect(pg.get_by_text('Esta conta está suspensa', exact=False)).to_be_visible(timeout=6000)
        log('conta suspensa não entra OK')
        await login(pg, 'marina.duarte@exemplo.com', 'Marina2026')
        await expect(pg).to_have_url(re.compile('/profissional$'), timeout=8000)
        await pg.goto(BASE + '/profissional/notificacoes')
        await expect(pg.get_by_text('Perfil aprovado e publicado')).to_be_visible()
        log('Marina recebe a notificação de aprovação OK')

        # teclado: menu do painel navegável com Tab
        await pg.goto(BASE + '/profissional')
        await pg.locator('.panel-nav__link').first.focus()
        await pg.keyboard.press('Tab')
        await pg.keyboard.press('Enter')
        await expect(pg).to_have_url(re.compile('profissional/agenda'))
        log('teclado: navegação do menu lateral OK')
        await logout(pg)

        # ================================================================ celular e tablet
        for (w, h, name) in [(390, 844, 'mobile'), (820, 1180, 'tablet')]:
            mctx = await b.new_context(viewport={'width': w, 'height': h}, is_mobile=(w < 500), has_touch=(w < 500))
            m = await mctx.new_page()
            watch(m)
            await login(m, 'profissional@vitalis.com')
            await expect(m).to_have_url(re.compile('/profissional$'), timeout=8000)
            for path in ['/profissional', '/profissional/agenda?visao=semana', '/profissional/horarios', '/profissional/servicos', '/profissional/financeiro', '/profissional/perfil']:
                await m.goto(BASE + path)
                await m.wait_for_timeout(700)
                await no_hscroll(m, f'{name} {path}')
            await shot(m, f'12-{name}-financeiro', True)
            await m.goto(BASE + '/profissional/agenda?visao=semana')
            await m.wait_for_timeout(700)
            await shot(m, f'13-{name}-agenda', True)
            await logout(m)
            await login(m, 'admin@vitalis.com')
            await expect(m).to_have_url(re.compile('/admin$'), timeout=8000)
            for path in ['/admin', '/admin/usuarios', '/admin/profissionais', '/admin/pagamentos']:
                await m.goto(BASE + path)
                await m.wait_for_timeout(700)
                await no_hscroll(m, f'{name} {path}')
            await shot(m, f'14-{name}-admin-usuarios', True)
            await logout(m)
            for path in ['/profissionais', '/profissionais/roberto-alves', '/agendar?profissional=roberto-alves']:
                await m.goto(BASE + path)
                await m.wait_for_timeout(700)
                await no_hscroll(m, f'{name} {path}')
            if w < 500:
                await m.goto(BASE + '/profissionais')
                await m.get_by_role('button', name=re.compile('^Filtros')).click()
                await expect(m.locator('.pros-filters.is-open')).to_be_visible()
                await shot(m, '15-mobile-filtros')
                await m.get_by_role('button', name=re.compile('^Ver .* resultado')).click()
            log(f'{name} ({w}px): páginas sem rolagem horizontal OK')
            await mctx.close()

        # ================================================================ migração do banco v1 (dados preservados)
        mctx = await b.new_context()
        m = await mctx.new_page()
        watch(m)
        await m.goto(BASE + '/')
        await m.wait_for_timeout(800)
        await m.evaluate("""() => {
            const db = JSON.parse(localStorage.getItem('vitalis:db:v1'));
            const demo = db.users.find((u) => u.id === 'usr_demo');
            const legacyUser = { ...demo, id: 'usr_legado', email: 'legado@exemplo.com', name: 'Pessoa Legada' };
            delete legacyUser.status;
            const appt = {
              id: 'apt_legado', protocol: 'VIT-99999', userId: 'usr_legado', serviceSlug: 'cardiologia', serviceName: 'Cardiologia',
              professionalId: 'carlos-silva', professionalName: 'Dr. Carlos Silva', specialty: 'Cardiologista', location: 'São Paulo, SP',
              date: '2030-03-04', time: '09:00', price: 200, fee: 10, total: 210, status: 'pendente_pagamento',
              history: [{ at: new Date().toISOString(), label: 'Agendamento criado' }], attempts: [], createdAt: new Date().toISOString(),
            };
            const v1 = { version: 1, users: [legacyUser], appointments: [appt], payments: [],
                         tickets: [{ id: 'tk_legado', protocol: 'SUP-111111', name: 'Pessoa Legada', email: 'legado@exemplo.com',
                                     subject: 'Outro', message: 'Mensagem antiga', status: 'registrado', createdAt: new Date().toISOString() }] };
            localStorage.setItem('vitalis:db:v1', JSON.stringify(v1));
            localStorage.removeItem('vitalis:session');
        }""")
        await m.reload()
        await m.wait_for_timeout(1200)
        info = await m.evaluate("""() => { const db = JSON.parse(localStorage.getItem('vitalis:db:v1'));
            return { version: db.version, legacy: db.appointments.filter((a) => a.userId === 'usr_legado').length,
                     pros: db.professionals.length, admin: db.users.some((u) => u.role === 'admin'),
                     ticket: db.tickets.find((t) => t.id === 'tk_legado')?.status,
                     offering: db.appointments.find((a) => a.id === 'apt_legado')?.offeringId || null }; }""")
        assert info['version'] == 2 and info['legacy'] == 1 and info['pros'] > 10 and info['admin'] and info['ticket'] == 'aberto' and info['offering'], info
        await login(m, 'legado@exemplo.com')
        await expect(m).to_have_url(re.compile('painel'), timeout=8000)
        await m.goto(BASE + '/consultas')
        await expect(m.locator('.appt-card')).to_have_count(1)
        log('migração v1 → v2: usuário, agendamento e solicitação preservados OK', json.dumps(info))
        await mctx.close()
        await b.close()


try:
    asyncio.run(main())
finally:
    print('\nCONSOLE:', len(errors))
    for e in errors[:30]:
        print('  ', e)
