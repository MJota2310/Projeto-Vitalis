import { readFileSync } from 'node:fs';
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

// Nos builds, troca o aviso de "código-fonte" do index.html por um aviso adequado
// ao site publicado (só aparece se o navegador não conseguir rodar o app).
function builtPageNotice(single) {
  const hint = single
    ? '<p>Abra este site em um navegador atualizado (Chrome, Edge ou Firefox) com o JavaScript ativado.</p>'
    : '<p>A pasta <code>dist</code> precisa de um servidor (ex.: <code>npm run preview</code>). Para abrir com dois cliques, use <code>docs/index.html</code>.</p>';
  return {
    name: 'vitalis-built-notice',
    apply: 'build',
    transformIndexHtml(html) {
      return html.replace(
        /<div class="boot-help">[\s\S]*?<\/div>/,
        `<div class="boot-help">
        <h1>Não foi possível carregar o Vitalis</h1>
        ${hint}
      </div>`,
      );
    },
  };
}

// No build de arquivo único, o favicon também é embutido (data URI).
function inlineFavicon() {
  return {
    name: 'vitalis-inline-favicon',
    transformIndexHtml(html) {
      const b64 = readFileSync(new URL('./public/favicon.png', import.meta.url)).toString('base64');
      return html.replace('href="./favicon.png"', `href="data:image/png;base64,${b64}"`);
    },
  };
}

// `npm run build`        → build padrão em dist/ (vários arquivos; precisa de um servidor para abrir).
// `npm run build:single` → um único docs/index.html com CSS, JS, fontes e imagens embutidos.
//                          Abre com dois cliques e é a pasta publicada no GitHub Pages.
export default defineConfig(({ mode }) => {
  const single = mode === 'single';
  return {
    base: './',
    plugins: [react(), builtPageNotice(single), ...(single ? [viteSingleFile(), inlineFavicon()] : [])],
    build: {
      outDir: single ? 'docs' : 'dist',
      emptyOutDir: true,
      copyPublicDir: !single,
      assetsInlineLimit: single ? 100_000_000 : 4096,
      chunkSizeWarningLimit: 1500,
    },
    server: { port: 5173, open: false },
  };
});
