# Vitalis — aplicação web

Plataforma de agendamento de serviços de saúde e bem-estar, construída a partir das telas do Figma (exportação HTML/CSS) e do vídeo do protótipo.

- **Stack:** React 18 · Vite 5 · React Router 6 (HashRouter) · CSS puro com design tokens
- **Dados:** camada de serviços simulada com `localStorage` (modo demonstração), pronta para ser trocada por uma API real
- **Fontes e ícones:** Rowdies, Poppins, Montserrat, Inter, Crimson Text e Open Sans (via `@fontsource`, servidas localmente) + Material Symbols (os mesmos ícones das telas originais)

---

## Para ver o site (sem instalar nada)

Abra o arquivo **`docs/index.html`** com dois cliques. Ele contém o site inteiro (código, fontes e imagens) e funciona até sem internet.

> O `index.html` que fica na raiz do projeto é o **código-fonte**: aberto com dois cliques ele não carrega (o navegador bloqueia os arquivos de código). Por isso existe a pasta `docs`.

## Publicar no GitHub Pages (passo a passo)

1. Em [github.com](https://github.com), clique em **+ → New repository**, dê o nome `vitalis`, marque **Public** e clique em **Create repository**.
2. Na página do repositório vazio, clique no link **uploading an existing file**.
3. Abra a pasta `vitalis` no seu computador e arraste **a pasta `docs`** para a página. Clique em **Commit changes**.
4. Clique em **Add file → Upload files** e arraste **todo o resto** do conteúdo da pasta `vitalis` (pastas `src`, `public`, `scripts`, `tests` e os arquivos soltos). Clique em **Commit changes**.
   - Arraste o **conteúdo** da pasta, não a pasta `vitalis` em si.
   - O GitHub aceita até 100 arquivos por envio; por isso são dois envios.
5. Vá em **Settings → Pages**. Em **Source**, escolha **Deploy from a branch**; em **Branch**, escolha `main` e a pasta **`/docs`**. Clique em **Save**.
6. Espere 1 a 2 minutos e recarregue a página. O endereço aparece no topo: `https://SEU-USUARIO.github.io/vitalis/`.

## Para programar (opcional)

Precisa do [Node.js](https://nodejs.org) instalado. No terminal, dentro da pasta do projeto:

```bash
npm install          # instala as dependências (só na primeira vez)
npm run dev          # abre o site em modo de desenvolvimento: http://localhost:5173
npm run build:single # gera de novo o docs/index.html depois de mudar o código
npm run build        # build em vários arquivos (dist/), precisa de servidor
npm run preview      # pré-visualiza o build de dist/
npm run format       # formata o código com Prettier
```

Depois de alterar o código, rode `npm run build:single` e envie o novo `docs/index.html` para o GitHub (**Add file → Upload files**, substituindo o antigo).

O roteamento usa `HashRouter` (`/#/servicos`), então o site funciona em qualquer hospedagem estática (GitHub Pages, Netlify, Vercel) sem configurar reescrita de URLs.

## Roteiro para apresentar (≈ 5 minutos)

1. **Início:** mostre o header fixo, clique em "Como funciona" e "Serviços" (rolagem suave) e passe o mouse nos botões e cards.
2. **Serviços:** clique em "Ver todos os serviços" e troque os filtros (Medicina 8 · Terapias 3 · Bem-estar 5). Busque "carlos".
3. **Agendamento:** em Cardiologia, clique em "Agendar" com o Dr. Carlos Silva, escolha data e horário e clique em "Confirmar Agendamento". O site pede login.
4. **Login:** clique em "Preencher" e em "Entrar". A seleção do agendamento continua lá. Revise e vá para o pagamento.
5. **Pagamento:** use o cartão de teste **recusado** (tela de erro), clique em "Tentar novamente" e pague com **PIX** (tela de aprovado).
6. **Área do usuário:** mostre o Dashboard, a lista de Consultas com filtros e os detalhes (remarcar/cancelar). Termine no Perfil e na Central de Ajuda (chat).

Dicas: abra o site uma vez antes da aula; para começar do zero, use uma **janela anônima**; leve o `docs/index.html` num pendrive como plano B (funciona sem internet).

---

## Dados de demonstração

| O quê | Valor |
| --- | --- |
| Conta de demonstração | `demo@vitalis.com` · `Vitalis@123` (botão **Preencher** na tela de login) |
| Cartão aprovado | `4242 4242 4242 4242` |
| Cartão recusado | `4000 0000 0000 0002` |
| PIX | “Já fiz o pagamento” aprova; “Simular pagamento não identificado” recusa |

- Tudo fica salvo **somente no navegador** (`localStorage`). Para zerar, limpe os dados do site no navegador.
- Senhas são guardadas apenas como **hash PBKDF2-SHA256 com sal** — nunca em texto puro.
- **Nenhum dado de cartão é armazenado**: o pagamento guarda só bandeira, 4 últimos dígitos, valor e status.
- As telas de pagamento exibem claramente que se trata de um **ambiente de demonstração** (nenhuma cobrança real).
- Adicione `?fast` antes do `#` na URL (ex.: `http://localhost:5173/?fast#/`) para desativar a latência simulada da API (útil em testes automatizados).

---

## Mapa de navegação

```
/                         Landing (Início · Como funciona · Serviços · Para profissionais · Diferenciais · Depoimentos · CTA)
├─ /servicos              Todos os serviços — filtros Todas(12) / Bem-estar(5) / Terapias(3) / Medicina(8) + busca
│  └─ /servicos/:slug     Detalhe do serviço → profissionais → "Agendar"
├─ /agendar               Etapas 1–3: serviço → profissional → data e horário
│  └─ /agendar/revisao    Etapa 4: revisão  (exige login — a seleção é preservada)
├─ /pagamento/:id         Etapa 5: cartão ou PIX
│  ├─ /pagamento/:id/aprovado
│  └─ /pagamento/:id/recusado  → "Tentar novamente" volta para /pagamento/:id
├─ /entrar · /cadastro    Login / criação de conta (usuário ou profissional)
├─ /painel                Dashboard (próxima consulta, estatísticas, histórico, pagamentos)
├─ /consultas             Minhas consultas (“Users Page” do Figma) — filtros, busca, cancelar
│  └─ /consultas/:id      Detalhes, histórico, pagamento, remarcar, cancelar, comprovante, .ics
├─ /perfil                Dados pessoais (editar) · ?aba=configuracoes (senha, 2 etapas, notificações)
├─ /ajuda                 Central de ajuda: FAQ com busca, chat, tutoriais, formulário de contato
├─ /termos · /privacidade Documentos legais
└─ atalhos: /como-funciona · /para-profissionais · /contato · /faq
```

Rotas privadas (`/painel`, `/consultas`, `/perfil`, `/agendar/revisao`, `/pagamento/*`) redirecionam para o login e **voltam ao destino** após entrar.

### Menus

- **Visitante:** INÍCIO · COMO FUNCIONA · SERVIÇOS · PARA PROFISSIONAIS · CONTATO (rolagem suave até as seções, como no protótipo) + ENTRAR / Criar conta.
- **Logado:** Início · Agende · Dashboard · Consultas · Suporte (menu das telas internas do Figma) + menu do avatar (perfil, configurações, sair).
- **Celular (≤ 1100 px):** menu lateral (drawer) com foco preso e fechamento por Esc.

---

## Telas do Figma → implementação

| Arquivo original | Implementação |
| --- | --- |
| `projetoVitalis Landing.html` | `pages/Home/HomePage.jsx` |
| `todos_os_serviços.html` + `frame_tudo` / `opções_*` | `pages/Services/ServicesPage.jsx` (filtros dinâmicos) |
| `agendar.html` + `confirmaragendamento.html` | `pages/Booking/BookingPage.jsx` (painel lateral de data/horário) |
| `pagamento.html` + `pix.html` | `pages/Payment/PaymentPage.jsx` |
| `aprovação_de_pagamento.html` / `reprovação_de_pagamento.html` | `pages/Payment/PaymentResultPage.jsx` |
| `frame_entrar_usuario.html` / `frame_criar_conta.html` | `pages/Auth/LoginPage.jsx` / `RegisterPage.jsx` |
| `PaginadoUsuario.html` (“Users Page”) | `pages/Account/AppointmentsPage.jsx` |
| `perfilusuario.html` + `frame_segurança.html` | `pages/Account/ProfilePage.jsx` (abas) |
| `frame_central_de_ajuda.html` | `pages/Help/HelpPage.jsx` |
| — (novas, exigidas pelos fluxos) | Dashboard, detalhe do serviço, revisão, detalhe da consulta, termos, privacidade, 404 |

---

## Arquitetura

```
src/
├─ assets/          imagens originais do Figma (logo, redes sociais, fundos, badges) + icons.js
├─ components/
│  ├─ layout/       Header, Footer, Layout, RequireAuth/GuestOnly, navegação
│  ├─ ui/           Button, Icon, Field, Modal, Accordion, Feedback (empty/erro/skeleton/badges)
│  ├─ services/     ServiceCard
│  ├─ booking/      ProfessionalCard, DatePicker, TimeSlots, Stepper, OrderSummary
│  └─ account/      AppointmentCard, modais de cancelar/remarcar
├─ context/         AuthContext, BookingContext (rascunho no sessionStorage), ToastContext
├─ data/            catálogo (serviços, profissionais), conteúdo, FAQ, textos legais
├─ hooks/           useReveal, useAsync, useForm, useFocusTrap, useScrollSpy, useSectionNav…
├─ pages/           uma pasta por área, cada uma com seu CSS
├─ services/        API simulada: auth, catálogo, consultas, pagamentos, suporte, storage, db
├─ styles/          tokens.css, base.css, animations.css, ui.css, cards.css
└─ utils/           formatação pt-BR, validações, máscaras, hash de senha, downloads (.ics/.txt)

scripts/gen-icons.py   regenera src/assets/icons.js a partir de @material-symbols/svg-400
tests/e2e_fluxos.py    testes ponta a ponta (Playwright)
```

### Integração com um backend real

Todas as páginas falam **apenas** com `src/services/*`. Cada função já é assíncrona e lança `ApiError` com `code`/`field`, então basta trocar o corpo por chamadas HTTP:

| Serviço | Funções | Endpoint sugerido |
| --- | --- | --- |
| `authService` | `login`, `register`, `logout`, `updateProfile`, `changePassword`, `requestPasswordReset` | `/auth/*`, `/me` |
| `catalogService` | `listServices`, `listProfessionals`, `fetchSlots` | `/services`, `/professionals`, `/professionals/:id/slots` |
| `appointmentService` | `listAppointments`, `getAppointment`, `createAppointment`, `cancelAppointment`, `rescheduleAppointment` | `/appointments` |
| `paymentService` | `payWithCard`, `createPixCharge`, `confirmPix`, `listPayments` | provedor de pagamento (Stripe, Mercado Pago, Pagar.me…) via backend |
| `supportService` | `createTicket`, `askAssistant` | `/support/tickets` |

---

## Regras de negócio aplicadas (vindas do material)

- **Taxa de serviço:** R$ 10,00 por consulta (tela de pagamento).
- **Horários:** 08:00–11:00 e 14:00–17:00 (tela de confirmação); dias de atendimento por profissional (Seg/Qua/Sex etc.).
- **Garantia de reembolso:** cancelamento com 24h de antecedência → reembolso total (tela de pagamento). Com menos de 24h o cancelamento é permitido, mas sem reembolso, e o usuário é avisado antes.
- **Remarcação:** permitida até 24h antes (mesma regra de antecedência).
- **Confirmação:** a consulta só é confirmada após o pagamento aprovado; antes disso fica como “Pagamento pendente”.
- **Status:** Pagamento pendente · Aguardando (confirmada) · Concluída · Cancelada. Consultas confirmadas cujo horário já passou viram “Concluída”.

---

## Animações e microinterações

Reproduzidas do vídeo do protótipo (transições de ~300 ms, ease-out):

- Header fixo com rolagem suave até as seções e destaque da seção ativa.
- Botão contorno → preenche com o gradiente; botão cheio → vira contorno; CTA branco → fundo verde-claro com a seta deslizando.
- Cards de serviço, profissionais e depoimentos sobem com sombra; blocos de “Nossos diferenciais” ganham cor.
- Links do menu e do rodapé ficam verdes; ícones sociais crescem.
- Entrada das seções ao rolar, linhas do card do hero em sequência, blobs decorativos flutuando.
- Skeletons, spinners em botões, modal de processamento, check desenhado no pagamento aprovado e “shake” no recusado.
- Tudo respeita `prefers-reduced-motion`.

---

## Acessibilidade e responsividade

- HTML semântico, link “Pular para o conteúdo”, foco visível, rótulos em todos os campos, mensagens de erro com `role="alert"`, modais com foco preso e Esc.
- Auditoria automática (axe-core) sem violações nas páginas principais.
- **Contraste:** textos pequenos usam tons derivados da paleta (`--green-text`, `--teal-text`, `--cyan-text`) e os botões com texto branco usam uma versão mais profunda do gradiente (`--grad-action`) para atingir 4.5:1. O gradiente original do Figma (`--grad-brand`) continua em ilustrações, ícones e elementos decorativos. Para usar o gradiente original também nos botões, basta trocar `--grad-action` em `src/styles/tokens.css`.
- Layouts com Grid/Flexbox, testados em 390 px, 768 px e 1366–1440 px, sem rolagem horizontal.

---

## Testes realizados

Testes ponta a ponta automatizados (Playwright) cobrindo:

1. Início → Serviços (filtros e busca) → Serviço → Agendamento → login exigido → cadastro → revisão com seleção preservada.
2. Criar conta (validações, e-mail duplicado) → Dashboard → Perfil (editar dados, trocar senha, notificações) → sair → rota protegida.
3. Pagamento: validação do cartão (Luhn), recusa → tentar novamente → PIX (copiar código) → aprovado → detalhes.
4. Dashboard → Consultas (filtros) → Detalhes → Remarcar → Cancelar com reembolso.
5. Rodapé, Central de ajuda (busca no FAQ, chat, formulário de contato), termos, privacidade, FAQ e 404.

Resultado: todos os fluxos passaram, sem erros ou avisos no console. O script está em `tests/e2e_fluxos.py` (instruções no topo do arquivo).

---

## Limitações conhecidas

- Não há backend: contas, consultas e pagamentos existem apenas no navegador de quem usa.
- E-mails (confirmação, recuperação de senha) e SMS/WhatsApp **não são enviados**; as telas deixam isso explícito.
- Login com Google/Facebook e a área administrativa não fazem parte do material; os botões informam que estão indisponíveis na demonstração.
- A área de gestão para profissionais (agenda, pacientes) não existe nas telas; contas de profissional são registradas e recebem um aviso.
- “Baixar Receita” gera um documento de exemplo, sem validade médica.
- O código PIX é o fictício do protótipo e o QR Code é marcado como demonstração.
