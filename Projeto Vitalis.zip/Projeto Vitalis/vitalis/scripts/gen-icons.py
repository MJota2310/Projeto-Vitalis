import re,os,json
base='node_modules/@material-symbols/svg-400/outlined'
names="""calendar_today search check check_small arrow_forward arrow_right_alt arrow_back arrow_left_alt stethoscope neurology vital_signs fitness_center ar_on_you alarm notifications article assignment_turned_in moving group card_travel add_moderator bookmark_stacks electric_bolt lock lock_open kid_star kid_star-fill star star-fill medical_information cardiology exercise spa ecg child_care symptoms humerus pill network_intelligence person_heart distance location_on nest_clock_farsight_analog schedule calendar_check add_card credit_card mobile_2 qr_code_2 content_copy check_circle check_circle-fill cancel cancel-fill archive download admin_panel_settings edit_square add_location_alt calendar_month call mail settings settings_b_roll data_loss_prevention chat account_circle person logout dashboard menu close keyboard_arrow_down visibility visibility_off info warning error help support_agent event_repeat event_busy receipt_long payments shield verified_user home event history lightbulb school menu_book send refresh block edit save delete tune medical_services health_and_safety person_add login event_available badge sms forum description open_in_new chevron_left chevron_right today timer hourglass_empty verified favorite psychology key password mobile trending_up clinical_notes contact_support groups map sentiment_satisfied east north_east done_all pending schedule_send event_note add upcoming task_alt""".split()
out={}
miss=[]
for n in names:
    p=f'{base}/{n}.svg'
    if not os.path.exists(p): miss.append(n); continue
    s=open(p).read()
    ds=re.findall(r'<path d="([^"]+)"',s)
    out[n.replace('-fill','Fill')]=' '.join(ds) if len(ds)==1 else ds
print('missing',miss)
js='// Ícones Material Symbols (Outlined, peso 400) extraídos de @material-symbols/svg-400.\n// Mesmos ícones usados nas telas originais do Figma. viewBox: 0 -960 960 960\nconst icons = '+json.dumps(out,indent=0,ensure_ascii=False)+';\n\nexport default icons;\n'
open('src/assets/icons.js','w').write(js)
print(len(out), os.path.getsize('src/assets/icons.js'))
