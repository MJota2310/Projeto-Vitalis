import { HashRouter, Navigate, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { ToastProvider } from './context/ToastContext';
import { BookingProvider } from './context/BookingContext';
import Layout, { GuestOnly, RequireAuth } from './components/layout/Layout';

import HomePage from './pages/Home/HomePage';
import ServicesPage from './pages/Services/ServicesPage';
import ServiceDetailPage from './pages/Services/ServiceDetailPage';
import LoginPage from './pages/Auth/LoginPage';
import RegisterPage from './pages/Auth/RegisterPage';
import BookingPage from './pages/Booking/BookingPage';
import BookingReviewPage from './pages/Booking/BookingReviewPage';
import PaymentPage from './pages/Payment/PaymentPage';
import PaymentResultPage from './pages/Payment/PaymentResultPage';
import DashboardPage from './pages/Account/DashboardPage';
import AppointmentsPage from './pages/Account/AppointmentsPage';
import AppointmentDetailPage from './pages/Account/AppointmentDetailPage';
import ProfilePage from './pages/Account/ProfilePage';
import HelpPage from './pages/Help/HelpPage';
import LegalPage from './pages/Legal/LegalPage';
import NotFoundPage from './pages/NotFoundPage';

/*
 * Mapa de rotas
 * ─────────────────────────────────────────────────────────────────────────
 *  Públicas     /  ·  /servicos  ·  /servicos/:slug  ·  /agendar  ·  /ajuda
 *               /termos  ·  /privacidade
 *  Visitante    /entrar  ·  /cadastro
 *  Privadas     /agendar/revisao  ·  /pagamento/:id  ·  /pagamento/:id/aprovado
 *               /pagamento/:id/recusado  ·  /painel  ·  /consultas
 *               /consultas/:id  ·  /perfil
 *  Atalhos      /como-funciona  ·  /para-profissionais  ·  /contato  ·  /faq
 *
 * HashRouter: funciona em qualquer hospedagem estática (GitHub Pages, Netlify,
 * abrir o build localmente) sem configuração de reescrita de URLs.
 */
export default function App() {
  return (
    <HashRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      <ToastProvider>
        <AuthProvider>
          <BookingProvider>
            <Routes>
              <Route element={<Layout />}>
                <Route index element={<HomePage />} />
                <Route path="como-funciona" element={<Navigate to="/?secao=como-funciona" replace />} />
                <Route path="para-profissionais" element={<Navigate to="/?secao=profissionais" replace />} />
                <Route path="contato" element={<Navigate to="/ajuda?secao=contato" replace />} />
                <Route path="faq" element={<Navigate to="/ajuda?secao=faq" replace />} />

                <Route path="servicos" element={<ServicesPage />} />
                <Route path="servicos/:slug" element={<ServiceDetailPage />} />

                <Route
                  path="entrar"
                  element={
                    <GuestOnly>
                      <LoginPage />
                    </GuestOnly>
                  }
                />
                <Route
                  path="cadastro"
                  element={
                    <GuestOnly>
                      <RegisterPage />
                    </GuestOnly>
                  }
                />

                <Route path="agendar" element={<BookingPage />} />
                <Route
                  path="agendar/revisao"
                  element={
                    <RequireAuth>
                      <BookingReviewPage />
                    </RequireAuth>
                  }
                />

                <Route
                  path="pagamento/:id"
                  element={
                    <RequireAuth>
                      <PaymentPage />
                    </RequireAuth>
                  }
                />
                <Route
                  path="pagamento/:id/aprovado"
                  element={
                    <RequireAuth>
                      <PaymentResultPage result="aprovado" />
                    </RequireAuth>
                  }
                />
                <Route
                  path="pagamento/:id/recusado"
                  element={
                    <RequireAuth>
                      <PaymentResultPage result="recusado" />
                    </RequireAuth>
                  }
                />

                <Route
                  path="painel"
                  element={
                    <RequireAuth>
                      <DashboardPage />
                    </RequireAuth>
                  }
                />
                <Route
                  path="consultas"
                  element={
                    <RequireAuth>
                      <AppointmentsPage />
                    </RequireAuth>
                  }
                />
                <Route
                  path="consultas/:id"
                  element={
                    <RequireAuth>
                      <AppointmentDetailPage />
                    </RequireAuth>
                  }
                />
                <Route
                  path="perfil"
                  element={
                    <RequireAuth>
                      <ProfilePage />
                    </RequireAuth>
                  }
                />

                <Route path="ajuda" element={<HelpPage />} />
                <Route path="termos" element={<LegalPage doc="termos" />} />
                <Route path="privacidade" element={<LegalPage doc="privacidade" />} />

                <Route path="*" element={<NotFoundPage />} />
              </Route>
            </Routes>
          </BookingProvider>
        </AuthProvider>
      </ToastProvider>
    </HashRouter>
  );
}
