import Icon from '../ui/Icon';
import Button from '../ui/Button';
import { StatusBadge } from '../ui/Feedback';
import { proEmoji, professionalById } from '../../data/catalog';
import { formatCurrency, formatDateBR } from '../../utils/format';
import { cancellationPolicy } from '../../services/appointmentService';

/** Card de consulta — "Users Page" do Figma. */
export default function AppointmentCard({ appt, onCancel, onDownload, style }) {
  const pro = professionalById(appt.professionalId);
  const policy = cancellationPolicy(appt);
  return (
    <article className="appt-card" style={style} aria-labelledby={`appt-${appt.id}`}>
      <span className="pro-avatar" aria-hidden="true">
        {proEmoji(pro)}
      </span>
      <div className="appt-card__head">
        <h3 id={`appt-${appt.id}`} className="appt-card__name">
          {appt.professionalName}
        </h3>
        <p className="appt-card__spec">
          {appt.specialty}
          {appt.serviceName !== appt.specialty ? ` · ${appt.serviceName}` : ''}
        </p>
      </div>
      <div className="appt-card__status">
        <StatusBadge status={appt.status} />
      </div>
      <div className="appt-card__meta">
        <span>
          <Icon name="calendar_today" size={19} />
          <span className="sr-only">Data:</span>
          {formatDateBR(appt.date)}
        </span>
        <span>
          <Icon name="alarm" size={19} />
          <span className="sr-only">Horário:</span>
          {appt.time}
        </span>
        <span>
          <Icon name="archive" size={19} />
          <span className="sr-only">Protocolo:</span>
          {appt.protocol}
        </span>
        <span className="appt-card__price">{formatCurrency(appt.total)}</span>
      </div>
      <div className="appt-card__actions">
        <Button variant="soft" size="sm" to={`/consultas/${appt.id}`}>
          Ver Detalhes
        </Button>
        {appt.status === 'pendente_pagamento' && (
          <Button variant="primary" size="sm" to={`/pagamento/${appt.id}`} icon="payments" iconSize={18}>
            Pagar agora
          </Button>
        )}
        {appt.status === 'concluida' && onDownload && (
          <Button variant="soft-green" size="sm" icon="download" iconSize={18} onClick={() => onDownload(appt)}>
            Baixar Receita
          </Button>
        )}
        {policy.canCancel && onCancel && (
          <Button variant="danger" size="sm" onClick={() => onCancel(appt)}>
            Cancelar
          </Button>
        )}
      </div>
    </article>
  );
}

export function AppointmentCardSkeleton() {
  return (
    <div className="appt-card appt-card--skeleton" aria-hidden="true">
      <span className="skeleton" style={{ width: 64, height: 64, borderRadius: 12 }} />
      <div>
        <span className="skeleton" style={{ width: '45%', height: 18 }} />
        <span className="skeleton" style={{ width: '25%', height: 12, marginTop: 10 }} />
      </div>
      <span className="skeleton" style={{ width: 90, height: 24, borderRadius: 99 }} />
      <span className="skeleton" style={{ gridColumn: '2 / 4', height: 14, width: '70%' }} />
    </div>
  );
}
