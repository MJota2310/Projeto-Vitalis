import { useEffect, useState } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import { Notice } from '../ui/Feedback';
import { TextField } from '../ui/Field';
import { DatePicker, TimeSlots } from '../booking/Schedule';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { cancelAppointment, cancellationPolicy, rescheduleAppointment } from '../../services/appointmentService';
import { professionalById } from '../../data/catalog';
import { formatCurrency, formatDateBR, formatDateLong } from '../../utils/format';

/** Confirmação de cancelamento, com a regra de reembolso de 24h do Figma. */
export function CancelModal({ appt, onClose, onDone }) {
  const { user } = useAuth();
  const toast = useToast();
  const [reason, setReason] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setReason('');
    setLoading(false);
  }, [appt]);

  if (!appt) return null;
  const policy = cancellationPolicy(appt);
  const paid = appt.status === 'agendada';

  const confirm = async () => {
    setLoading(true);
    try {
      const updated = await cancelAppointment(user.id, appt.id, reason);
      toast.success(
        'Consulta cancelada',
        updated.refund?.status === 'reembolsado'
          ? `Reembolso de ${formatCurrency(updated.refund.amount)} registrado (demonstração).`
          : paid
            ? 'Cancelamento fora do prazo de reembolso.'
            : 'O horário foi liberado.',
      );
      onDone?.(updated);
      onClose();
    } catch (err) {
      toast.error('Não foi possível cancelar', err.message);
      setLoading(false);
    }
  };

  return (
    <Modal
      open={!!appt}
      onClose={loading ? () => {} : onClose}
      title="Cancelar consulta?"
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={loading}>
            Manter consulta
          </Button>
          <Button variant="danger-solid" onClick={confirm} loading={loading} loadingText="Cancelando…">
            Confirmar cancelamento
          </Button>
        </>
      }
    >
      <div className="stack">
        <p>
          <strong>{appt.serviceName}</strong> com {appt.professionalName}
          <br />
          {formatDateLong(appt.date, true)} às {appt.time} · Protocolo {appt.protocol}
        </p>
        {!paid ? (
          <Notice tone="info">Este agendamento ainda não foi pago. O horário será liberado.</Notice>
        ) : policy.refundable ? (
          <Notice tone="success" title="Reembolso total:">
            você está cancelando com mais de 24h de antecedência e receberá {formatCurrency(appt.total)} de volta.
          </Notice>
        ) : (
          <Notice tone="warning" title="Fora do prazo de reembolso.">
            A garantia de reembolso vale para cancelamentos feitos até 24h antes. Em caso de dúvida, fale com o suporte.
          </Notice>
        )}
        <TextField
          as="textarea"
          label="Motivo (opcional)"
          name="cancel-reason"
          rows={3}
          maxLength={280}
          placeholder="Conte o motivo do cancelamento"
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          hint={`${reason.length}/280`}
        />
      </div>
    </Modal>
  );
}

/** Remarcação com o mesmo profissional (até 24h antes). */
export function RescheduleModal({ appt, onClose, onDone }) {
  const { user } = useAuth();
  const toast = useToast();
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    setDate('');
    setTime('');
    setError('');
    setLoading(false);
  }, [appt]);

  if (!appt) return null;
  const pro = professionalById(appt.professionalId);

  const confirm = async () => {
    setError('');
    setLoading(true);
    try {
      const updated = await rescheduleAppointment(user.id, appt.id, { date, time });
      toast.success('Consulta remarcada', `${formatDateBR(date)} às ${time}.`);
      onDone?.(updated);
      onClose();
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  return (
    <Modal
      open={!!appt}
      onClose={loading ? () => {} : onClose}
      title="Remarcar consulta"
      width={520}
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={loading}>
            Voltar
          </Button>
          <Button variant="primary" onClick={confirm} disabled={!date || !time} loading={loading} loadingText="Remarcando…">
            Confirmar nova data
          </Button>
        </>
      }
    >
      <div className="stack">
        <p className="muted">
          Atual:{' '}
          <strong>
            {formatDateBR(appt.date)} às {appt.time}
          </strong>{' '}
          com {appt.professionalName}
        </p>
        {error && <Notice tone="error">{error}</Notice>}
        <DatePicker
          pro={pro}
          value={date}
          onChange={(d) => {
            setDate(d);
            setTime('');
          }}
          label="Nova data"
        />
        <TimeSlots proId={pro.id} date={date} value={time} onChange={setTime} ignoreAppointmentId={appt.id} />
      </div>
    </Modal>
  );
}
