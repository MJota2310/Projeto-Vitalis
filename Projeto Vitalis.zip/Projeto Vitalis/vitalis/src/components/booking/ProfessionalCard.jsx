import Icon from '../ui/Icon';
import Button from '../ui/Button';
import { Stars } from '../ui/Feedback';
import { proEmoji, serviceBySlug } from '../../data/catalog';
import { WEEKDAYS_SHORT, formatPriceShort } from '../../utils/format';

/**
 * Card de profissional (tela "Agendar" do Figma).
 * - modo seleção: `selectable` + `selected` + `onSelect` (radio acessível)
 * - modo ação: `actionTo` (ex.: agendar com este profissional)
 */
export default function ProfessionalCard({
  pro,
  selectable,
  selected,
  onSelect,
  actionTo,
  actionLabel = 'Agendar',
  showService,
}) {
  const service = serviceBySlug(pro.service);
  const NameTag = selectable ? 'p' : 'h3';
  const content = (
    <>
      <span className="pro-avatar" aria-hidden="true">
        {proEmoji(pro)}
      </span>
      <div className="pro-item__body">
        <div className="pro-item__head">
          <div className="pro-item__id">
            <NameTag className="pro-item__name">{pro.name}</NameTag>
            <p className="pro-item__spec">
              {pro.specialty}
              {showService && service && service.name !== pro.specialty ? ` · ${service.name}` : ''}
            </p>
          </div>
          <div className="pro-item__price">
            <strong>{formatPriceShort(pro.price)}</strong>
            <span>por consulta</span>
          </div>
        </div>
        <div className="pro-item__meta">
          <Stars rating={pro.rating} reviews={pro.reviews} size={15} />
          <span className="pro-item__city">
            <Icon name="distance" size={17} /> {pro.city}
          </span>
        </div>
        <div className="pro-item__days">
          <span className="pro-item__days-label">Disponível:</span>
          {pro.days.map((d) => (
            <span key={d} className="day-chip">
              {WEEKDAYS_SHORT[d]}
            </span>
          ))}
        </div>
      </div>
      {selectable && (
        <span className="pro-item__radio" aria-hidden="true">
          <Icon name="check" size={18} />
        </span>
      )}
    </>
  );

  if (selectable) {
    return (
      <div
        role="radio"
        tabIndex={0}
        aria-checked={!!selected}
        aria-label={`${pro.name}, ${pro.specialty}, ${formatPriceShort(pro.price)} por consulta`}
        className={`pro-item pro-item--selectable${selected ? ' is-selected' : ''}`}
        onClick={() => onSelect(pro.id)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onSelect(pro.id);
          }
        }}
      >
        {content}
      </div>
    );
  }

  return (
    <article className="pro-item">
      {content}
      {actionTo && (
        <div className="pro-item__action">
          <Button variant="primary" size="sm" to={actionTo} icon="calendar_today" iconSize={18}>
            {actionLabel}
          </Button>
        </div>
      )}
    </article>
  );
}

export function ProfessionalCardSkeleton() {
  return (
    <div className="pro-item" aria-hidden="true">
      <span className="skeleton" style={{ width: 64, height: 64, borderRadius: 12 }} />
      <div className="pro-item__body">
        <span className="skeleton" style={{ width: '40%', height: 18 }} />
        <span className="skeleton" style={{ width: '25%', height: 12, marginTop: 10 }} />
        <span className="skeleton" style={{ width: '60%', height: 12, marginTop: 14 }} />
        <span className="skeleton" style={{ width: '35%', height: 20, marginTop: 14 }} />
      </div>
    </div>
  );
}
