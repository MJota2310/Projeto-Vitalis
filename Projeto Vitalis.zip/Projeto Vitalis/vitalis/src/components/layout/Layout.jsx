import { useEffect } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import Header from './Header';
import Footer from './Footer';
import { useAuth } from '../../context/AuthContext';

/** Volta ao topo a cada troca de página (exceto quando há uma seção alvo). */
function ScrollManager() {
  const location = useLocation();
  useEffect(() => {
    if (location.state?.scrollTo || location.state?.keepScroll) return;
    if (location.pathname === '/' && new URLSearchParams(location.search).get('secao')) return;
    window.scrollTo({ top: 0, behavior: 'auto' });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname]);
  return null;
}

export default function Layout() {
  const location = useLocation();
  return (
    <>
      <a
        href="#conteudo"
        className="skip-link"
        onClick={(e) => {
          e.preventDefault();
          document.getElementById('conteudo')?.focus();
        }}
      >
        Pular para o conteúdo
      </a>
      <ScrollManager />
      <Header />
      <main id="conteudo" tabIndex={-1} className="site-main">
        <div key={location.pathname} className="page-transition">
          <Outlet />
        </div>
      </main>
      <Footer />
    </>
  );
}

/** Protege rotas privadas: sem sessão → login, voltando depois ao destino. */
export function RequireAuth({ children }) {
  const { isAuthenticated, signedOut } = useAuth();
  const location = useLocation();
  if (!isAuthenticated) {
    if (signedOut) return <Navigate to="/" replace />;
    const redirect = encodeURIComponent(location.pathname + location.search);
    return <Navigate to={`/entrar?redirect=${redirect}`} replace state={{ reason: 'auth' }} />;
  }
  return children;
}

/** Páginas de login/cadastro: se já estiver logado, vai para o painel. */
export function GuestOnly({ children }) {
  const { isAuthenticated } = useAuth();
  const location = useLocation();
  if (isAuthenticated) {
    const redirect = new URLSearchParams(location.search).get('redirect');
    return <Navigate to={redirect && redirect.startsWith('/') ? redirect : '/painel'} replace />;
  }
  return children;
}
