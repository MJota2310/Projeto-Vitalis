// Mapa de navegação do cabeçalho e rodapé.

// Seções da landing page (menu do visitante, como no Figma)
export const LANDING_SECTIONS = [
  { id: 'inicio', label: 'Início' },
  { id: 'como-funciona', label: 'Como funciona' },
  { id: 'servicos', label: 'Serviços' },
  { id: 'profissionais', label: 'Para profissionais' },
  { id: 'contato', label: 'Contato' },
];

// Menu da área logada (telas internas do Figma: Início, Agende, Dashboard, Consultas, Suporte)
export const APP_LINKS = [
  { to: '/', label: 'Início', end: true, icon: 'home' },
  { to: '/agendar', label: 'Agende', icon: 'calendar_today' },
  { to: '/painel', label: 'Dashboard', icon: 'dashboard' },
  { to: '/consultas', label: 'Consultas', icon: 'event_note' },
  { to: '/ajuda', label: 'Suporte', icon: 'support_agent' },
];

export const FOOTER_LINKS = {
  uteis: [
    { label: 'Início', section: 'inicio' },
    { label: 'Como Funciona', section: 'como-funciona' },
    { label: 'Serviços', to: '/servicos' },
    { label: 'Para Profissionais', section: 'profissionais' },
  ],
  suporte: [
    { label: 'Central de ajuda', to: '/ajuda' },
    { label: 'FAQ', to: '/faq' },
    { label: 'Termos de uso', to: '/termos' },
    { label: 'Política de privacidade', to: '/privacidade' },
  ],
};
