import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import * as authService from '../services/authService';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => authService.getSessionUser());
  // true após um "Sair" voluntário: rotas privadas mandam para o início, não para o login
  const [signedOut, setSignedOut] = useState(false);
  const { pathname } = useLocation();

  // Depois de chegar ao início, rotas privadas voltam a pedir login normalmente
  useEffect(() => {
    if (signedOut && pathname === '/') setSignedOut(false);
  }, [signedOut, pathname]);

  const login = useCallback(async (credentials) => {
    const u = await authService.login(credentials);
    setSignedOut(false);
    setUser(u);
    return u;
  }, []);

  const register = useCallback(async (data) => {
    const u = await authService.register(data);
    setSignedOut(false);
    setUser(u);
    return u;
  }, []);

  const logout = useCallback(async () => {
    await authService.logout();
    setSignedOut(true);
    setUser(null);
  }, []);

  const updateProfile = useCallback(
    async (data) => {
      const u = await authService.updateProfile(user.id, data);
      setUser(u);
      return u;
    },
    [user],
  );

  const updatePreferences = useCallback(
    async (prefs) => {
      const u = await authService.updatePreferences(user.id, prefs);
      setUser(u);
      return u;
    },
    [user],
  );

  const changePassword = useCallback((current, next) => authService.changePassword(user.id, current, next), [user]);

  const value = useMemo(
    () => ({
      user,
      isAuthenticated: !!user,
      signedOut,
      login,
      register,
      logout,
      updateProfile,
      updatePreferences,
      changePassword,
    }),
    [user, signedOut, login, register, logout, updateProfile, updatePreferences, changePassword],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth deve ser usado dentro de <AuthProvider>');
  return ctx;
}
