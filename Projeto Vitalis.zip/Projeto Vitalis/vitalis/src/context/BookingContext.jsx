// Rascunho do agendamento — preservado entre as etapas (e após um refresh ou
// login) no sessionStorage.

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { session, KEYS } from '../services/storage';
import { professionalById, serviceBySlug, SERVICE_FEE } from '../data/catalog';

const BookingContext = createContext(null);

const EMPTY = { serviceSlug: '', professionalId: '', date: '', time: '' };

export function BookingProvider({ children }) {
  const [draft, setDraft] = useState(() => ({ ...EMPTY, ...(session.get(KEYS.bookingDraft) || {}) }));

  useEffect(() => {
    session.set(KEYS.bookingDraft, draft);
  }, [draft]);

  const setService = useCallback((serviceSlug) => {
    setDraft((d) => {
      if (d.serviceSlug === serviceSlug) return d;
      const pro = professionalById(d.professionalId);
      const keepPro = pro && pro.service === serviceSlug;
      return keepPro ? { ...d, serviceSlug } : { ...EMPTY, serviceSlug };
    });
  }, []);

  const setProfessional = useCallback((professionalId) => {
    const pro = professionalById(professionalId);
    setDraft((d) => {
      if (d.professionalId === professionalId) return d;
      return { serviceSlug: pro?.service || d.serviceSlug, professionalId, date: '', time: '' };
    });
  }, []);

  const setDate = useCallback((date) => setDraft((d) => (d.date === date ? d : { ...d, date, time: '' })), []);
  const setTime = useCallback((time) => setDraft((d) => ({ ...d, time })), []);
  const reset = useCallback(() => setDraft(EMPTY), []);
  const hydrate = useCallback((partial) => setDraft((d) => ({ ...d, ...partial })), []);

  const value = useMemo(() => {
    const service = serviceBySlug(draft.serviceSlug);
    const professional = professionalById(draft.professionalId);
    const price = professional?.price || 0;
    const step = !professional ? (service ? 2 : 1) : !draft.date || !draft.time ? 3 : 4;
    return {
      draft,
      service,
      professional,
      price,
      fee: SERVICE_FEE,
      total: price ? price + SERVICE_FEE : 0,
      isComplete: !!(professional && draft.date && draft.time),
      step,
      setService,
      setProfessional,
      setDate,
      setTime,
      reset,
      hydrate,
    };
  }, [draft, setService, setProfessional, setDate, setTime, reset, hydrate]);

  return <BookingContext.Provider value={value}>{children}</BookingContext.Provider>;
}

export function useBooking() {
  const ctx = useContext(BookingContext);
  if (!ctx) throw new Error('useBooking deve ser usado dentro de <BookingProvider>');
  return ctx;
}
