// Central de Ajuda — perguntas extraídas da tela "frame_central_de_ajuda".
// As respostas descrevem o funcionamento implementado nesta aplicação.

export const FAQ_GROUPS = [
  {
    id: 'agendamento',
    title: 'Agendamento',
    items: [
      {
        q: 'Como posso agendar uma consulta?',
        a: [
          'Clique em “Agendar Agora” ou escolha um serviço na página de serviços. Selecione a especialidade, o profissional, a data e um horário disponível.',
          'Em seguida, revise os dados e conclua o pagamento — a consulta é confirmada assim que o pagamento é aprovado.',
        ],
        keywords: ['agendar', 'marcar', 'consulta', 'horario'],
      },
      {
        q: 'Posso cancelar ou remarcar uma consulta?',
        a: [
          'Sim. Em “Consultas”, abra a consulta desejada e use as opções “Remarcar” ou “Cancelar”.',
          'Cancelamentos feitos com pelo menos 24h de antecedência recebem reembolso total. A remarcação fica disponível até 24h antes do horário marcado.',
        ],
        keywords: ['cancelar', 'remarcar', 'reagendar', 'desmarcar'],
      },
      {
        q: 'Como sei se minha consulta foi confirmada?',
        a: [
          'Depois que o pagamento é aprovado, a consulta aparece com o status “Aguardando” (confirmada) em “Consultas” e no seu Dashboard, com o número de protocolo.',
          'Você também pode baixar o evento para a sua agenda (.ics) na página de detalhes da consulta.',
        ],
        keywords: ['confirmada', 'confirmacao', 'status', 'protocolo'],
      },
    ],
  },
  {
    id: 'pagamento',
    title: 'Pagamento',
    items: [
      {
        q: 'Quais formas de pagamento são aceitas?',
        a: ['Cartão (débito ou crédito) e PIX, com aprovação instantânea.'],
        keywords: ['pagamento', 'cartao', 'pix', 'credito', 'debito', 'formas'],
      },
      {
        q: 'Quando serei cobrado?',
        a: [
          'O pagamento é feito no momento do agendamento. Enquanto ele não é concluído, a consulta fica como “Pagamento pendente” e você pode pagar depois pela página da consulta.',
        ],
        keywords: ['cobrado', 'cobranca', 'quando', 'pendente'],
      },
      {
        q: 'Como funciona o reembolso?',
        a: [
          'Garantia de reembolso: se você não puder comparecer, cancele até 24h antes e receba o reembolso total do valor pago.',
        ],
        keywords: ['reembolso', 'devolucao', 'estorno', 'dinheiro de volta'],
      },
    ],
  },
  {
    id: 'conta',
    title: 'Conta e Perfil',
    items: [
      {
        q: 'Como criar uma conta?',
        a: [
          'Clique em “Criar conta”, informe se você é Usuário ou Profissional, preencha nome, telefone, e-mail e senha e aceite os termos de uso e a política de privacidade.',
        ],
        keywords: ['criar conta', 'cadastro', 'registrar', 'cadastrar'],
      },
      {
        q: 'Esqueci minha senha, o que faço?',
        a: [
          'Na tela de login, clique em “Esqueceu a senha?” e informe seu e-mail para receber as instruções de redefinição.',
          'Se você ainda lembra a senha atual, também pode trocá-la em Perfil → Configurações → Segurança.',
        ],
        keywords: ['senha', 'esqueci', 'recuperar', 'redefinir'],
      },
      {
        q: 'Como atualizar minhas informações cadastrais?',
        a: ['Acesse “Meu Perfil”, clique em “Editar”, altere os dados desejados e clique em “Salvar alterações”.'],
        keywords: ['atualizar', 'dados', 'perfil', 'endereco', 'telefone', 'editar'],
      },
    ],
  },
  {
    id: 'profissionais',
    title: 'Para Profissionais',
    items: [
      {
        q: 'Como me cadastrar como profissional?',
        a: ['Em “Criar conta”, selecione a opção “Profissional — Ofereço serviços de saúde” e complete o cadastro.'],
        keywords: ['profissional', 'cadastrar profissional', 'medico', 'terapeuta'],
      },
      {
        q: 'Como gerencio minha agenda?',
        a: [
          'O painel de gestão para profissionais (agenda, pacientes e atendimentos) está em desenvolvimento e ainda não faz parte desta versão. Ao se cadastrar como profissional, sua conta já fica registrada para o lançamento.',
        ],
        keywords: ['agenda', 'gerenciar', 'horarios', 'pacientes'],
      },
      {
        q: 'Qual a taxa da plataforma?',
        a: [
          'Para quem agenda, é cobrada uma taxa de serviço de R$ 10,00 por consulta, sempre exibida no resumo antes do pagamento.',
          'Para condições comerciais de profissionais, fale com o nosso suporte.',
        ],
        keywords: ['taxa', 'tarifa', 'custo', 'preco', 'valor'],
      },
    ],
  },
];

export const TUTORIALS = [
  {
    id: 'primeira-consulta',
    title: 'Como agendar sua primeira consulta',
    icon: 'event_available',
    steps: [
      'Crie sua conta ou faça login.',
      'Clique em “Agende” no menu e escolha a especialidade.',
      'Selecione o profissional e veja os dias em que ele atende.',
      'Escolha a data no calendário e um horário livre.',
      'Revise o resumo e siga para o pagamento.',
    ],
  },
  {
    id: 'pix',
    title: 'Como pagar com PIX',
    icon: 'qr_code_2',
    steps: [
      'Na tela de pagamento, escolha a opção “PIX”.',
      'Escaneie o QR Code ou copie o código “Copia e Cola”.',
      'Conclua o pagamento no app do seu banco dentro do prazo exibido.',
      'Volte ao Vitalis e clique em “Já fiz o pagamento”.',
    ],
  },
  {
    id: 'remarcar',
    title: 'Como remarcar ou cancelar',
    icon: 'event_repeat',
    steps: [
      'Acesse “Consultas” no menu.',
      'Clique em “Ver detalhes” na consulta desejada.',
      'Use “Remarcar” para escolher nova data e horário, ou “Cancelar”.',
      'Cancelamentos com 24h de antecedência têm reembolso total.',
    ],
  },
  {
    id: 'perfil',
    title: 'Como manter seu perfil atualizado',
    icon: 'badge',
    steps: [
      'Clique no seu avatar e escolha “Meu perfil”.',
      'Clique em “Editar” e atualize seus dados.',
      'Em “Configurações”, altere a senha e ajuste as notificações.',
    ],
  },
];

export const SUPPORT_SUBJECTS = ['Agendamento', 'Pagamento', 'Conta e perfil', 'Para profissionais', 'Outro assunto'];
