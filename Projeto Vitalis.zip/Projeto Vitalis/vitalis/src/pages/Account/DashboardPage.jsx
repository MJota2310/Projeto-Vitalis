import { Link, useNavigate } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState, Notice, StatusBadge } from '../../components/ui/Feedback';
import { useAuth } from '../../context/AuthContext';
import { useAsync, useDocumentTitle } from '../../hooks';
import { useAppointments } from './useAppointments';
import { StatCards } from './AppointmentsPage';
import { listPayments } from '../../services/paymentService';
import { proEmoji, professionalById } from '../../data/catalog';
import { downloadCalendarEvent } from '../../utils/download';
import {
  firstName,
  formatCurrency,
  formatDateBR,
  formatDateLong,
  formatDateTimeBR,
  relativeDay,
  toDateTime,
} from '../../utils/format';
import './account.css';

const QUICK = [
  { to: '/agendar', icon: 'calendar_today', label: 'Agendar consulta', text: 'Escolha profissional, data e horário' },
  { to: '/consultas', icon: 'event_note', label: 'Minhas consultas', text: 'Histórico, comprovantes e status' },
  { to: '/perfil', icon: 'account_circle', label: 'Meu perfil', text: 'Dados pessoais e estatísticas' },
  { to: '/perfil?aba=configuracoes', icon: 'settings', label: 'Configurações', text: 'Senha e notificações' },
  { to: '/servicos', icon: 'medical_services', label: 'Serviços', text: 'Todas as especialidades' },
  { to: '/ajuda', icon: 'support_agent', label: 'Central de ajuda', text: 'Dúvidas, chat e contato' },
];

const PAY_LABEL = { aprovado: ['Aprovado', 'green'], recusado: ['Recusado', 'red'], reembolsado: ['Reembolsado', 'blue'] };

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return 'Bom dia';
  if (h < 18) return 'Boa tarde';
  return 'Boa noite';
}

export default function DashboardPage() {
  useDocumentTitle('Dashboard');
  const { user } = useAuth();
  const navigate = useNavigate();
  const { list, stats, loading, error, reload } = useAppointments();
  const payments = useAsync(() => listPayments(user.id), [user.id]);

  const upcoming = list
    .filter((a) => a.status === 'agendada')
    .sort((a, b) => toDateTime(a.date, a.time) - toDateTime(b.date, b.time));
  const next = upcoming[0];
  const pending = list.filter((a) => a.status === 'pendente_pagamento');
  const recent = list.filter((a) => a.status === 'concluida' || a.status === 'cancelada').slice(0, 3);

  return (
    <div className="account-page">
      <div className="container page dashboard">
        <header className="dash-hero">
          <div>
            <p className="dash-hero__eyebrow">{greeting()},</p>
            <h1 className="dash-hero__title">
              {firstName(user.name)} <span aria-hidden="true">👋</span>
            </h1>
            <p className="dash-hero__text">Aqui está um resumo dos seus atendimentos na Vitalis.</p>
          </div>
          <Button variant="light" to="/agendar" icon="calendar_today">
            Agendar consulta
          </Button>
        </header>

        {user.role === 'profissional' && (
          <Notice tone="info" className="dash-notice">
            <strong>Conta de profissional.</strong> As ferramentas de gestão de agenda e pacientes estão em desenvolvimento.
            Enquanto isso, você pode usar a plataforma normalmente para agendar atendimentos.
          </Notice>
        )}

        {pending.length > 0 && (
          <div className="pending-list">
            {pending.map((p) => (
              <Notice key={p.id} tone="warning">
                <strong>Pagamento pendente:</strong> {p.serviceName} com {p.professionalName} em {formatDateBR(p.date)} às{' '}
                {p.time}.{' '}
                <Link to={`/pagamento/${p.id}`} className="text-link">
                  Pagar agora
                </Link>
              </Notice>
            ))}
          </div>
        )}

        <div className="dash-grid">
          <section className="next-card" aria-labelledby="next-title">
            <h2 id="next-title" className="next-card__label">
              <Icon name="upcoming" size={20} /> Próxima consulta
            </h2>
            {loading ? (
              <div className="next-card__skeleton">
                <span className="skeleton" style={{ height: 22, width: '60%', opacity: 0.4 }} />
                <span className="skeleton" style={{ height: 16, width: '40%', opacity: 0.4, marginTop: 12 }} />
              </div>
            ) : next ? (
              <>
                <div className="next-card__main">
                  <span className="pro-avatar next-card__avatar" aria-hidden="true">
                    {proEmoji(professionalById(next.professionalId))}
                  </span>
                  <div>
                    <p className="next-card__when">
                      {formatDateLong(next.date)} · {next.time}
                    </p>
                    <p className="next-card__who">
                      {next.serviceName} com {next.professionalName}
                    </p>
                    <p className="next-card__where">
                      <Icon name="distance" size={16} /> {next.location} · Protocolo {next.protocol}
                    </p>
                  </div>
                  <span className="next-card__countdown">{relativeDay(next.date)}</span>
                </div>
                <div className="next-card__actions">
                  <Button variant="light" size="sm" to={`/consultas/${next.id}`}>
                    Ver detalhes
                  </Button>
                  <button type="button" className="next-card__link" onClick={() => downloadCalendarEvent(next)}>
                    <Icon name="event" size={18} /> Adicionar à agenda
                  </button>
                </div>
                {upcoming.length > 1 && <p className="next-card__more">+ {upcoming.length - 1} consulta(s) agendada(s)</p>}
              </>
            ) : (
              <div className="next-card__empty">
                <p>Você não tem consultas agendadas.</p>
                <Button variant="light" size="sm" to="/agendar" iconRight="arrow_forward">
                  Agendar agora
                </Button>
              </div>
            )}
          </section>

          <section className="quick" aria-labelledby="quick-title">
            <h2 id="quick-title" className="card-title">
              Acesso rápido
            </h2>
            <ul className="quick__grid">
              {QUICK.map((q) => (
                <li key={q.to}>
                  <Link to={q.to} className="quick__item">
                    <span className="quick__icon">
                      <Icon name={q.icon} size={24} />
                    </span>
                    <span>
                      <strong>{q.label}</strong>
                      <small>{q.text}</small>
                    </span>
                  </Link>
                </li>
              ))}
            </ul>
          </section>
        </div>

        <section className="dash-section" aria-labelledby="stats-title">
          <div className="section-head">
            <h2 id="stats-title" className="card-title">
              Suas estatísticas
            </h2>
            <Link to="/consultas" className="text-link">
              Ver todas as consultas
            </Link>
          </div>
          {error ? (
            <ErrorState error={error} onRetry={reload} />
          ) : loading ? (
            <div className="stat-grid">
              {Array.from({ length: 4 }, (_, i) => (
                <span key={i} className="skeleton" style={{ height: 118, borderRadius: 16 }} />
              ))}
            </div>
          ) : (
            <StatCards stats={stats} onSelect={(id) => navigate(id === 'todas' ? '/consultas' : `/consultas?status=${id}`)} />
          )}
        </section>

        <div className="dash-columns">
          <section className="card card--pad" aria-labelledby="recent-title">
            <div className="section-head">
              <h2 id="recent-title" className="card-title">
                Histórico recente
              </h2>
              <Link to="/consultas" className="text-link">
                Ver tudo
              </Link>
            </div>
            {loading ? (
              <span className="skeleton" style={{ height: 160, display: 'block' }} />
            ) : recent.length === 0 ? (
              <EmptyState
                icon="history"
                title="Sem histórico ainda"
                text="Suas consultas realizadas e canceladas aparecerão aqui."
              />
            ) : (
              <ul className="mini-list">
                {recent.map((a) => (
                  <li key={a.id}>
                    <Link to={`/consultas/${a.id}`} className="mini-item">
                      <span className="pro-avatar" style={{ '--pro-avatar': '44px' }} aria-hidden="true">
                        {proEmoji(professionalById(a.professionalId))}
                      </span>
                      <span className="mini-item__body">
                        <strong>{a.professionalName}</strong>
                        <small>
                          {a.specialty} · {formatDateBR(a.date)}
                        </small>
                      </span>
                      <StatusBadge status={a.status} />
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section className="card card--pad" aria-labelledby="payments-title">
            <div className="section-head">
              <h2 id="payments-title" className="card-title">
                Pagamentos recentes
              </h2>
            </div>
            {payments.loading ? (
              <span className="skeleton" style={{ height: 160, display: 'block' }} />
            ) : !payments.data?.length ? (
              <EmptyState icon="payments" title="Nenhum pagamento" text="Os pagamentos das suas consultas aparecerão aqui." />
            ) : (
              <ul className="mini-list">
                {payments.data.slice(0, 4).map((p) => (
                  <li key={p.id}>
                    <Link to={p.appointment ? `/consultas/${p.appointment.id}` : '/consultas'} className="mini-item">
                      <span className="mini-item__icon">
                        <Icon name={p.method === 'pix' ? 'qr_code_2' : 'credit_card'} size={22} />
                      </span>
                      <span className="mini-item__body">
                        <strong>{formatCurrency(p.amount)}</strong>
                        <small>
                          {p.method === 'pix' ? 'PIX' : `${p.brand} •••• ${p.last4}`} · {formatDateTimeBR(p.createdAt)}
                        </small>
                      </span>
                      <span className={`badge badge--${PAY_LABEL[p.status]?.[1] || 'gray'}`}>
                        {PAY_LABEL[p.status]?.[0] || p.status}
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
