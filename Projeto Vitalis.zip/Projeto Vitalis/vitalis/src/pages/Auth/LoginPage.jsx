import { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import Modal from '../../components/ui/Modal';
import { Checkbox, PasswordField, TextField } from '../../components/ui/Field';
import { Notice } from '../../components/ui/Feedback';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { useDocumentTitle, useForm } from '../../hooks';
import { validateEmail } from '../../utils/validation';
import { requestPasswordReset } from '../../services/authService';
import { DEMO_ACCOUNT } from '../../services/db';
import { firstName } from '../../utils/format';
import facebookIcon from '../../assets/images/social-facebook.png';
import './auth.css';

function ForgotPasswordModal({ open, onClose, initialEmail }) {
  const [email, setEmail] = useState(initialEmail || '');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  const close = () => {
    onClose();
    setTimeout(() => {
      setDone(false);
      setError('');
    }, 250);
  };

  const submit = async (e) => {
    e.preventDefault();
    const msg = validateEmail(email);
    setError(msg);
    if (msg) return;
    setLoading(true);
    await requestPasswordReset(email);
    setLoading(false);
    setDone(true);
  };

  return (
    <Modal
      open={open}
      onClose={close}
      title={done ? 'Solicitação registrada' : 'Recuperar senha'}
      footer={
        done ? (
          <Button variant="primary" onClick={close}>
            Entendi
          </Button>
        ) : (
          <>
            <Button variant="ghost" onClick={close}>
              Cancelar
            </Button>
            <Button variant="primary" type="submit" form="forgot-form" loading={loading} loadingText="Enviando…">
              Enviar instruções
            </Button>
          </>
        )
      }
    >
      {done ? (
        <div className="stack">
          <p>
            Se existir uma conta com <strong>{email}</strong>, as instruções de redefinição seriam enviadas para esse e-mail.
          </p>
          <Notice tone="demo" title="Modo demonstração:">
            nenhum e-mail é enviado nesta versão. Para testar, use a conta de demonstração ou crie uma nova conta.
          </Notice>
        </div>
      ) : (
        <form id="forgot-form" onSubmit={submit} noValidate className="stack">
          <p className="muted">Informe o e-mail da sua conta e enviaremos um link para você criar uma nova senha.</p>
          <TextField
            label="E-mail"
            name="reset-email"
            type="email"
            icon="mail"
            autoComplete="email"
            placeholder="seu@email.com"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
              if (error) setError(validateEmail(e.target.value));
            }}
            error={error}
            data-autofocus
          />
        </form>
      )}
    </Modal>
  );
}

export default function LoginPage() {
  useDocumentTitle('Entrar');
  const { login } = useAuth();
  const toast = useToast();
  const [params] = useSearchParams();
  const redirect = params.get('redirect') || '';
  const [formError, setFormError] = useState('');
  const [shake, setShake] = useState(false);
  const [loading, setLoading] = useState(false);
  const [forgotOpen, setForgotOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);

  const validators = useMemo(
    () => ({
      email: validateEmail,
      password: (v) => (v ? '' : 'Informe sua senha.'),
    }),
    [],
  );
  const form = useForm({ email: '', password: '', remember: true }, validators);
  const { values, errors, setField, onBlur, validateAll, setValues } = form;

  const reason = redirect.startsWith('/agendar')
    ? 'Entre na sua conta para concluir o agendamento — sua seleção foi mantida.'
    : redirect.startsWith('/pagamento')
      ? 'Entre na sua conta para continuar o pagamento.'
      : redirect
        ? 'Entre na sua conta para acessar esta página.'
        : '';

  const submit = async (e) => {
    e.preventDefault();
    setFormError('');
    const errs = validateAll();
    if (Object.keys(errs).length) {
      setShake(true);
      return;
    }
    setLoading(true);
    try {
      const user = await login({ email: values.email, password: values.password, remember: values.remember });
      toast.success(`Olá, ${firstName(user.name)}!`, 'Login realizado com sucesso.');
      // o redirecionamento é feito por <GuestOnly> (respeita ?redirect=)
    } catch (err) {
      setFormError(err.message || 'Não foi possível entrar. Tente novamente.');
      setShake(true);
      setLoading(false);
    }
  };

  const social = (name) => toast.info(`Login com ${name} indisponível`, 'Na versão de demonstração, entre com e-mail e senha.');

  return (
    <div className="auth-page">
      <div className="auth-page__bg" aria-hidden="true" />
      <div className="container auth-page__inner">
        <section
          className={`auth-card${shake ? ' anim-shake' : ''}`}
          onAnimationEnd={(e) => e.target === e.currentTarget && setShake(false)}
          aria-labelledby="login-title"
        >
          <header className="auth-card__header">
            <h1 id="login-title" className="auth-card__title auth-card__title--display">
              Bem-vindo de volta
            </h1>
            <p className="auth-card__subtitle">Acesse sua conta para continuar</p>
          </header>

          {reason && (
            <Notice tone="info" className="auth-card__notice">
              {reason}
            </Notice>
          )}

          {formError && (
            <Notice tone="error" className="auth-card__notice">
              {formError}
            </Notice>
          )}

          <form onSubmit={submit} noValidate className="auth-form">
            <TextField
              label="Email"
              name="email"
              type="email"
              icon="mail"
              autoComplete="email"
              inputMode="email"
              placeholder="seu@email.com"
              value={values.email}
              onChange={(e) => setField('email', e.target.value)}
              onBlur={() => onBlur('email')}
              error={errors.email}
              required
            />
            <PasswordField
              label="Senha"
              name="password"
              autoComplete="current-password"
              placeholder="••••••••"
              value={values.password}
              onChange={(e) => setField('password', e.target.value)}
              onBlur={() => onBlur('password')}
              error={errors.password}
              required
            />
            <div className="auth-form__row">
              <Checkbox
                label="Lembrar de mim"
                checked={values.remember}
                onChange={(e) => setValues((v) => ({ ...v, remember: e.target.checked }))}
              />
              <button type="button" className="text-link" onClick={() => setForgotOpen(true)}>
                Esqueceu a senha?
              </button>
            </div>
            <Button
              type="submit"
              variant="primary"
              block
              size="lg"
              iconRight="arrow_right_alt"
              loading={loading}
              loadingText="Entrando…"
            >
              Entrar
            </Button>
          </form>

          <p className="auth-card__switch">
            Não tem uma conta?{' '}
            <Link to={`/cadastro${redirect ? `?redirect=${encodeURIComponent(redirect)}` : ''}`} className="text-link">
              Criar uma
            </Link>
          </p>

          <div className="auth-divider">
            <span>Ou continue com</span>
          </div>
          <div className="social-login">
            <button type="button" className="social-btn" onClick={() => social('Google')}>
              <Icon name="login" size={20} /> Google
            </button>
            <button type="button" className="social-btn" onClick={() => social('Facebook')}>
              <img src={facebookIcon} alt="" width="22" height="22" /> Facebook
            </button>
          </div>

          <div className="demo-box">
            <div>
              <p className="demo-box__title">
                <Icon name="info" size={18} /> Conta de demonstração
              </p>
              <p className="demo-box__cred">
                <span>{DEMO_ACCOUNT.email}</span> · <span>{DEMO_ACCOUNT.password}</span>
              </p>
            </div>
            <Button
              variant="soft-green"
              size="sm"
              onClick={() => {
                setValues((v) => ({ ...v, email: DEMO_ACCOUNT.email, password: DEMO_ACCOUNT.password }));
                form.setErrors({});
                setFormError('');
              }}
            >
              Preencher
            </Button>
          </div>
        </section>

        <button type="button" className="admin-btn" onClick={() => setAdminOpen(true)}>
          <Icon name="settings_b_roll" size={24} /> Sou Administrador. Entrar.
        </button>
      </div>

      <ForgotPasswordModal open={forgotOpen} onClose={() => setForgotOpen(false)} initialEmail={values.email} />

      <Modal
        open={adminOpen}
        onClose={() => setAdminOpen(false)}
        title="Área administrativa"
        footer={
          <Button variant="primary" onClick={() => setAdminOpen(false)}>
            Entendi
          </Button>
        }
      >
        <div className="stack">
          <p>O acesso de administradores é feito por um painel separado, que não faz parte desta versão da aplicação.</p>
          <Notice tone="demo" title="Modo demonstração:">
            nenhuma conta administrativa foi criada. Use uma conta de usuário para testar os fluxos.
          </Notice>
        </div>
      </Modal>
    </div>
  );
}
