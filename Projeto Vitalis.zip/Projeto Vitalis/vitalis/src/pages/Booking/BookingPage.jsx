import { useEffect, useMemo, useRef, useState } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState } from '../../components/ui/Feedback';
import ProfessionalCard, { ProfessionalCardSkeleton } from '../../components/booking/ProfessionalCard';
import { DatePicker, Stepper, TimeSlots } from '../../components/booking/Schedule';
import { useBooking } from '../../context/BookingContext';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { CITIES, SERVICES, proEmoji, professionalById, serviceBySlug } from '../../data/catalog';
import { listProfessionals } from '../../services/catalogService';
import { useAsync, useDocumentTitle, useMediaQuery } from '../../hooks';
import { formatCurrency, formatDateLong } from '../../utils/format';
import './booking.css';

export default function BookingPage() {
  useDocumentTitle('Agendar serviço');
  const [params, setParams] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useToast();
  const { isAuthenticated } = useAuth();
  const booking = useBooking();
  const { draft, service, professional, setService, setProfessional, setDate, setTime, hydrate } = booking;
  const [query, setQuery] = useState('');
  const [city, setCity] = useState('');
  const panelRef = useRef(null);
  const isMobile = useMediaQuery('(max-width: 960px)');

  // Parâmetros vindos de "Agendar agora" (serviço / profissional)
  useEffect(() => {
    const s = params.get('servico');
    const p = params.get('profissional');
    const pro = professionalById(p);
    if (pro)
      hydrate({
        serviceSlug: pro.service,
        professionalId: pro.id,
        ...(pro.id !== draft.professionalId ? { date: '', time: '' } : {}),
      });
    else if (serviceBySlug(s)) setService(s);
    if (s || p) setParams({}, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // "Alterar data/horário" na revisão → rola até o painel de agenda
  useEffect(() => {
    if (location.state?.focus !== 'horario') return undefined;
    const t = setTimeout(() => panelRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 150);
    return () => clearTimeout(t);
  }, [location.state]);

  const {
    data: pros,
    loading,
    error,
    reload,
  } = useAsync(() => listProfessionals({ service: draft.serviceSlug, query, city }), [draft.serviceSlug, query, city]);

  const step = booking.step;
  const canContinue = booking.isComplete;

  const handleSelectPro = (id) => {
    setProfessional(id);
    if (isMobile) setTimeout(() => panelRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 120);
  };

  const handleContinue = () => {
    if (!canContinue) return;
    if (!isAuthenticated) {
      toast.info('Entre para concluir', 'Sua seleção foi salva — faça login ou crie uma conta.');
      navigate(`/entrar?redirect=${encodeURIComponent('/agendar/revisao')}`);
      return;
    }
    navigate('/agendar/revisao');
  };

  const chips = useMemo(() => [{ slug: '', name: 'Todas' }, ...SERVICES], []);

  return (
    <div className="container page booking-page">
      <header className="page-header booking-page__header">
        <div>
          <h1 className="page-title">Agendar Serviço</h1>
          <p className="page-subtitle">Encontre o profissional ideal e agende seu atendimento</p>
        </div>
        <Stepper current={step} />
      </header>

      <div className="booking-layout">
        <div className="booking-main">
          <section className="search-panel" aria-labelledby="search-title">
            <h2 id="search-title" className="search-panel__title">
              Busca profissional
            </h2>
            <div className="search-panel__fields">
              <div className="field field--icon field--action search-panel__query">
                <label htmlFor="pro-search" className="sr-only">
                  Buscar por nome ou especialidade
                </label>
                <div className="field__control">
                  <Icon name="search" size={20} className="field__icon" />
                  <input
                    id="pro-search"
                    className="input"
                    type="search"
                    placeholder="Busca por especialidade ou nome"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    autoComplete="off"
                  />
                  {query && (
                    <button type="button" className="field__action" onClick={() => setQuery('')} aria-label="Limpar busca">
                      <Icon name="close" size={18} />
                    </button>
                  )}
                </div>
              </div>
              <div className="field field--icon search-panel__city">
                <label htmlFor="pro-city" className="sr-only">
                  Localização
                </label>
                <div className="field__control">
                  <Icon name="distance" size={20} className="field__icon" />
                  <select id="pro-city" className="select" value={city} onChange={(e) => setCity(e.target.value)}>
                    <option value="">Localização: todas</option>
                    {CITIES.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
            <div className="search-panel__chips" role="group" aria-label="Especialidade">
              {chips.map((c) => (
                <button
                  key={c.slug || 'all'}
                  type="button"
                  className="chip chip--sm"
                  aria-pressed={draft.serviceSlug === c.slug}
                  onClick={() => setService(c.slug)}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </section>

          <section aria-labelledby="pros-list-title" className="booking-pros">
            <div className="booking-pros__head">
              <h2 id="pros-list-title" className="card-title">
                {service ? `Profissionais de ${service.name}` : 'Todos os profissionais'}
              </h2>
              {!loading && pros && <span className="muted">{pros.length} encontrados</span>}
            </div>
            {error ? (
              <ErrorState error={error} onRetry={reload} />
            ) : loading ? (
              <div className="pro-list">
                <ProfessionalCardSkeleton />
                <ProfessionalCardSkeleton />
                <ProfessionalCardSkeleton />
              </div>
            ) : pros.length === 0 ? (
              <EmptyState
                icon="person"
                title="Nenhum profissional encontrado"
                text="Ajuste a busca, a localização ou escolha outra especialidade."
                actions={
                  <Button
                    variant="outline"
                    size="sm"
                    icon="refresh"
                    onClick={() => {
                      setQuery('');
                      setCity('');
                      setService('');
                    }}
                  >
                    Limpar filtros
                  </Button>
                }
              />
            ) : (
              <div
                className="pro-list"
                role="radiogroup"
                aria-label="Escolha um profissional"
                key={`${draft.serviceSlug}-${city}-${query}`}
              >
                {pros.map((p, i) => (
                  <div key={p.id} style={{ animationDelay: `${i * 40}ms` }} className="pro-list__item">
                    <ProfessionalCard
                      pro={p}
                      selectable
                      selected={draft.professionalId === p.id}
                      onSelect={handleSelectPro}
                      showService={!service}
                    />
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>

        <aside className="booking-panel" ref={panelRef} aria-labelledby="panel-title" id="horario">
          <h2 id="panel-title" className="booking-panel__title">
            Confirmar agendamento
          </h2>

          {!professional ? (
            <div className="booking-panel__empty">
              <Icon name="calendar_today" size={40} />
              <p>Selecione um profissional para continuar</p>
            </div>
          ) : (
            <div className="booking-panel__body" key={professional.id}>
              <div className="panel-pro">
                <span className="pro-avatar" style={{ '--pro-avatar': '48px' }} aria-hidden="true">
                  {proEmoji(professional)}
                </span>
                <div>
                  <p className="panel-pro__name">{professional.name}</p>
                  <p className="panel-pro__spec">
                    {professional.specialty} · {professional.city}
                  </p>
                </div>
                <button type="button" className="icon-btn" onClick={() => setProfessional('')} aria-label="Trocar profissional">
                  <Icon name="close" size={20} />
                </button>
              </div>

              <DatePicker pro={professional} value={draft.date} onChange={setDate} />
              <TimeSlots proId={professional.id} date={draft.date} value={draft.time} onChange={setTime} />

              <hr className="divider" />

              <div className="summary-rows">
                <div className="summary-row">
                  <span>Consulta</span>
                  <strong>{formatCurrency(booking.price)}</strong>
                </div>
                <div className="summary-row">
                  <span>Taxa de Serviço</span>
                  <strong>{formatCurrency(booking.fee)}</strong>
                </div>
                <div className="summary-row summary-row--total">
                  <span>Total</span>
                  <strong>{formatCurrency(booking.total)}</strong>
                </div>
              </div>

              {draft.date && draft.time && (
                <p className="booking-panel__selection" aria-live="polite">
                  <Icon name="event_available" size={18} /> {formatDateLong(draft.date)} às {draft.time}
                </p>
              )}

              <Button
                variant="primary"
                block
                size="lg"
                iconRight="arrow_forward"
                disabled={!canContinue}
                onClick={handleContinue}
              >
                Confirmar Agendamento
              </Button>
              <p className="booking-panel__note">
                {canContinue
                  ? 'Você revisará os dados antes do pagamento.'
                  : !draft.date
                    ? 'Escolha uma data disponível.'
                    : 'Escolha um horário livre.'}
              </p>
            </div>
          )}
        </aside>
      </div>

      {/* Barra fixa no celular */}
      {isMobile && professional && (
        <div className={`booking-bar${canContinue ? ' is-ready' : ''}`}>
          <div>
            <p className="booking-bar__title">
              {canContinue ? `${formatDateLong(draft.date)} · ${draft.time}` : professional.name}
            </p>
            <p className="booking-bar__sub">
              {canContinue ? `Total ${formatCurrency(booking.total)}` : 'Escolha data e horário'}
            </p>
          </div>
          {canContinue ? (
            <Button variant="primary" size="sm" iconRight="arrow_forward" onClick={handleContinue}>
              Continuar
            </Button>
          ) : (
            <Button variant="outline" size="sm" onClick={() => panelRef.current?.scrollIntoView({ behavior: 'smooth' })}>
              Ver agenda
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
