import { Link, useParams } from 'react-router-dom';
import Icon from '../../components/ui/Icon';
import Button from '../../components/ui/Button';
import { EmptyState, ErrorState, Skeleton } from '../../components/ui/Feedback';
import ProfessionalCard, { ProfessionalCardSkeleton } from '../../components/booking/ProfessionalCard';
import { CATEGORIES, SERVICES, SERVICE_FEE, serviceBySlug } from '../../data/catalog';
import { listProfessionals } from '../../services/catalogService';
import { useAsync, useDocumentTitle } from '../../hooks';
import { formatCurrency } from '../../utils/format';
import './services.css';

export default function ServiceDetailPage() {
  const { slug } = useParams();
  const service = serviceBySlug(slug);
  useDocumentTitle(service ? service.name : 'Serviço não encontrado');
  const { data: pros, loading, error, reload } = useAsync(() => listProfessionals({ service: slug }), [slug]);

  if (!service) {
    return (
      <div className="container page">
        <EmptyState
          icon="search"
          title="Serviço não encontrado"
          text="O serviço que você procura não existe ou foi removido."
          actions={
            <Button variant="primary" to="/servicos">
              Ver todos os serviços
            </Button>
          }
        />
      </div>
    );
  }

  const prices = (pros || []).map((p) => p.price);
  const related = SERVICES.filter((s) => s.slug !== slug && s.categories.some((c) => service.categories.includes(c))).slice(0, 3);

  return (
    <div className="container page service-detail">
      <nav className="breadcrumb" aria-label="Você está em">
        <ol>
          <li>
            <Link to="/">Início</Link>
          </li>
          <li>
            <Link to="/servicos">Serviços</Link>
          </li>
          <li aria-current="page">{service.name}</li>
        </ol>
      </nav>

      <header className="service-hero">
        <span className={`icon-tile icon-tile--${service.tile}`} style={{ '--tile': '84px' }}>
          <Icon name={service.icon} size={48} />
        </span>
        <div className="service-hero__copy">
          <h1 className="page-title">{service.name}</h1>
          <p className="page-subtitle">{service.description}</p>
          <div className="service-hero__tags">
            {service.categories.map((c) => (
              <Link key={c} to={`/servicos?categoria=${c}`} className="chip chip--sm">
                {CATEGORIES.find((x) => x.id === c)?.label}
              </Link>
            ))}
          </div>
        </div>
        <div className="service-hero__facts">
          {loading ? (
            <Skeleton width={180} height={56} />
          ) : (
            pros?.length > 0 && (
              <>
                <p>
                  <strong>{pros.length}</strong> {pros.length === 1 ? 'profissional disponível' : 'profissionais disponíveis'}
                </p>
                <p>
                  Consultas a partir de <strong>{formatCurrency(Math.min(...prices))}</strong>
                </p>
                <p className="muted">+ taxa de serviço de {formatCurrency(SERVICE_FEE)}</p>
              </>
            )
          )}
        </div>
      </header>

      <div className="service-detail__grid">
        <section aria-labelledby="pros-title">
          <div className="section-head">
            <h2 id="pros-title" className="card-title">
              Profissionais disponíveis
            </h2>
            <Button variant="link" to={`/agendar?servico=${slug}`} iconRight="arrow_forward" iconSize={18}>
              Ver agenda completa
            </Button>
          </div>
          {error ? (
            <ErrorState error={error} onRetry={reload} />
          ) : loading ? (
            <div className="pro-list">
              <ProfessionalCardSkeleton />
              <ProfessionalCardSkeleton />
            </div>
          ) : pros.length === 0 ? (
            <EmptyState
              icon="person"
              title="Nenhum profissional disponível"
              text="Ainda não há profissionais para este serviço."
            />
          ) : (
            <div className="pro-list">
              {pros.map((p) => (
                <ProfessionalCard
                  key={p.id}
                  pro={p}
                  actionTo={`/agendar?servico=${slug}&profissional=${p.id}`}
                  actionLabel="Agendar"
                />
              ))}
            </div>
          )}
        </section>

        <aside className="service-detail__aside">
          <div className="card card--pad">
            <h2 className="card-title">Como agendar</h2>
            <ol className="mini-steps">
              <li>
                <span>1</span> Escolha o profissional
              </li>
              <li>
                <span>2</span> Selecione data e horário livres
              </li>
              <li>
                <span>3</span> Revise e conclua o pagamento
              </li>
            </ol>
            <Button variant="primary" block to={`/agendar?servico=${slug}`} icon="calendar_today">
              Agendar agora
            </Button>
            <p className="aside-note">
              <Icon name="verified_user" size={18} /> Cancele até 24h antes e receba reembolso total.
            </p>
          </div>

          {related.length > 0 && (
            <div className="card card--pad">
              <h2 className="card-title">Serviços relacionados</h2>
              <ul className="related-list">
                {related.map((r) => (
                  <li key={r.slug}>
                    <Link to={`/servicos/${r.slug}`} className="related-item">
                      <span className={`icon-tile icon-tile--${r.tile}`} style={{ '--tile': '42px' }}>
                        <Icon name={r.icon} size={24} />
                      </span>
                      <span>
                        <strong>{r.name}</strong>
                        <span className="muted">{r.short}</span>
                      </span>
                      <Icon name="chevron_right" size={22} />
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
