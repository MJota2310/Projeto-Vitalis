// Consultas / agendamentos do usuário.

import { getDb, mutate } from './db';
import { ApiError, delay, makeProtocol, uid } from './api';
import { isSlotAvailable } from './catalogService';
import { professionalById, serviceBySlug, SERVICE_FEE } from '../data/catalog';
import { hoursUntil, toDateTime, formatDateBR } from '../utils/format';

export const STATUS = {
  pendente_pagamento: { label: 'Pagamento pendente', tone: 'yellow', icon: 'hourglass_empty' },
  agendada: { label: 'Aguardando', tone: 'blue', icon: 'alarm' },
  concluida: { label: 'Concluída', tone: 'green', icon: 'check_circle' },
  cancelada: { label: 'Cancelada', tone: 'red', icon: 'cancel' },
};

export const CANCEL_REFUND_HOURS = 24; // "cancele até 24h antes e receba reembolso total"
export const RESCHEDULE_MIN_HOURS = 24;

/** Consultas confirmadas cujo horário já passou são marcadas como concluídas. */
function syncStatuses(db) {
  const now = Date.now();
  let changed = false;
  db.appointments.forEach((a) => {
    if (a.status === 'agendada' && toDateTime(a.date, a.time).getTime() + 60 * 60 * 1000 < now) {
      a.status = 'concluida';
      a.history = [...(a.history || []), { at: new Date().toISOString(), label: 'Consulta realizada' }];
      changed = true;
    }
  });
  return changed;
}

function withPayment(db, appt) {
  const payment = db.payments.find((p) => p.id === appt.paymentId) || null;
  const attempts = db.payments.filter((p) => p.appointmentId === appt.id);
  return { ...appt, payment, attempts };
}

function sortAppointments(list) {
  const rank = { pendente_pagamento: 0, agendada: 1, concluida: 2, cancelada: 3 };
  return [...list].sort((a, b) => {
    if (rank[a.status] !== rank[b.status]) return rank[a.status] - rank[b.status];
    const ta = toDateTime(a.date, a.time).getTime();
    const tb = toDateTime(b.date, b.time).getTime();
    // futuras: mais próximas primeiro; passadas: mais recentes primeiro
    return a.status === 'agendada' || a.status === 'pendente_pagamento' ? ta - tb : tb - ta;
  });
}

export async function listAppointments(userId) {
  await delay(300, 650);
  const db = mutate((d) => {
    syncStatuses(d);
    return d;
  });
  return sortAppointments(db.appointments.filter((a) => a.userId === userId)).map((a) => withPayment(db, a));
}

export async function getAppointment(userId, id) {
  await delay(200, 450);
  const db = mutate((d) => {
    syncStatuses(d);
    return d;
  });
  const appt = db.appointments.find((a) => a.id === id && a.userId === userId);
  if (!appt) throw new ApiError('Consulta não encontrada.', 'NOT_FOUND');
  return withPayment(db, appt);
}

export function computeStats(list) {
  return {
    total: list.length,
    concluidas: list.filter((a) => a.status === 'concluida').length,
    agendadas: list.filter((a) => a.status === 'agendada').length,
    pendentes: list.filter((a) => a.status === 'pendente_pagamento').length,
    canceladas: list.filter((a) => a.status === 'cancelada').length,
  };
}

/** Cria a consulta com status "pagamento pendente" (confirmada após o pagamento). */
export async function createAppointment(userId, { serviceSlug, professionalId, date, time }) {
  await delay(500, 900);
  const pro = professionalById(professionalId);
  const service = serviceBySlug(serviceSlug || pro?.service);
  if (!pro || !service || pro.service !== service.slug) {
    throw new ApiError('Profissional ou serviço inválido. Refaça a seleção.', 'INVALID_SELECTION');
  }
  if (!isSlotAvailable(pro.id, date, time)) {
    throw new ApiError('Este horário acabou de ficar indisponível. Escolha outro horário.', 'SLOT_TAKEN', 'time');
  }
  return mutate((db) => {
    const now = new Date().toISOString();
    const appt = {
      id: uid('apt'),
      protocol: makeProtocol(db.appointments.map((a) => a.protocol)),
      userId,
      serviceSlug: service.slug,
      serviceName: service.name,
      professionalId: pro.id,
      professionalName: pro.name,
      specialty: pro.specialty,
      location: pro.city,
      date,
      time,
      price: pro.price,
      fee: SERVICE_FEE,
      total: pro.price + SERVICE_FEE,
      status: 'pendente_pagamento',
      createdAt: now,
      updatedAt: now,
      paymentId: null,
      history: [{ at: now, label: 'Agendamento criado — aguardando pagamento' }],
    };
    db.appointments.push(appt);
    return { ...appt, payment: null, attempts: [] };
  });
}

export function cancellationPolicy(appt) {
  const hours = hoursUntil(appt.date, appt.time);
  const paid = appt.status === 'agendada';
  return {
    hours,
    canCancel: appt.status === 'agendada' || appt.status === 'pendente_pagamento',
    refundable: paid && hours >= CANCEL_REFUND_HOURS,
    canReschedule: (appt.status === 'agendada' || appt.status === 'pendente_pagamento') && hours >= RESCHEDULE_MIN_HOURS,
  };
}

export async function cancelAppointment(userId, id, reason = '') {
  await delay(500, 900);
  return mutate((db) => {
    const appt = db.appointments.find((a) => a.id === id && a.userId === userId);
    if (!appt) throw new ApiError('Consulta não encontrada.', 'NOT_FOUND');
    const policy = cancellationPolicy(appt);
    if (!policy.canCancel) throw new ApiError('Esta consulta não pode mais ser cancelada.', 'NOT_CANCELABLE');
    const now = new Date().toISOString();
    appt.status = 'cancelada';
    appt.canceledAt = now;
    appt.cancelReason = reason.trim();
    appt.updatedAt = now;
    const payment = db.payments.find((p) => p.id === appt.paymentId);
    if (payment && payment.status === 'aprovado') {
      if (policy.refundable) {
        payment.status = 'reembolsado';
        appt.refund = { amount: payment.amount, status: 'reembolsado' };
        appt.history.push({ at: now, label: 'Consulta cancelada com reembolso total' });
      } else {
        appt.refund = { amount: 0, status: 'fora_do_prazo' };
        appt.history.push({ at: now, label: 'Consulta cancelada com menos de 24h de antecedência' });
      }
    } else {
      appt.history.push({ at: now, label: 'Agendamento cancelado antes do pagamento' });
    }
    return withPayment(db, appt);
  });
}

export async function rescheduleAppointment(userId, id, { date, time }) {
  await delay(500, 900);
  const current = getDb().appointments.find((a) => a.id === id && a.userId === userId);
  if (!current) throw new ApiError('Consulta não encontrada.', 'NOT_FOUND');
  if (!cancellationPolicy(current).canReschedule) {
    throw new ApiError('A remarcação só é possível até 24h antes do horário marcado.', 'NOT_RESCHEDULABLE');
  }
  if (current.date === date && current.time === time) {
    throw new ApiError('Escolha uma data ou horário diferente do atual.', 'SAME_SLOT');
  }
  if (!isSlotAvailable(current.professionalId, date, time, { ignoreAppointmentId: id })) {
    throw new ApiError('Este horário não está mais disponível. Escolha outro.', 'SLOT_TAKEN', 'time');
  }
  return mutate((db) => {
    const appt = db.appointments.find((a) => a.id === id);
    const now = new Date().toISOString();
    appt.history.push({
      at: now,
      label: `Remarcada de ${formatDateBR(appt.date)} ${appt.time} para ${formatDateBR(date)} ${time}`,
    });
    appt.date = date;
    appt.time = time;
    appt.updatedAt = now;
    return withPayment(db, appt);
  });
}
