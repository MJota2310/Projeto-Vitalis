// Autenticação (modo demonstração, 100% local).
// Para integrar um backend real, substitua o corpo destas funções por chamadas
// HTTP (ex.: POST /auth/login) mantendo as mesmas assinaturas.

import { getDb, mutate } from './db';
import { local, session, KEYS } from './storage';
import { ApiError, delay, uid } from './api';
import { hashPassword, verifyPassword } from '../utils/crypto';

/** Remove campos sensíveis antes de expor o usuário à interface. */
export function publicUser(user) {
  if (!user) return null;
  // eslint-disable-next-line no-unused-vars
  const { password, ...rest } = user;
  return rest;
}

function findByEmail(email) {
  const target = String(email).trim().toLowerCase();
  return getDb().users.find((u) => u.email.toLowerCase() === target) || null;
}

function persistSession(userId, remember) {
  const data = { userId, createdAt: new Date().toISOString(), remember: !!remember };
  if (remember) {
    local.set(KEYS.session, data);
    session.remove(KEYS.session);
  } else {
    session.set(KEYS.session, data);
    local.remove(KEYS.session);
  }
}

export function getSessionUser() {
  const s = session.get(KEYS.session) || local.get(KEYS.session);
  if (!s?.userId) return null;
  const user = getDb().users.find((u) => u.id === s.userId);
  return publicUser(user);
}

export async function login({ email, password, remember }) {
  await delay(450, 800);
  const user = findByEmail(email);
  const ok = user ? await verifyPassword(password, user.password) : false;
  if (!ok) throw new ApiError('E-mail ou senha incorretos.', 'INVALID_CREDENTIALS');
  persistSession(user.id, remember);
  return publicUser(user);
}

export async function register({ name, email, phone, password, role }) {
  await delay(500, 900);
  if (findByEmail(email)) {
    throw new ApiError('Já existe uma conta com este e-mail.', 'EMAIL_IN_USE', 'email');
  }
  const hashed = await hashPassword(password);
  const user = mutate((db) => {
    const u = {
      id: uid('usr'),
      role: role === 'profissional' ? 'profissional' : 'usuario',
      name: name.trim().replace(/\s+/g, ' '),
      email: email.trim().toLowerCase(),
      phone,
      birthDate: '',
      address: '',
      createdAt: new Date().toISOString(),
      password: hashed,
      prefs: { twoFactor: false, notifyEmail: true, notifySms: false, notifyWhatsapp: false },
    };
    db.users.push(u);
    return u;
  });
  persistSession(user.id, true);
  return publicUser(user);
}

export async function logout() {
  await delay(150, 300);
  local.remove(KEYS.session);
  session.remove(KEYS.session);
}

export async function updateProfile(userId, data) {
  await delay(400, 700);
  const email = data.email?.trim().toLowerCase();
  const other = email ? findByEmail(email) : null;
  if (other && other.id !== userId) {
    throw new ApiError('Este e-mail já está em uso por outra conta.', 'EMAIL_IN_USE', 'email');
  }
  const updated = mutate((db) => {
    const u = db.users.find((x) => x.id === userId);
    if (!u) throw new ApiError('Usuário não encontrado.', 'NOT_FOUND');
    Object.assign(u, {
      name: data.name.trim().replace(/\s+/g, ' '),
      email,
      phone: data.phone,
      birthDate: data.birthDate,
      address: data.address.trim(),
      updatedAt: new Date().toISOString(),
    });
    return u;
  });
  return publicUser(updated);
}

export async function updatePreferences(userId, prefs) {
  await delay(200, 400);
  const updated = mutate((db) => {
    const u = db.users.find((x) => x.id === userId);
    if (!u) throw new ApiError('Usuário não encontrado.', 'NOT_FOUND');
    u.prefs = { ...u.prefs, ...prefs };
    return u;
  });
  return publicUser(updated);
}

export async function changePassword(userId, currentPassword, newPassword) {
  await delay(500, 800);
  const user = getDb().users.find((u) => u.id === userId);
  if (!user) throw new ApiError('Usuário não encontrado.', 'NOT_FOUND');
  const ok = await verifyPassword(currentPassword, user.password);
  if (!ok) throw new ApiError('A senha atual está incorreta.', 'INVALID_PASSWORD', 'current');
  const same = await verifyPassword(newPassword, user.password);
  if (same) throw new ApiError('A nova senha deve ser diferente da atual.', 'SAME_PASSWORD', 'next');
  const hashed = await hashPassword(newPassword);
  mutate((db) => {
    const u = db.users.find((x) => x.id === userId);
    u.password = hashed;
    u.passwordChangedAt = new Date().toISOString();
  });
  return true;
}

/**
 * Recuperação de senha. Sem servidor de e-mail na demonstração, apenas
 * valida a solicitação — a interface informa claramente que nenhum e-mail é
 * enviado. A resposta é a mesma exista ou não a conta (boa prática de segurança).
 */
export async function requestPasswordReset(email) {
  await delay(500, 800);
  return { email: String(email).trim().toLowerCase(), sent: false, demo: true };
}
