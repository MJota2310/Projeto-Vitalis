// Catálogo: serviços, profissionais e disponibilidade de agenda.

import { SERVICES, PROFESSIONALS, TIME_SLOTS, serviceBySlug, professionalById, servicesInCategory } from '../data/catalog';
import { getDb } from './db';
import { delay, hashString } from './api';
import { normalize, parseISODate, toDateTime, toISODate, addDays } from '../utils/format';

export const BOOKING_WINDOW_DAYS = 45;

export async function listServices({ category = 'todas', query = '' } = {}) {
  await delay(200, 450);
  const q = normalize(query.trim());
  return servicesInCategory(category).filter((s) => {
    if (!q) return true;
    const pros = PROFESSIONALS.filter((p) => p.service === s.slug);
    const haystack = normalize([s.name, s.description, s.short, ...pros.map((p) => `${p.name} ${p.specialty}`)].join(' '));
    return haystack.includes(q);
  });
}

export async function getService(slug) {
  await delay(150, 350);
  return serviceBySlug(slug);
}

export function professionalCount(slug) {
  return PROFESSIONALS.filter((p) => p.service === slug).length;
}

export async function listProfessionals({ service = '', query = '', city = '' } = {}) {
  await delay(250, 500);
  const q = normalize(query.trim());
  return PROFESSIONALS.filter((p) => {
    if (service && p.service !== service) return false;
    if (city && p.city !== city) return false;
    if (q) {
      const s = serviceBySlug(p.service);
      const hay = normalize(`${p.name} ${p.specialty} ${p.title} ${s?.name ?? ''}`);
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}

export async function getProfessional(id) {
  await delay(100, 250);
  return professionalById(id);
}

/** A data é atendida pelo profissional e está dentro da janela de agendamento? */
export function isBookableDate(pro, iso) {
  if (!pro || !iso) return false;
  const d = parseISODate(iso);
  const today = parseISODate(toISODate(new Date()));
  const limit = addDays(today, BOOKING_WINDOW_DAYS);
  if (d < today || d > limit) return false;
  return pro.days.includes(d.getDay());
}

/**
 * Horários de um profissional em uma data.
 * status: 'livre' | 'ocupado' (reservado por outro paciente ou por você) | 'passado'
 * Obs.: parte da ocupação é fictícia e determinística, apenas para a agenda
 * da demonstração parecer realista.
 */
export function getSlots(proId, iso, { ignoreAppointmentId } = {}) {
  const pro = professionalById(proId);
  if (!isBookableDate(pro, iso)) return [];
  const taken = new Set(
    getDb()
      .appointments.filter(
        (a) =>
          a.professionalId === proId &&
          a.date === iso &&
          a.id !== ignoreAppointmentId &&
          (a.status === 'agendada' || a.status === 'pendente_pagamento'),
      )
      .map((a) => a.time),
  );
  const now = Date.now();
  return TIME_SLOTS.map((time) => {
    const dt = toDateTime(iso, time).getTime();
    let status = 'livre';
    if (dt <= now + 60 * 60 * 1000) status = 'passado';
    else if (taken.has(time) || hashString(`${proId}|${iso}|${time}`) % 5 === 0) status = 'ocupado';
    return { time, status };
  });
}

export async function fetchSlots(proId, iso, opts) {
  await delay(200, 400);
  return getSlots(proId, iso, opts);
}

export function isSlotAvailable(proId, iso, time, opts) {
  return getSlots(proId, iso, opts).some((s) => s.time === time && s.status === 'livre');
}

export { SERVICES, PROFESSIONALS };
