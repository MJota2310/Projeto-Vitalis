// "Banco de dados" local da demonstração (persistido no localStorage).
// Estrutura pensada para espelhar tabelas de um backend real:
// users, appointments, payments e tickets.

import { local, KEYS } from './storage';
import { hashPassword } from '../utils/crypto';
import { addDays, toISODate } from '../utils/format';
import { professionalById, serviceBySlug, SERVICE_FEE } from '../data/catalog';
import { uid } from './api';

const SCHEMA_VERSION = 1;

export const DEMO_ACCOUNT = {
  email: 'demo@vitalis.com',
  password: 'Vitalis@123',
};

let cache = null;

function emptyDb() {
  return { version: SCHEMA_VERSION, users: [], appointments: [], payments: [], tickets: [] };
}

export function getDb() {
  if (!cache) cache = local.get(KEYS.db, null) || emptyDb();
  return cache;
}

export function saveDb(next = cache) {
  cache = next;
  local.set(KEYS.db, cache);
  return cache;
}

/** Aplica uma alteração no banco e persiste. */
export function mutate(fn) {
  const db = getDb();
  const result = fn(db);
  saveDb(db);
  return result;
}

function nextWeekday(from, offset, allowedDays) {
  // encontra a próxima data (a partir de from + offset) em um dos dias permitidos
  let d = addDays(from, offset);
  for (let i = 0; i < 7; i += 1) {
    if (allowedDays.includes(d.getDay())) return d;
    d = addDays(d, 1);
  }
  return d;
}

function prevWeekday(from, offset, allowedDays) {
  let d = addDays(from, -offset);
  for (let i = 0; i < 7; i += 1) {
    if (allowedDays.includes(d.getDay())) return d;
    d = addDays(d, -1);
  }
  return d;
}

function buildAppointment({ userId, proId, date, time, status, protocol, method = 'card' }) {
  const pro = professionalById(proId);
  const service = serviceBySlug(pro.service);
  const createdAt = addDays(new Date(`${date}T09:00:00`), -7).toISOString();
  const appt = {
    id: uid('apt'),
    protocol,
    userId,
    serviceSlug: service.slug,
    serviceName: service.name,
    professionalId: pro.id,
    professionalName: pro.name,
    specialty: pro.specialty,
    location: pro.city,
    date,
    time,
    price: pro.price,
    fee: SERVICE_FEE,
    total: pro.price + SERVICE_FEE,
    status,
    createdAt,
    updatedAt: createdAt,
    paymentId: null,
    history: [{ at: createdAt, label: 'Agendamento criado' }],
  };
  const payment = {
    id: uid('pay'),
    appointmentId: appt.id,
    userId,
    method,
    brand: method === 'card' ? 'Visa' : null,
    last4: method === 'card' ? '4242' : null,
    amount: appt.total,
    status: 'aprovado',
    createdAt,
    paidAt: createdAt,
    demo: true,
  };
  appt.paymentId = payment.id;
  appt.history.push({ at: createdAt, label: `Pagamento aprovado (${method === 'pix' ? 'PIX' : 'cartão'})` });
  if (status === 'cancelada') {
    const at = addDays(new Date(createdAt), 2).toISOString();
    appt.canceledAt = at;
    appt.refund = { amount: appt.total, status: 'reembolsado' };
    payment.status = 'reembolsado';
    appt.history.push({ at, label: 'Consulta cancelada com reembolso total' });
  }
  if (status === 'concluida') {
    appt.history.push({ at: new Date(`${date}T${time}:00`).toISOString(), label: 'Consulta realizada' });
  }
  return { appt, payment };
}

/** Cria a conta de demonstração com histórico coerente com a "Users Page" do Figma. */
async function seed() {
  const db = emptyDb();
  const now = new Date();
  const userId = 'usr_demo';
  const password = await hashPassword(DEMO_ACCOUNT.password);

  db.users.push({
    id: userId,
    role: 'usuario',
    name: 'Silvia Sandra Menezes',
    email: DEMO_ACCOUNT.email,
    phone: '(11) 99999-9999',
    birthDate: '2001-05-15',
    address: 'Rua das Flores, 123 - São Paulo, SP',
    createdAt: '2024-03-12T10:00:00.000Z',
    password,
    prefs: { twoFactor: false, notifyEmail: true, notifySms: false, notifyWhatsapp: true },
    demo: true,
  });

  const plan = [
    { proId: 'carlos-silva', when: prevWeekday(now, 12, [1, 3, 5]), time: '10:00', status: 'concluida', protocol: 'VIT-12345' },
    {
      proId: 'ana-costa',
      when: prevWeekday(now, 16, [2, 4]),
      time: '14:00',
      status: 'concluida',
      protocol: 'VIT-12346',
      method: 'pix',
    },
    { proId: 'joao-santos', when: prevWeekday(now, 55, [1, 3, 5]), time: '11:00', status: 'concluida', protocol: 'VIT-12347' },
    { proId: 'carla-mendes', when: prevWeekday(now, 30, [2, 4]), time: '16:00', status: 'cancelada', protocol: 'VIT-12348' },
    {
      proId: 'roberto-alves',
      when: nextWeekday(now, 6, [1, 2, 3, 4, 5]),
      time: '09:00',
      status: 'agendada',
      protocol: 'VIT-12349',
      method: 'pix',
    },
    {
      proId: 'patricia-lima',
      when: nextWeekday(now, 20, [1, 2, 3, 4, 5]),
      time: '15:00',
      status: 'agendada',
      protocol: 'VIT-12350',
    },
  ];

  plan.forEach((p) => {
    const { appt, payment } = buildAppointment({
      userId,
      proId: p.proId,
      date: toISODate(p.when),
      time: p.time,
      status: p.status,
      protocol: p.protocol,
      method: p.method,
    });
    db.appointments.push(appt);
    db.payments.push(payment);
  });

  return db;
}

/** Inicializa o banco (cria os dados de demonstração na primeira execução). */
export async function initDb() {
  const stored = local.get(KEYS.db, null);
  if (stored && stored.version === SCHEMA_VERSION && Array.isArray(stored.users)) {
    cache = stored;
    return cache;
  }
  const db = await seed();
  saveDb(db);
  return db;
}

/** Restaura os dados de demonstração (usado em Configurações). */
export async function resetDb() {
  const db = await seed();
  saveDb(db);
  return db;
}
