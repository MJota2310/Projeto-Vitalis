// Pagamentos — MODO DEMONSTRAÇÃO.
// Nenhuma transação real é realizada e nenhum dado de cartão é armazenado:
// guardamos apenas bandeira, 4 últimos dígitos, valor e status.
//
// Cartões de teste:
//   4242 4242 4242 4242 → aprovado
//   4000 0000 0000 0002 → recusado
//   qualquer outro número válido (Luhn) → aprovado
//
// Para integrar um provedor real (Stripe, Mercado Pago, Pagar.me…), substitua
// payWithCard/createPixCharge/confirmPix por chamadas ao seu backend.

import { getDb, mutate } from './db';
import { ApiError, delay, uid } from './api';
import { cardBrand, luhnCheck } from '../utils/validation';

export const DEMO_CARDS = [
  { number: '4242 4242 4242 4242', result: 'aprovado', label: 'Aprovado' },
  { number: '4000 0000 0000 0002', result: 'recusado', label: 'Recusado' },
];

const DECLINED = new Set(['4000000000000002', '4000000000009995']);

// Código "Copia e Cola" exibido no protótipo do Figma (fictício).
const PIX_DEMO_CODE = '00020126580014br.gov.bcb.pix01365ys1acw6mp452040000530398654040.005802BR';
export const PIX_TTL_MINUTES = 30;

function getPayable(userId, appointmentId) {
  const appt = getDb().appointments.find((a) => a.id === appointmentId && a.userId === userId);
  if (!appt) throw new ApiError('Agendamento não encontrado.', 'NOT_FOUND');
  if (appt.status === 'agendada' || appt.status === 'concluida') {
    throw new ApiError('Esta consulta já está paga.', 'ALREADY_PAID');
  }
  if (appt.status === 'cancelada') throw new ApiError('Este agendamento foi cancelado.', 'CANCELED');
  return appt;
}

function recordPayment({ appt, userId, method, brand = null, last4 = null, approved, reason = '' }) {
  return mutate((db) => {
    const target = db.appointments.find((a) => a.id === appt.id);
    // proteção contra envios duplicados (ex.: duas abas processando o mesmo pagamento)
    if (!target || target.status !== 'pendente_pagamento') {
      throw new ApiError('Este agendamento já foi processado.', 'ALREADY_PROCESSED');
    }
    const now = new Date().toISOString();
    const payment = {
      id: uid('pay'),
      appointmentId: appt.id,
      userId,
      method,
      brand,
      last4,
      amount: appt.total,
      status: approved ? 'aprovado' : 'recusado',
      failureReason: approved ? '' : reason,
      createdAt: now,
      paidAt: approved ? now : null,
      demo: true,
    };
    db.payments.push(payment);
    target.updatedAt = now;
    if (approved) {
      target.status = 'agendada';
      target.paymentId = payment.id;
      target.history.push({ at: now, label: `Pagamento aprovado (${method === 'pix' ? 'PIX' : `${brand} •••• ${last4}`})` });
    } else {
      target.history.push({ at: now, label: `Pagamento recusado (${method === 'pix' ? 'PIX' : 'cartão'})` });
    }
    return payment;
  });
}

/** Processa o cartão. Os dados recebidos são usados só nesta função. */
export async function payWithCard(userId, appointmentId, card) {
  const appt = getPayable(userId, appointmentId);
  await delay(1400, 2200);
  const digits = String(card.number).replace(/\D/g, '');
  if (!luhnCheck(digits)) throw new ApiError('Número do cartão inválido.', 'INVALID_CARD', 'number');
  const approved = !DECLINED.has(digits);
  return recordPayment({
    appt,
    userId,
    method: 'card',
    brand: cardBrand(digits),
    last4: digits.slice(-4),
    approved,
    reason: approved ? '' : 'Transação não autorizada pelo emissor (cartão de teste de recusa).',
  });
}

export async function createPixCharge(userId, appointmentId) {
  const appt = getPayable(userId, appointmentId);
  await delay(400, 700);
  return {
    appointmentId: appt.id,
    amount: appt.total,
    code: PIX_DEMO_CODE,
    qrPayload: `VITALIS DEMONSTRACAO - PAGAMENTO FICTICIO - ${appt.protocol} - NAO PAGAR`,
    expiresAt: new Date(Date.now() + PIX_TTL_MINUTES * 60 * 1000).toISOString(),
  };
}

/** "Já fiz o pagamento" — na demonstração, simula a confirmação do banco. */
export async function confirmPix(userId, appointmentId, { simulateFailure = false } = {}) {
  const appt = getPayable(userId, appointmentId);
  await delay(1600, 2400);
  return recordPayment({
    appt,
    userId,
    method: 'pix',
    approved: !simulateFailure,
    reason: simulateFailure ? 'Pagamento PIX não identificado.' : '',
  });
}

export async function getPayment(userId, paymentId) {
  await delay(100, 250);
  const p = getDb().payments.find((x) => x.id === paymentId && x.userId === userId);
  if (!p) throw new ApiError('Pagamento não encontrado.', 'NOT_FOUND');
  return p;
}

export async function listPayments(userId) {
  await delay(200, 400);
  const db = getDb();
  return db.payments
    .filter((p) => p.userId === userId)
    .map((p) => ({ ...p, appointment: db.appointments.find((a) => a.id === p.appointmentId) || null }))
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}
