// Suporte: mensagens de contato e assistente automático do chat.

import { mutate } from './db';
import { delay, uid } from './api';
import { FAQ_GROUPS } from '../data/help';
import { normalize } from '../utils/format';

export async function createTicket({ name, email, subject, message, userId = null }) {
  await delay(600, 1000);
  return mutate((db) => {
    const ticket = {
      id: uid('tkt'),
      protocol: `SUP-${Math.floor(100000 + Math.random() * 900000)}`,
      userId,
      name: name.trim(),
      email: email.trim().toLowerCase(),
      subject,
      message: message.trim(),
      createdAt: new Date().toISOString(),
      status: 'registrado',
    };
    db.tickets = db.tickets || [];
    db.tickets.push(ticket);
    return ticket;
  });
}

const ALL_FAQ = FAQ_GROUPS.flatMap((g) => g.items.map((i) => ({ ...i, group: g.title })));

/** Assistente automático: procura a pergunta frequente mais parecida. */
export async function askAssistant(message) {
  await delay(600, 1100);
  const text = normalize(message);
  const words = text.split(/[^a-z0-9]+/).filter((w) => w.length > 2);
  let best = null;
  let bestScore = 0;
  ALL_FAQ.forEach((item) => {
    const hay = normalize(`${item.q} ${item.keywords.join(' ')}`);
    let score = 0;
    item.keywords.forEach((k) => {
      if (text.includes(normalize(k))) score += 3;
    });
    words.forEach((w) => {
      if (hay.includes(w)) score += 1;
    });
    if (score > bestScore) {
      bestScore = score;
      best = item;
    }
  });
  if (!best || bestScore < 2) {
    return {
      text: 'Não encontrei uma resposta pronta para isso. Você pode enviar sua dúvida pelo formulário de contato ou por e-mail — nossa equipe responde em horário comercial.',
      related: null,
    };
  }
  return { text: best.a.join(' '), related: best.q };
}
