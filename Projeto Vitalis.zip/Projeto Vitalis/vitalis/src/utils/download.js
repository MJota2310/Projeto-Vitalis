// Geração de arquivos para download (comprovantes, receitas de demonstração e
// eventos de calendário .ics).

import { formatCurrency, formatDateBR, toDateTime } from './format';

/** Avisa a interface (ToastProvider escuta este evento). */
function notify(type, title, text) {
  window.dispatchEvent(new CustomEvent('vitalis:notice', { detail: { type, title, text } }));
}

/**
 * Salva um arquivo gerado no navegador.
 * - Navegador comum: link temporário com Blob.
 * - Prévia publicada no claude.ai: usa a capacidade `downloads` do visualizador
 *   (o download direto é bloqueado nesse ambiente).
 */
export async function downloadFile(filename, content, mime = 'text/plain;charset=utf-8') {
  const runtime = typeof window !== 'undefined' ? window.claude : undefined;
  if (runtime && typeof runtime.use === 'function') {
    const downloads = await runtime.use('downloads').catch(() => null);
    if (downloads) {
      try {
        await downloads.save({ filename, data: content });
        return true;
      } catch (err) {
        if (err?.code === 'declined') return false;
        notify(
          'warning',
          'Download indisponível nesta prévia',
          'Este formato de arquivo não pode ser salvo aqui. Ele funciona na versão instalada do site.',
        );
        return false;
      }
    }
  }
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  return true;
}

function icsDate(d) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getUTCFullYear()}${pad(d.getUTCMonth() + 1)}${pad(d.getUTCDate())}T${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}00Z`;
}

/** Cria um evento de calendário (.ics) para a consulta. */
export function downloadCalendarEvent(appointment) {
  const start = toDateTime(appointment.date, appointment.time);
  const end = new Date(start.getTime() + 60 * 60 * 1000);
  const lines = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Vitalis//Agendamentos//PT-BR',
    'CALSCALE:GREGORIAN',
    'BEGIN:VEVENT',
    `UID:${appointment.id}@vitalis.demo`,
    `DTSTAMP:${icsDate(new Date())}`,
    `DTSTART:${icsDate(start)}`,
    `DTEND:${icsDate(end)}`,
    `SUMMARY:${appointment.serviceName} com ${appointment.professionalName}`,
    `DESCRIPTION:Protocolo ${appointment.protocol} — agendado pelo Vitalis.`,
    `LOCATION:${appointment.location || ''}`,
    'END:VEVENT',
    'END:VCALENDAR',
  ];
  downloadFile(`consulta-${appointment.protocol}.ics`, lines.join('\r\n'), 'text/calendar;charset=utf-8');
}

/** Documento de exemplo — o modo demonstração não emite receitas reais. */
export function downloadPrescriptionDemo(appointment, user) {
  const content = [
    '==============================================================',
    '                VITALIS — DOCUMENTO DE DEMONSTRAÇÃO',
    '==============================================================',
    '',
    'ATENÇÃO: arquivo gerado automaticamente pelo modo demonstração.',
    'Não é uma receita médica e não possui validade clínica ou legal.',
    '',
    `Paciente ........: ${user?.name || '—'}`,
    `Profissional ....: ${appointment.professionalName} (${appointment.specialty})`,
    `Serviço .........: ${appointment.serviceName}`,
    `Data da consulta : ${formatDateBR(appointment.date)} às ${appointment.time}`,
    `Protocolo .......: ${appointment.protocol}`,
    '',
    'Orientações registradas pelo profissional:',
    '  (No sistema real, este documento seria emitido e assinado',
    '   digitalmente pelo profissional responsável.)',
    '',
    `Gerado em ${new Date().toLocaleString('pt-BR')}`,
  ].join('\n');
  downloadFile(`documento-${appointment.protocol}.txt`, content);
}

/** Comprovante de pagamento em texto. */
export function downloadReceipt(appointment, payment) {
  const content = [
    'VITALIS — COMPROVANTE DE PAGAMENTO (MODO DEMONSTRAÇÃO)',
    'Nenhuma cobrança real foi realizada.',
    '',
    `Protocolo ......: ${appointment.protocol}`,
    `Consulta .......: ${appointment.serviceName} — ${appointment.professionalName}`,
    `Data/horário ...: ${formatDateBR(appointment.date)} às ${appointment.time}`,
    `Valor consulta .: ${formatCurrency(appointment.price)}`,
    `Taxa de serviço : ${formatCurrency(appointment.fee)}`,
    `Total pago .....: ${formatCurrency(payment.amount)}`,
    `Método .........: ${payment.method === 'pix' ? 'PIX' : `${payment.brand} •••• ${payment.last4}`}`,
    `Transação ......: ${payment.id}`,
    `Pago em ........: ${new Date(payment.paidAt || payment.createdAt).toLocaleString('pt-BR')}`,
  ].join('\n');
  downloadFile(`comprovante-${appointment.protocol}.txt`, content);
}
